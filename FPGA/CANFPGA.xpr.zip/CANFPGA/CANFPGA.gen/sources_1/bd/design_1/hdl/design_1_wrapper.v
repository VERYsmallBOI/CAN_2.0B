//Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
//Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
//--------------------------------------------------------------------------------
//Tool Version: Vivado v.2025.2 (win64) Build 6299465 Fri Nov 14 19:35:11 GMT 2025
//Date        : Wed Sep 16 10:32:01 2026
//Host        : CLANKER running 64-bit major release  (build 9200)
//Command     : generate_target design_1_wrapper.bd
//Design      : design_1_wrapper
//Purpose     : IP block netlist
//--------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

module design_1_wrapper
   (clk_in1_0,
    resetn_0);
  input clk_in1_0;
  input resetn_0;

  wire clk_in1_0;
  wire resetn_0;

  design_1 design_1_i
       (.clk_in1_0(clk_in1_0),
        .resetn_0(resetn_0));
endmodule
