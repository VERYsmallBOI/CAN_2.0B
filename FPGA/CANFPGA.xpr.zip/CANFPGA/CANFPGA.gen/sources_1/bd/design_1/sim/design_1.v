//Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
//Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
//--------------------------------------------------------------------------------
//Tool Version: Vivado v.2025.2 (win64) Build 6299465 Fri Nov 14 19:35:11 GMT 2025
//Date        : Wed Sep 16 10:32:01 2026
//Host        : CLANKER running 64-bit major release  (build 9200)
//Command     : generate_target design_1.bd
//Design      : design_1
//Purpose     : IP block netlist
//--------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CORE_GENERATION_INFO = "design_1,IP_Integrator,{x_ipVendor=xilinx.com,x_ipLibrary=BlockDiagram,x_ipName=design_1,x_ipVersion=1.00.a,x_ipLanguage=VERILOG,numBlks=3,numReposBlks=3,numNonXlnxBlks=0,numHierBlks=0,maxHierDepth=0,numSysgenBlks=0,numHlsBlks=0,numHdlrefBlks=1,numPkgbdBlks=0,bdsource=USER,synth_mode=Hierarchical}" *) (* HW_HANDOFF = "design_1.hwdef" *) 
module design_1
   (clk_in1_0,
    resetn_0);
  (* X_INTERFACE_INFO = "xilinx.com:signal:clock:1.0 CLK.CLK_IN1_0 CLK" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME CLK.CLK_IN1_0, CLK_DOMAIN design_1_clk_in1_0, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, INSERT_VIP 0, PHASE 0.0" *) input clk_in1_0;
  (* X_INTERFACE_INFO = "xilinx.com:signal:reset:1.0 RST.RESETN_0 RST" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME RST.RESETN_0, INSERT_VIP 0, POLARITY ACTIVE_LOW" *) input resetn_0;

  wire [3:0]FPGAPROJECT_0_D_Len_rec_0;
  wire [3:0]FPGAPROJECT_0_D_Len_rec_1;
  wire FPGAPROJECT_0_IDE_rec_0;
  wire FPGAPROJECT_0_IDE_rec_1;
  wire [8:0]FPGAPROJECT_0_REC_0;
  wire [8:0]FPGAPROJECT_0_REC_1;
  wire FPGAPROJECT_0_RTR_rec_0;
  wire FPGAPROJECT_0_RTR_rec_1;
  wire [8:0]FPGAPROJECT_0_TEC_0;
  wire [8:0]FPGAPROJECT_0_TEC_1;
  wire [28:0]FPGAPROJECT_0_TOFILTERI_0;
  wire [28:0]FPGAPROJECT_0_TOFILTERI_1;
  wire [63:0]FPGAPROJECT_0_TOFILTERd_0;
  wire [63:0]FPGAPROJECT_0_TOFILTERd_1;
  wire FPGAPROJECT_0_done_RX_0;
  wire FPGAPROJECT_0_done_RX_1;
  wire FPGAPROJECT_0_done_TX_0;
  wire FPGAPROJECT_0_done_TX_1;
  wire clk_in1_0_1;
  wire clk_wiz_0_clk_out1;
  wire resetn_0;
  wire [63:0]vio_0_probe_out0;
  wire [28:0]vio_0_probe_out1;
  wire [4:0]vio_0_probe_out10;
  wire [3:0]vio_0_probe_out11;
  wire [2:0]vio_0_probe_out12;
  wire [0:0]vio_0_probe_out13;
  wire [0:0]vio_0_probe_out14;
  wire [0:0]vio_0_probe_out15;
  wire [0:0]vio_0_probe_out16;
  wire [4:0]vio_0_probe_out2;
  wire [3:0]vio_0_probe_out3;
  wire [2:0]vio_0_probe_out4;
  wire [0:0]vio_0_probe_out5;
  wire [0:0]vio_0_probe_out6;
  wire [0:0]vio_0_probe_out7;
  wire [63:0]vio_0_probe_out8;
  wire [28:0]vio_0_probe_out9;

  assign clk_in1_0_1 = clk_in1_0;
  design_1_FPGAPROJECT_0_0 FPGAPROJECT_0
       (.BRP_0(vio_0_probe_out2),
        .BRP_1(vio_0_probe_out10),
        .CAN_CLK(clk_wiz_0_clk_out1),
        .CAN_RST(resetn_0),
        .D_Len_TX_0(vio_0_probe_out3),
        .D_Len_TX_1(vio_0_probe_out11),
        .D_Len_rec_0(FPGAPROJECT_0_D_Len_rec_0),
        .D_Len_rec_1(FPGAPROJECT_0_D_Len_rec_1),
        .IDE_TX_0(vio_0_probe_out6),
        .IDE_TX_1(vio_0_probe_out14),
        .IDE_rec_0(FPGAPROJECT_0_IDE_rec_0),
        .IDE_rec_1(FPGAPROJECT_0_IDE_rec_1),
        .ID_TX_0(vio_0_probe_out1),
        .ID_TX_1(vio_0_probe_out9),
        .Mode_0(vio_0_probe_out4),
        .Mode_1(vio_0_probe_out12),
        .REC_0(FPGAPROJECT_0_REC_0),
        .REC_1(FPGAPROJECT_0_REC_1),
        .RTR_TX_0(vio_0_probe_out7),
        .RTR_TX_1(vio_0_probe_out15),
        .RTR_rec_0(FPGAPROJECT_0_RTR_rec_0),
        .RTR_rec_1(FPGAPROJECT_0_RTR_rec_1),
        .SRST_0(vio_0_probe_out16),
        .SRST_1(vio_0_probe_out16),
        .TEC_0(FPGAPROJECT_0_TEC_0),
        .TEC_1(FPGAPROJECT_0_TEC_1),
        .TOFILTERI_0(FPGAPROJECT_0_TOFILTERI_0),
        .TOFILTERI_1(FPGAPROJECT_0_TOFILTERI_1),
        .TOFILTERd_0(FPGAPROJECT_0_TOFILTERd_0),
        .TOFILTERd_1(FPGAPROJECT_0_TOFILTERd_1),
        .TRANSMIT_0(vio_0_probe_out5),
        .TRANSMIT_1(vio_0_probe_out13),
        .data_TX_0(vio_0_probe_out0),
        .data_TX_1(vio_0_probe_out8),
        .done_RX_0(FPGAPROJECT_0_done_RX_0),
        .done_RX_1(FPGAPROJECT_0_done_RX_1),
        .done_TX_0(FPGAPROJECT_0_done_TX_0),
        .done_TX_1(FPGAPROJECT_0_done_TX_1));
  design_1_clk_wiz_0_0 clk_wiz_0
       (.clk_in1(clk_in1_0_1),
        .clk_out1(clk_wiz_0_clk_out1));
  design_1_vio_0_0 vio_0
       (.clk(clk_in1_0_1),
        .probe_in0(FPGAPROJECT_0_TOFILTERd_0),
        .probe_in1(FPGAPROJECT_0_TOFILTERI_0),
        .probe_in10(FPGAPROJECT_0_TEC_1),
        .probe_in11(FPGAPROJECT_0_REC_1),
        .probe_in12(FPGAPROJECT_0_D_Len_rec_1),
        .probe_in13(FPGAPROJECT_0_RTR_rec_1),
        .probe_in14(FPGAPROJECT_0_IDE_rec_1),
        .probe_in15(FPGAPROJECT_0_done_TX_1),
        .probe_in16(FPGAPROJECT_0_done_RX_1),
        .probe_in17(FPGAPROJECT_0_done_RX_0),
        .probe_in2(FPGAPROJECT_0_TEC_0),
        .probe_in3(FPGAPROJECT_0_REC_0),
        .probe_in4(FPGAPROJECT_0_D_Len_rec_0),
        .probe_in5(FPGAPROJECT_0_RTR_rec_0),
        .probe_in6(FPGAPROJECT_0_IDE_rec_0),
        .probe_in7(FPGAPROJECT_0_done_TX_0),
        .probe_in8(FPGAPROJECT_0_TOFILTERd_1),
        .probe_in9(FPGAPROJECT_0_TOFILTERI_1),
        .probe_out0(vio_0_probe_out0),
        .probe_out1(vio_0_probe_out1),
        .probe_out10(vio_0_probe_out10),
        .probe_out11(vio_0_probe_out11),
        .probe_out12(vio_0_probe_out12),
        .probe_out13(vio_0_probe_out13),
        .probe_out14(vio_0_probe_out14),
        .probe_out15(vio_0_probe_out15),
        .probe_out16(vio_0_probe_out16),
        .probe_out2(vio_0_probe_out2),
        .probe_out3(vio_0_probe_out3),
        .probe_out4(vio_0_probe_out4),
        .probe_out5(vio_0_probe_out5),
        .probe_out6(vio_0_probe_out6),
        .probe_out7(vio_0_probe_out7),
        .probe_out8(vio_0_probe_out8),
        .probe_out9(vio_0_probe_out9));
endmodule
