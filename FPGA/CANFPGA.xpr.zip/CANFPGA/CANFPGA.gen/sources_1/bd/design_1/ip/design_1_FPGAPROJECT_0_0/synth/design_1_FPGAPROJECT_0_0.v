// (c) Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// (c) Copyright 2022-2026 Advanced Micro Devices, Inc. All rights reserved.
// 
// This file contains confidential and proprietary information
// of AMD and is protected under U.S. and international copyright
// and other intellectual property laws.
// 
// DISCLAIMER
// This disclaimer is not a license and does not grant any
// rights to the materials distributed herewith. Except as
// otherwise provided in a valid license issued to you by
// AMD, and to the maximum extent permitted by applicable
// law: (1) THESE MATERIALS ARE MADE AVAILABLE "AS IS" AND
// WITH ALL FAULTS, AND AMD HEREBY DISCLAIMS ALL WARRANTIES
// AND CONDITIONS, EXPRESS, IMPLIED, OR STATUTORY, INCLUDING
// BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, NON-
// INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE; and
// (2) AMD shall not be liable (whether in contract or tort,
// including negligence, or under any other theory of
// liability) for any loss or damage of any kind or nature
// related to, arising under or in connection with these
// materials, including for any direct, or any indirect,
// special, incidental, or consequential loss or damage
// (including loss of data, profits, goodwill, or any type of
// loss or damage suffered as a result of any action brought
// by a third party) even if such damage or loss was
// reasonably foreseeable or AMD had been advised of the
// possibility of the same.
// 
// CRITICAL APPLICATIONS
// AMD products are not designed or intended to be fail-
// safe, or for use in any application requiring fail-safe
// performance, such as life-support or safety devices or
// systems, Class III medical devices, nuclear facilities,
// applications related to the deployment of airbags, or any
// other applications that could lead to death, personal
// injury, or severe property or environmental damage
// (individually and collectively, "Critical
// Applications"). Customer assumes the sole risk and
// liability of any use of AMD products in Critical
// Applications, subject only to applicable laws and
// regulations governing limitations on product liability.
// 
// THIS COPYRIGHT NOTICE AND DISCLAIMER MUST BE RETAINED AS
// PART OF THIS FILE AT ALL TIMES.
// 
// DO NOT MODIFY THIS FILE.


// IP VLNV: xilinx.com:module_ref:FPGAPROJECT:1.0
// IP Revision: 1

(* X_CORE_INFO = "FPGAPROJECT,Vivado 2025.2" *)
(* CHECK_LICENSE_TYPE = "design_1_FPGAPROJECT_0_0,FPGAPROJECT,{}" *)
(* CORE_GENERATION_INFO = "design_1_FPGAPROJECT_0_0,FPGAPROJECT,{x_ipProduct=Vivado 2025.2,x_ipVendor=xilinx.com,x_ipLibrary=module_ref,x_ipName=FPGAPROJECT,x_ipVersion=1.0,x_ipCoreRevision=1,x_ipLanguage=VERILOG,x_ipSimLanguage=MIXED}" *)
(* IP_DEFINITION_SOURCE = "module_ref" *)
(* DowngradeIPIdentifiedWarnings = "yes" *)
module design_1_FPGAPROJECT_0_0 (
  CAN_CLK,
  CAN_RST,
  SRST_0,
  BRP_0,
  Mode_0,
  TRANSMIT_0,
  IDE_TX_0,
  RTR_TX_0,
  D_Len_TX_0,
  ID_TX_0,
  data_TX_0,
  done_RX_0,
  done_TX_0,
  IDE_rec_0,
  RTR_rec_0,
  D_Len_rec_0,
  TOFILTERd_0,
  TOFILTERI_0,
  TEC_0,
  REC_0,
  SRST_1,
  BRP_1,
  Mode_1,
  TRANSMIT_1,
  IDE_TX_1,
  RTR_TX_1,
  D_Len_TX_1,
  ID_TX_1,
  data_TX_1,
  done_RX_1,
  done_TX_1,
  IDE_rec_1,
  RTR_rec_1,
  D_Len_rec_1,
  TOFILTERd_1,
  TOFILTERI_1,
  TEC_1,
  REC_1
);

(* X_INTERFACE_INFO = "xilinx.com:signal:clock:1.0 CAN_CLK CLK" *)
(* X_INTERFACE_MODE = "slave" *)
(* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME CAN_CLK, ASSOCIATED_RESET CAN_RST, FREQ_HZ 10000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN /clk_wiz_0_clk_out1, INSERT_VIP 0" *)
input wire CAN_CLK;
(* X_INTERFACE_INFO = "xilinx.com:signal:reset:1.0 CAN_RST RST" *)
(* X_INTERFACE_MODE = "slave" *)
(* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME CAN_RST, POLARITY ACTIVE_LOW, INSERT_VIP 0" *)
input wire CAN_RST;
input wire SRST_0;
input wire [4 : 0] BRP_0;
input wire [2 : 0] Mode_0;
input wire TRANSMIT_0;
input wire IDE_TX_0;
input wire RTR_TX_0;
input wire [3 : 0] D_Len_TX_0;
input wire [28 : 0] ID_TX_0;
input wire [63 : 0] data_TX_0;
output wire done_RX_0;
output wire done_TX_0;
output wire IDE_rec_0;
output wire RTR_rec_0;
output wire [3 : 0] D_Len_rec_0;
output wire [63 : 0] TOFILTERd_0;
output wire [28 : 0] TOFILTERI_0;
output wire [8 : 0] TEC_0;
output wire [8 : 0] REC_0;
input wire SRST_1;
input wire [4 : 0] BRP_1;
input wire [2 : 0] Mode_1;
input wire TRANSMIT_1;
input wire IDE_TX_1;
input wire RTR_TX_1;
input wire [3 : 0] D_Len_TX_1;
input wire [28 : 0] ID_TX_1;
input wire [63 : 0] data_TX_1;
output wire done_RX_1;
output wire done_TX_1;
output wire IDE_rec_1;
output wire RTR_rec_1;
output wire [3 : 0] D_Len_rec_1;
output wire [63 : 0] TOFILTERd_1;
output wire [28 : 0] TOFILTERI_1;
output wire [8 : 0] TEC_1;
output wire [8 : 0] REC_1;

  FPGAPROJECT inst (
    .CAN_CLK(CAN_CLK),
    .CAN_RST(CAN_RST),
    .SRST_0(SRST_0),
    .BRP_0(BRP_0),
    .Mode_0(Mode_0),
    .TRANSMIT_0(TRANSMIT_0),
    .IDE_TX_0(IDE_TX_0),
    .RTR_TX_0(RTR_TX_0),
    .D_Len_TX_0(D_Len_TX_0),
    .ID_TX_0(ID_TX_0),
    .data_TX_0(data_TX_0),
    .done_RX_0(done_RX_0),
    .done_TX_0(done_TX_0),
    .IDE_rec_0(IDE_rec_0),
    .RTR_rec_0(RTR_rec_0),
    .D_Len_rec_0(D_Len_rec_0),
    .TOFILTERd_0(TOFILTERd_0),
    .TOFILTERI_0(TOFILTERI_0),
    .TEC_0(TEC_0),
    .REC_0(REC_0),
    .SRST_1(SRST_1),
    .BRP_1(BRP_1),
    .Mode_1(Mode_1),
    .TRANSMIT_1(TRANSMIT_1),
    .IDE_TX_1(IDE_TX_1),
    .RTR_TX_1(RTR_TX_1),
    .D_Len_TX_1(D_Len_TX_1),
    .ID_TX_1(ID_TX_1),
    .data_TX_1(data_TX_1),
    .done_RX_1(done_RX_1),
    .done_TX_1(done_TX_1),
    .IDE_rec_1(IDE_rec_1),
    .RTR_rec_1(RTR_rec_1),
    .D_Len_rec_1(D_Len_rec_1),
    .TOFILTERd_1(TOFILTERd_1),
    .TOFILTERI_1(TOFILTERI_1),
    .TEC_1(TEC_1),
    .REC_1(REC_1)
  );
endmodule
