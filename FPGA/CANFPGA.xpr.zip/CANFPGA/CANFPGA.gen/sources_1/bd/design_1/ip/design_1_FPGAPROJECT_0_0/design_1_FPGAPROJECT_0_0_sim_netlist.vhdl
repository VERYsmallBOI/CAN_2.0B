-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2025.2 (win64) Build 6299465 Fri Nov 14 19:35:11 GMT 2025
-- Date        : Tue Sep 15 17:17:25 2026
-- Host        : CLANKER running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim
--               c:/Users/Tamil/Documents/Mirafra/CAN_FPGA/CANFPGA/CANFPGA.gen/sources_1/bd/design_1/ip/design_1_FPGAPROJECT_0_0/design_1_FPGAPROJECT_0_0_sim_netlist.vhdl
-- Design      : design_1_FPGAPROJECT_0_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7z007sclg400-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1_FPGAPROJECT_0_0_CRC is
  port (
    \TXSTATES_reg[3]\ : out STD_LOGIC;
    \Cnt_reg[0]\ : out STD_LOGIC;
    \TXSTATES_reg[3]_0\ : out STD_LOGIC;
    SRST_0_0 : out STD_LOGIC;
    \Cnt_reg[2]\ : out STD_LOGIC;
    \Cnt_reg[3]\ : out STD_LOGIC;
    \TXSTATES_reg[0]\ : out STD_LOGIC;
    \TXSTATES_reg[2]\ : out STD_LOGIC;
    Q : in STD_LOGIC_VECTOR ( 3 downto 0 );
    \serial[0]_i_12_0\ : in STD_LOGIC_VECTOR ( 5 downto 0 );
    \CRC_RG_reg[14]_0\ : in STD_LOGIC;
    SRST_0 : in STD_LOGIC;
    IDE_TX_0 : in STD_LOGIC;
    RTR_TX_0 : in STD_LOGIC;
    ID_TX_0 : in STD_LOGIC_VECTOR ( 28 downto 0 );
    D_Len_TX_0 : in STD_LOGIC_VECTOR ( 3 downto 0 );
    data_TX_0 : in STD_LOGIC_VECTOR ( 63 downto 0 );
    E : in STD_LOGIC_VECTOR ( 0 to 0 );
    clk : in STD_LOGIC;
    \CRC_RG_reg[0]_0\ : in STD_LOGIC
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of design_1_FPGAPROJECT_0_0_CRC : entity is "CRC";
end design_1_FPGAPROJECT_0_0_CRC;

architecture STRUCTURE of design_1_FPGAPROJECT_0_0_CRC is
  signal \CRC_RG[14]_i_7_n_0\ : STD_LOGIC;
  signal \CRC_RG_reg_n_0_[0]\ : STD_LOGIC;
  signal \CRC_RG_reg_n_0_[10]\ : STD_LOGIC;
  signal \CRC_RG_reg_n_0_[11]\ : STD_LOGIC;
  signal \CRC_RG_reg_n_0_[12]\ : STD_LOGIC;
  signal \CRC_RG_reg_n_0_[13]\ : STD_LOGIC;
  signal \CRC_RG_reg_n_0_[1]\ : STD_LOGIC;
  signal \CRC_RG_reg_n_0_[2]\ : STD_LOGIC;
  signal \CRC_RG_reg_n_0_[3]\ : STD_LOGIC;
  signal \CRC_RG_reg_n_0_[4]\ : STD_LOGIC;
  signal \CRC_RG_reg_n_0_[5]\ : STD_LOGIC;
  signal \CRC_RG_reg_n_0_[6]\ : STD_LOGIC;
  signal \CRC_RG_reg_n_0_[7]\ : STD_LOGIC;
  signal \CRC_RG_reg_n_0_[8]\ : STD_LOGIC;
  signal \CRC_RG_reg_n_0_[9]\ : STD_LOGIC;
  signal \^cnt_reg[0]\ : STD_LOGIC;
  signal \^cnt_reg[2]\ : STD_LOGIC;
  signal \^cnt_reg[3]\ : STD_LOGIC;
  signal \^srst_0_0\ : STD_LOGIC;
  signal \^txstates_reg[0]\ : STD_LOGIC;
  signal \^txstates_reg[3]\ : STD_LOGIC;
  signal out_CRC : STD_LOGIC_VECTOR ( 14 to 14 );
  signal \p_1_in__0\ : STD_LOGIC_VECTOR ( 14 downto 0 );
  signal \serial[0]_i_10_n_0\ : STD_LOGIC;
  signal \serial[0]_i_11_n_0\ : STD_LOGIC;
  signal \serial[0]_i_12_n_0\ : STD_LOGIC;
  signal \serial[0]_i_13_n_0\ : STD_LOGIC;
  signal \serial[0]_i_14_n_0\ : STD_LOGIC;
  signal \serial[0]_i_15_n_0\ : STD_LOGIC;
  signal \serial[0]_i_16_n_0\ : STD_LOGIC;
  signal \serial[0]_i_17_n_0\ : STD_LOGIC;
  signal \serial[0]_i_18_n_0\ : STD_LOGIC;
  signal \serial[0]_i_19_n_0\ : STD_LOGIC;
  signal \serial[0]_i_20_n_0\ : STD_LOGIC;
  signal \serial[0]_i_21_n_0\ : STD_LOGIC;
  signal \serial[0]_i_22_n_0\ : STD_LOGIC;
  signal \serial[0]_i_23_n_0\ : STD_LOGIC;
  signal \serial[0]_i_24_n_0\ : STD_LOGIC;
  signal \serial[0]_i_25_n_0\ : STD_LOGIC;
  signal \serial[0]_i_26_n_0\ : STD_LOGIC;
  signal \serial[0]_i_27_n_0\ : STD_LOGIC;
  signal \serial[0]_i_28_n_0\ : STD_LOGIC;
  signal \serial[0]_i_29_n_0\ : STD_LOGIC;
  signal \serial[0]_i_30_n_0\ : STD_LOGIC;
  signal \serial[0]_i_31_n_0\ : STD_LOGIC;
  signal \serial[0]_i_32_n_0\ : STD_LOGIC;
  signal \serial[0]_i_33_n_0\ : STD_LOGIC;
  signal \serial[0]_i_34_n_0\ : STD_LOGIC;
  signal \serial[0]_i_35_n_0\ : STD_LOGIC;
  signal \serial[0]_i_36_n_0\ : STD_LOGIC;
  signal \serial[0]_i_37_n_0\ : STD_LOGIC;
  signal \serial[0]_i_38_n_0\ : STD_LOGIC;
  signal \serial[0]_i_39_n_0\ : STD_LOGIC;
  signal \serial[0]_i_4_n_0\ : STD_LOGIC;
  signal \serial[0]_i_50_n_0\ : STD_LOGIC;
  signal \serial[0]_i_51_n_0\ : STD_LOGIC;
  signal \serial[0]_i_52_n_0\ : STD_LOGIC;
  signal \serial[0]_i_53_n_0\ : STD_LOGIC;
  signal \serial[0]_i_54_n_0\ : STD_LOGIC;
  signal \serial[0]_i_55_n_0\ : STD_LOGIC;
  signal \serial[0]_i_56_n_0\ : STD_LOGIC;
  signal \serial[0]_i_57_n_0\ : STD_LOGIC;
  signal \serial[0]_i_58_n_0\ : STD_LOGIC;
  signal \serial[0]_i_59_n_0\ : STD_LOGIC;
  signal \serial[0]_i_5_n_0\ : STD_LOGIC;
  signal \serial[0]_i_60_n_0\ : STD_LOGIC;
  signal \serial[0]_i_61_n_0\ : STD_LOGIC;
  signal \serial[0]_i_62_n_0\ : STD_LOGIC;
  signal \serial[0]_i_63_n_0\ : STD_LOGIC;
  signal \serial[0]_i_64_n_0\ : STD_LOGIC;
  signal \serial[0]_i_65_n_0\ : STD_LOGIC;
  signal \serial[0]_i_66_n_0\ : STD_LOGIC;
  signal \serial[0]_i_67_n_0\ : STD_LOGIC;
  signal \serial[0]_i_68_n_0\ : STD_LOGIC;
  signal \serial[0]_i_69_n_0\ : STD_LOGIC;
  signal \serial[0]_i_6_n_0\ : STD_LOGIC;
  signal \serial[0]_i_7_n_0\ : STD_LOGIC;
  signal \serial[0]_i_8_n_0\ : STD_LOGIC;
  signal \serial[0]_i_9_n_0\ : STD_LOGIC;
  signal \serial_reg[0]_i_40_n_0\ : STD_LOGIC;
  signal \serial_reg[0]_i_41_n_0\ : STD_LOGIC;
  signal \serial_reg[0]_i_42_n_0\ : STD_LOGIC;
  signal \serial_reg[0]_i_43_n_0\ : STD_LOGIC;
  signal \serial_reg[0]_i_44_n_0\ : STD_LOGIC;
  signal \serial_reg[0]_i_45_n_0\ : STD_LOGIC;
  signal \serial_reg[0]_i_46_n_0\ : STD_LOGIC;
  signal \serial_reg[0]_i_47_n_0\ : STD_LOGIC;
  signal \serial_reg[0]_i_48_n_0\ : STD_LOGIC;
  signal \serial_reg[0]_i_49_n_0\ : STD_LOGIC;
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \CRC_RG[10]_i_1\ : label is "soft_lutpair210";
  attribute SOFT_HLUTNM of \CRC_RG[14]_i_2\ : label is "soft_lutpair210";
  attribute SOFT_HLUTNM of \CRC_RG[14]_i_3\ : label is "soft_lutpair204";
  attribute SOFT_HLUTNM of \CRC_RG[14]_i_4\ : label is "soft_lutpair203";
  attribute SOFT_HLUTNM of \CRC_RG[14]_i_6\ : label is "soft_lutpair203";
  attribute SOFT_HLUTNM of \CRC_RG[3]_i_1\ : label is "soft_lutpair208";
  attribute SOFT_HLUTNM of \CRC_RG[4]_i_1\ : label is "soft_lutpair208";
  attribute SOFT_HLUTNM of \CRC_RG[7]_i_1\ : label is "soft_lutpair209";
  attribute SOFT_HLUTNM of \CRC_RG[8]_i_1\ : label is "soft_lutpair209";
  attribute SOFT_HLUTNM of \Cnt[2]_i_6__0\ : label is "soft_lutpair207";
  attribute SOFT_HLUTNM of \Cnt[3]_i_6\ : label is "soft_lutpair206";
  attribute SOFT_HLUTNM of done_i_12 : label is "soft_lutpair204";
  attribute SOFT_HLUTNM of \serial[0]_i_15\ : label is "soft_lutpair205";
  attribute SOFT_HLUTNM of \serial[0]_i_17\ : label is "soft_lutpair211";
  attribute SOFT_HLUTNM of \serial[0]_i_24\ : label is "soft_lutpair207";
  attribute SOFT_HLUTNM of \serial[0]_i_26\ : label is "soft_lutpair211";
  attribute SOFT_HLUTNM of \serial[0]_i_33\ : label is "soft_lutpair206";
  attribute SOFT_HLUTNM of \serial[0]_i_8\ : label is "soft_lutpair205";
begin
  \Cnt_reg[0]\ <= \^cnt_reg[0]\;
  \Cnt_reg[2]\ <= \^cnt_reg[2]\;
  \Cnt_reg[3]\ <= \^cnt_reg[3]\;
  SRST_0_0 <= \^srst_0_0\;
  \TXSTATES_reg[0]\ <= \^txstates_reg[0]\;
  \TXSTATES_reg[3]\ <= \^txstates_reg[3]\;
\CRC_RG[0]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000FF9E0000"
    )
        port map (
      I0 => Q(1),
      I1 => Q(0),
      I2 => Q(3),
      I3 => Q(2),
      I4 => SRST_0,
      I5 => \CRC_RG[14]_i_7_n_0\,
      O => \p_1_in__0\(0)
    );
\CRC_RG[10]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"82"
    )
        port map (
      I0 => \^srst_0_0\,
      I1 => \CRC_RG[14]_i_7_n_0\,
      I2 => \CRC_RG_reg_n_0_[9]\,
      O => \p_1_in__0\(10)
    );
\CRC_RG[11]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAA82A800000000"
    )
        port map (
      I0 => \CRC_RG_reg_n_0_[10]\,
      I1 => Q(1),
      I2 => Q(0),
      I3 => Q(3),
      I4 => Q(2),
      I5 => SRST_0,
      O => \p_1_in__0\(11)
    );
\CRC_RG[12]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAA82A800000000"
    )
        port map (
      I0 => \CRC_RG_reg_n_0_[11]\,
      I1 => Q(1),
      I2 => Q(0),
      I3 => Q(3),
      I4 => Q(2),
      I5 => SRST_0,
      O => \p_1_in__0\(12)
    );
\CRC_RG[13]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAA82A800000000"
    )
        port map (
      I0 => \CRC_RG_reg_n_0_[12]\,
      I1 => Q(1),
      I2 => Q(0),
      I3 => Q(3),
      I4 => Q(2),
      I5 => SRST_0,
      O => \p_1_in__0\(13)
    );
\CRC_RG[14]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"82"
    )
        port map (
      I0 => \^srst_0_0\,
      I1 => \CRC_RG[14]_i_7_n_0\,
      I2 => \CRC_RG_reg_n_0_[13]\,
      O => \p_1_in__0\(14)
    );
\CRC_RG[14]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"AA8A8AA8"
    )
        port map (
      I0 => SRST_0,
      I1 => Q(2),
      I2 => Q(3),
      I3 => Q(0),
      I4 => Q(1),
      O => \^srst_0_0\
    );
\CRC_RG[14]_i_4\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"15140000"
    )
        port map (
      I0 => Q(3),
      I1 => Q(1),
      I2 => Q(2),
      I3 => Q(0),
      I4 => \CRC_RG_reg[14]_0\,
      O => \TXSTATES_reg[3]_0\
    );
\CRC_RG[14]_i_6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => Q(2),
      I1 => Q(1),
      O => \TXSTATES_reg[2]\
    );
\CRC_RG[14]_i_7\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => out_CRC(14),
      I1 => \^txstates_reg[3]\,
      O => \CRC_RG[14]_i_7_n_0\
    );
\CRC_RG[1]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAA82A800000000"
    )
        port map (
      I0 => \CRC_RG_reg_n_0_[0]\,
      I1 => Q(1),
      I2 => Q(0),
      I3 => Q(3),
      I4 => Q(2),
      I5 => SRST_0,
      O => \p_1_in__0\(1)
    );
\CRC_RG[2]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAA82A800000000"
    )
        port map (
      I0 => \CRC_RG_reg_n_0_[1]\,
      I1 => Q(1),
      I2 => Q(0),
      I3 => Q(3),
      I4 => Q(2),
      I5 => SRST_0,
      O => \p_1_in__0\(2)
    );
\CRC_RG[3]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"82"
    )
        port map (
      I0 => \^srst_0_0\,
      I1 => \CRC_RG[14]_i_7_n_0\,
      I2 => \CRC_RG_reg_n_0_[2]\,
      O => \p_1_in__0\(3)
    );
\CRC_RG[4]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"82"
    )
        port map (
      I0 => \^srst_0_0\,
      I1 => \CRC_RG[14]_i_7_n_0\,
      I2 => \CRC_RG_reg_n_0_[3]\,
      O => \p_1_in__0\(4)
    );
\CRC_RG[5]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAA82A800000000"
    )
        port map (
      I0 => \CRC_RG_reg_n_0_[4]\,
      I1 => Q(1),
      I2 => Q(0),
      I3 => Q(3),
      I4 => Q(2),
      I5 => SRST_0,
      O => \p_1_in__0\(5)
    );
\CRC_RG[6]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAA82A800000000"
    )
        port map (
      I0 => \CRC_RG_reg_n_0_[5]\,
      I1 => Q(1),
      I2 => Q(0),
      I3 => Q(3),
      I4 => Q(2),
      I5 => SRST_0,
      O => \p_1_in__0\(6)
    );
\CRC_RG[7]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"82"
    )
        port map (
      I0 => \^srst_0_0\,
      I1 => \CRC_RG[14]_i_7_n_0\,
      I2 => \CRC_RG_reg_n_0_[6]\,
      O => \p_1_in__0\(7)
    );
\CRC_RG[8]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"82"
    )
        port map (
      I0 => \^srst_0_0\,
      I1 => \CRC_RG[14]_i_7_n_0\,
      I2 => \CRC_RG_reg_n_0_[7]\,
      O => \p_1_in__0\(8)
    );
\CRC_RG[9]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAA82A800000000"
    )
        port map (
      I0 => \CRC_RG_reg_n_0_[8]\,
      I1 => Q(1),
      I2 => Q(0),
      I3 => Q(3),
      I4 => Q(2),
      I5 => SRST_0,
      O => \p_1_in__0\(9)
    );
\CRC_RG_reg[0]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => E(0),
      CLR => \CRC_RG_reg[0]_0\,
      D => \p_1_in__0\(0),
      Q => \CRC_RG_reg_n_0_[0]\
    );
\CRC_RG_reg[10]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => E(0),
      CLR => \CRC_RG_reg[0]_0\,
      D => \p_1_in__0\(10),
      Q => \CRC_RG_reg_n_0_[10]\
    );
\CRC_RG_reg[11]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => E(0),
      CLR => \CRC_RG_reg[0]_0\,
      D => \p_1_in__0\(11),
      Q => \CRC_RG_reg_n_0_[11]\
    );
\CRC_RG_reg[12]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => E(0),
      CLR => \CRC_RG_reg[0]_0\,
      D => \p_1_in__0\(12),
      Q => \CRC_RG_reg_n_0_[12]\
    );
\CRC_RG_reg[13]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => E(0),
      CLR => \CRC_RG_reg[0]_0\,
      D => \p_1_in__0\(13),
      Q => \CRC_RG_reg_n_0_[13]\
    );
\CRC_RG_reg[14]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => E(0),
      CLR => \CRC_RG_reg[0]_0\,
      D => \p_1_in__0\(14),
      Q => out_CRC(14)
    );
\CRC_RG_reg[1]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => E(0),
      CLR => \CRC_RG_reg[0]_0\,
      D => \p_1_in__0\(1),
      Q => \CRC_RG_reg_n_0_[1]\
    );
\CRC_RG_reg[2]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => E(0),
      CLR => \CRC_RG_reg[0]_0\,
      D => \p_1_in__0\(2),
      Q => \CRC_RG_reg_n_0_[2]\
    );
\CRC_RG_reg[3]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => E(0),
      CLR => \CRC_RG_reg[0]_0\,
      D => \p_1_in__0\(3),
      Q => \CRC_RG_reg_n_0_[3]\
    );
\CRC_RG_reg[4]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => E(0),
      CLR => \CRC_RG_reg[0]_0\,
      D => \p_1_in__0\(4),
      Q => \CRC_RG_reg_n_0_[4]\
    );
\CRC_RG_reg[5]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => E(0),
      CLR => \CRC_RG_reg[0]_0\,
      D => \p_1_in__0\(5),
      Q => \CRC_RG_reg_n_0_[5]\
    );
\CRC_RG_reg[6]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => E(0),
      CLR => \CRC_RG_reg[0]_0\,
      D => \p_1_in__0\(6),
      Q => \CRC_RG_reg_n_0_[6]\
    );
\CRC_RG_reg[7]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => E(0),
      CLR => \CRC_RG_reg[0]_0\,
      D => \p_1_in__0\(7),
      Q => \CRC_RG_reg_n_0_[7]\
    );
\CRC_RG_reg[8]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => E(0),
      CLR => \CRC_RG_reg[0]_0\,
      D => \p_1_in__0\(8),
      Q => \CRC_RG_reg_n_0_[8]\
    );
\CRC_RG_reg[9]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => E(0),
      CLR => \CRC_RG_reg[0]_0\,
      D => \p_1_in__0\(9),
      Q => \CRC_RG_reg_n_0_[9]\
    );
\Cnt[2]_i_6__0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E1"
    )
        port map (
      I0 => \serial[0]_i_12_0\(0),
      I1 => \serial[0]_i_12_0\(1),
      I2 => \serial[0]_i_12_0\(2),
      O => \^cnt_reg[0]\
    );
\Cnt[3]_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"AAA9"
    )
        port map (
      I0 => \serial[0]_i_12_0\(3),
      I1 => \serial[0]_i_12_0\(2),
      I2 => \serial[0]_i_12_0\(0),
      I3 => \serial[0]_i_12_0\(1),
      O => \^cnt_reg[3]\
    );
done_i_12: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => Q(0),
      I1 => Q(1),
      O => \^txstates_reg[0]\
    );
done_i_13: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000001"
    )
        port map (
      I0 => \serial[0]_i_12_0\(2),
      I1 => \serial[0]_i_12_0\(0),
      I2 => \serial[0]_i_12_0\(1),
      I3 => \serial[0]_i_12_0\(4),
      I4 => \serial[0]_i_12_0\(3),
      I5 => \serial[0]_i_12_0\(5),
      O => \^cnt_reg[2]\
    );
\serial[0]_i_10\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8888888F8F888888"
    )
        port map (
      I0 => \^cnt_reg[2]\,
      I1 => RTR_TX_0,
      I2 => \serial[0]_i_26_n_0\,
      I3 => \serial[0]_i_12_0\(0),
      I4 => \serial[0]_i_12_0\(1),
      I5 => \serial[0]_i_12_0\(2),
      O => \serial[0]_i_10_n_0\
    );
\serial[0]_i_11\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \serial[0]_i_27_n_0\,
      I1 => \serial[0]_i_28_n_0\,
      I2 => \^cnt_reg[3]\,
      I3 => \serial[0]_i_29_n_0\,
      I4 => \^cnt_reg[0]\,
      I5 => \serial[0]_i_30_n_0\,
      O => \serial[0]_i_11_n_0\
    );
\serial[0]_i_12\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"55555555555555D5"
    )
        port map (
      I0 => \serial[0]_i_13_n_0\,
      I1 => \serial[0]_i_12_0\(1),
      I2 => \serial[0]_i_12_0\(0),
      I3 => IDE_TX_0,
      I4 => \serial[0]_i_12_0\(2),
      I5 => \serial[0]_i_26_n_0\,
      O => \serial[0]_i_12_n_0\
    );
\serial[0]_i_13\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000570000FFFF"
    )
        port map (
      I0 => \serial[0]_i_12_0\(2),
      I1 => \serial[0]_i_12_0\(1),
      I2 => \serial[0]_i_12_0\(0),
      I3 => \serial[0]_i_12_0\(3),
      I4 => \serial[0]_i_12_0\(5),
      I5 => \serial[0]_i_12_0\(4),
      O => \serial[0]_i_13_n_0\
    );
\serial[0]_i_14\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \serial[0]_i_31_n_0\,
      I1 => \serial[0]_i_32_n_0\,
      I2 => \serial[0]_i_33_n_0\,
      I3 => \serial[0]_i_34_n_0\,
      I4 => \serial[0]_i_35_n_0\,
      I5 => ID_TX_0(28),
      O => \serial[0]_i_14_n_0\
    );
\serial[0]_i_15\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"AAAAA999"
    )
        port map (
      I0 => \serial[0]_i_12_0\(4),
      I1 => \serial[0]_i_12_0\(2),
      I2 => \serial[0]_i_12_0\(1),
      I3 => \serial[0]_i_12_0\(0),
      I4 => \serial[0]_i_12_0\(3),
      O => \serial[0]_i_15_n_0\
    );
\serial[0]_i_16\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \serial[0]_i_36_n_0\,
      I1 => \serial[0]_i_37_n_0\,
      I2 => \serial[0]_i_33_n_0\,
      I3 => \serial[0]_i_38_n_0\,
      I4 => \serial[0]_i_35_n_0\,
      I5 => \serial[0]_i_39_n_0\,
      O => \serial[0]_i_16_n_0\
    );
\serial[0]_i_17\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"01"
    )
        port map (
      I0 => \serial[0]_i_12_0\(5),
      I1 => \serial[0]_i_12_0\(3),
      I2 => \serial[0]_i_12_0\(4),
      O => \serial[0]_i_17_n_0\
    );
\serial[0]_i_18\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => D_Len_TX_0(3),
      I1 => D_Len_TX_0(2),
      I2 => \serial[0]_i_12_0\(1),
      I3 => D_Len_TX_0(1),
      I4 => \serial[0]_i_12_0\(0),
      I5 => D_Len_TX_0(0),
      O => \serial[0]_i_18_n_0\
    );
\serial[0]_i_19\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \serial_reg[0]_i_40_n_0\,
      I1 => \serial_reg[0]_i_41_n_0\,
      I2 => \serial[0]_i_12_0\(4),
      I3 => \serial_reg[0]_i_42_n_0\,
      I4 => \serial[0]_i_12_0\(3),
      I5 => \serial_reg[0]_i_43_n_0\,
      O => \serial[0]_i_19_n_0\
    );
\serial[0]_i_20\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \serial_reg[0]_i_44_n_0\,
      I1 => \serial_reg[0]_i_45_n_0\,
      I2 => \serial[0]_i_12_0\(4),
      I3 => \serial_reg[0]_i_46_n_0\,
      I4 => \serial[0]_i_12_0\(3),
      I5 => \serial_reg[0]_i_47_n_0\,
      O => \serial[0]_i_20_n_0\
    );
\serial[0]_i_21\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFF8A80FFFFFFFF"
    )
        port map (
      I0 => Q(0),
      I1 => \serial_reg[0]_i_48_n_0\,
      I2 => \serial[0]_i_12_0\(3),
      I3 => \serial_reg[0]_i_49_n_0\,
      I4 => Q(1),
      I5 => Q(2),
      O => \serial[0]_i_21_n_0\
    );
\serial[0]_i_22\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FCAF0CAFFCA00CA0"
    )
        port map (
      I0 => ID_TX_0(24),
      I1 => ID_TX_0(25),
      I2 => \serial[0]_i_12_0\(0),
      I3 => \serial[0]_i_12_0\(1),
      I4 => ID_TX_0(26),
      I5 => ID_TX_0(27),
      O => \serial[0]_i_22_n_0\
    );
\serial[0]_i_23\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FCAF0CAFFCA00CA0"
    )
        port map (
      I0 => ID_TX_0(16),
      I1 => ID_TX_0(17),
      I2 => \serial[0]_i_12_0\(0),
      I3 => \serial[0]_i_12_0\(1),
      I4 => ID_TX_0(18),
      I5 => ID_TX_0(19),
      O => \serial[0]_i_23_n_0\
    );
\serial[0]_i_24\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"56"
    )
        port map (
      I0 => \serial[0]_i_12_0\(2),
      I1 => \serial[0]_i_12_0\(1),
      I2 => \serial[0]_i_12_0\(0),
      O => \serial[0]_i_24_n_0\
    );
\serial[0]_i_25\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FCAF0CAFFCA00CA0"
    )
        port map (
      I0 => ID_TX_0(20),
      I1 => ID_TX_0(21),
      I2 => \serial[0]_i_12_0\(0),
      I3 => \serial[0]_i_12_0\(1),
      I4 => ID_TX_0(22),
      I5 => ID_TX_0(23),
      O => \serial[0]_i_25_n_0\
    );
\serial[0]_i_26\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"FB"
    )
        port map (
      I0 => \serial[0]_i_12_0\(3),
      I1 => \serial[0]_i_12_0\(4),
      I2 => \serial[0]_i_12_0\(5),
      O => \serial[0]_i_26_n_0\
    );
\serial[0]_i_27\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FCAF0CAFFCA00CA0"
    )
        port map (
      I0 => ID_TX_0(12),
      I1 => ID_TX_0(13),
      I2 => \serial[0]_i_12_0\(0),
      I3 => \serial[0]_i_12_0\(1),
      I4 => ID_TX_0(14),
      I5 => ID_TX_0(15),
      O => \serial[0]_i_27_n_0\
    );
\serial[0]_i_28\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FCAF0CAFFCA00CA0"
    )
        port map (
      I0 => ID_TX_0(8),
      I1 => ID_TX_0(9),
      I2 => \serial[0]_i_12_0\(0),
      I3 => \serial[0]_i_12_0\(1),
      I4 => ID_TX_0(10),
      I5 => ID_TX_0(11),
      O => \serial[0]_i_28_n_0\
    );
\serial[0]_i_29\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FCAF0CAFFCA00CA0"
    )
        port map (
      I0 => ID_TX_0(4),
      I1 => ID_TX_0(5),
      I2 => \serial[0]_i_12_0\(0),
      I3 => \serial[0]_i_12_0\(1),
      I4 => ID_TX_0(6),
      I5 => ID_TX_0(7),
      O => \serial[0]_i_29_n_0\
    );
\serial[0]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0010111155555555"
    )
        port map (
      I0 => Q(3),
      I1 => Q(2),
      I2 => \serial[0]_i_4_n_0\,
      I3 => \serial[0]_i_5_n_0\,
      I4 => \serial[0]_i_6_n_0\,
      I5 => \serial[0]_i_7_n_0\,
      O => \^txstates_reg[3]\
    );
\serial[0]_i_30\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FCAF0CAFFCA00CA0"
    )
        port map (
      I0 => ID_TX_0(0),
      I1 => ID_TX_0(1),
      I2 => \serial[0]_i_12_0\(0),
      I3 => \serial[0]_i_12_0\(1),
      I4 => ID_TX_0(2),
      I5 => ID_TX_0(3),
      O => \serial[0]_i_30_n_0\
    );
\serial[0]_i_31\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FCAF0CAFFCA00CA0"
    )
        port map (
      I0 => ID_TX_0(18),
      I1 => ID_TX_0(19),
      I2 => \serial[0]_i_12_0\(0),
      I3 => \serial[0]_i_12_0\(1),
      I4 => ID_TX_0(16),
      I5 => ID_TX_0(17),
      O => \serial[0]_i_31_n_0\
    );
\serial[0]_i_32\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FCAF0CAFFCA00CA0"
    )
        port map (
      I0 => ID_TX_0(22),
      I1 => ID_TX_0(23),
      I2 => \serial[0]_i_12_0\(0),
      I3 => \serial[0]_i_12_0\(1),
      I4 => ID_TX_0(20),
      I5 => ID_TX_0(21),
      O => \serial[0]_i_32_n_0\
    );
\serial[0]_i_33\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"556A"
    )
        port map (
      I0 => \serial[0]_i_12_0\(3),
      I1 => \serial[0]_i_12_0\(0),
      I2 => \serial[0]_i_12_0\(1),
      I3 => \serial[0]_i_12_0\(2),
      O => \serial[0]_i_33_n_0\
    );
\serial[0]_i_34\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FCAF0CAFFCA00CA0"
    )
        port map (
      I0 => ID_TX_0(26),
      I1 => ID_TX_0(27),
      I2 => \serial[0]_i_12_0\(0),
      I3 => \serial[0]_i_12_0\(1),
      I4 => ID_TX_0(24),
      I5 => ID_TX_0(25),
      O => \serial[0]_i_34_n_0\
    );
\serial[0]_i_35\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"6A"
    )
        port map (
      I0 => \serial[0]_i_12_0\(2),
      I1 => \serial[0]_i_12_0\(1),
      I2 => \serial[0]_i_12_0\(0),
      O => \serial[0]_i_35_n_0\
    );
\serial[0]_i_36\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FCAF0CAFFCA00CA0"
    )
        port map (
      I0 => ID_TX_0(2),
      I1 => ID_TX_0(3),
      I2 => \serial[0]_i_12_0\(0),
      I3 => \serial[0]_i_12_0\(1),
      I4 => ID_TX_0(0),
      I5 => ID_TX_0(1),
      O => \serial[0]_i_36_n_0\
    );
\serial[0]_i_37\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FCAF0CAFFCA00CA0"
    )
        port map (
      I0 => ID_TX_0(6),
      I1 => ID_TX_0(7),
      I2 => \serial[0]_i_12_0\(0),
      I3 => \serial[0]_i_12_0\(1),
      I4 => ID_TX_0(4),
      I5 => ID_TX_0(5),
      O => \serial[0]_i_37_n_0\
    );
\serial[0]_i_38\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FCAF0CAFFCA00CA0"
    )
        port map (
      I0 => ID_TX_0(10),
      I1 => ID_TX_0(11),
      I2 => \serial[0]_i_12_0\(0),
      I3 => \serial[0]_i_12_0\(1),
      I4 => ID_TX_0(8),
      I5 => ID_TX_0(9),
      O => \serial[0]_i_38_n_0\
    );
\serial[0]_i_39\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FCAF0CAFFCA00CA0"
    )
        port map (
      I0 => ID_TX_0(14),
      I1 => ID_TX_0(15),
      I2 => \serial[0]_i_12_0\(0),
      I3 => \serial[0]_i_12_0\(1),
      I4 => ID_TX_0(12),
      I5 => ID_TX_0(13),
      O => \serial[0]_i_39_n_0\
    );
\serial[0]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFF002300EF"
    )
        port map (
      I0 => \^cnt_reg[2]\,
      I1 => \serial[0]_i_8_n_0\,
      I2 => \serial[0]_i_9_n_0\,
      I3 => \serial[0]_i_10_n_0\,
      I4 => \serial[0]_i_11_n_0\,
      I5 => \serial[0]_i_12_n_0\,
      O => \serial[0]_i_4_n_0\
    );
\serial[0]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"DFDDDFDFDFDDDDDD"
    )
        port map (
      I0 => Q(1),
      I1 => Q(0),
      I2 => \serial[0]_i_13_n_0\,
      I3 => \serial[0]_i_14_n_0\,
      I4 => \serial[0]_i_15_n_0\,
      I5 => \serial[0]_i_16_n_0\,
      O => \serial[0]_i_5_n_0\
    );
\serial[0]_i_50\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => data_TX_0(59),
      I1 => data_TX_0(58),
      I2 => \serial[0]_i_12_0\(1),
      I3 => data_TX_0(57),
      I4 => \serial[0]_i_12_0\(0),
      I5 => data_TX_0(56),
      O => \serial[0]_i_50_n_0\
    );
\serial[0]_i_51\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => data_TX_0(63),
      I1 => data_TX_0(62),
      I2 => \serial[0]_i_12_0\(1),
      I3 => data_TX_0(61),
      I4 => \serial[0]_i_12_0\(0),
      I5 => data_TX_0(60),
      O => \serial[0]_i_51_n_0\
    );
\serial[0]_i_52\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => data_TX_0(51),
      I1 => data_TX_0(50),
      I2 => \serial[0]_i_12_0\(1),
      I3 => data_TX_0(49),
      I4 => \serial[0]_i_12_0\(0),
      I5 => data_TX_0(48),
      O => \serial[0]_i_52_n_0\
    );
\serial[0]_i_53\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => data_TX_0(55),
      I1 => data_TX_0(54),
      I2 => \serial[0]_i_12_0\(1),
      I3 => data_TX_0(53),
      I4 => \serial[0]_i_12_0\(0),
      I5 => data_TX_0(52),
      O => \serial[0]_i_53_n_0\
    );
\serial[0]_i_54\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => data_TX_0(43),
      I1 => data_TX_0(42),
      I2 => \serial[0]_i_12_0\(1),
      I3 => data_TX_0(41),
      I4 => \serial[0]_i_12_0\(0),
      I5 => data_TX_0(40),
      O => \serial[0]_i_54_n_0\
    );
\serial[0]_i_55\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => data_TX_0(47),
      I1 => data_TX_0(46),
      I2 => \serial[0]_i_12_0\(1),
      I3 => data_TX_0(45),
      I4 => \serial[0]_i_12_0\(0),
      I5 => data_TX_0(44),
      O => \serial[0]_i_55_n_0\
    );
\serial[0]_i_56\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => data_TX_0(35),
      I1 => data_TX_0(34),
      I2 => \serial[0]_i_12_0\(1),
      I3 => data_TX_0(33),
      I4 => \serial[0]_i_12_0\(0),
      I5 => data_TX_0(32),
      O => \serial[0]_i_56_n_0\
    );
\serial[0]_i_57\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => data_TX_0(39),
      I1 => data_TX_0(38),
      I2 => \serial[0]_i_12_0\(1),
      I3 => data_TX_0(37),
      I4 => \serial[0]_i_12_0\(0),
      I5 => data_TX_0(36),
      O => \serial[0]_i_57_n_0\
    );
\serial[0]_i_58\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => data_TX_0(27),
      I1 => data_TX_0(26),
      I2 => \serial[0]_i_12_0\(1),
      I3 => data_TX_0(25),
      I4 => \serial[0]_i_12_0\(0),
      I5 => data_TX_0(24),
      O => \serial[0]_i_58_n_0\
    );
\serial[0]_i_59\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => data_TX_0(31),
      I1 => data_TX_0(30),
      I2 => \serial[0]_i_12_0\(1),
      I3 => data_TX_0(29),
      I4 => \serial[0]_i_12_0\(0),
      I5 => data_TX_0(28),
      O => \serial[0]_i_59_n_0\
    );
\serial[0]_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BF000000FFFFFFFF"
    )
        port map (
      I0 => \serial[0]_i_12_0\(1),
      I1 => \serial[0]_i_12_0\(2),
      I2 => \serial[0]_i_17_n_0\,
      I3 => Q(1),
      I4 => \serial[0]_i_18_n_0\,
      I5 => Q(0),
      O => \serial[0]_i_6_n_0\
    );
\serial[0]_i_60\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => data_TX_0(19),
      I1 => data_TX_0(18),
      I2 => \serial[0]_i_12_0\(1),
      I3 => data_TX_0(17),
      I4 => \serial[0]_i_12_0\(0),
      I5 => data_TX_0(16),
      O => \serial[0]_i_60_n_0\
    );
\serial[0]_i_61\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => data_TX_0(23),
      I1 => data_TX_0(22),
      I2 => \serial[0]_i_12_0\(1),
      I3 => data_TX_0(21),
      I4 => \serial[0]_i_12_0\(0),
      I5 => data_TX_0(20),
      O => \serial[0]_i_61_n_0\
    );
\serial[0]_i_62\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => data_TX_0(11),
      I1 => data_TX_0(10),
      I2 => \serial[0]_i_12_0\(1),
      I3 => data_TX_0(9),
      I4 => \serial[0]_i_12_0\(0),
      I5 => data_TX_0(8),
      O => \serial[0]_i_62_n_0\
    );
\serial[0]_i_63\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => data_TX_0(15),
      I1 => data_TX_0(14),
      I2 => \serial[0]_i_12_0\(1),
      I3 => data_TX_0(13),
      I4 => \serial[0]_i_12_0\(0),
      I5 => data_TX_0(12),
      O => \serial[0]_i_63_n_0\
    );
\serial[0]_i_64\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => data_TX_0(3),
      I1 => data_TX_0(2),
      I2 => \serial[0]_i_12_0\(1),
      I3 => data_TX_0(1),
      I4 => \serial[0]_i_12_0\(0),
      I5 => data_TX_0(0),
      O => \serial[0]_i_64_n_0\
    );
\serial[0]_i_65\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => data_TX_0(7),
      I1 => data_TX_0(6),
      I2 => \serial[0]_i_12_0\(1),
      I3 => data_TX_0(5),
      I4 => \serial[0]_i_12_0\(0),
      I5 => data_TX_0(4),
      O => \serial[0]_i_65_n_0\
    );
\serial[0]_i_66\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \CRC_RG_reg_n_0_[11]\,
      I1 => \CRC_RG_reg_n_0_[10]\,
      I2 => \serial[0]_i_12_0\(1),
      I3 => \CRC_RG_reg_n_0_[9]\,
      I4 => \serial[0]_i_12_0\(0),
      I5 => \CRC_RG_reg_n_0_[8]\,
      O => \serial[0]_i_66_n_0\
    );
\serial[0]_i_67\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => out_CRC(14),
      I1 => \serial[0]_i_12_0\(1),
      I2 => \CRC_RG_reg_n_0_[13]\,
      I3 => \serial[0]_i_12_0\(0),
      I4 => \CRC_RG_reg_n_0_[12]\,
      O => \serial[0]_i_67_n_0\
    );
\serial[0]_i_68\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \CRC_RG_reg_n_0_[3]\,
      I1 => \CRC_RG_reg_n_0_[2]\,
      I2 => \serial[0]_i_12_0\(1),
      I3 => \CRC_RG_reg_n_0_[1]\,
      I4 => \serial[0]_i_12_0\(0),
      I5 => \CRC_RG_reg_n_0_[0]\,
      O => \serial[0]_i_68_n_0\
    );
\serial[0]_i_69\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \CRC_RG_reg_n_0_[7]\,
      I1 => \CRC_RG_reg_n_0_[6]\,
      I2 => \serial[0]_i_12_0\(1),
      I3 => \CRC_RG_reg_n_0_[5]\,
      I4 => \serial[0]_i_12_0\(0),
      I5 => \CRC_RG_reg_n_0_[4]\,
      O => \serial[0]_i_69_n_0\
    );
\serial[0]_i_7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFF0000B800"
    )
        port map (
      I0 => \serial[0]_i_19_n_0\,
      I1 => \serial[0]_i_12_0\(5),
      I2 => \serial[0]_i_20_n_0\,
      I3 => Q(2),
      I4 => \^txstates_reg[0]\,
      I5 => \serial[0]_i_21_n_0\,
      O => \serial[0]_i_7_n_0\
    );
\serial[0]_i_8\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"55555556"
    )
        port map (
      I0 => \serial[0]_i_12_0\(4),
      I1 => \serial[0]_i_12_0\(1),
      I2 => \serial[0]_i_12_0\(0),
      I3 => \serial[0]_i_12_0\(2),
      I4 => \serial[0]_i_12_0\(3),
      O => \serial[0]_i_8_n_0\
    );
\serial[0]_i_9\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CFC0AFAFCFC0A0A0"
    )
        port map (
      I0 => ID_TX_0(28),
      I1 => \serial[0]_i_22_n_0\,
      I2 => \^cnt_reg[3]\,
      I3 => \serial[0]_i_23_n_0\,
      I4 => \serial[0]_i_24_n_0\,
      I5 => \serial[0]_i_25_n_0\,
      O => \serial[0]_i_9_n_0\
    );
\serial_reg[0]_i_40\: unisim.vcomponents.MUXF7
     port map (
      I0 => \serial[0]_i_50_n_0\,
      I1 => \serial[0]_i_51_n_0\,
      O => \serial_reg[0]_i_40_n_0\,
      S => \serial[0]_i_12_0\(2)
    );
\serial_reg[0]_i_41\: unisim.vcomponents.MUXF7
     port map (
      I0 => \serial[0]_i_52_n_0\,
      I1 => \serial[0]_i_53_n_0\,
      O => \serial_reg[0]_i_41_n_0\,
      S => \serial[0]_i_12_0\(2)
    );
\serial_reg[0]_i_42\: unisim.vcomponents.MUXF7
     port map (
      I0 => \serial[0]_i_54_n_0\,
      I1 => \serial[0]_i_55_n_0\,
      O => \serial_reg[0]_i_42_n_0\,
      S => \serial[0]_i_12_0\(2)
    );
\serial_reg[0]_i_43\: unisim.vcomponents.MUXF7
     port map (
      I0 => \serial[0]_i_56_n_0\,
      I1 => \serial[0]_i_57_n_0\,
      O => \serial_reg[0]_i_43_n_0\,
      S => \serial[0]_i_12_0\(2)
    );
\serial_reg[0]_i_44\: unisim.vcomponents.MUXF7
     port map (
      I0 => \serial[0]_i_58_n_0\,
      I1 => \serial[0]_i_59_n_0\,
      O => \serial_reg[0]_i_44_n_0\,
      S => \serial[0]_i_12_0\(2)
    );
\serial_reg[0]_i_45\: unisim.vcomponents.MUXF7
     port map (
      I0 => \serial[0]_i_60_n_0\,
      I1 => \serial[0]_i_61_n_0\,
      O => \serial_reg[0]_i_45_n_0\,
      S => \serial[0]_i_12_0\(2)
    );
\serial_reg[0]_i_46\: unisim.vcomponents.MUXF7
     port map (
      I0 => \serial[0]_i_62_n_0\,
      I1 => \serial[0]_i_63_n_0\,
      O => \serial_reg[0]_i_46_n_0\,
      S => \serial[0]_i_12_0\(2)
    );
\serial_reg[0]_i_47\: unisim.vcomponents.MUXF7
     port map (
      I0 => \serial[0]_i_64_n_0\,
      I1 => \serial[0]_i_65_n_0\,
      O => \serial_reg[0]_i_47_n_0\,
      S => \serial[0]_i_12_0\(2)
    );
\serial_reg[0]_i_48\: unisim.vcomponents.MUXF7
     port map (
      I0 => \serial[0]_i_66_n_0\,
      I1 => \serial[0]_i_67_n_0\,
      O => \serial_reg[0]_i_48_n_0\,
      S => \serial[0]_i_12_0\(2)
    );
\serial_reg[0]_i_49\: unisim.vcomponents.MUXF7
     port map (
      I0 => \serial[0]_i_68_n_0\,
      I1 => \serial[0]_i_69_n_0\,
      O => \serial_reg[0]_i_49_n_0\,
      S => \serial[0]_i_12_0\(2)
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1_FPGAPROJECT_0_0_CRC_0 is
  port (
    SRST_0_0 : out STD_LOGIC;
    \bs_reg[1]\ : out STD_LOGIC;
    CAN_RST_0 : out STD_LOGIC;
    Q : in STD_LOGIC_VECTOR ( 3 downto 0 );
    SRST_0 : in STD_LOGIC;
    \CRC_RG_reg[3]_0\ : in STD_LOGIC;
    \CRC_RG_reg[14]_0\ : in STD_LOGIC;
    req_Error_reg : in STD_LOGIC;
    req_Error_reg_0 : in STD_LOGIC;
    req_Error_reg_1 : in STD_LOGIC_VECTOR ( 0 to 0 );
    req_Error_reg_2 : in STD_LOGIC;
    req_Error_reg_3 : in STD_LOGIC;
    req_Error_reg_4 : in STD_LOGIC_VECTOR ( 5 downto 0 );
    req_Error_reg_5 : in STD_LOGIC;
    req_Error_reg_6 : in STD_LOGIC;
    CAN_RST : in STD_LOGIC;
    clk : in STD_LOGIC
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of design_1_FPGAPROJECT_0_0_CRC_0 : entity is "CRC";
end design_1_FPGAPROJECT_0_0_CRC_0;

architecture STRUCTURE of design_1_FPGAPROJECT_0_0_CRC_0 is
  signal \^can_rst_0\ : STD_LOGIC;
  signal \CRC_RG[0]_i_1__0_n_0\ : STD_LOGIC;
  signal \CRC_RG[10]_i_1__0_n_0\ : STD_LOGIC;
  signal \CRC_RG[14]_i_1__0_n_0\ : STD_LOGIC;
  signal \CRC_RG[14]_i_2__0_n_0\ : STD_LOGIC;
  signal \CRC_RG[14]_i_3__0_n_0\ : STD_LOGIC;
  signal \CRC_RG[14]_i_4__0_n_0\ : STD_LOGIC;
  signal \CRC_RG[3]_i_1__0_n_0\ : STD_LOGIC;
  signal \CRC_RG[4]_i_1__0_n_0\ : STD_LOGIC;
  signal \CRC_RG[7]_i_1__0_n_0\ : STD_LOGIC;
  signal \CRC_RG[8]_i_1__0_n_0\ : STD_LOGIC;
  signal \RXSTATES[3]_i_5_n_0\ : STD_LOGIC;
  signal out_CRC : STD_LOGIC_VECTOR ( 14 downto 0 );
  signal \p_1_in__0\ : STD_LOGIC_VECTOR ( 13 downto 1 );
  signal req_Error_i_10_n_0 : STD_LOGIC;
  signal req_Error_i_11_n_0 : STD_LOGIC;
  signal req_Error_i_3_n_0 : STD_LOGIC;
  signal req_Error_i_7_n_0 : STD_LOGIC;
  signal req_Error_i_9_n_0 : STD_LOGIC;
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \CRC_RG[10]_i_1__0\ : label is "soft_lutpair172";
  attribute SOFT_HLUTNM of \CRC_RG[14]_i_2__0\ : label is "soft_lutpair172";
  attribute SOFT_HLUTNM of \CRC_RG[14]_i_4__0\ : label is "soft_lutpair171";
  attribute SOFT_HLUTNM of \CRC_RG[3]_i_1__0\ : label is "soft_lutpair174";
  attribute SOFT_HLUTNM of \CRC_RG[4]_i_1__0\ : label is "soft_lutpair174";
  attribute SOFT_HLUTNM of \CRC_RG[7]_i_1__0\ : label is "soft_lutpair173";
  attribute SOFT_HLUTNM of \CRC_RG[8]_i_1__0\ : label is "soft_lutpair173";
  attribute SOFT_HLUTNM of \RXSTATES[3]_i_5\ : label is "soft_lutpair171";
begin
  CAN_RST_0 <= \^can_rst_0\;
\CRC_RG[0]_i_1__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAA22A800000000"
    )
        port map (
      I0 => \CRC_RG[14]_i_3__0_n_0\,
      I1 => Q(0),
      I2 => Q(1),
      I3 => Q(3),
      I4 => Q(2),
      I5 => SRST_0,
      O => \CRC_RG[0]_i_1__0_n_0\
    );
\CRC_RG[10]_i_1__0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"60"
    )
        port map (
      I0 => \CRC_RG[14]_i_3__0_n_0\,
      I1 => out_CRC(9),
      I2 => \CRC_RG[14]_i_4__0_n_0\,
      O => \CRC_RG[10]_i_1__0_n_0\
    );
\CRC_RG[11]_i_1__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAA22A800000000"
    )
        port map (
      I0 => out_CRC(10),
      I1 => Q(0),
      I2 => Q(1),
      I3 => Q(3),
      I4 => Q(2),
      I5 => SRST_0,
      O => \p_1_in__0\(11)
    );
\CRC_RG[12]_i_1__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAA22A800000000"
    )
        port map (
      I0 => out_CRC(11),
      I1 => Q(0),
      I2 => Q(1),
      I3 => Q(3),
      I4 => Q(2),
      I5 => SRST_0,
      O => \p_1_in__0\(12)
    );
\CRC_RG[13]_i_1__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAA22A800000000"
    )
        port map (
      I0 => out_CRC(12),
      I1 => Q(0),
      I2 => Q(1),
      I3 => Q(3),
      I4 => Q(2),
      I5 => SRST_0,
      O => \p_1_in__0\(13)
    );
\CRC_RG[14]_i_1__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000ACCABFFFFFFFF"
    )
        port map (
      I0 => \CRC_RG_reg[14]_0\,
      I1 => Q(0),
      I2 => Q(1),
      I3 => Q(3),
      I4 => Q(2),
      I5 => SRST_0,
      O => \CRC_RG[14]_i_1__0_n_0\
    );
\CRC_RG[14]_i_2__0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"60"
    )
        port map (
      I0 => \CRC_RG[14]_i_3__0_n_0\,
      I1 => out_CRC(13),
      I2 => \CRC_RG[14]_i_4__0_n_0\,
      O => \CRC_RG[14]_i_2__0_n_0\
    );
\CRC_RG[14]_i_3__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => out_CRC(14),
      I1 => \CRC_RG_reg[3]_0\,
      O => \CRC_RG[14]_i_3__0_n_0\
    );
\CRC_RG[14]_i_4__0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"8A8AAAA8"
    )
        port map (
      I0 => SRST_0,
      I1 => Q(2),
      I2 => Q(3),
      I3 => Q(1),
      I4 => Q(0),
      O => \CRC_RG[14]_i_4__0_n_0\
    );
\CRC_RG[1]_i_1__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAA22A800000000"
    )
        port map (
      I0 => out_CRC(0),
      I1 => Q(0),
      I2 => Q(1),
      I3 => Q(3),
      I4 => Q(2),
      I5 => SRST_0,
      O => \p_1_in__0\(1)
    );
\CRC_RG[2]_i_1__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAA22A800000000"
    )
        port map (
      I0 => out_CRC(1),
      I1 => Q(0),
      I2 => Q(1),
      I3 => Q(3),
      I4 => Q(2),
      I5 => SRST_0,
      O => \p_1_in__0\(2)
    );
\CRC_RG[3]_i_1__0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"60"
    )
        port map (
      I0 => \CRC_RG[14]_i_3__0_n_0\,
      I1 => out_CRC(2),
      I2 => \CRC_RG[14]_i_4__0_n_0\,
      O => \CRC_RG[3]_i_1__0_n_0\
    );
\CRC_RG[4]_i_1__0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"60"
    )
        port map (
      I0 => \CRC_RG[14]_i_3__0_n_0\,
      I1 => out_CRC(3),
      I2 => \CRC_RG[14]_i_4__0_n_0\,
      O => \CRC_RG[4]_i_1__0_n_0\
    );
\CRC_RG[5]_i_1__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAA22A800000000"
    )
        port map (
      I0 => out_CRC(4),
      I1 => Q(0),
      I2 => Q(1),
      I3 => Q(3),
      I4 => Q(2),
      I5 => SRST_0,
      O => \p_1_in__0\(5)
    );
\CRC_RG[6]_i_1__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAA22A800000000"
    )
        port map (
      I0 => out_CRC(5),
      I1 => Q(0),
      I2 => Q(1),
      I3 => Q(3),
      I4 => Q(2),
      I5 => SRST_0,
      O => \p_1_in__0\(6)
    );
\CRC_RG[7]_i_1__0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"60"
    )
        port map (
      I0 => \CRC_RG[14]_i_3__0_n_0\,
      I1 => out_CRC(6),
      I2 => \CRC_RG[14]_i_4__0_n_0\,
      O => \CRC_RG[7]_i_1__0_n_0\
    );
\CRC_RG[8]_i_1__0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"60"
    )
        port map (
      I0 => \CRC_RG[14]_i_3__0_n_0\,
      I1 => out_CRC(7),
      I2 => \CRC_RG[14]_i_4__0_n_0\,
      O => \CRC_RG[8]_i_1__0_n_0\
    );
\CRC_RG[9]_i_1__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAA22A800000000"
    )
        port map (
      I0 => out_CRC(8),
      I1 => Q(0),
      I2 => Q(1),
      I3 => Q(3),
      I4 => Q(2),
      I5 => SRST_0,
      O => \p_1_in__0\(9)
    );
\CRC_RG_reg[0]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \CRC_RG[14]_i_1__0_n_0\,
      CLR => \^can_rst_0\,
      D => \CRC_RG[0]_i_1__0_n_0\,
      Q => out_CRC(0)
    );
\CRC_RG_reg[10]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \CRC_RG[14]_i_1__0_n_0\,
      CLR => \^can_rst_0\,
      D => \CRC_RG[10]_i_1__0_n_0\,
      Q => out_CRC(10)
    );
\CRC_RG_reg[11]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \CRC_RG[14]_i_1__0_n_0\,
      CLR => \^can_rst_0\,
      D => \p_1_in__0\(11),
      Q => out_CRC(11)
    );
\CRC_RG_reg[12]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \CRC_RG[14]_i_1__0_n_0\,
      CLR => \^can_rst_0\,
      D => \p_1_in__0\(12),
      Q => out_CRC(12)
    );
\CRC_RG_reg[13]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \CRC_RG[14]_i_1__0_n_0\,
      CLR => \^can_rst_0\,
      D => \p_1_in__0\(13),
      Q => out_CRC(13)
    );
\CRC_RG_reg[14]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \CRC_RG[14]_i_1__0_n_0\,
      CLR => \^can_rst_0\,
      D => \CRC_RG[14]_i_2__0_n_0\,
      Q => out_CRC(14)
    );
\CRC_RG_reg[1]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \CRC_RG[14]_i_1__0_n_0\,
      CLR => \^can_rst_0\,
      D => \p_1_in__0\(1),
      Q => out_CRC(1)
    );
\CRC_RG_reg[2]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \CRC_RG[14]_i_1__0_n_0\,
      CLR => \^can_rst_0\,
      D => \p_1_in__0\(2),
      Q => out_CRC(2)
    );
\CRC_RG_reg[3]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \CRC_RG[14]_i_1__0_n_0\,
      CLR => \^can_rst_0\,
      D => \CRC_RG[3]_i_1__0_n_0\,
      Q => out_CRC(3)
    );
\CRC_RG_reg[4]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \CRC_RG[14]_i_1__0_n_0\,
      CLR => \^can_rst_0\,
      D => \CRC_RG[4]_i_1__0_n_0\,
      Q => out_CRC(4)
    );
\CRC_RG_reg[5]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \CRC_RG[14]_i_1__0_n_0\,
      CLR => \^can_rst_0\,
      D => \p_1_in__0\(5),
      Q => out_CRC(5)
    );
\CRC_RG_reg[6]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \CRC_RG[14]_i_1__0_n_0\,
      CLR => \^can_rst_0\,
      D => \p_1_in__0\(6),
      Q => out_CRC(6)
    );
\CRC_RG_reg[7]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \CRC_RG[14]_i_1__0_n_0\,
      CLR => \^can_rst_0\,
      D => \CRC_RG[7]_i_1__0_n_0\,
      Q => out_CRC(7)
    );
\CRC_RG_reg[8]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \CRC_RG[14]_i_1__0_n_0\,
      CLR => \^can_rst_0\,
      D => \CRC_RG[8]_i_1__0_n_0\,
      Q => out_CRC(8)
    );
\CRC_RG_reg[9]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \CRC_RG[14]_i_1__0_n_0\,
      CLR => \^can_rst_0\,
      D => \p_1_in__0\(9),
      Q => out_CRC(9)
    );
\RXSTATES[3]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"4000000000000001"
    )
        port map (
      I0 => \RXSTATES[3]_i_5_n_0\,
      I1 => req_Error_reg_4(1),
      I2 => req_Error_reg_4(0),
      I3 => req_Error_reg_4(3),
      I4 => req_Error_reg_4(4),
      I5 => req_Error_reg_4(2),
      O => \bs_reg[1]\
    );
\RXSTATES[3]_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FCF1"
    )
        port map (
      I0 => Q(0),
      I1 => Q(1),
      I2 => Q(3),
      I3 => Q(2),
      O => \RXSTATES[3]_i_5_n_0\
    );
done_i_2: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => CAN_RST,
      O => \^can_rst_0\
    );
req_Error_i_1: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0FFF0F0F0E000E0E"
    )
        port map (
      I0 => req_Error_reg,
      I1 => req_Error_i_3_n_0,
      I2 => req_Error_reg_0,
      I3 => req_Error_reg_1(0),
      I4 => SRST_0,
      I5 => req_Error_reg_2,
      O => SRST_0_0
    );
req_Error_i_10: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0001"
    )
        port map (
      I0 => out_CRC(11),
      I1 => out_CRC(0),
      I2 => out_CRC(5),
      I3 => out_CRC(2),
      O => req_Error_i_10_n_0
    );
req_Error_i_11: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFE"
    )
        port map (
      I0 => out_CRC(10),
      I1 => out_CRC(6),
      I2 => out_CRC(13),
      I3 => out_CRC(1),
      O => req_Error_i_11_n_0
    );
req_Error_i_3: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5404FFFF54045404"
    )
        port map (
      I0 => \RXSTATES[3]_i_5_n_0\,
      I1 => req_Error_reg_3,
      I2 => req_Error_reg_4(5),
      I3 => req_Error_reg_5,
      I4 => req_Error_i_7_n_0,
      I5 => req_Error_reg_6,
      O => req_Error_i_3_n_0
    );
req_Error_i_7: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000004"
    )
        port map (
      I0 => req_Error_i_9_n_0,
      I1 => req_Error_i_10_n_0,
      I2 => req_Error_i_11_n_0,
      I3 => out_CRC(14),
      I4 => out_CRC(7),
      I5 => out_CRC(4),
      O => req_Error_i_7_n_0
    );
req_Error_i_9: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFE"
    )
        port map (
      I0 => out_CRC(12),
      I1 => out_CRC(8),
      I2 => out_CRC(9),
      I3 => out_CRC(3),
      O => req_Error_i_9_n_0
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1_FPGAPROJECT_0_0_CRC_10 is
  port (
    CAN_RST_0 : out STD_LOGIC;
    SRST_1 : out STD_LOGIC;
    \bs_reg[1]\ : out STD_LOGIC;
    CAN_RST : in STD_LOGIC;
    Q : in STD_LOGIC_VECTOR ( 3 downto 0 );
    SRST : in STD_LOGIC;
    req_Error_reg : in STD_LOGIC;
    req_Error_reg_0 : in STD_LOGIC_VECTOR ( 5 downto 0 );
    req_Error_reg_1 : in STD_LOGIC;
    req_Error_reg_2 : in STD_LOGIC;
    req_Error_reg_3 : in STD_LOGIC;
    req_Error_reg_4 : in STD_LOGIC;
    req_Error_reg_5 : in STD_LOGIC_VECTOR ( 0 to 0 );
    req_Error_reg_6 : in STD_LOGIC;
    \CRC_RG_reg[3]_0\ : in STD_LOGIC;
    \CRC_RG_reg[14]_0\ : in STD_LOGIC;
    Tq : in STD_LOGIC
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of design_1_FPGAPROJECT_0_0_CRC_10 : entity is "CRC";
end design_1_FPGAPROJECT_0_0_CRC_10;

architecture STRUCTURE of design_1_FPGAPROJECT_0_0_CRC_10 is
  signal \^can_rst_0\ : STD_LOGIC;
  signal \CRC_RG[0]_i_1__0_n_0\ : STD_LOGIC;
  signal \CRC_RG[10]_i_1__0_n_0\ : STD_LOGIC;
  signal \CRC_RG[14]_i_1__0_n_0\ : STD_LOGIC;
  signal \CRC_RG[14]_i_2__0_n_0\ : STD_LOGIC;
  signal \CRC_RG[14]_i_3__0_n_0\ : STD_LOGIC;
  signal \CRC_RG[14]_i_4__0_n_0\ : STD_LOGIC;
  signal \CRC_RG[3]_i_1__0_n_0\ : STD_LOGIC;
  signal \CRC_RG[4]_i_1__0_n_0\ : STD_LOGIC;
  signal \CRC_RG[7]_i_1__0_n_0\ : STD_LOGIC;
  signal \CRC_RG[8]_i_1__0_n_0\ : STD_LOGIC;
  signal \RXSTATES[3]_i_5_n_0\ : STD_LOGIC;
  signal out_CRC : STD_LOGIC_VECTOR ( 14 downto 0 );
  signal \p_1_in__0\ : STD_LOGIC_VECTOR ( 13 downto 1 );
  signal req_Error_i_10_n_0 : STD_LOGIC;
  signal req_Error_i_11_n_0 : STD_LOGIC;
  signal req_Error_i_3_n_0 : STD_LOGIC;
  signal req_Error_i_7_n_0 : STD_LOGIC;
  signal req_Error_i_9_n_0 : STD_LOGIC;
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \CRC_RG[10]_i_1__0\ : label is "soft_lutpair68";
  attribute SOFT_HLUTNM of \CRC_RG[14]_i_2__0\ : label is "soft_lutpair68";
  attribute SOFT_HLUTNM of \CRC_RG[14]_i_3__0\ : label is "soft_lutpair67";
  attribute SOFT_HLUTNM of \CRC_RG[14]_i_4__0\ : label is "soft_lutpair66";
  attribute SOFT_HLUTNM of \CRC_RG[3]_i_1__0\ : label is "soft_lutpair70";
  attribute SOFT_HLUTNM of \CRC_RG[4]_i_1__0\ : label is "soft_lutpair70";
  attribute SOFT_HLUTNM of \CRC_RG[7]_i_1__0\ : label is "soft_lutpair69";
  attribute SOFT_HLUTNM of \CRC_RG[8]_i_1__0\ : label is "soft_lutpair69";
  attribute SOFT_HLUTNM of \RXSTATES[3]_i_5\ : label is "soft_lutpair66";
  attribute SOFT_HLUTNM of req_Error_i_11 : label is "soft_lutpair67";
begin
  CAN_RST_0 <= \^can_rst_0\;
\CRC_RG[0]_i_1__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAA22A800000000"
    )
        port map (
      I0 => \CRC_RG[14]_i_3__0_n_0\,
      I1 => Q(0),
      I2 => Q(1),
      I3 => Q(3),
      I4 => Q(2),
      I5 => SRST,
      O => \CRC_RG[0]_i_1__0_n_0\
    );
\CRC_RG[10]_i_1__0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"60"
    )
        port map (
      I0 => \CRC_RG[14]_i_3__0_n_0\,
      I1 => out_CRC(9),
      I2 => \CRC_RG[14]_i_4__0_n_0\,
      O => \CRC_RG[10]_i_1__0_n_0\
    );
\CRC_RG[11]_i_1__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAA22A800000000"
    )
        port map (
      I0 => out_CRC(10),
      I1 => Q(0),
      I2 => Q(1),
      I3 => Q(3),
      I4 => Q(2),
      I5 => SRST,
      O => \p_1_in__0\(11)
    );
\CRC_RG[12]_i_1__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAA22A800000000"
    )
        port map (
      I0 => out_CRC(11),
      I1 => Q(0),
      I2 => Q(1),
      I3 => Q(3),
      I4 => Q(2),
      I5 => SRST,
      O => \p_1_in__0\(12)
    );
\CRC_RG[13]_i_1__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAA22A800000000"
    )
        port map (
      I0 => out_CRC(12),
      I1 => Q(0),
      I2 => Q(1),
      I3 => Q(3),
      I4 => Q(2),
      I5 => SRST,
      O => \p_1_in__0\(13)
    );
\CRC_RG[14]_i_1__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000ACCABFFFFFFFF"
    )
        port map (
      I0 => \CRC_RG_reg[14]_0\,
      I1 => Q(0),
      I2 => Q(1),
      I3 => Q(3),
      I4 => Q(2),
      I5 => SRST,
      O => \CRC_RG[14]_i_1__0_n_0\
    );
\CRC_RG[14]_i_2__0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"60"
    )
        port map (
      I0 => \CRC_RG[14]_i_3__0_n_0\,
      I1 => out_CRC(13),
      I2 => \CRC_RG[14]_i_4__0_n_0\,
      O => \CRC_RG[14]_i_2__0_n_0\
    );
\CRC_RG[14]_i_3__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => out_CRC(14),
      I1 => \CRC_RG_reg[3]_0\,
      O => \CRC_RG[14]_i_3__0_n_0\
    );
\CRC_RG[14]_i_4__0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"8A8AAAA8"
    )
        port map (
      I0 => SRST,
      I1 => Q(2),
      I2 => Q(3),
      I3 => Q(1),
      I4 => Q(0),
      O => \CRC_RG[14]_i_4__0_n_0\
    );
\CRC_RG[1]_i_1__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAA22A800000000"
    )
        port map (
      I0 => out_CRC(0),
      I1 => Q(0),
      I2 => Q(1),
      I3 => Q(3),
      I4 => Q(2),
      I5 => SRST,
      O => \p_1_in__0\(1)
    );
\CRC_RG[2]_i_1__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAA22A800000000"
    )
        port map (
      I0 => out_CRC(1),
      I1 => Q(0),
      I2 => Q(1),
      I3 => Q(3),
      I4 => Q(2),
      I5 => SRST,
      O => \p_1_in__0\(2)
    );
\CRC_RG[3]_i_1__0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"60"
    )
        port map (
      I0 => \CRC_RG[14]_i_3__0_n_0\,
      I1 => out_CRC(2),
      I2 => \CRC_RG[14]_i_4__0_n_0\,
      O => \CRC_RG[3]_i_1__0_n_0\
    );
\CRC_RG[4]_i_1__0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"60"
    )
        port map (
      I0 => \CRC_RG[14]_i_3__0_n_0\,
      I1 => out_CRC(3),
      I2 => \CRC_RG[14]_i_4__0_n_0\,
      O => \CRC_RG[4]_i_1__0_n_0\
    );
\CRC_RG[5]_i_1__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAA22A800000000"
    )
        port map (
      I0 => out_CRC(4),
      I1 => Q(0),
      I2 => Q(1),
      I3 => Q(3),
      I4 => Q(2),
      I5 => SRST,
      O => \p_1_in__0\(5)
    );
\CRC_RG[6]_i_1__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAA22A800000000"
    )
        port map (
      I0 => out_CRC(5),
      I1 => Q(0),
      I2 => Q(1),
      I3 => Q(3),
      I4 => Q(2),
      I5 => SRST,
      O => \p_1_in__0\(6)
    );
\CRC_RG[7]_i_1__0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"60"
    )
        port map (
      I0 => \CRC_RG[14]_i_3__0_n_0\,
      I1 => out_CRC(6),
      I2 => \CRC_RG[14]_i_4__0_n_0\,
      O => \CRC_RG[7]_i_1__0_n_0\
    );
\CRC_RG[8]_i_1__0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"60"
    )
        port map (
      I0 => \CRC_RG[14]_i_3__0_n_0\,
      I1 => out_CRC(7),
      I2 => \CRC_RG[14]_i_4__0_n_0\,
      O => \CRC_RG[8]_i_1__0_n_0\
    );
\CRC_RG[9]_i_1__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAA22A800000000"
    )
        port map (
      I0 => out_CRC(8),
      I1 => Q(0),
      I2 => Q(1),
      I3 => Q(3),
      I4 => Q(2),
      I5 => SRST,
      O => \p_1_in__0\(9)
    );
\CRC_RG_reg[0]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \CRC_RG[14]_i_1__0_n_0\,
      CLR => \^can_rst_0\,
      D => \CRC_RG[0]_i_1__0_n_0\,
      Q => out_CRC(0)
    );
\CRC_RG_reg[10]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \CRC_RG[14]_i_1__0_n_0\,
      CLR => \^can_rst_0\,
      D => \CRC_RG[10]_i_1__0_n_0\,
      Q => out_CRC(10)
    );
\CRC_RG_reg[11]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \CRC_RG[14]_i_1__0_n_0\,
      CLR => \^can_rst_0\,
      D => \p_1_in__0\(11),
      Q => out_CRC(11)
    );
\CRC_RG_reg[12]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \CRC_RG[14]_i_1__0_n_0\,
      CLR => \^can_rst_0\,
      D => \p_1_in__0\(12),
      Q => out_CRC(12)
    );
\CRC_RG_reg[13]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \CRC_RG[14]_i_1__0_n_0\,
      CLR => \^can_rst_0\,
      D => \p_1_in__0\(13),
      Q => out_CRC(13)
    );
\CRC_RG_reg[14]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \CRC_RG[14]_i_1__0_n_0\,
      CLR => \^can_rst_0\,
      D => \CRC_RG[14]_i_2__0_n_0\,
      Q => out_CRC(14)
    );
\CRC_RG_reg[1]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \CRC_RG[14]_i_1__0_n_0\,
      CLR => \^can_rst_0\,
      D => \p_1_in__0\(1),
      Q => out_CRC(1)
    );
\CRC_RG_reg[2]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \CRC_RG[14]_i_1__0_n_0\,
      CLR => \^can_rst_0\,
      D => \p_1_in__0\(2),
      Q => out_CRC(2)
    );
\CRC_RG_reg[3]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \CRC_RG[14]_i_1__0_n_0\,
      CLR => \^can_rst_0\,
      D => \CRC_RG[3]_i_1__0_n_0\,
      Q => out_CRC(3)
    );
\CRC_RG_reg[4]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \CRC_RG[14]_i_1__0_n_0\,
      CLR => \^can_rst_0\,
      D => \CRC_RG[4]_i_1__0_n_0\,
      Q => out_CRC(4)
    );
\CRC_RG_reg[5]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \CRC_RG[14]_i_1__0_n_0\,
      CLR => \^can_rst_0\,
      D => \p_1_in__0\(5),
      Q => out_CRC(5)
    );
\CRC_RG_reg[6]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \CRC_RG[14]_i_1__0_n_0\,
      CLR => \^can_rst_0\,
      D => \p_1_in__0\(6),
      Q => out_CRC(6)
    );
\CRC_RG_reg[7]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \CRC_RG[14]_i_1__0_n_0\,
      CLR => \^can_rst_0\,
      D => \CRC_RG[7]_i_1__0_n_0\,
      Q => out_CRC(7)
    );
\CRC_RG_reg[8]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \CRC_RG[14]_i_1__0_n_0\,
      CLR => \^can_rst_0\,
      D => \CRC_RG[8]_i_1__0_n_0\,
      Q => out_CRC(8)
    );
\CRC_RG_reg[9]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \CRC_RG[14]_i_1__0_n_0\,
      CLR => \^can_rst_0\,
      D => \p_1_in__0\(9),
      Q => out_CRC(9)
    );
\RXSTATES[3]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8000000000000002"
    )
        port map (
      I0 => \RXSTATES[3]_i_5_n_0\,
      I1 => req_Error_reg_0(1),
      I2 => req_Error_reg_0(0),
      I3 => req_Error_reg_0(3),
      I4 => req_Error_reg_0(4),
      I5 => req_Error_reg_0(2),
      O => \bs_reg[1]\
    );
\RXSTATES[3]_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"003E"
    )
        port map (
      I0 => Q(0),
      I1 => Q(2),
      I2 => Q(1),
      I3 => Q(3),
      O => \RXSTATES[3]_i_5_n_0\
    );
done_i_2: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => CAN_RST,
      O => \^can_rst_0\
    );
req_Error_i_1: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0FFF0F0F0E000E0E"
    )
        port map (
      I0 => req_Error_reg_3,
      I1 => req_Error_i_3_n_0,
      I2 => req_Error_reg_4,
      I3 => req_Error_reg_5(0),
      I4 => SRST,
      I5 => req_Error_reg_6,
      O => SRST_1
    );
req_Error_i_10: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0001"
    )
        port map (
      I0 => out_CRC(11),
      I1 => out_CRC(5),
      I2 => out_CRC(4),
      I3 => out_CRC(1),
      O => req_Error_i_10_n_0
    );
req_Error_i_11: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFE"
    )
        port map (
      I0 => out_CRC(3),
      I1 => out_CRC(2),
      I2 => out_CRC(7),
      I3 => out_CRC(14),
      O => req_Error_i_11_n_0
    );
req_Error_i_3: unisim.vcomponents.LUT6
    generic map(
      INIT => X"E020FFFFE020E020"
    )
        port map (
      I0 => req_Error_reg,
      I1 => req_Error_reg_0(5),
      I2 => \RXSTATES[3]_i_5_n_0\,
      I3 => req_Error_reg_1,
      I4 => req_Error_i_7_n_0,
      I5 => req_Error_reg_2,
      O => req_Error_i_3_n_0
    );
req_Error_i_7: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000004"
    )
        port map (
      I0 => req_Error_i_9_n_0,
      I1 => req_Error_i_10_n_0,
      I2 => req_Error_i_11_n_0,
      I3 => out_CRC(13),
      I4 => out_CRC(6),
      I5 => out_CRC(0),
      O => req_Error_i_7_n_0
    );
req_Error_i_9: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFE"
    )
        port map (
      I0 => out_CRC(10),
      I1 => out_CRC(8),
      I2 => out_CRC(12),
      I3 => out_CRC(9),
      O => req_Error_i_9_n_0
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1_FPGAPROJECT_0_0_CRC_9 is
  port (
    SRST_1 : out STD_LOGIC;
    \TXSTATES_reg[3]\ : out STD_LOGIC;
    \TXSTATES_reg[3]_0\ : out STD_LOGIC;
    \Cnt_reg[5]\ : out STD_LOGIC;
    \TXSTATES_reg[0]\ : out STD_LOGIC;
    \TXSTATES_reg[2]\ : out STD_LOGIC;
    Q : in STD_LOGIC_VECTOR ( 3 downto 0 );
    SRST : in STD_LOGIC;
    \CRC_RG_reg[14]_0\ : in STD_LOGIC;
    \Cnt[5]_i_7\ : in STD_LOGIC;
    \CRC_RG[14]_i_8_0\ : in STD_LOGIC;
    \CRC_RG[14]_i_8_1\ : in STD_LOGIC;
    \CRC_RG[14]_i_8_2\ : in STD_LOGIC;
    \serial[0]_i_2\ : in STD_LOGIC_VECTOR ( 5 downto 0 );
    data_TX : in STD_LOGIC_VECTOR ( 63 downto 0 );
    \CRC_RG[14]_i_8_3\ : in STD_LOGIC;
    E : in STD_LOGIC_VECTOR ( 0 to 0 );
    Tq : in STD_LOGIC;
    \CRC_RG_reg[0]_0\ : in STD_LOGIC
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of design_1_FPGAPROJECT_0_0_CRC_9 : entity is "CRC";
end design_1_FPGAPROJECT_0_0_CRC_9;

architecture STRUCTURE of design_1_FPGAPROJECT_0_0_CRC_9 is
  signal \CRC_RG[14]_i_10_n_0\ : STD_LOGIC;
  signal \CRC_RG[14]_i_11_n_0\ : STD_LOGIC;
  signal \CRC_RG[14]_i_13_n_0\ : STD_LOGIC;
  signal \CRC_RG[14]_i_14_n_0\ : STD_LOGIC;
  signal \CRC_RG[14]_i_7_n_0\ : STD_LOGIC;
  signal \CRC_RG_reg_n_0_[0]\ : STD_LOGIC;
  signal \CRC_RG_reg_n_0_[10]\ : STD_LOGIC;
  signal \CRC_RG_reg_n_0_[11]\ : STD_LOGIC;
  signal \CRC_RG_reg_n_0_[12]\ : STD_LOGIC;
  signal \CRC_RG_reg_n_0_[13]\ : STD_LOGIC;
  signal \CRC_RG_reg_n_0_[1]\ : STD_LOGIC;
  signal \CRC_RG_reg_n_0_[2]\ : STD_LOGIC;
  signal \CRC_RG_reg_n_0_[3]\ : STD_LOGIC;
  signal \CRC_RG_reg_n_0_[4]\ : STD_LOGIC;
  signal \CRC_RG_reg_n_0_[5]\ : STD_LOGIC;
  signal \CRC_RG_reg_n_0_[6]\ : STD_LOGIC;
  signal \CRC_RG_reg_n_0_[7]\ : STD_LOGIC;
  signal \CRC_RG_reg_n_0_[8]\ : STD_LOGIC;
  signal \CRC_RG_reg_n_0_[9]\ : STD_LOGIC;
  signal \^cnt_reg[5]\ : STD_LOGIC;
  signal \^srst_1\ : STD_LOGIC;
  signal \^txstates_reg[0]\ : STD_LOGIC;
  signal \^txstates_reg[3]_0\ : STD_LOGIC;
  signal out_CRC : STD_LOGIC_VECTOR ( 14 to 14 );
  signal \p_1_in__0\ : STD_LOGIC_VECTOR ( 14 downto 0 );
  signal \serial[0]_i_35_n_0\ : STD_LOGIC;
  signal \serial[0]_i_36_n_0\ : STD_LOGIC;
  signal \serial[0]_i_37_n_0\ : STD_LOGIC;
  signal \serial[0]_i_38_n_0\ : STD_LOGIC;
  signal \serial[0]_i_39_n_0\ : STD_LOGIC;
  signal \serial[0]_i_40_n_0\ : STD_LOGIC;
  signal \serial[0]_i_41_n_0\ : STD_LOGIC;
  signal \serial[0]_i_42_n_0\ : STD_LOGIC;
  signal \serial[0]_i_43_n_0\ : STD_LOGIC;
  signal \serial[0]_i_44_n_0\ : STD_LOGIC;
  signal \serial[0]_i_45_n_0\ : STD_LOGIC;
  signal \serial[0]_i_46_n_0\ : STD_LOGIC;
  signal \serial[0]_i_47_n_0\ : STD_LOGIC;
  signal \serial[0]_i_48_n_0\ : STD_LOGIC;
  signal \serial[0]_i_49_n_0\ : STD_LOGIC;
  signal \serial[0]_i_50_n_0\ : STD_LOGIC;
  signal \serial[0]_i_51_n_0\ : STD_LOGIC;
  signal \serial[0]_i_52_n_0\ : STD_LOGIC;
  signal \serial[0]_i_53_n_0\ : STD_LOGIC;
  signal \serial[0]_i_54_n_0\ : STD_LOGIC;
  signal \serial[0]_i_7_n_0\ : STD_LOGIC;
  signal \serial[0]_i_8_n_0\ : STD_LOGIC;
  signal \serial[0]_i_9_n_0\ : STD_LOGIC;
  signal \serial_reg[0]_i_14_n_0\ : STD_LOGIC;
  signal \serial_reg[0]_i_15_n_0\ : STD_LOGIC;
  signal \serial_reg[0]_i_16_n_0\ : STD_LOGIC;
  signal \serial_reg[0]_i_17_n_0\ : STD_LOGIC;
  signal \serial_reg[0]_i_18_n_0\ : STD_LOGIC;
  signal \serial_reg[0]_i_19_n_0\ : STD_LOGIC;
  signal \serial_reg[0]_i_20_n_0\ : STD_LOGIC;
  signal \serial_reg[0]_i_21_n_0\ : STD_LOGIC;
  signal \serial_reg[0]_i_22_n_0\ : STD_LOGIC;
  signal \serial_reg[0]_i_23_n_0\ : STD_LOGIC;
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \CRC_RG[10]_i_1\ : label is "soft_lutpair103";
  attribute SOFT_HLUTNM of \CRC_RG[14]_i_2\ : label is "soft_lutpair103";
  attribute SOFT_HLUTNM of \CRC_RG[14]_i_3\ : label is "soft_lutpair99";
  attribute SOFT_HLUTNM of \CRC_RG[14]_i_4\ : label is "soft_lutpair100";
  attribute SOFT_HLUTNM of \CRC_RG[14]_i_6\ : label is "soft_lutpair99";
  attribute SOFT_HLUTNM of \CRC_RG[3]_i_1\ : label is "soft_lutpair101";
  attribute SOFT_HLUTNM of \CRC_RG[4]_i_1\ : label is "soft_lutpair101";
  attribute SOFT_HLUTNM of \CRC_RG[7]_i_1\ : label is "soft_lutpair102";
  attribute SOFT_HLUTNM of \CRC_RG[8]_i_1\ : label is "soft_lutpair102";
  attribute SOFT_HLUTNM of \Cnt[4]_i_7\ : label is "soft_lutpair100";
begin
  \Cnt_reg[5]\ <= \^cnt_reg[5]\;
  SRST_1 <= \^srst_1\;
  \TXSTATES_reg[0]\ <= \^txstates_reg[0]\;
  \TXSTATES_reg[3]_0\ <= \^txstates_reg[3]_0\;
\CRC_RG[0]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000FF9E0000"
    )
        port map (
      I0 => Q(1),
      I1 => Q(0),
      I2 => Q(3),
      I3 => Q(2),
      I4 => SRST,
      I5 => \CRC_RG[14]_i_7_n_0\,
      O => \p_1_in__0\(0)
    );
\CRC_RG[10]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"82"
    )
        port map (
      I0 => \^srst_1\,
      I1 => \CRC_RG[14]_i_7_n_0\,
      I2 => \CRC_RG_reg_n_0_[9]\,
      O => \p_1_in__0\(10)
    );
\CRC_RG[11]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAA82A800000000"
    )
        port map (
      I0 => \CRC_RG_reg_n_0_[10]\,
      I1 => Q(1),
      I2 => Q(0),
      I3 => Q(3),
      I4 => Q(2),
      I5 => SRST,
      O => \p_1_in__0\(11)
    );
\CRC_RG[12]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAA82A800000000"
    )
        port map (
      I0 => \CRC_RG_reg_n_0_[11]\,
      I1 => Q(1),
      I2 => Q(0),
      I3 => Q(3),
      I4 => Q(2),
      I5 => SRST,
      O => \p_1_in__0\(12)
    );
\CRC_RG[13]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAA82A800000000"
    )
        port map (
      I0 => \CRC_RG_reg_n_0_[12]\,
      I1 => Q(1),
      I2 => Q(0),
      I3 => Q(3),
      I4 => Q(2),
      I5 => SRST,
      O => \p_1_in__0\(13)
    );
\CRC_RG[14]_i_10\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFF4540FFFF"
    )
        port map (
      I0 => \CRC_RG[14]_i_8_0\,
      I1 => \CRC_RG[14]_i_8_1\,
      I2 => \CRC_RG[14]_i_13_n_0\,
      I3 => \CRC_RG[14]_i_8_2\,
      I4 => Q(1),
      I5 => Q(0),
      O => \CRC_RG[14]_i_10_n_0\
    );
\CRC_RG[14]_i_11\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"4F"
    )
        port map (
      I0 => \CRC_RG[14]_i_14_n_0\,
      I1 => \CRC_RG[14]_i_8_3\,
      I2 => Q(0),
      O => \CRC_RG[14]_i_11_n_0\
    );
\CRC_RG[14]_i_13\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"AAAAA999"
    )
        port map (
      I0 => \serial[0]_i_2\(4),
      I1 => \serial[0]_i_2\(2),
      I2 => \serial[0]_i_2\(1),
      I3 => \serial[0]_i_2\(0),
      I4 => \serial[0]_i_2\(3),
      O => \CRC_RG[14]_i_13_n_0\
    );
\CRC_RG[14]_i_14\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000004FFFFFFFF"
    )
        port map (
      I0 => \serial[0]_i_2\(1),
      I1 => \serial[0]_i_2\(2),
      I2 => \serial[0]_i_2\(3),
      I3 => \serial[0]_i_2\(4),
      I4 => \serial[0]_i_2\(5),
      I5 => Q(1),
      O => \CRC_RG[14]_i_14_n_0\
    );
\CRC_RG[14]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"82"
    )
        port map (
      I0 => \^srst_1\,
      I1 => \CRC_RG[14]_i_7_n_0\,
      I2 => \CRC_RG_reg_n_0_[13]\,
      O => \p_1_in__0\(14)
    );
\CRC_RG[14]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"AA8A8AA8"
    )
        port map (
      I0 => SRST,
      I1 => Q(2),
      I2 => Q(3),
      I3 => Q(0),
      I4 => Q(1),
      O => \^srst_1\
    );
\CRC_RG[14]_i_4\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"15140000"
    )
        port map (
      I0 => Q(3),
      I1 => Q(1),
      I2 => Q(2),
      I3 => Q(0),
      I4 => \CRC_RG_reg[14]_0\,
      O => \TXSTATES_reg[3]\
    );
\CRC_RG[14]_i_6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => Q(2),
      I1 => Q(1),
      O => \TXSTATES_reg[2]\
    );
\CRC_RG[14]_i_7\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => out_CRC(14),
      I1 => \^txstates_reg[3]_0\,
      O => \CRC_RG[14]_i_7_n_0\
    );
\CRC_RG[14]_i_8\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BBBBBABBBABABABA"
    )
        port map (
      I0 => Q(3),
      I1 => \^cnt_reg[5]\,
      I2 => Q(2),
      I3 => \Cnt[5]_i_7\,
      I4 => \CRC_RG[14]_i_10_n_0\,
      I5 => \CRC_RG[14]_i_11_n_0\,
      O => \^txstates_reg[3]_0\
    );
\CRC_RG[1]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAA82A800000000"
    )
        port map (
      I0 => \CRC_RG_reg_n_0_[0]\,
      I1 => Q(1),
      I2 => Q(0),
      I3 => Q(3),
      I4 => Q(2),
      I5 => SRST,
      O => \p_1_in__0\(1)
    );
\CRC_RG[2]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAA82A800000000"
    )
        port map (
      I0 => \CRC_RG_reg_n_0_[1]\,
      I1 => Q(1),
      I2 => Q(0),
      I3 => Q(3),
      I4 => Q(2),
      I5 => SRST,
      O => \p_1_in__0\(2)
    );
\CRC_RG[3]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"82"
    )
        port map (
      I0 => \^srst_1\,
      I1 => \CRC_RG[14]_i_7_n_0\,
      I2 => \CRC_RG_reg_n_0_[2]\,
      O => \p_1_in__0\(3)
    );
\CRC_RG[4]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"82"
    )
        port map (
      I0 => \^srst_1\,
      I1 => \CRC_RG[14]_i_7_n_0\,
      I2 => \CRC_RG_reg_n_0_[3]\,
      O => \p_1_in__0\(4)
    );
\CRC_RG[5]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAA82A800000000"
    )
        port map (
      I0 => \CRC_RG_reg_n_0_[4]\,
      I1 => Q(1),
      I2 => Q(0),
      I3 => Q(3),
      I4 => Q(2),
      I5 => SRST,
      O => \p_1_in__0\(5)
    );
\CRC_RG[6]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAA82A800000000"
    )
        port map (
      I0 => \CRC_RG_reg_n_0_[5]\,
      I1 => Q(1),
      I2 => Q(0),
      I3 => Q(3),
      I4 => Q(2),
      I5 => SRST,
      O => \p_1_in__0\(6)
    );
\CRC_RG[7]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"82"
    )
        port map (
      I0 => \^srst_1\,
      I1 => \CRC_RG[14]_i_7_n_0\,
      I2 => \CRC_RG_reg_n_0_[6]\,
      O => \p_1_in__0\(7)
    );
\CRC_RG[8]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"82"
    )
        port map (
      I0 => \^srst_1\,
      I1 => \CRC_RG[14]_i_7_n_0\,
      I2 => \CRC_RG_reg_n_0_[7]\,
      O => \p_1_in__0\(8)
    );
\CRC_RG[9]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAA82A800000000"
    )
        port map (
      I0 => \CRC_RG_reg_n_0_[8]\,
      I1 => Q(1),
      I2 => Q(0),
      I3 => Q(3),
      I4 => Q(2),
      I5 => SRST,
      O => \p_1_in__0\(9)
    );
\CRC_RG_reg[0]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => E(0),
      CLR => \CRC_RG_reg[0]_0\,
      D => \p_1_in__0\(0),
      Q => \CRC_RG_reg_n_0_[0]\
    );
\CRC_RG_reg[10]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => E(0),
      CLR => \CRC_RG_reg[0]_0\,
      D => \p_1_in__0\(10),
      Q => \CRC_RG_reg_n_0_[10]\
    );
\CRC_RG_reg[11]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => E(0),
      CLR => \CRC_RG_reg[0]_0\,
      D => \p_1_in__0\(11),
      Q => \CRC_RG_reg_n_0_[11]\
    );
\CRC_RG_reg[12]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => E(0),
      CLR => \CRC_RG_reg[0]_0\,
      D => \p_1_in__0\(12),
      Q => \CRC_RG_reg_n_0_[12]\
    );
\CRC_RG_reg[13]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => E(0),
      CLR => \CRC_RG_reg[0]_0\,
      D => \p_1_in__0\(13),
      Q => \CRC_RG_reg_n_0_[13]\
    );
\CRC_RG_reg[14]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => E(0),
      CLR => \CRC_RG_reg[0]_0\,
      D => \p_1_in__0\(14),
      Q => out_CRC(14)
    );
\CRC_RG_reg[1]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => E(0),
      CLR => \CRC_RG_reg[0]_0\,
      D => \p_1_in__0\(1),
      Q => \CRC_RG_reg_n_0_[1]\
    );
\CRC_RG_reg[2]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => E(0),
      CLR => \CRC_RG_reg[0]_0\,
      D => \p_1_in__0\(2),
      Q => \CRC_RG_reg_n_0_[2]\
    );
\CRC_RG_reg[3]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => E(0),
      CLR => \CRC_RG_reg[0]_0\,
      D => \p_1_in__0\(3),
      Q => \CRC_RG_reg_n_0_[3]\
    );
\CRC_RG_reg[4]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => E(0),
      CLR => \CRC_RG_reg[0]_0\,
      D => \p_1_in__0\(4),
      Q => \CRC_RG_reg_n_0_[4]\
    );
\CRC_RG_reg[5]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => E(0),
      CLR => \CRC_RG_reg[0]_0\,
      D => \p_1_in__0\(5),
      Q => \CRC_RG_reg_n_0_[5]\
    );
\CRC_RG_reg[6]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => E(0),
      CLR => \CRC_RG_reg[0]_0\,
      D => \p_1_in__0\(6),
      Q => \CRC_RG_reg_n_0_[6]\
    );
\CRC_RG_reg[7]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => E(0),
      CLR => \CRC_RG_reg[0]_0\,
      D => \p_1_in__0\(7),
      Q => \CRC_RG_reg_n_0_[7]\
    );
\CRC_RG_reg[8]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => E(0),
      CLR => \CRC_RG_reg[0]_0\,
      D => \p_1_in__0\(8),
      Q => \CRC_RG_reg_n_0_[8]\
    );
\CRC_RG_reg[9]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => E(0),
      CLR => \CRC_RG_reg[0]_0\,
      D => \p_1_in__0\(9),
      Q => \CRC_RG_reg_n_0_[9]\
    );
\Cnt[4]_i_7\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => Q(0),
      I1 => Q(1),
      O => \^txstates_reg[0]\
    );
\serial[0]_i_35\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => data_TX(59),
      I1 => data_TX(58),
      I2 => \serial[0]_i_2\(1),
      I3 => data_TX(57),
      I4 => \serial[0]_i_2\(0),
      I5 => data_TX(56),
      O => \serial[0]_i_35_n_0\
    );
\serial[0]_i_36\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => data_TX(63),
      I1 => data_TX(62),
      I2 => \serial[0]_i_2\(1),
      I3 => data_TX(61),
      I4 => \serial[0]_i_2\(0),
      I5 => data_TX(60),
      O => \serial[0]_i_36_n_0\
    );
\serial[0]_i_37\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => data_TX(51),
      I1 => data_TX(50),
      I2 => \serial[0]_i_2\(1),
      I3 => data_TX(49),
      I4 => \serial[0]_i_2\(0),
      I5 => data_TX(48),
      O => \serial[0]_i_37_n_0\
    );
\serial[0]_i_38\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => data_TX(55),
      I1 => data_TX(54),
      I2 => \serial[0]_i_2\(1),
      I3 => data_TX(53),
      I4 => \serial[0]_i_2\(0),
      I5 => data_TX(52),
      O => \serial[0]_i_38_n_0\
    );
\serial[0]_i_39\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => data_TX(43),
      I1 => data_TX(42),
      I2 => \serial[0]_i_2\(1),
      I3 => data_TX(41),
      I4 => \serial[0]_i_2\(0),
      I5 => data_TX(40),
      O => \serial[0]_i_39_n_0\
    );
\serial[0]_i_40\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => data_TX(47),
      I1 => data_TX(46),
      I2 => \serial[0]_i_2\(1),
      I3 => data_TX(45),
      I4 => \serial[0]_i_2\(0),
      I5 => data_TX(44),
      O => \serial[0]_i_40_n_0\
    );
\serial[0]_i_41\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => data_TX(35),
      I1 => data_TX(34),
      I2 => \serial[0]_i_2\(1),
      I3 => data_TX(33),
      I4 => \serial[0]_i_2\(0),
      I5 => data_TX(32),
      O => \serial[0]_i_41_n_0\
    );
\serial[0]_i_42\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => data_TX(39),
      I1 => data_TX(38),
      I2 => \serial[0]_i_2\(1),
      I3 => data_TX(37),
      I4 => \serial[0]_i_2\(0),
      I5 => data_TX(36),
      O => \serial[0]_i_42_n_0\
    );
\serial[0]_i_43\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => data_TX(27),
      I1 => data_TX(26),
      I2 => \serial[0]_i_2\(1),
      I3 => data_TX(25),
      I4 => \serial[0]_i_2\(0),
      I5 => data_TX(24),
      O => \serial[0]_i_43_n_0\
    );
\serial[0]_i_44\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => data_TX(31),
      I1 => data_TX(30),
      I2 => \serial[0]_i_2\(1),
      I3 => data_TX(29),
      I4 => \serial[0]_i_2\(0),
      I5 => data_TX(28),
      O => \serial[0]_i_44_n_0\
    );
\serial[0]_i_45\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => data_TX(19),
      I1 => data_TX(18),
      I2 => \serial[0]_i_2\(1),
      I3 => data_TX(17),
      I4 => \serial[0]_i_2\(0),
      I5 => data_TX(16),
      O => \serial[0]_i_45_n_0\
    );
\serial[0]_i_46\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => data_TX(23),
      I1 => data_TX(22),
      I2 => \serial[0]_i_2\(1),
      I3 => data_TX(21),
      I4 => \serial[0]_i_2\(0),
      I5 => data_TX(20),
      O => \serial[0]_i_46_n_0\
    );
\serial[0]_i_47\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => data_TX(11),
      I1 => data_TX(10),
      I2 => \serial[0]_i_2\(1),
      I3 => data_TX(9),
      I4 => \serial[0]_i_2\(0),
      I5 => data_TX(8),
      O => \serial[0]_i_47_n_0\
    );
\serial[0]_i_48\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => data_TX(15),
      I1 => data_TX(14),
      I2 => \serial[0]_i_2\(1),
      I3 => data_TX(13),
      I4 => \serial[0]_i_2\(0),
      I5 => data_TX(12),
      O => \serial[0]_i_48_n_0\
    );
\serial[0]_i_49\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => data_TX(3),
      I1 => data_TX(2),
      I2 => \serial[0]_i_2\(1),
      I3 => data_TX(1),
      I4 => \serial[0]_i_2\(0),
      I5 => data_TX(0),
      O => \serial[0]_i_49_n_0\
    );
\serial[0]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000FFFF47FF"
    )
        port map (
      I0 => \serial[0]_i_7_n_0\,
      I1 => \serial[0]_i_2\(5),
      I2 => \serial[0]_i_8_n_0\,
      I3 => Q(2),
      I4 => \^txstates_reg[0]\,
      I5 => \serial[0]_i_9_n_0\,
      O => \^cnt_reg[5]\
    );
\serial[0]_i_50\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => data_TX(7),
      I1 => data_TX(6),
      I2 => \serial[0]_i_2\(1),
      I3 => data_TX(5),
      I4 => \serial[0]_i_2\(0),
      I5 => data_TX(4),
      O => \serial[0]_i_50_n_0\
    );
\serial[0]_i_51\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \CRC_RG_reg_n_0_[11]\,
      I1 => \CRC_RG_reg_n_0_[10]\,
      I2 => \serial[0]_i_2\(1),
      I3 => \CRC_RG_reg_n_0_[9]\,
      I4 => \serial[0]_i_2\(0),
      I5 => \CRC_RG_reg_n_0_[8]\,
      O => \serial[0]_i_51_n_0\
    );
\serial[0]_i_52\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => out_CRC(14),
      I1 => \serial[0]_i_2\(1),
      I2 => \CRC_RG_reg_n_0_[13]\,
      I3 => \serial[0]_i_2\(0),
      I4 => \CRC_RG_reg_n_0_[12]\,
      O => \serial[0]_i_52_n_0\
    );
\serial[0]_i_53\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \CRC_RG_reg_n_0_[3]\,
      I1 => \CRC_RG_reg_n_0_[2]\,
      I2 => \serial[0]_i_2\(1),
      I3 => \CRC_RG_reg_n_0_[1]\,
      I4 => \serial[0]_i_2\(0),
      I5 => \CRC_RG_reg_n_0_[0]\,
      O => \serial[0]_i_53_n_0\
    );
\serial[0]_i_54\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \CRC_RG_reg_n_0_[7]\,
      I1 => \CRC_RG_reg_n_0_[6]\,
      I2 => \serial[0]_i_2\(1),
      I3 => \CRC_RG_reg_n_0_[5]\,
      I4 => \serial[0]_i_2\(0),
      I5 => \CRC_RG_reg_n_0_[4]\,
      O => \serial[0]_i_54_n_0\
    );
\serial[0]_i_7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \serial_reg[0]_i_14_n_0\,
      I1 => \serial_reg[0]_i_15_n_0\,
      I2 => \serial[0]_i_2\(4),
      I3 => \serial_reg[0]_i_16_n_0\,
      I4 => \serial[0]_i_2\(3),
      I5 => \serial_reg[0]_i_17_n_0\,
      O => \serial[0]_i_7_n_0\
    );
\serial[0]_i_8\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \serial_reg[0]_i_18_n_0\,
      I1 => \serial_reg[0]_i_19_n_0\,
      I2 => \serial[0]_i_2\(4),
      I3 => \serial_reg[0]_i_20_n_0\,
      I4 => \serial[0]_i_2\(3),
      I5 => \serial_reg[0]_i_21_n_0\,
      O => \serial[0]_i_8_n_0\
    );
\serial[0]_i_9\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFF8A80FFFFFFFF"
    )
        port map (
      I0 => Q(0),
      I1 => \serial_reg[0]_i_22_n_0\,
      I2 => \serial[0]_i_2\(3),
      I3 => \serial_reg[0]_i_23_n_0\,
      I4 => Q(1),
      I5 => Q(2),
      O => \serial[0]_i_9_n_0\
    );
\serial_reg[0]_i_14\: unisim.vcomponents.MUXF7
     port map (
      I0 => \serial[0]_i_35_n_0\,
      I1 => \serial[0]_i_36_n_0\,
      O => \serial_reg[0]_i_14_n_0\,
      S => \serial[0]_i_2\(2)
    );
\serial_reg[0]_i_15\: unisim.vcomponents.MUXF7
     port map (
      I0 => \serial[0]_i_37_n_0\,
      I1 => \serial[0]_i_38_n_0\,
      O => \serial_reg[0]_i_15_n_0\,
      S => \serial[0]_i_2\(2)
    );
\serial_reg[0]_i_16\: unisim.vcomponents.MUXF7
     port map (
      I0 => \serial[0]_i_39_n_0\,
      I1 => \serial[0]_i_40_n_0\,
      O => \serial_reg[0]_i_16_n_0\,
      S => \serial[0]_i_2\(2)
    );
\serial_reg[0]_i_17\: unisim.vcomponents.MUXF7
     port map (
      I0 => \serial[0]_i_41_n_0\,
      I1 => \serial[0]_i_42_n_0\,
      O => \serial_reg[0]_i_17_n_0\,
      S => \serial[0]_i_2\(2)
    );
\serial_reg[0]_i_18\: unisim.vcomponents.MUXF7
     port map (
      I0 => \serial[0]_i_43_n_0\,
      I1 => \serial[0]_i_44_n_0\,
      O => \serial_reg[0]_i_18_n_0\,
      S => \serial[0]_i_2\(2)
    );
\serial_reg[0]_i_19\: unisim.vcomponents.MUXF7
     port map (
      I0 => \serial[0]_i_45_n_0\,
      I1 => \serial[0]_i_46_n_0\,
      O => \serial_reg[0]_i_19_n_0\,
      S => \serial[0]_i_2\(2)
    );
\serial_reg[0]_i_20\: unisim.vcomponents.MUXF7
     port map (
      I0 => \serial[0]_i_47_n_0\,
      I1 => \serial[0]_i_48_n_0\,
      O => \serial_reg[0]_i_20_n_0\,
      S => \serial[0]_i_2\(2)
    );
\serial_reg[0]_i_21\: unisim.vcomponents.MUXF7
     port map (
      I0 => \serial[0]_i_49_n_0\,
      I1 => \serial[0]_i_50_n_0\,
      O => \serial_reg[0]_i_21_n_0\,
      S => \serial[0]_i_2\(2)
    );
\serial_reg[0]_i_22\: unisim.vcomponents.MUXF7
     port map (
      I0 => \serial[0]_i_51_n_0\,
      I1 => \serial[0]_i_52_n_0\,
      O => \serial_reg[0]_i_22_n_0\,
      S => \serial[0]_i_2\(2)
    );
\serial_reg[0]_i_23\: unisim.vcomponents.MUXF7
     port map (
      I0 => \serial[0]_i_53_n_0\,
      I1 => \serial[0]_i_54_n_0\,
      O => \serial_reg[0]_i_23_n_0\,
      S => \serial[0]_i_2\(2)
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1_FPGAPROJECT_0_0_ErrorHandler is
  port (
    lastvalue : out STD_LOGIC;
    Q : out STD_LOGIC_VECTOR ( 8 downto 0 );
    \State_reg[0]_0\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    \REC_reg[8]_0\ : out STD_LOGIC_VECTOR ( 8 downto 0 );
    \State_reg[0]_1\ : out STD_LOGIC;
    \State_reg[2]_0\ : out STD_LOGIC;
    D : out STD_LOGIC_VECTOR ( 1 downto 0 );
    RXOUT_reg : out STD_LOGIC;
    Mode_0_1_sp_1 : out STD_LOGIC;
    q_reg : out STD_LOGIC;
    RXBUS : out STD_LOGIC;
    RX : out STD_LOGIC;
    SRST_0_0 : out STD_LOGIC_VECTOR ( 0 to 0 );
    \State_reg[2]_1\ : out STD_LOGIC;
    \State_reg[0]_2\ : out STD_LOGIC;
    \REC_reg[7]_0\ : out STD_LOGIC;
    \REC_reg[8]_1\ : out STD_LOGIC;
    \State_reg[0]_3\ : out STD_LOGIC;
    E : in STD_LOGIC_VECTOR ( 0 to 0 );
    lastvalue_reg_0 : in STD_LOGIC;
    clk : in STD_LOGIC;
    ack_error_reg_0 : in STD_LOGIC;
    donefromtxr : in STD_LOGIC;
    donefromrxr : in STD_LOGIC;
    imTX : in STD_LOGIC;
    req_Error_RX : in STD_LOGIC;
    \D_Len[0]_i_2_0\ : in STD_LOGIC;
    AckTakeOver : in STD_LOGIC;
    Sampled_din : in STD_LOGIC;
    SRST_0 : in STD_LOGIC;
    \REC_reg[0]_0\ : in STD_LOGIC;
    ack_error_reg_1 : in STD_LOGIC;
    \TEC_reg[0]_0\ : in STD_LOGIC;
    TXpin_reg_0 : in STD_LOGIC;
    \Cnt_reg[0]_0\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \TEC[8]_i_11_0\ : in STD_LOGIC;
    \State_reg[0]_4\ : in STD_LOGIC;
    \State_reg[0]_5\ : in STD_LOGIC;
    \TXSTATES_reg[2]\ : in STD_LOGIC;
    \TXSTATES_reg[3]\ : in STD_LOGIC;
    ack_error_reg_2 : in STD_LOGIC;
    ack_error_reg_3 : in STD_LOGIC;
    RXBUS_d : in STD_LOGIC;
    \^q\ : in STD_LOGIC;
    Mode_0 : in STD_LOGIC_VECTOR ( 2 downto 0 );
    TX : in STD_LOGIC;
    \RXSTATES_reg[1]\ : in STD_LOGIC;
    \Cnt_reg[3]_0\ : in STD_LOGIC;
    \REC[0]_i_2_0\ : in STD_LOGIC;
    \TEC_reg[0]_1\ : in STD_LOGIC;
    \REC[8]_i_7_0\ : in STD_LOGIC
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of design_1_FPGAPROJECT_0_0_ErrorHandler : entity is "ErrorHandler";
end design_1_FPGAPROJECT_0_0_ErrorHandler;

architecture STRUCTURE of design_1_FPGAPROJECT_0_0_ErrorHandler is
  signal \Cnt[0]_i_2__1_n_0\ : STD_LOGIC;
  signal \Cnt[0]_i_3__1_n_0\ : STD_LOGIC;
  signal \Cnt[0]_i_4__1_n_0\ : STD_LOGIC;
  signal \Cnt[0]_i_5__0_n_0\ : STD_LOGIC;
  signal \Cnt[0]_i_6_n_0\ : STD_LOGIC;
  signal \Cnt[1]_i_2__1_n_0\ : STD_LOGIC;
  signal \Cnt[2]_i_2__1_n_0\ : STD_LOGIC;
  signal \Cnt[2]_i_3__1_n_0\ : STD_LOGIC;
  signal \Cnt[2]_i_4__1_n_0\ : STD_LOGIC;
  signal \Cnt[2]_i_5__1_n_0\ : STD_LOGIC;
  signal \Cnt[2]_i_6__1_n_0\ : STD_LOGIC;
  signal \Cnt[3]_i_10__0_n_0\ : STD_LOGIC;
  signal \Cnt[3]_i_11_n_0\ : STD_LOGIC;
  signal \Cnt[3]_i_3__0_n_0\ : STD_LOGIC;
  signal \Cnt[3]_i_4__1_n_0\ : STD_LOGIC;
  signal \Cnt[3]_i_5__0_n_0\ : STD_LOGIC;
  signal \Cnt[3]_i_6__0_n_0\ : STD_LOGIC;
  signal \Cnt[3]_i_7__0_n_0\ : STD_LOGIC;
  signal \Cnt[3]_i_9__0_n_0\ : STD_LOGIC;
  signal \Cnt_reg_n_0_[0]\ : STD_LOGIC;
  signal \Cnt_reg_n_0_[1]\ : STD_LOGIC;
  signal \Cnt_reg_n_0_[2]\ : STD_LOGIC;
  signal \Cnt_reg_n_0_[3]\ : STD_LOGIC;
  signal Cntr : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \D_Len[0]_i_3_n_0\ : STD_LOGIC;
  signal Mode_0_1_sn_1 : STD_LOGIC;
  signal \^q_1\ : STD_LOGIC_VECTOR ( 8 downto 0 );
  signal \REC[0]_i_1_n_0\ : STD_LOGIC;
  signal \REC[0]_i_2_n_0\ : STD_LOGIC;
  signal \REC[0]_i_3_n_0\ : STD_LOGIC;
  signal \REC[0]_i_4_n_0\ : STD_LOGIC;
  signal \REC[1]_i_1_n_0\ : STD_LOGIC;
  signal \REC[1]_i_2_n_0\ : STD_LOGIC;
  signal \REC[1]_i_3_n_0\ : STD_LOGIC;
  signal \REC[1]_i_4_n_0\ : STD_LOGIC;
  signal \REC[1]_i_5_n_0\ : STD_LOGIC;
  signal \REC[1]_i_6_n_0\ : STD_LOGIC;
  signal \REC[2]_i_1_n_0\ : STD_LOGIC;
  signal \REC[2]_i_2_n_0\ : STD_LOGIC;
  signal \REC[2]_i_3_n_0\ : STD_LOGIC;
  signal \REC[2]_i_4_n_0\ : STD_LOGIC;
  signal \REC[2]_i_5_n_0\ : STD_LOGIC;
  signal \REC[2]_i_6_n_0\ : STD_LOGIC;
  signal \REC[2]_i_7_n_0\ : STD_LOGIC;
  signal \REC[3]_i_1_n_0\ : STD_LOGIC;
  signal \REC[3]_i_2_n_0\ : STD_LOGIC;
  signal \REC[3]_i_3_n_0\ : STD_LOGIC;
  signal \REC[3]_i_4_n_0\ : STD_LOGIC;
  signal \REC[3]_i_5_n_0\ : STD_LOGIC;
  signal \REC[3]_i_6_n_0\ : STD_LOGIC;
  signal \REC[4]_i_1_n_0\ : STD_LOGIC;
  signal \REC[4]_i_2_n_0\ : STD_LOGIC;
  signal \REC[4]_i_3_n_0\ : STD_LOGIC;
  signal \REC[4]_i_4_n_0\ : STD_LOGIC;
  signal \REC[4]_i_5_n_0\ : STD_LOGIC;
  signal \REC[4]_i_6_n_0\ : STD_LOGIC;
  signal \REC[4]_i_7_n_0\ : STD_LOGIC;
  signal \REC[4]_i_8_n_0\ : STD_LOGIC;
  signal \REC[5]_i_1_n_0\ : STD_LOGIC;
  signal \REC[5]_i_2_n_0\ : STD_LOGIC;
  signal \REC[5]_i_3_n_0\ : STD_LOGIC;
  signal \REC[5]_i_4_n_0\ : STD_LOGIC;
  signal \REC[5]_i_5_n_0\ : STD_LOGIC;
  signal \REC[5]_i_7_n_0\ : STD_LOGIC;
  signal \REC[5]_i_8_n_0\ : STD_LOGIC;
  signal \REC[5]_i_9_n_0\ : STD_LOGIC;
  signal \REC[6]_i_1_n_0\ : STD_LOGIC;
  signal \REC[6]_i_2_n_0\ : STD_LOGIC;
  signal \REC[6]_i_3_n_0\ : STD_LOGIC;
  signal \REC[6]_i_4_n_0\ : STD_LOGIC;
  signal \REC[6]_i_5_n_0\ : STD_LOGIC;
  signal \REC[6]_i_6_n_0\ : STD_LOGIC;
  signal \REC[6]_i_7_n_0\ : STD_LOGIC;
  signal \REC[6]_i_8_n_0\ : STD_LOGIC;
  signal \REC[6]_i_9_n_0\ : STD_LOGIC;
  signal \REC[7]_i_1_n_0\ : STD_LOGIC;
  signal \REC[7]_i_2_n_0\ : STD_LOGIC;
  signal \REC[7]_i_3_n_0\ : STD_LOGIC;
  signal \REC[7]_i_4_n_0\ : STD_LOGIC;
  signal \REC[7]_i_5_n_0\ : STD_LOGIC;
  signal \REC[7]_i_6_n_0\ : STD_LOGIC;
  signal \REC[7]_i_7_n_0\ : STD_LOGIC;
  signal \REC[8]_i_10_n_0\ : STD_LOGIC;
  signal \REC[8]_i_11_n_0\ : STD_LOGIC;
  signal \REC[8]_i_12_n_0\ : STD_LOGIC;
  signal \REC[8]_i_13_n_0\ : STD_LOGIC;
  signal \REC[8]_i_14_n_0\ : STD_LOGIC;
  signal \REC[8]_i_15_n_0\ : STD_LOGIC;
  signal \REC[8]_i_17_n_0\ : STD_LOGIC;
  signal \REC[8]_i_1_n_0\ : STD_LOGIC;
  signal \REC[8]_i_2_n_0\ : STD_LOGIC;
  signal \REC[8]_i_3_n_0\ : STD_LOGIC;
  signal \REC[8]_i_4_n_0\ : STD_LOGIC;
  signal \REC[8]_i_5_n_0\ : STD_LOGIC;
  signal \REC[8]_i_6_n_0\ : STD_LOGIC;
  signal \REC[8]_i_7_n_0\ : STD_LOGIC;
  signal \REC[8]_i_8_n_0\ : STD_LOGIC;
  signal \REC[8]_i_9_n_0\ : STD_LOGIC;
  signal \^rec_reg[7]_0\ : STD_LOGIC;
  signal \^rec_reg[8]_0\ : STD_LOGIC_VECTOR ( 8 downto 0 );
  signal \^rec_reg[8]_1\ : STD_LOGIC;
  signal RECin : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \RECin_reg_n_0_[7]\ : STD_LOGIC;
  signal \RECin_reg_n_0_[8]\ : STD_LOGIC;
  signal Reck : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \Reck[4]_i_2_n_0\ : STD_LOGIC;
  signal \Reck[5]_i_2_n_0\ : STD_LOGIC;
  signal \Reck[6]_i_3_n_0\ : STD_LOGIC;
  signal \Reck[6]_i_4_n_0\ : STD_LOGIC;
  signal \Reck_reg_n_0_[0]\ : STD_LOGIC;
  signal \Reck_reg_n_0_[1]\ : STD_LOGIC;
  signal \Reck_reg_n_0_[2]\ : STD_LOGIC;
  signal \Reck_reg_n_0_[3]\ : STD_LOGIC;
  signal \Reck_reg_n_0_[4]\ : STD_LOGIC;
  signal \Reck_reg_n_0_[5]\ : STD_LOGIC;
  signal \Reck_reg_n_0_[6]\ : STD_LOGIC;
  signal Reckr : STD_LOGIC_VECTOR ( 6 downto 0 );
  signal State : STD_LOGIC_VECTOR ( 2 downto 1 );
  signal \State[0]_i_1_n_0\ : STD_LOGIC;
  signal \State[0]_i_2_n_0\ : STD_LOGIC;
  signal \State[0]_i_3_n_0\ : STD_LOGIC;
  signal \State[0]_i_5_n_0\ : STD_LOGIC;
  signal \State[0]_i_8_n_0\ : STD_LOGIC;
  signal \State[0]_i_9_n_0\ : STD_LOGIC;
  signal \State[1]_i_1_n_0\ : STD_LOGIC;
  signal \State[1]_i_2_n_0\ : STD_LOGIC;
  signal \State[1]_i_3_n_0\ : STD_LOGIC;
  signal \State[1]_i_4_n_0\ : STD_LOGIC;
  signal \State[1]_i_5_n_0\ : STD_LOGIC;
  signal \State[2]_i_1_n_0\ : STD_LOGIC;
  signal \State[2]_i_2_n_0\ : STD_LOGIC;
  signal \State[2]_i_3_n_0\ : STD_LOGIC;
  signal \State[2]_i_4_n_0\ : STD_LOGIC;
  signal \State[2]_i_5_n_0\ : STD_LOGIC;
  signal \State[2]_i_6_n_0\ : STD_LOGIC;
  signal \State[2]_i_7_n_0\ : STD_LOGIC;
  signal \State[2]_i_8_n_0\ : STD_LOGIC;
  signal \^state_reg[0]_0\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \^state_reg[0]_1\ : STD_LOGIC;
  signal \^state_reg[0]_2\ : STD_LOGIC;
  signal \TEC[0]_i_1_n_0\ : STD_LOGIC;
  signal \TEC[0]_i_2_n_0\ : STD_LOGIC;
  signal \TEC[0]_i_3_n_0\ : STD_LOGIC;
  signal \TEC[1]_i_1_n_0\ : STD_LOGIC;
  signal \TEC[1]_i_2_n_0\ : STD_LOGIC;
  signal \TEC[1]_i_3_n_0\ : STD_LOGIC;
  signal \TEC[1]_i_4_n_0\ : STD_LOGIC;
  signal \TEC[1]_i_5_n_0\ : STD_LOGIC;
  signal \TEC[2]_i_1_n_0\ : STD_LOGIC;
  signal \TEC[2]_i_2_n_0\ : STD_LOGIC;
  signal \TEC[2]_i_3_n_0\ : STD_LOGIC;
  signal \TEC[2]_i_4_n_0\ : STD_LOGIC;
  signal \TEC[2]_i_5_n_0\ : STD_LOGIC;
  signal \TEC[3]_i_1_n_0\ : STD_LOGIC;
  signal \TEC[3]_i_2_n_0\ : STD_LOGIC;
  signal \TEC[3]_i_3_n_0\ : STD_LOGIC;
  signal \TEC[3]_i_4_n_0\ : STD_LOGIC;
  signal \TEC[3]_i_5_n_0\ : STD_LOGIC;
  signal \TEC[4]_i_1_n_0\ : STD_LOGIC;
  signal \TEC[4]_i_2_n_0\ : STD_LOGIC;
  signal \TEC[4]_i_3_n_0\ : STD_LOGIC;
  signal \TEC[4]_i_4_n_0\ : STD_LOGIC;
  signal \TEC[4]_i_5_n_0\ : STD_LOGIC;
  signal \TEC[4]_i_6_n_0\ : STD_LOGIC;
  signal \TEC[5]_i_1_n_0\ : STD_LOGIC;
  signal \TEC[5]_i_2_n_0\ : STD_LOGIC;
  signal \TEC[5]_i_3_n_0\ : STD_LOGIC;
  signal \TEC[5]_i_4_n_0\ : STD_LOGIC;
  signal \TEC[5]_i_5_n_0\ : STD_LOGIC;
  signal \TEC[5]_i_6_n_0\ : STD_LOGIC;
  signal \TEC[6]_i_1_n_0\ : STD_LOGIC;
  signal \TEC[6]_i_2_n_0\ : STD_LOGIC;
  signal \TEC[6]_i_3_n_0\ : STD_LOGIC;
  signal \TEC[6]_i_4_n_0\ : STD_LOGIC;
  signal \TEC[6]_i_5_n_0\ : STD_LOGIC;
  signal \TEC[6]_i_6_n_0\ : STD_LOGIC;
  signal \TEC[6]_i_7_n_0\ : STD_LOGIC;
  signal \TEC[7]_i_1_n_0\ : STD_LOGIC;
  signal \TEC[7]_i_2_n_0\ : STD_LOGIC;
  signal \TEC[7]_i_3_n_0\ : STD_LOGIC;
  signal \TEC[7]_i_4_n_0\ : STD_LOGIC;
  signal \TEC[7]_i_5_n_0\ : STD_LOGIC;
  signal \TEC[7]_i_6_n_0\ : STD_LOGIC;
  signal \TEC[8]_i_10_n_0\ : STD_LOGIC;
  signal \TEC[8]_i_11_n_0\ : STD_LOGIC;
  signal \TEC[8]_i_12_n_0\ : STD_LOGIC;
  signal \TEC[8]_i_13_n_0\ : STD_LOGIC;
  signal \TEC[8]_i_14_n_0\ : STD_LOGIC;
  signal \TEC[8]_i_15_n_0\ : STD_LOGIC;
  signal \TEC[8]_i_16_n_0\ : STD_LOGIC;
  signal \TEC[8]_i_17_n_0\ : STD_LOGIC;
  signal \TEC[8]_i_18_n_0\ : STD_LOGIC;
  signal \TEC[8]_i_19_n_0\ : STD_LOGIC;
  signal \TEC[8]_i_1_n_0\ : STD_LOGIC;
  signal \TEC[8]_i_20_n_0\ : STD_LOGIC;
  signal \TEC[8]_i_21_n_0\ : STD_LOGIC;
  signal \TEC[8]_i_2_n_0\ : STD_LOGIC;
  signal \TEC[8]_i_4_n_0\ : STD_LOGIC;
  signal \TEC[8]_i_5_n_0\ : STD_LOGIC;
  signal \TEC[8]_i_6_n_0\ : STD_LOGIC;
  signal \TEC[8]_i_7_n_0\ : STD_LOGIC;
  signal \TEC[8]_i_8_n_0\ : STD_LOGIC;
  signal \TEC[8]_i_9_n_0\ : STD_LOGIC;
  signal \TECin[8]_i_2_n_0\ : STD_LOGIC;
  signal \TECin[8]_i_3_n_0\ : STD_LOGIC;
  signal \TECin_reg_n_0_[7]\ : STD_LOGIC;
  signal \TECin_reg_n_0_[8]\ : STD_LOGIC;
  signal TX_from_Err : STD_LOGIC;
  signal TXpin_i_1_n_0 : STD_LOGIC;
  signal TXpin_i_2_n_0 : STD_LOGIC;
  signal TXpin_i_3_n_0 : STD_LOGIC;
  signal TXpin_i_4_n_0 : STD_LOGIC;
  signal ack_error : STD_LOGIC;
  signal ack_error_i_1_n_0 : STD_LOGIC;
  signal ack_error_i_3_n_0 : STD_LOGIC;
  signal ack_error_i_4_n_0 : STD_LOGIC;
  signal ack_error_reg_n_0 : STD_LOGIC;
  signal donefromrxr_reg_n_0 : STD_LOGIC;
  signal donefromtxr_reg_n_0 : STD_LOGIC;
  signal \^lastvalue\ : STD_LOGIC;
  signal nozero_i_1_n_0 : STD_LOGIC;
  signal nozero_reg_n_0 : STD_LOGIC;
  signal \^q_reg\ : STD_LOGIC;
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of CANCORE_1_i_1 : label is "soft_lutpair139";
  attribute SOFT_HLUTNM of CANCORE_1_i_2 : label is "soft_lutpair122";
  attribute SOFT_HLUTNM of \CNT1[4]_i_3\ : label is "soft_lutpair139";
  attribute SOFT_HLUTNM of \Cnt[0]_i_3__1\ : label is "soft_lutpair115";
  attribute SOFT_HLUTNM of \Cnt[0]_i_4__1\ : label is "soft_lutpair128";
  attribute SOFT_HLUTNM of \Cnt[0]_i_5__0\ : label is "soft_lutpair127";
  attribute SOFT_HLUTNM of \Cnt[0]_i_6\ : label is "soft_lutpair130";
  attribute SOFT_HLUTNM of \Cnt[1]_i_2__1\ : label is "soft_lutpair130";
  attribute SOFT_HLUTNM of \Cnt[2]_i_2__1\ : label is "soft_lutpair131";
  attribute SOFT_HLUTNM of \Cnt[2]_i_5__1\ : label is "soft_lutpair114";
  attribute SOFT_HLUTNM of \Cnt[2]_i_6__1\ : label is "soft_lutpair115";
  attribute SOFT_HLUTNM of \Cnt[3]_i_10__0\ : label is "soft_lutpair127";
  attribute SOFT_HLUTNM of \Cnt[3]_i_11\ : label is "soft_lutpair148";
  attribute SOFT_HLUTNM of \Cnt[3]_i_5__0\ : label is "soft_lutpair154";
  attribute SOFT_HLUTNM of \Cnt[3]_i_7__0\ : label is "soft_lutpair148";
  attribute SOFT_HLUTNM of \Cnt[3]_i_9__0\ : label is "soft_lutpair154";
  attribute SOFT_HLUTNM of \D_Len[0]_i_2\ : label is "soft_lutpair122";
  attribute SOFT_HLUTNM of \D_Len[0]_i_3\ : label is "soft_lutpair135";
  attribute SOFT_HLUTNM of \REC[1]_i_2\ : label is "soft_lutpair141";
  attribute SOFT_HLUTNM of \REC[1]_i_3\ : label is "soft_lutpair159";
  attribute SOFT_HLUTNM of \REC[1]_i_4\ : label is "soft_lutpair157";
  attribute SOFT_HLUTNM of \REC[2]_i_2\ : label is "soft_lutpair142";
  attribute SOFT_HLUTNM of \REC[2]_i_3\ : label is "soft_lutpair159";
  attribute SOFT_HLUTNM of \REC[2]_i_4\ : label is "soft_lutpair142";
  attribute SOFT_HLUTNM of \REC[3]_i_3\ : label is "soft_lutpair143";
  attribute SOFT_HLUTNM of \REC[3]_i_4\ : label is "soft_lutpair134";
  attribute SOFT_HLUTNM of \REC[3]_i_6\ : label is "soft_lutpair144";
  attribute SOFT_HLUTNM of \REC[4]_i_4\ : label is "soft_lutpair134";
  attribute SOFT_HLUTNM of \REC[4]_i_5\ : label is "soft_lutpair152";
  attribute SOFT_HLUTNM of \REC[4]_i_7\ : label is "soft_lutpair144";
  attribute SOFT_HLUTNM of \REC[5]_i_5\ : label is "soft_lutpair120";
  attribute SOFT_HLUTNM of \REC[5]_i_6\ : label is "soft_lutpair126";
  attribute SOFT_HLUTNM of \REC[5]_i_7\ : label is "soft_lutpair152";
  attribute SOFT_HLUTNM of \REC[5]_i_8\ : label is "soft_lutpair157";
  attribute SOFT_HLUTNM of \REC[6]_i_2\ : label is "soft_lutpair126";
  attribute SOFT_HLUTNM of \REC[6]_i_5\ : label is "soft_lutpair120";
  attribute SOFT_HLUTNM of \REC[6]_i_7\ : label is "soft_lutpair113";
  attribute SOFT_HLUTNM of \REC[7]_i_3\ : label is "soft_lutpair119";
  attribute SOFT_HLUTNM of \REC[7]_i_5\ : label is "soft_lutpair118";
  attribute SOFT_HLUTNM of \REC[8]_i_10\ : label is "soft_lutpair119";
  attribute SOFT_HLUTNM of \REC[8]_i_11\ : label is "soft_lutpair118";
  attribute SOFT_HLUTNM of \REC[8]_i_14\ : label is "soft_lutpair143";
  attribute SOFT_HLUTNM of \REC[8]_i_15\ : label is "soft_lutpair138";
  attribute SOFT_HLUTNM of \REC[8]_i_4\ : label is "soft_lutpair131";
  attribute SOFT_HLUTNM of \REC[8]_i_5\ : label is "soft_lutpair150";
  attribute SOFT_HLUTNM of \REC[8]_i_6\ : label is "soft_lutpair113";
  attribute SOFT_HLUTNM of \RXSTATES[0]_i_2\ : label is "soft_lutpair145";
  attribute SOFT_HLUTNM of \RXSTATES[0]_i_5\ : label is "soft_lutpair123";
  attribute SOFT_HLUTNM of \RXSTATES[3]_i_3\ : label is "soft_lutpair140";
  attribute SOFT_HLUTNM of \Reck[0]_i_1\ : label is "soft_lutpair153";
  attribute SOFT_HLUTNM of \Reck[1]_i_1\ : label is "soft_lutpair153";
  attribute SOFT_HLUTNM of \Reck[2]_i_1\ : label is "soft_lutpair129";
  attribute SOFT_HLUTNM of \Reck[3]_i_1\ : label is "soft_lutpair129";
  attribute SOFT_HLUTNM of \Reck[4]_i_2\ : label is "soft_lutpair145";
  attribute SOFT_HLUTNM of \Reck[5]_i_1\ : label is "soft_lutpair123";
  attribute SOFT_HLUTNM of \Reck[6]_i_2\ : label is "soft_lutpair124";
  attribute SOFT_HLUTNM of \Reck[6]_i_3\ : label is "soft_lutpair147";
  attribute SOFT_HLUTNM of \State[0]_i_3\ : label is "soft_lutpair128";
  attribute SOFT_HLUTNM of \State[0]_i_5\ : label is "soft_lutpair125";
  attribute SOFT_HLUTNM of \State[2]_i_2\ : label is "soft_lutpair146";
  attribute SOFT_HLUTNM of \State[2]_i_4\ : label is "soft_lutpair132";
  attribute SOFT_HLUTNM of \State[2]_i_6\ : label is "soft_lutpair114";
  attribute SOFT_HLUTNM of \State[2]_i_8\ : label is "soft_lutpair147";
  attribute SOFT_HLUTNM of \State[2]_i_9\ : label is "soft_lutpair132";
  attribute SOFT_HLUTNM of \TEC[0]_i_2\ : label is "soft_lutpair136";
  attribute SOFT_HLUTNM of \TEC[1]_i_2\ : label is "soft_lutpair156";
  attribute SOFT_HLUTNM of \TEC[1]_i_4\ : label is "soft_lutpair158";
  attribute SOFT_HLUTNM of \TEC[2]_i_2\ : label is "soft_lutpair156";
  attribute SOFT_HLUTNM of \TEC[2]_i_4\ : label is "soft_lutpair151";
  attribute SOFT_HLUTNM of \TEC[2]_i_5\ : label is "soft_lutpair158";
  attribute SOFT_HLUTNM of \TEC[3]_i_2\ : label is "soft_lutpair149";
  attribute SOFT_HLUTNM of \TEC[3]_i_4\ : label is "soft_lutpair135";
  attribute SOFT_HLUTNM of \TEC[3]_i_5\ : label is "soft_lutpair133";
  attribute SOFT_HLUTNM of \TEC[4]_i_2\ : label is "soft_lutpair149";
  attribute SOFT_HLUTNM of \TEC[4]_i_4\ : label is "soft_lutpair155";
  attribute SOFT_HLUTNM of \TEC[4]_i_5\ : label is "soft_lutpair133";
  attribute SOFT_HLUTNM of \TEC[5]_i_2\ : label is "soft_lutpair121";
  attribute SOFT_HLUTNM of \TEC[5]_i_4\ : label is "soft_lutpair117";
  attribute SOFT_HLUTNM of \TEC[6]_i_2\ : label is "soft_lutpair121";
  attribute SOFT_HLUTNM of \TEC[6]_i_4\ : label is "soft_lutpair117";
  attribute SOFT_HLUTNM of \TEC[6]_i_5\ : label is "soft_lutpair116";
  attribute SOFT_HLUTNM of \TEC[6]_i_6\ : label is "soft_lutpair155";
  attribute SOFT_HLUTNM of \TEC[8]_i_12\ : label is "soft_lutpair151";
  attribute SOFT_HLUTNM of \TEC[8]_i_13\ : label is "soft_lutpair116";
  attribute SOFT_HLUTNM of \TEC[8]_i_14\ : label is "soft_lutpair136";
  attribute SOFT_HLUTNM of \TEC[8]_i_18\ : label is "soft_lutpair125";
  attribute SOFT_HLUTNM of \TEC[8]_i_19\ : label is "soft_lutpair124";
  attribute SOFT_HLUTNM of \TEC[8]_i_5\ : label is "soft_lutpair137";
  attribute SOFT_HLUTNM of \TXSTATES[2]_i_1\ : label is "soft_lutpair150";
  attribute SOFT_HLUTNM of \TXSTATES[3]_i_3\ : label is "soft_lutpair137";
  attribute SOFT_HLUTNM of TXpin_i_1 : label is "soft_lutpair138";
  attribute SOFT_HLUTNM of TXpin_i_6 : label is "soft_lutpair141";
  attribute SOFT_HLUTNM of ack_error_i_3 : label is "soft_lutpair140";
  attribute SOFT_HLUTNM of ack_error_i_4 : label is "soft_lutpair146";
begin
  Mode_0_1_sp_1 <= Mode_0_1_sn_1;
  Q(8 downto 0) <= \^q_1\(8 downto 0);
  \REC_reg[7]_0\ <= \^rec_reg[7]_0\;
  \REC_reg[8]_0\(8 downto 0) <= \^rec_reg[8]_0\(8 downto 0);
  \REC_reg[8]_1\ <= \^rec_reg[8]_1\;
  \State_reg[0]_0\(0) <= \^state_reg[0]_0\(0);
  \State_reg[0]_1\ <= \^state_reg[0]_1\;
  \State_reg[0]_2\ <= \^state_reg[0]_2\;
  lastvalue <= \^lastvalue\;
  q_reg <= \^q_reg\;
CANCORE_1_i_1: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => TX,
      I1 => Mode_0_1_sn_1,
      O => RX
    );
CANCORE_1_i_2: unisim.vcomponents.LUT4
    generic map(
      INIT => X"00A2"
    )
        port map (
      I0 => \D_Len[0]_i_3_n_0\,
      I1 => Mode_0(1),
      I2 => Mode_0(2),
      I3 => Mode_0(0),
      O => Mode_0_1_sn_1
    );
\CNT1[4]_i_3\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"4000"
    )
        port map (
      I0 => Mode_0_1_sn_1,
      I1 => Sampled_din,
      I2 => RXBUS_d,
      I3 => \^q_reg\,
      O => RXOUT_reg
    );
\Cnt[0]_i_1__1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BB33BB30BB33BB33"
    )
        port map (
      I0 => \Cnt[0]_i_2__1_n_0\,
      I1 => \Cnt_reg_n_0_[0]\,
      I2 => \Cnt[0]_i_3__1_n_0\,
      I3 => \Cnt[0]_i_4__1_n_0\,
      I4 => \Cnt[0]_i_5__0_n_0\,
      I5 => \Cnt[0]_i_6_n_0\,
      O => Cntr(0)
    );
\Cnt[0]_i_2__1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000FFFEFFFE0000"
    )
        port map (
      I0 => \TECin_reg_n_0_[7]\,
      I1 => \RECin_reg_n_0_[8]\,
      I2 => \TECin_reg_n_0_[8]\,
      I3 => \RECin_reg_n_0_[7]\,
      I4 => \^lastvalue\,
      I5 => Sampled_din,
      O => \Cnt[0]_i_2__1_n_0\
    );
\Cnt[0]_i_3__1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00040804"
    )
        port map (
      I0 => \^state_reg[0]_0\(0),
      I1 => State(1),
      I2 => State(2),
      I3 => Sampled_din,
      I4 => \State[2]_i_8_n_0\,
      O => \Cnt[0]_i_3__1_n_0\
    );
\Cnt[0]_i_4__1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0010"
    )
        port map (
      I0 => State(2),
      I1 => State(1),
      I2 => \^state_reg[0]_0\(0),
      I3 => \Cnt[3]_i_7__0_n_0\,
      O => \Cnt[0]_i_4__1_n_0\
    );
\Cnt[0]_i_5__0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000002"
    )
        port map (
      I0 => ack_error_i_3_n_0,
      I1 => \TECin_reg_n_0_[7]\,
      I2 => \RECin_reg_n_0_[8]\,
      I3 => \TECin_reg_n_0_[8]\,
      I4 => \RECin_reg_n_0_[7]\,
      O => \Cnt[0]_i_5__0_n_0\
    );
\Cnt[0]_i_6\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FD7FFD5F"
    )
        port map (
      I0 => State(2),
      I1 => State(1),
      I2 => Sampled_din,
      I3 => \^state_reg[0]_0\(0),
      I4 => \Reck[6]_i_3_n_0\,
      O => \Cnt[0]_i_6_n_0\
    );
\Cnt[1]_i_1__1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"60666666"
    )
        port map (
      I0 => \Cnt_reg_n_0_[0]\,
      I1 => \Cnt_reg_n_0_[1]\,
      I2 => \Cnt[1]_i_2__1_n_0\,
      I3 => \Cnt[3]_i_3__0_n_0\,
      I4 => \Cnt[2]_i_4__1_n_0\,
      O => Cntr(1)
    );
\Cnt[1]_i_2__1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0080"
    )
        port map (
      I0 => State(1),
      I1 => State(2),
      I2 => Sampled_din,
      I3 => \^state_reg[0]_0\(0),
      O => \Cnt[1]_i_2__1_n_0\
    );
\Cnt[2]_i_1__1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"7878780078787878"
    )
        port map (
      I0 => \Cnt_reg_n_0_[1]\,
      I1 => \Cnt_reg_n_0_[0]\,
      I2 => \Cnt_reg_n_0_[2]\,
      I3 => \Cnt[2]_i_2__1_n_0\,
      I4 => \Cnt[2]_i_3__1_n_0\,
      I5 => \Cnt[2]_i_4__1_n_0\,
      O => Cntr(2)
    );
\Cnt[2]_i_2__1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00040000"
    )
        port map (
      I0 => \Cnt[3]_i_7__0_n_0\,
      I1 => \^state_reg[0]_0\(0),
      I2 => Sampled_din,
      I3 => State(1),
      I4 => State(2),
      O => \Cnt[2]_i_2__1_n_0\
    );
\Cnt[2]_i_3__1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"08"
    )
        port map (
      I0 => State(2),
      I1 => Sampled_din,
      I2 => \^state_reg[0]_0\(0),
      O => \Cnt[2]_i_3__1_n_0\
    );
\Cnt[2]_i_4__1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F1F1F100F100F100"
    )
        port map (
      I0 => \^state_reg[0]_0\(0),
      I1 => \Cnt[2]_i_5__1_n_0\,
      I2 => \Cnt[2]_i_6__1_n_0\,
      I3 => \Cnt[3]_i_4__1_n_0\,
      I4 => \Cnt[3]_i_10__0_n_0\,
      I5 => \Cnt[3]_i_7__0_n_0\,
      O => \Cnt[2]_i_4__1_n_0\
    );
\Cnt[2]_i_5__1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"55551555"
    )
        port map (
      I0 => Sampled_din,
      I1 => \Cnt_reg_n_0_[1]\,
      I2 => \Cnt_reg_n_0_[0]\,
      I3 => \Cnt_reg_n_0_[2]\,
      I4 => \Cnt_reg_n_0_[3]\,
      O => \Cnt[2]_i_5__1_n_0\
    );
\Cnt[2]_i_6__1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"F8FFFAFF"
    )
        port map (
      I0 => \^state_reg[0]_0\(0),
      I1 => \State[2]_i_8_n_0\,
      I2 => State(2),
      I3 => State(1),
      I4 => Sampled_din,
      O => \Cnt[2]_i_6__1_n_0\
    );
\Cnt[3]_i_10__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0001"
    )
        port map (
      I0 => \RECin_reg_n_0_[7]\,
      I1 => \TECin_reg_n_0_[8]\,
      I2 => \RECin_reg_n_0_[8]\,
      I3 => \TECin_reg_n_0_[7]\,
      O => \Cnt[3]_i_10__0_n_0\
    );
\Cnt[3]_i_11\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2AAA"
    )
        port map (
      I0 => \Cnt_reg_n_0_[3]\,
      I1 => \Cnt_reg_n_0_[2]\,
      I2 => \Cnt_reg_n_0_[0]\,
      I3 => \Cnt_reg_n_0_[1]\,
      O => \Cnt[3]_i_11_n_0\
    );
\Cnt[3]_i_2__1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFF0770"
    )
        port map (
      I0 => \Cnt[3]_i_3__0_n_0\,
      I1 => \Cnt[3]_i_4__1_n_0\,
      I2 => \Cnt_reg_n_0_[3]\,
      I3 => \Cnt[3]_i_5__0_n_0\,
      I4 => \Cnt[3]_i_6__0_n_0\,
      O => Cntr(3)
    );
\Cnt[3]_i_3__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFBFFFFF3FBFF"
    )
        port map (
      I0 => \Reck[6]_i_3_n_0\,
      I1 => State(2),
      I2 => State(1),
      I3 => Sampled_din,
      I4 => \^state_reg[0]_0\(0),
      I5 => \Cnt[3]_i_7__0_n_0\,
      O => \Cnt[3]_i_3__0_n_0\
    );
\Cnt[3]_i_4__1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000D55DFFFFFFFF"
    )
        port map (
      I0 => \Cnt_reg[3]_0\,
      I1 => \Cnt[3]_i_9__0_n_0\,
      I2 => \Cnt_reg_n_0_[0]\,
      I3 => \Cnt_reg_n_0_[2]\,
      I4 => \Cnt[3]_i_10__0_n_0\,
      I5 => ack_error_i_3_n_0,
      O => \Cnt[3]_i_4__1_n_0\
    );
\Cnt[3]_i_5__0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"80"
    )
        port map (
      I0 => \Cnt_reg_n_0_[1]\,
      I1 => \Cnt_reg_n_0_[0]\,
      I2 => \Cnt_reg_n_0_[2]\,
      O => \Cnt[3]_i_5__0_n_0\
    );
\Cnt[3]_i_6__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00E00000A00A0000"
    )
        port map (
      I0 => \Cnt[3]_i_11_n_0\,
      I1 => \State[2]_i_6_n_0\,
      I2 => Sampled_din,
      I3 => State(2),
      I4 => State(1),
      I5 => \^state_reg[0]_0\(0),
      O => \Cnt[3]_i_6__0_n_0\
    );
\Cnt[3]_i_7__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0008"
    )
        port map (
      I0 => \Cnt_reg_n_0_[0]\,
      I1 => \Cnt_reg_n_0_[2]\,
      I2 => \Cnt_reg_n_0_[3]\,
      I3 => \Cnt_reg_n_0_[1]\,
      O => \Cnt[3]_i_7__0_n_0\
    );
\Cnt[3]_i_9__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \Cnt_reg_n_0_[1]\,
      I1 => \Cnt_reg_n_0_[3]\,
      O => \Cnt[3]_i_9__0_n_0\
    );
\Cnt_reg[0]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \Cnt_reg[0]_0\(0),
      CLR => ack_error_reg_0,
      D => Cntr(0),
      Q => \Cnt_reg_n_0_[0]\
    );
\Cnt_reg[1]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \Cnt_reg[0]_0\(0),
      CLR => ack_error_reg_0,
      D => Cntr(1),
      Q => \Cnt_reg_n_0_[1]\
    );
\Cnt_reg[2]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \Cnt_reg[0]_0\(0),
      CLR => ack_error_reg_0,
      D => Cntr(2),
      Q => \Cnt_reg_n_0_[2]\
    );
\Cnt_reg[3]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \Cnt_reg[0]_0\(0),
      CLR => ack_error_reg_0,
      D => Cntr(3),
      Q => \Cnt_reg_n_0_[3]\
    );
\D_Len[0]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00003A33"
    )
        port map (
      I0 => \D_Len[0]_i_3_n_0\,
      I1 => \^q\,
      I2 => Mode_0(1),
      I3 => Mode_0(2),
      I4 => Mode_0(0),
      O => \^q_reg\
    );
\D_Len[0]_i_3\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"4555"
    )
        port map (
      I0 => \^q_1\(8),
      I1 => \D_Len[0]_i_2_0\,
      I2 => TX_from_Err,
      I3 => AckTakeOver,
      O => \D_Len[0]_i_3_n_0\
    );
\REC[0]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0077035533773377"
    )
        port map (
      I0 => \REC[1]_i_2_n_0\,
      I1 => \REC[0]_i_2_n_0\,
      I2 => \^rec_reg[8]_0\(8),
      I3 => \^rec_reg[8]_0\(0),
      I4 => \REC[8]_i_9_n_0\,
      I5 => \REC[8]_i_5_n_0\,
      O => \REC[0]_i_1_n_0\
    );
\REC[0]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8AFA8A8AFFFFFFFF"
    )
        port map (
      I0 => \REC[8]_i_13_n_0\,
      I1 => \REC[0]_i_3_n_0\,
      I2 => \^rec_reg[8]_0\(0),
      I3 => \^state_reg[0]_1\,
      I4 => req_Error_RX,
      I5 => \REC[8]_i_6_n_0\,
      O => \REC[0]_i_2_n_0\
    );
\REC[0]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"1000000000000000"
    )
        port map (
      I0 => \REC[0]_i_4_n_0\,
      I1 => imTX,
      I2 => \^rec_reg[8]_0\(8),
      I3 => \State[2]_i_6_n_0\,
      I4 => \REC[8]_i_15_n_0\,
      I5 => \REC[0]_i_2_0\,
      O => \REC[0]_i_3_n_0\
    );
\REC[0]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000002"
    )
        port map (
      I0 => \REC[5]_i_7_n_0\,
      I1 => \^rec_reg[8]_0\(5),
      I2 => \^rec_reg[8]_0\(0),
      I3 => \^rec_reg[8]_0\(1),
      I4 => \^rec_reg[8]_0\(7),
      I5 => \^rec_reg[8]_0\(6),
      O => \REC[0]_i_4_n_0\
    );
\REC[1]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5F7FFF3F55550000"
    )
        port map (
      I0 => \REC[1]_i_2_n_0\,
      I1 => \REC[1]_i_3_n_0\,
      I2 => \REC[8]_i_5_n_0\,
      I3 => \REC[8]_i_9_n_0\,
      I4 => \REC[1]_i_4_n_0\,
      I5 => \REC[1]_i_5_n_0\,
      O => \REC[1]_i_1_n_0\
    );
\REC[1]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"EF"
    )
        port map (
      I0 => \^rec_reg[8]_0\(7),
      I1 => \^rec_reg[8]_0\(8),
      I2 => \REC[4]_i_6_n_0\,
      O => \REC[1]_i_2_n_0\
    );
\REC[1]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => \^rec_reg[8]_0\(8),
      I1 => \^rec_reg[8]_0\(1),
      O => \REC[1]_i_3_n_0\
    );
\REC[1]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^rec_reg[8]_0\(1),
      I1 => \^rec_reg[8]_0\(0),
      O => \REC[1]_i_4_n_0\
    );
\REC[1]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFF515D00000000"
    )
        port map (
      I0 => \REC[8]_i_13_n_0\,
      I1 => req_Error_RX,
      I2 => \^state_reg[0]_1\,
      I3 => \REC[1]_i_4_n_0\,
      I4 => \REC[1]_i_6_n_0\,
      I5 => \REC[8]_i_6_n_0\,
      O => \REC[1]_i_5_n_0\
    );
\REC[1]_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"4F44444400000000"
    )
        port map (
      I0 => \^rec_reg[8]_0\(8),
      I1 => \REC[2]_i_7_n_0\,
      I2 => imTX,
      I3 => \Cnt[0]_i_5__0_n_0\,
      I4 => Sampled_din,
      I5 => \^rec_reg[8]_0\(1),
      O => \REC[1]_i_6_n_0\
    );
\REC[2]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFBFFFBFAAAAAAAA"
    )
        port map (
      I0 => \REC[2]_i_2_n_0\,
      I1 => \REC[2]_i_3_n_0\,
      I2 => \REC[8]_i_5_n_0\,
      I3 => \REC[8]_i_9_n_0\,
      I4 => \REC[2]_i_4_n_0\,
      I5 => \REC[2]_i_5_n_0\,
      O => \REC[2]_i_1_n_0\
    );
\REC[2]_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"00E1"
    )
        port map (
      I0 => \^rec_reg[8]_0\(1),
      I1 => \^rec_reg[8]_0\(0),
      I2 => \^rec_reg[8]_0\(2),
      I3 => \REC[1]_i_2_n_0\,
      O => \REC[2]_i_2_n_0\
    );
\REC[2]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => \^rec_reg[8]_0\(8),
      I1 => \^rec_reg[8]_0\(2),
      O => \REC[2]_i_3_n_0\
    );
\REC[2]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"95"
    )
        port map (
      I0 => \^rec_reg[8]_0\(2),
      I1 => \^rec_reg[8]_0\(0),
      I2 => \^rec_reg[8]_0\(1),
      O => \REC[2]_i_4_n_0\
    );
\REC[2]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFF515D00000000"
    )
        port map (
      I0 => \REC[8]_i_13_n_0\,
      I1 => req_Error_RX,
      I2 => \^state_reg[0]_1\,
      I3 => \REC[2]_i_4_n_0\,
      I4 => \REC[2]_i_6_n_0\,
      I5 => \REC[8]_i_6_n_0\,
      O => \REC[2]_i_5_n_0\
    );
\REC[2]_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"4F44444400000000"
    )
        port map (
      I0 => \^rec_reg[8]_0\(8),
      I1 => \REC[2]_i_7_n_0\,
      I2 => imTX,
      I3 => \Cnt[0]_i_5__0_n_0\,
      I4 => Sampled_din,
      I5 => \^rec_reg[8]_0\(2),
      O => \REC[2]_i_6_n_0\
    );
\REC[2]_i_7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000001000000000"
    )
        port map (
      I0 => imTX,
      I1 => State(2),
      I2 => State(1),
      I3 => \^state_reg[0]_0\(0),
      I4 => Sampled_din,
      I5 => \State[2]_i_6_n_0\,
      O => \REC[2]_i_7_n_0\
    );
\REC[3]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFAFBFBFAAAAAAAA"
    )
        port map (
      I0 => \REC[3]_i_2_n_0\,
      I1 => \REC[3]_i_3_n_0\,
      I2 => \REC[8]_i_5_n_0\,
      I3 => \REC[3]_i_4_n_0\,
      I4 => \REC[8]_i_9_n_0\,
      I5 => \REC[3]_i_5_n_0\,
      O => \REC[3]_i_1_n_0\
    );
\REC[3]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"88888882AAAAAAAA"
    )
        port map (
      I0 => \REC[4]_i_6_n_0\,
      I1 => \^rec_reg[8]_0\(3),
      I2 => \^rec_reg[8]_0\(2),
      I3 => \^rec_reg[8]_0\(1),
      I4 => \^rec_reg[8]_0\(0),
      I5 => \^rec_reg[8]_1\,
      O => \REC[3]_i_2_n_0\
    );
\REC[3]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \^rec_reg[8]_0\(8),
      I1 => \^rec_reg[8]_0\(3),
      O => \REC[3]_i_3_n_0\
    );
\REC[3]_i_4\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6AAA"
    )
        port map (
      I0 => \^rec_reg[8]_0\(3),
      I1 => \^rec_reg[8]_0\(2),
      I2 => \^rec_reg[8]_0\(1),
      I3 => \^rec_reg[8]_0\(0),
      O => \REC[3]_i_4_n_0\
    );
\REC[3]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFCF000055C50000"
    )
        port map (
      I0 => \REC[8]_i_13_n_0\,
      I1 => \REC[3]_i_4_n_0\,
      I2 => req_Error_RX,
      I3 => \^state_reg[0]_1\,
      I4 => \REC[8]_i_6_n_0\,
      I5 => \REC[3]_i_6_n_0\,
      O => \REC[3]_i_5_n_0\
    );
\REC[3]_i_6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"04"
    )
        port map (
      I0 => \^rec_reg[8]_0\(3),
      I1 => \REC[8]_i_13_n_0\,
      I2 => \REC[0]_i_3_n_0\,
      O => \REC[3]_i_6_n_0\
    );
\REC[4]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BABBBAAABBBBBBBB"
    )
        port map (
      I0 => \REC[4]_i_2_n_0\,
      I1 => \REC[4]_i_3_n_0\,
      I2 => \REC[4]_i_4_n_0\,
      I3 => \REC[8]_i_9_n_0\,
      I4 => \REC[4]_i_5_n_0\,
      I5 => \REC[8]_i_5_n_0\,
      O => \REC[4]_i_1_n_0\
    );
\REC[4]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"88888288AAAAAAAA"
    )
        port map (
      I0 => \REC[4]_i_6_n_0\,
      I1 => \^rec_reg[8]_0\(4),
      I2 => \^rec_reg[8]_0\(3),
      I3 => \REC[5]_i_8_n_0\,
      I4 => \^rec_reg[8]_0\(2),
      I5 => \^rec_reg[8]_1\,
      O => \REC[4]_i_2_n_0\
    );
\REC[4]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"BBBBBFBB"
    )
        port map (
      I0 => \REC[4]_i_7_n_0\,
      I1 => \REC[8]_i_6_n_0\,
      I2 => \^state_reg[0]_1\,
      I3 => req_Error_RX,
      I4 => \REC[4]_i_4_n_0\,
      O => \REC[4]_i_3_n_0\
    );
\REC[4]_i_4\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"6AAAAAAA"
    )
        port map (
      I0 => \^rec_reg[8]_0\(4),
      I1 => \^rec_reg[8]_0\(0),
      I2 => \^rec_reg[8]_0\(1),
      I3 => \^rec_reg[8]_0\(2),
      I4 => \^rec_reg[8]_0\(3),
      O => \REC[4]_i_4_n_0\
    );
\REC[4]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"06"
    )
        port map (
      I0 => \^rec_reg[8]_0\(3),
      I1 => \^rec_reg[8]_0\(4),
      I2 => \^rec_reg[8]_0\(8),
      O => \REC[4]_i_5_n_0\
    );
\REC[4]_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000AA8A0000"
    )
        port map (
      I0 => \REC[4]_i_8_n_0\,
      I1 => \^state_reg[0]_0\(0),
      I2 => State(2),
      I3 => State(1),
      I4 => \REC_reg[0]_0\,
      I5 => donefromrxr_reg_n_0,
      O => \REC[4]_i_6_n_0\
    );
\REC[4]_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"A88A"
    )
        port map (
      I0 => \REC[8]_i_13_n_0\,
      I1 => \REC[0]_i_3_n_0\,
      I2 => \^rec_reg[8]_0\(4),
      I3 => \^rec_reg[8]_0\(3),
      O => \REC[4]_i_7_n_0\
    );
\REC[4]_i_8\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFBFFFFFFFF"
    )
        port map (
      I0 => \^rec_reg[8]_0\(6),
      I1 => \^rec_reg[8]_1\,
      I2 => \^rec_reg[8]_0\(1),
      I3 => \^rec_reg[8]_0\(0),
      I4 => \^rec_reg[8]_0\(5),
      I5 => \REC[5]_i_7_n_0\,
      O => \REC[4]_i_8_n_0\
    );
\REC[5]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BABBBAAABBBBBBBB"
    )
        port map (
      I0 => \REC[5]_i_2_n_0\,
      I1 => \REC[5]_i_3_n_0\,
      I2 => \REC[5]_i_4_n_0\,
      I3 => \REC[8]_i_9_n_0\,
      I4 => \REC[5]_i_5_n_0\,
      I5 => \REC[8]_i_5_n_0\,
      O => \REC[5]_i_1_n_0\
    );
\REC[5]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"22AAAAAAA2222222"
    )
        port map (
      I0 => \REC[6]_i_7_n_0\,
      I1 => \^rec_reg[8]_1\,
      I2 => \^rec_reg[8]_0\(6),
      I3 => \REC[5]_i_7_n_0\,
      I4 => \REC[5]_i_8_n_0\,
      I5 => \^rec_reg[8]_0\(5),
      O => \REC[5]_i_2_n_0\
    );
\REC[5]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"BBBBBFBB"
    )
        port map (
      I0 => \REC[5]_i_9_n_0\,
      I1 => \REC[8]_i_6_n_0\,
      I2 => \^state_reg[0]_1\,
      I3 => req_Error_RX,
      I4 => \REC[5]_i_4_n_0\,
      O => \REC[5]_i_3_n_0\
    );
\REC[5]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"6AAAAAAAAAAAAAAA"
    )
        port map (
      I0 => \^rec_reg[8]_0\(5),
      I1 => \^rec_reg[8]_0\(0),
      I2 => \^rec_reg[8]_0\(1),
      I3 => \^rec_reg[8]_0\(2),
      I4 => \^rec_reg[8]_0\(4),
      I5 => \^rec_reg[8]_0\(3),
      O => \REC[5]_i_4_n_0\
    );
\REC[5]_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"1540"
    )
        port map (
      I0 => \^rec_reg[8]_0\(8),
      I1 => \^rec_reg[8]_0\(4),
      I2 => \^rec_reg[8]_0\(3),
      I3 => \^rec_reg[8]_0\(5),
      O => \REC[5]_i_5_n_0\
    );
\REC[5]_i_6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \^rec_reg[8]_0\(8),
      I1 => \^rec_reg[8]_0\(7),
      O => \^rec_reg[8]_1\
    );
\REC[5]_i_7\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"01"
    )
        port map (
      I0 => \^rec_reg[8]_0\(2),
      I1 => \^rec_reg[8]_0\(3),
      I2 => \^rec_reg[8]_0\(4),
      O => \REC[5]_i_7_n_0\
    );
\REC[5]_i_8\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \^rec_reg[8]_0\(1),
      I1 => \^rec_reg[8]_0\(0),
      O => \REC[5]_i_8_n_0\
    );
\REC[5]_i_9\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"AAAA8222"
    )
        port map (
      I0 => \REC[8]_i_13_n_0\,
      I1 => \^rec_reg[8]_0\(5),
      I2 => \^rec_reg[8]_0\(3),
      I3 => \^rec_reg[8]_0\(4),
      I4 => \REC[7]_i_7_n_0\,
      O => \REC[5]_i_9_n_0\
    );
\REC[6]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BABBBAAABBBBBBBB"
    )
        port map (
      I0 => \REC[6]_i_2_n_0\,
      I1 => \REC[6]_i_3_n_0\,
      I2 => \REC[6]_i_4_n_0\,
      I3 => \REC[8]_i_9_n_0\,
      I4 => \REC[6]_i_5_n_0\,
      I5 => \REC[8]_i_5_n_0\,
      O => \REC[6]_i_1_n_0\
    );
\REC[6]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"88888880"
    )
        port map (
      I0 => \REC[6]_i_6_n_0\,
      I1 => \REC[6]_i_7_n_0\,
      I2 => \^rec_reg[8]_0\(8),
      I3 => \^rec_reg[8]_0\(6),
      I4 => \^rec_reg[8]_0\(7),
      O => \REC[6]_i_2_n_0\
    );
\REC[6]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFF4004FFFFFFFF"
    )
        port map (
      I0 => \^state_reg[0]_1\,
      I1 => req_Error_RX,
      I2 => \REC[6]_i_8_n_0\,
      I3 => \^rec_reg[8]_0\(6),
      I4 => \REC[6]_i_9_n_0\,
      I5 => \REC[8]_i_6_n_0\,
      O => \REC[6]_i_3_n_0\
    );
\REC[6]_i_4\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"6AAAAAAA"
    )
        port map (
      I0 => \^rec_reg[8]_0\(6),
      I1 => \REC[7]_i_5_n_0\,
      I2 => \^rec_reg[8]_0\(3),
      I3 => \^rec_reg[8]_0\(4),
      I4 => \^rec_reg[8]_0\(5),
      O => \REC[6]_i_4_n_0\
    );
\REC[6]_i_5\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"15554000"
    )
        port map (
      I0 => \^rec_reg[8]_0\(8),
      I1 => \^rec_reg[8]_0\(3),
      I2 => \^rec_reg[8]_0\(4),
      I3 => \^rec_reg[8]_0\(5),
      I4 => \^rec_reg[8]_0\(6),
      O => \REC[6]_i_5_n_0\
    );
\REC[6]_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFFFFD"
    )
        port map (
      I0 => \REC[5]_i_7_n_0\,
      I1 => \^rec_reg[8]_0\(5),
      I2 => \^rec_reg[8]_0\(0),
      I3 => \^rec_reg[8]_0\(1),
      I4 => \^rec_reg[8]_0\(7),
      I5 => \^rec_reg[8]_0\(8),
      O => \REC[6]_i_6_n_0\
    );
\REC[6]_i_7\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"44444044"
    )
        port map (
      I0 => donefromrxr_reg_n_0,
      I1 => \REC_reg[0]_0\,
      I2 => State(1),
      I3 => State(2),
      I4 => \^state_reg[0]_0\(0),
      O => \REC[6]_i_7_n_0\
    );
\REC[6]_i_8\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8000000000000000"
    )
        port map (
      I0 => \^rec_reg[8]_0\(5),
      I1 => \^rec_reg[8]_0\(4),
      I2 => \^rec_reg[8]_0\(3),
      I3 => \^rec_reg[8]_0\(2),
      I4 => \^rec_reg[8]_0\(1),
      I5 => \^rec_reg[8]_0\(0),
      O => \REC[6]_i_8_n_0\
    );
\REC[6]_i_9\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAAAAA82222222"
    )
        port map (
      I0 => \REC[8]_i_13_n_0\,
      I1 => \^rec_reg[8]_0\(6),
      I2 => \^rec_reg[8]_0\(5),
      I3 => \^rec_reg[8]_0\(4),
      I4 => \^rec_reg[8]_0\(3),
      I5 => \REC[7]_i_7_n_0\,
      O => \REC[6]_i_9_n_0\
    );
\REC[7]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000008F8FDF8F"
    )
        port map (
      I0 => \REC[8]_i_9_n_0\,
      I1 => \REC[7]_i_2_n_0\,
      I2 => \REC[8]_i_5_n_0\,
      I3 => \REC[7]_i_3_n_0\,
      I4 => \^rec_reg[8]_0\(8),
      I5 => \REC[7]_i_4_n_0\,
      O => \REC[7]_i_1_n_0\
    );
\REC[7]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"6AAAAAAAAAAAAAAA"
    )
        port map (
      I0 => \^rec_reg[8]_0\(7),
      I1 => \^rec_reg[8]_0\(6),
      I2 => \^rec_reg[8]_0\(5),
      I3 => \^rec_reg[8]_0\(4),
      I4 => \^rec_reg[8]_0\(3),
      I5 => \REC[7]_i_5_n_0\,
      O => \REC[7]_i_2_n_0\
    );
\REC[7]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"6AAAAAAA"
    )
        port map (
      I0 => \^rec_reg[8]_0\(7),
      I1 => \^rec_reg[8]_0\(6),
      I2 => \^rec_reg[8]_0\(3),
      I3 => \^rec_reg[8]_0\(4),
      I4 => \^rec_reg[8]_0\(5),
      O => \REC[7]_i_3_n_0\
    );
\REC[7]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0404FF04FFFFFFFF"
    )
        port map (
      I0 => \^state_reg[0]_1\,
      I1 => req_Error_RX,
      I2 => \REC[7]_i_2_n_0\,
      I3 => \REC[8]_i_13_n_0\,
      I4 => \REC[7]_i_6_n_0\,
      I5 => \REC[8]_i_6_n_0\,
      O => \REC[7]_i_4_n_0\
    );
\REC[7]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"80"
    )
        port map (
      I0 => \^rec_reg[8]_0\(0),
      I1 => \^rec_reg[8]_0\(1),
      I2 => \^rec_reg[8]_0\(2),
      O => \REC[7]_i_5_n_0\
    );
\REC[7]_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000007FFF8000"
    )
        port map (
      I0 => \^rec_reg[8]_0\(5),
      I1 => \^rec_reg[8]_0\(4),
      I2 => \^rec_reg[8]_0\(3),
      I3 => \^rec_reg[8]_0\(6),
      I4 => \^rec_reg[8]_0\(7),
      I5 => \REC[7]_i_7_n_0\,
      O => \REC[7]_i_6_n_0\
    );
\REC[7]_i_7\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \REC[8]_i_17_n_0\,
      I1 => imTX,
      O => \REC[7]_i_7_n_0\
    );
\REC[8]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0222AAAAAAAAAAAA"
    )
        port map (
      I0 => \Cnt_reg[0]_0\(0),
      I1 => imTX,
      I2 => \REC[8]_i_3_n_0\,
      I3 => \REC[8]_i_4_n_0\,
      I4 => \REC[8]_i_5_n_0\,
      I5 => \REC[8]_i_6_n_0\,
      O => \REC[8]_i_1_n_0\
    );
\REC[8]_i_10\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"80000000"
    )
        port map (
      I0 => \^rec_reg[8]_0\(6),
      I1 => \^rec_reg[8]_0\(3),
      I2 => \^rec_reg[8]_0\(4),
      I3 => \^rec_reg[8]_0\(5),
      I4 => \^rec_reg[8]_0\(7),
      O => \REC[8]_i_10_n_0\
    );
\REC[8]_i_11\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"6AAAAAAA"
    )
        port map (
      I0 => \^rec_reg[8]_0\(8),
      I1 => \^rec_reg[8]_0\(0),
      I2 => \^rec_reg[8]_0\(1),
      I3 => \^rec_reg[8]_0\(2),
      I4 => \REC[8]_i_10_n_0\,
      O => \REC[8]_i_11_n_0\
    );
\REC[8]_i_12\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FBAAEAAA"
    )
        port map (
      I0 => \State[2]_i_4_n_0\,
      I1 => \REC[8]_i_7_0\,
      I2 => \State_reg[0]_5\,
      I3 => \^state_reg[0]_2\,
      I4 => \^q_1\(8),
      O => \REC[8]_i_12_n_0\
    );
\REC[8]_i_13\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5054505000040000"
    )
        port map (
      I0 => imTX,
      I1 => \State[2]_i_6_n_0\,
      I2 => Sampled_din,
      I3 => \^state_reg[0]_0\(0),
      I4 => \REC[8]_i_15_n_0\,
      I5 => \Cnt[0]_i_5__0_n_0\,
      O => \REC[8]_i_13_n_0\
    );
\REC[8]_i_14\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0082"
    )
        port map (
      I0 => \REC[8]_i_13_n_0\,
      I1 => \^rec_reg[8]_0\(8),
      I2 => \REC[8]_i_10_n_0\,
      I3 => \REC[8]_i_17_n_0\,
      O => \REC[8]_i_14_n_0\
    );
\REC[8]_i_15\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => State(1),
      I1 => State(2),
      O => \REC[8]_i_15_n_0\
    );
\REC[8]_i_17\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0004000000000000"
    )
        port map (
      I0 => \REC[0]_i_4_n_0\,
      I1 => \State[2]_i_6_n_0\,
      I2 => Sampled_din,
      I3 => \^state_reg[0]_0\(0),
      I4 => \REC[8]_i_15_n_0\,
      I5 => \^rec_reg[8]_0\(8),
      O => \REC[8]_i_17_n_0\
    );
\REC[8]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BBBBBBBBABAABBBB"
    )
        port map (
      I0 => \REC[8]_i_7_n_0\,
      I1 => \REC[8]_i_8_n_0\,
      I2 => \REC[8]_i_9_n_0\,
      I3 => \REC[8]_i_10_n_0\,
      I4 => \REC[8]_i_5_n_0\,
      I5 => \REC[8]_i_11_n_0\,
      O => \REC[8]_i_2_n_0\
    );
\REC[8]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFB8FFFF"
    )
        port map (
      I0 => \State[2]_i_3_n_0\,
      I1 => State(2),
      I2 => \REC[8]_i_12_n_0\,
      I3 => \State[1]_i_2_n_0\,
      I4 => \TEC[8]_i_18_n_0\,
      I5 => \State[0]_i_2_n_0\,
      O => \REC[8]_i_3_n_0\
    );
\REC[8]_i_4\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"DFFF"
    )
        port map (
      I0 => Sampled_din,
      I1 => State(1),
      I2 => State(2),
      I3 => \^state_reg[0]_0\(0),
      O => \REC[8]_i_4_n_0\
    );
\REC[8]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"45"
    )
        port map (
      I0 => \REC[8]_i_13_n_0\,
      I1 => \^state_reg[0]_1\,
      I2 => req_Error_RX,
      O => \REC[8]_i_5_n_0\
    );
\REC[8]_i_6\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"BBBBB0BB"
    )
        port map (
      I0 => donefromrxr_reg_n_0,
      I1 => \REC_reg[0]_0\,
      I2 => State(1),
      I3 => State(2),
      I4 => \^state_reg[0]_0\(0),
      O => \REC[8]_i_6_n_0\
    );
\REC[8]_i_7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAA888A8AAAAAAAA"
    )
        port map (
      I0 => \TEC[8]_i_19_n_0\,
      I1 => \State[1]_i_2_n_0\,
      I2 => \REC[8]_i_12_n_0\,
      I3 => State(2),
      I4 => \State[2]_i_3_n_0\,
      I5 => \State[0]_i_2_n_0\,
      O => \REC[8]_i_7_n_0\
    );
\REC[8]_i_8\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFF5575"
    )
        port map (
      I0 => \REC[8]_i_6_n_0\,
      I1 => \^state_reg[0]_1\,
      I2 => req_Error_RX,
      I3 => \REC[8]_i_11_n_0\,
      I4 => \REC[8]_i_14_n_0\,
      O => \REC[8]_i_8_n_0\
    );
\REC[8]_i_9\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000001000"
    )
        port map (
      I0 => imTX,
      I1 => \State[0]_i_2_n_0\,
      I2 => \^state_reg[0]_0\(0),
      I3 => \REC[8]_i_15_n_0\,
      I4 => \State[1]_i_2_n_0\,
      I5 => \TEC[8]_i_17_n_0\,
      O => \REC[8]_i_9_n_0\
    );
\REC_reg[0]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \REC[8]_i_1_n_0\,
      CLR => ack_error_reg_0,
      D => \REC[0]_i_1_n_0\,
      Q => \^rec_reg[8]_0\(0)
    );
\REC_reg[1]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \REC[8]_i_1_n_0\,
      CLR => ack_error_reg_0,
      D => \REC[1]_i_1_n_0\,
      Q => \^rec_reg[8]_0\(1)
    );
\REC_reg[2]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \REC[8]_i_1_n_0\,
      CLR => ack_error_reg_0,
      D => \REC[2]_i_1_n_0\,
      Q => \^rec_reg[8]_0\(2)
    );
\REC_reg[3]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \REC[8]_i_1_n_0\,
      CLR => ack_error_reg_0,
      D => \REC[3]_i_1_n_0\,
      Q => \^rec_reg[8]_0\(3)
    );
\REC_reg[4]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \REC[8]_i_1_n_0\,
      CLR => ack_error_reg_0,
      D => \REC[4]_i_1_n_0\,
      Q => \^rec_reg[8]_0\(4)
    );
\REC_reg[5]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \REC[8]_i_1_n_0\,
      CLR => ack_error_reg_0,
      D => \REC[5]_i_1_n_0\,
      Q => \^rec_reg[8]_0\(5)
    );
\REC_reg[6]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \REC[8]_i_1_n_0\,
      CLR => ack_error_reg_0,
      D => \REC[6]_i_1_n_0\,
      Q => \^rec_reg[8]_0\(6)
    );
\REC_reg[7]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \REC[8]_i_1_n_0\,
      CLR => ack_error_reg_0,
      D => \REC[7]_i_1_n_0\,
      Q => \^rec_reg[8]_0\(7)
    );
\REC_reg[8]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \REC[8]_i_1_n_0\,
      CLR => ack_error_reg_0,
      D => \REC[8]_i_2_n_0\,
      Q => \^rec_reg[8]_0\(8)
    );
\RECin_reg[7]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => RECin(0),
      CLR => ack_error_reg_0,
      D => \^rec_reg[8]_0\(7),
      Q => \RECin_reg_n_0_[7]\
    );
\RECin_reg[8]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => RECin(0),
      CLR => ack_error_reg_0,
      D => \^rec_reg[8]_0\(8),
      Q => \RECin_reg_n_0_[8]\
    );
RXBUS_d_i_1: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \^q_reg\,
      O => RXBUS
    );
\RXSTATES[0]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B7"
    )
        port map (
      I0 => \^state_reg[0]_0\(0),
      I1 => State(2),
      I2 => State(1),
      O => \State_reg[0]_3\
    );
\RXSTATES[0]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"54"
    )
        port map (
      I0 => State(2),
      I1 => State(1),
      I2 => \^state_reg[0]_0\(0),
      O => \State_reg[2]_0\
    );
\RXSTATES[1]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000000000800A"
    )
        port map (
      I0 => SRST_0,
      I1 => State(2),
      I2 => State(1),
      I3 => \^state_reg[0]_0\(0),
      I4 => req_Error_RX,
      I5 => \RXSTATES_reg[1]\,
      O => SRST_0_0(0)
    );
\RXSTATES[3]_i_3\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0083"
    )
        port map (
      I0 => State(2),
      I1 => State(1),
      I2 => \^state_reg[0]_0\(0),
      I3 => req_Error_RX,
      O => \State_reg[2]_1\
    );
\Reck[0]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \Reck[4]_i_2_n_0\,
      I1 => \Reck_reg_n_0_[0]\,
      O => Reckr(0)
    );
\Reck[1]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"28"
    )
        port map (
      I0 => \Reck[4]_i_2_n_0\,
      I1 => \Reck_reg_n_0_[1]\,
      I2 => \Reck_reg_n_0_[0]\,
      O => Reckr(1)
    );
\Reck[2]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2A80"
    )
        port map (
      I0 => \Reck[4]_i_2_n_0\,
      I1 => \Reck_reg_n_0_[0]\,
      I2 => \Reck_reg_n_0_[1]\,
      I3 => \Reck_reg_n_0_[2]\,
      O => Reckr(2)
    );
\Reck[3]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"2AAA8000"
    )
        port map (
      I0 => \Reck[4]_i_2_n_0\,
      I1 => \Reck_reg_n_0_[1]\,
      I2 => \Reck_reg_n_0_[0]\,
      I3 => \Reck_reg_n_0_[2]\,
      I4 => \Reck_reg_n_0_[3]\,
      O => Reckr(3)
    );
\Reck[4]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2AAAAAAA80000000"
    )
        port map (
      I0 => \Reck[4]_i_2_n_0\,
      I1 => \Reck_reg_n_0_[3]\,
      I2 => \Reck_reg_n_0_[2]\,
      I3 => \Reck_reg_n_0_[0]\,
      I4 => \Reck_reg_n_0_[1]\,
      I5 => \Reck_reg_n_0_[4]\,
      O => Reckr(4)
    );
\Reck[4]_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0400"
    )
        port map (
      I0 => State(1),
      I1 => State(2),
      I2 => \^state_reg[0]_0\(0),
      I3 => \State[2]_i_7_n_0\,
      O => \Reck[4]_i_2_n_0\
    );
\Reck[5]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00101000"
    )
        port map (
      I0 => State(1),
      I1 => \^state_reg[0]_0\(0),
      I2 => State(2),
      I3 => \Reck_reg_n_0_[5]\,
      I4 => \Reck[5]_i_2_n_0\,
      O => Reckr(5)
    );
\Reck[5]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"80000000"
    )
        port map (
      I0 => \Reck_reg_n_0_[4]\,
      I1 => \Reck_reg_n_0_[1]\,
      I2 => \Reck_reg_n_0_[0]\,
      I3 => \Reck_reg_n_0_[2]\,
      I4 => \Reck_reg_n_0_[3]\,
      O => \Reck[5]_i_2_n_0\
    );
\Reck[6]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAAAAAAA80AAAA"
    )
        port map (
      I0 => \Cnt_reg[0]_0\(0),
      I1 => \Reck[6]_i_3_n_0\,
      I2 => Sampled_din,
      I3 => \^state_reg[0]_0\(0),
      I4 => State(2),
      I5 => State(1),
      O => Reck(0)
    );
\Reck[6]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"01100000"
    )
        port map (
      I0 => State(1),
      I1 => \^state_reg[0]_0\(0),
      I2 => \Reck_reg_n_0_[6]\,
      I3 => \Reck[6]_i_4_n_0\,
      I4 => State(2),
      O => Reckr(6)
    );
\Reck[6]_i_3\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"1000"
    )
        port map (
      I0 => \Cnt_reg_n_0_[0]\,
      I1 => \Cnt_reg_n_0_[2]\,
      I2 => \Cnt_reg_n_0_[3]\,
      I3 => \Cnt_reg_n_0_[1]\,
      O => \Reck[6]_i_3_n_0\
    );
\Reck[6]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8000000000000000"
    )
        port map (
      I0 => \Reck_reg_n_0_[3]\,
      I1 => \Reck_reg_n_0_[2]\,
      I2 => \Reck_reg_n_0_[0]\,
      I3 => \Reck_reg_n_0_[1]\,
      I4 => \Reck_reg_n_0_[4]\,
      I5 => \Reck_reg_n_0_[5]\,
      O => \Reck[6]_i_4_n_0\
    );
\Reck_reg[0]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => Reck(0),
      CLR => ack_error_reg_0,
      D => Reckr(0),
      Q => \Reck_reg_n_0_[0]\
    );
\Reck_reg[1]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => Reck(0),
      CLR => ack_error_reg_0,
      D => Reckr(1),
      Q => \Reck_reg_n_0_[1]\
    );
\Reck_reg[2]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => Reck(0),
      CLR => ack_error_reg_0,
      D => Reckr(2),
      Q => \Reck_reg_n_0_[2]\
    );
\Reck_reg[3]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => Reck(0),
      CLR => ack_error_reg_0,
      D => Reckr(3),
      Q => \Reck_reg_n_0_[3]\
    );
\Reck_reg[4]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => Reck(0),
      CLR => ack_error_reg_0,
      D => Reckr(4),
      Q => \Reck_reg_n_0_[4]\
    );
\Reck_reg[5]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => Reck(0),
      CLR => ack_error_reg_0,
      D => Reckr(5),
      Q => \Reck_reg_n_0_[5]\
    );
\Reck_reg[6]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => Reck(0),
      CLR => ack_error_reg_0,
      D => Reckr(6),
      Q => \Reck_reg_n_0_[6]\
    );
\State[0]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0404040404440404"
    )
        port map (
      I0 => \State[0]_i_2_n_0\,
      I1 => SRST_0,
      I2 => \^q_1\(8),
      I3 => State(1),
      I4 => State(2),
      I5 => \^state_reg[0]_0\(0),
      O => \State[0]_i_1_n_0\
    );
\State[0]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000AABABBBA"
    )
        port map (
      I0 => \State[0]_i_3_n_0\,
      I1 => \^state_reg[0]_0\(0),
      I2 => \^q_1\(8),
      I3 => \State_reg[0]_4\,
      I4 => \State_reg[0]_5\,
      I5 => \State[0]_i_5_n_0\,
      O => \State[0]_i_2_n_0\
    );
\State[0]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"EEEEFEEE"
    )
        port map (
      I0 => State(1),
      I1 => State(2),
      I2 => \^state_reg[0]_0\(0),
      I3 => \Cnt[3]_i_7__0_n_0\,
      I4 => \Cnt[0]_i_2__1_n_0\,
      O => \State[0]_i_3_n_0\
    );
\State[0]_i_5\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFF4440"
    )
        port map (
      I0 => \State[0]_i_8_n_0\,
      I1 => State(2),
      I2 => State(1),
      I3 => \^state_reg[0]_0\(0),
      I4 => \State[0]_i_9_n_0\,
      O => \State[0]_i_5_n_0\
    );
\State[0]_i_8\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFBAFFBAF0BAF000"
    )
        port map (
      I0 => \^state_reg[0]_0\(0),
      I1 => \State[2]_i_6_n_0\,
      I2 => \^q_1\(8),
      I3 => Sampled_din,
      I4 => \Cnt[3]_i_7__0_n_0\,
      I5 => State(1),
      O => \State[0]_i_8_n_0\
    );
\State[0]_i_9\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0440440004404440"
    )
        port map (
      I0 => State(2),
      I1 => State(1),
      I2 => \^state_reg[0]_0\(0),
      I3 => Sampled_din,
      I4 => \State[2]_i_8_n_0\,
      I5 => \^q_1\(8),
      O => \State[0]_i_9_n_0\
    );
\State[1]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0808080808880808"
    )
        port map (
      I0 => \State[1]_i_2_n_0\,
      I1 => SRST_0,
      I2 => \^q_1\(8),
      I3 => State(1),
      I4 => State(2),
      I5 => \^state_reg[0]_0\(0),
      O => \State[1]_i_1_n_0\
    );
\State[1]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFF33333F77"
    )
        port map (
      I0 => \State[1]_i_3_n_0\,
      I1 => \State[1]_i_4_n_0\,
      I2 => \^state_reg[0]_0\(0),
      I3 => State(1),
      I4 => State(2),
      I5 => \State[1]_i_5_n_0\,
      O => \State[1]_i_2_n_0\
    );
\State[1]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"06FFFFFF"
    )
        port map (
      I0 => Sampled_din,
      I1 => \^lastvalue\,
      I2 => \Cnt[3]_i_10__0_n_0\,
      I3 => \Cnt[3]_i_7__0_n_0\,
      I4 => \^state_reg[0]_0\(0),
      O => \State[1]_i_3_n_0\
    );
\State[1]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFF3BFFFFFFFBFFF"
    )
        port map (
      I0 => \State[2]_i_6_n_0\,
      I1 => State(2),
      I2 => State(1),
      I3 => Sampled_din,
      I4 => \^state_reg[0]_0\(0),
      I5 => \Cnt[3]_i_7__0_n_0\,
      O => \State[1]_i_4_n_0\
    );
\State[1]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8888888880888888"
    )
        port map (
      I0 => Sampled_din,
      I1 => \REC[8]_i_15_n_0\,
      I2 => \Cnt_reg_n_0_[0]\,
      I3 => \Cnt_reg_n_0_[1]\,
      I4 => \Cnt_reg_n_0_[2]\,
      I5 => \Cnt_reg_n_0_[3]\,
      O => \State[1]_i_5_n_0\
    );
\State[2]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"A8AAA8AAA8AAA888"
    )
        port map (
      I0 => SRST_0,
      I1 => \State[2]_i_2_n_0\,
      I2 => \State[2]_i_3_n_0\,
      I3 => State(2),
      I4 => \State[2]_i_4_n_0\,
      I5 => \State[2]_i_5_n_0\,
      O => \State[2]_i_1_n_0\
    );
\State[2]_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"AA8A"
    )
        port map (
      I0 => \^q_1\(8),
      I1 => State(1),
      I2 => State(2),
      I3 => \^state_reg[0]_0\(0),
      O => \State[2]_i_2_n_0\
    );
\State[2]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"3077304433FB33FB"
    )
        port map (
      I0 => \State[2]_i_6_n_0\,
      I1 => State(1),
      I2 => \^q_1\(8),
      I3 => \^state_reg[0]_0\(0),
      I4 => \State[2]_i_7_n_0\,
      I5 => Sampled_din,
      O => \State[2]_i_3_n_0\
    );
\State[2]_i_4\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"08080800"
    )
        port map (
      I0 => State(1),
      I1 => \^state_reg[0]_0\(0),
      I2 => Sampled_din,
      I3 => \State[2]_i_8_n_0\,
      I4 => \^q_1\(8),
      O => \State[2]_i_4_n_0\
    );
\State[2]_i_5\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"888888C0"
    )
        port map (
      I0 => \^q_1\(8),
      I1 => \^state_reg[0]_2\,
      I2 => \State_reg[0]_5\,
      I3 => \TEC_reg[0]_0\,
      I4 => req_Error_RX,
      O => \State[2]_i_5_n_0\
    );
\State[2]_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"4000"
    )
        port map (
      I0 => \Cnt_reg_n_0_[3]\,
      I1 => \Cnt_reg_n_0_[2]\,
      I2 => \Cnt_reg_n_0_[0]\,
      I3 => \Cnt_reg_n_0_[1]\,
      O => \State[2]_i_6_n_0\
    );
\State[2]_i_7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFF7FFF"
    )
        port map (
      I0 => \Reck[6]_i_4_n_0\,
      I1 => \Reck_reg_n_0_[6]\,
      I2 => \Cnt_reg_n_0_[1]\,
      I3 => \Cnt_reg_n_0_[3]\,
      I4 => \Cnt_reg_n_0_[2]\,
      I5 => \Cnt_reg_n_0_[0]\,
      O => \State[2]_i_7_n_0\
    );
\State[2]_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0040"
    )
        port map (
      I0 => \Cnt_reg_n_0_[3]\,
      I1 => \Cnt_reg_n_0_[2]\,
      I2 => \Cnt_reg_n_0_[1]\,
      I3 => \Cnt_reg_n_0_[0]\,
      O => \State[2]_i_8_n_0\
    );
\State[2]_i_9\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \^state_reg[0]_0\(0),
      I1 => State(1),
      O => \^state_reg[0]_2\
    );
\State_reg[0]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => E(0),
      CLR => ack_error_reg_0,
      D => \State[0]_i_1_n_0\,
      Q => \^state_reg[0]_0\(0)
    );
\State_reg[1]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => E(0),
      CLR => ack_error_reg_0,
      D => \State[1]_i_1_n_0\,
      Q => State(1)
    );
\State_reg[2]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => E(0),
      CLR => ack_error_reg_0,
      D => \State[2]_i_1_n_0\,
      Q => State(2)
    );
\TEC[0]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BB33BB33AA33AB00"
    )
        port map (
      I0 => \TEC[0]_i_2_n_0\,
      I1 => \TEC[0]_i_3_n_0\,
      I2 => \^q_1\(8),
      I3 => \^q_1\(0),
      I4 => \TEC[8]_i_7_n_0\,
      I5 => \TEC[8]_i_6_n_0\,
      O => \TEC[0]_i_1_n_0\
    );
\TEC[0]_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"A082"
    )
        port map (
      I0 => \TEC_reg[0]_0\,
      I1 => State(1),
      I2 => State(2),
      I3 => \^state_reg[0]_0\(0),
      O => \TEC[0]_i_2_n_0\
    );
\TEC[0]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFEFEFEFEEEEEEEE"
    )
        port map (
      I0 => \TEC[8]_i_14_n_0\,
      I1 => \TEC[8]_i_19_n_0\,
      I2 => \^q_1\(0),
      I3 => \^q_1\(8),
      I4 => \TEC[8]_i_16_n_0\,
      I5 => \TEC[8]_i_6_n_0\,
      O => \TEC[0]_i_3_n_0\
    );
\TEC[1]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BBBBBBBBAAABBBAB"
    )
        port map (
      I0 => \TEC[1]_i_2_n_0\,
      I1 => \TEC[1]_i_3_n_0\,
      I2 => \TEC[1]_i_4_n_0\,
      I3 => \TEC[8]_i_7_n_0\,
      I4 => \TEC[1]_i_5_n_0\,
      I5 => \TEC[8]_i_6_n_0\,
      O => \TEC[1]_i_1_n_0\
    );
\TEC[1]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \^q_1\(1),
      I1 => \TEC[0]_i_2_n_0\,
      O => \TEC[1]_i_2_n_0\
    );
\TEC[1]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFEFEFEFEEEEEEEE"
    )
        port map (
      I0 => \TEC[8]_i_14_n_0\,
      I1 => \TEC[8]_i_19_n_0\,
      I2 => \^q_1\(1),
      I3 => \^q_1\(8),
      I4 => \TEC[8]_i_16_n_0\,
      I5 => \TEC[8]_i_6_n_0\,
      O => \TEC[1]_i_3_n_0\
    );
\TEC[1]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => \^q_1\(8),
      I1 => \^q_1\(1),
      O => \TEC[1]_i_4_n_0\
    );
\TEC[1]_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \^q_1\(0),
      I1 => \^q_1\(1),
      O => \TEC[1]_i_5_n_0\
    );
\TEC[2]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BBBBBBBBABAAABBB"
    )
        port map (
      I0 => \TEC[2]_i_2_n_0\,
      I1 => \TEC[2]_i_3_n_0\,
      I2 => \TEC[2]_i_4_n_0\,
      I3 => \TEC[8]_i_7_n_0\,
      I4 => \TEC[2]_i_5_n_0\,
      I5 => \TEC[8]_i_6_n_0\,
      O => \TEC[2]_i_1_n_0\
    );
\TEC[2]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \TEC[0]_i_2_n_0\,
      I1 => \^q_1\(2),
      O => \TEC[2]_i_2_n_0\
    );
\TEC[2]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFEFEFEFEEEEEEEE"
    )
        port map (
      I0 => \TEC[8]_i_14_n_0\,
      I1 => \TEC[8]_i_19_n_0\,
      I2 => \^q_1\(2),
      I3 => \^q_1\(8),
      I4 => \TEC[8]_i_16_n_0\,
      I5 => \TEC[8]_i_6_n_0\,
      O => \TEC[2]_i_3_n_0\
    );
\TEC[2]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"56"
    )
        port map (
      I0 => \^q_1\(2),
      I1 => \^q_1\(1),
      I2 => \^q_1\(0),
      O => \TEC[2]_i_4_n_0\
    );
\TEC[2]_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => \^q_1\(8),
      I1 => \^q_1\(2),
      O => \TEC[2]_i_5_n_0\
    );
\TEC[3]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BBBBBBBBAAABBBAB"
    )
        port map (
      I0 => \TEC[3]_i_2_n_0\,
      I1 => \TEC[3]_i_3_n_0\,
      I2 => \TEC[3]_i_4_n_0\,
      I3 => \TEC[8]_i_7_n_0\,
      I4 => \TEC[3]_i_5_n_0\,
      I5 => \TEC[8]_i_6_n_0\,
      O => \TEC[3]_i_1_n_0\
    );
\TEC[3]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \TEC[0]_i_2_n_0\,
      I1 => \^q_1\(3),
      O => \TEC[3]_i_2_n_0\
    );
\TEC[3]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFEFEFEEEEEEEEE"
    )
        port map (
      I0 => \TEC[8]_i_14_n_0\,
      I1 => \TEC[8]_i_19_n_0\,
      I2 => \^q_1\(3),
      I3 => \^q_1\(8),
      I4 => \TEC[8]_i_16_n_0\,
      I5 => \TEC[8]_i_6_n_0\,
      O => \TEC[3]_i_3_n_0\
    );
\TEC[3]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \^q_1\(8),
      I1 => \^q_1\(3),
      O => \TEC[3]_i_4_n_0\
    );
\TEC[3]_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"5556"
    )
        port map (
      I0 => \^q_1\(3),
      I1 => \^q_1\(2),
      I2 => \^q_1\(0),
      I3 => \^q_1\(1),
      O => \TEC[3]_i_5_n_0\
    );
\TEC[4]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BBBBBBBBAABABBBA"
    )
        port map (
      I0 => \TEC[4]_i_2_n_0\,
      I1 => \TEC[4]_i_3_n_0\,
      I2 => \TEC[4]_i_4_n_0\,
      I3 => \TEC[8]_i_7_n_0\,
      I4 => \TEC[4]_i_5_n_0\,
      I5 => \TEC[8]_i_6_n_0\,
      O => \TEC[4]_i_1_n_0\
    );
\TEC[4]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"28"
    )
        port map (
      I0 => \TEC[0]_i_2_n_0\,
      I1 => \^q_1\(3),
      I2 => \^q_1\(4),
      O => \TEC[4]_i_2_n_0\
    );
\TEC[4]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFEEEFEFFFEEE"
    )
        port map (
      I0 => \TEC[8]_i_14_n_0\,
      I1 => \TEC[8]_i_19_n_0\,
      I2 => \TEC[8]_i_15_n_0\,
      I3 => \TEC[4]_i_6_n_0\,
      I4 => \TEC[8]_i_16_n_0\,
      I5 => \^q_1\(8),
      O => \TEC[4]_i_3_n_0\
    );
\TEC[4]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"06"
    )
        port map (
      I0 => \^q_1\(3),
      I1 => \^q_1\(4),
      I2 => \^q_1\(8),
      O => \TEC[4]_i_4_n_0\
    );
\TEC[4]_i_5\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"55555556"
    )
        port map (
      I0 => \^q_1\(4),
      I1 => \^q_1\(1),
      I2 => \^q_1\(0),
      I3 => \^q_1\(2),
      I4 => \^q_1\(3),
      O => \TEC[4]_i_5_n_0\
    );
\TEC[4]_i_6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \^q_1\(4),
      I1 => \^q_1\(3),
      O => \TEC[4]_i_6_n_0\
    );
\TEC[5]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BBBBBBBBAAABBBAB"
    )
        port map (
      I0 => \TEC[5]_i_2_n_0\,
      I1 => \TEC[5]_i_3_n_0\,
      I2 => \TEC[5]_i_4_n_0\,
      I3 => \TEC[8]_i_7_n_0\,
      I4 => \TEC[5]_i_5_n_0\,
      I5 => \TEC[8]_i_6_n_0\,
      O => \TEC[5]_i_1_n_0\
    );
\TEC[5]_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2A80"
    )
        port map (
      I0 => \TEC[0]_i_2_n_0\,
      I1 => \^q_1\(4),
      I2 => \^q_1\(3),
      I3 => \^q_1\(5),
      O => \TEC[5]_i_2_n_0\
    );
\TEC[5]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000FFFFFF04"
    )
        port map (
      I0 => State(1),
      I1 => State(2),
      I2 => \^state_reg[0]_0\(0),
      I3 => \TEC[8]_i_14_n_0\,
      I4 => \TEC[8]_i_6_n_0\,
      I5 => \TEC[5]_i_6_n_0\,
      O => \TEC[5]_i_3_n_0\
    );
\TEC[5]_i_4\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"EABF"
    )
        port map (
      I0 => \^q_1\(8),
      I1 => \^q_1\(4),
      I2 => \^q_1\(3),
      I3 => \^q_1\(5),
      O => \TEC[5]_i_4_n_0\
    );
\TEC[5]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5555555555555556"
    )
        port map (
      I0 => \^q_1\(5),
      I1 => \^q_1\(4),
      I2 => \^q_1\(3),
      I3 => \^q_1\(1),
      I4 => \^q_1\(0),
      I5 => \^q_1\(2),
      O => \TEC[5]_i_5_n_0\
    );
\TEC[5]_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"ABB3300AAAA0000A"
    )
        port map (
      I0 => \TEC[8]_i_15_n_0\,
      I1 => \^q_1\(8),
      I2 => \^q_1\(4),
      I3 => \^q_1\(3),
      I4 => \^q_1\(5),
      I5 => \TEC[8]_i_16_n_0\,
      O => \TEC[5]_i_6_n_0\
    );
\TEC[6]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BBBBBBBBAABABBBA"
    )
        port map (
      I0 => \TEC[6]_i_2_n_0\,
      I1 => \TEC[6]_i_3_n_0\,
      I2 => \TEC[6]_i_4_n_0\,
      I3 => \TEC[8]_i_7_n_0\,
      I4 => \TEC[6]_i_5_n_0\,
      I5 => \TEC[8]_i_6_n_0\,
      O => \TEC[6]_i_1_n_0\
    );
\TEC[6]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"2AAA8000"
    )
        port map (
      I0 => \TEC[0]_i_2_n_0\,
      I1 => \^q_1\(3),
      I2 => \^q_1\(4),
      I3 => \^q_1\(5),
      I4 => \^q_1\(6),
      O => \TEC[6]_i_2_n_0\
    );
\TEC[6]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFEEEEEFE"
    )
        port map (
      I0 => \TEC[8]_i_14_n_0\,
      I1 => \TEC[8]_i_19_n_0\,
      I2 => \TEC[8]_i_15_n_0\,
      I3 => \TEC[6]_i_6_n_0\,
      I4 => \^q_1\(6),
      I5 => \TEC[6]_i_7_n_0\,
      O => \TEC[6]_i_3_n_0\
    );
\TEC[6]_i_4\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"15554000"
    )
        port map (
      I0 => \^q_1\(8),
      I1 => \^q_1\(3),
      I2 => \^q_1\(4),
      I3 => \^q_1\(5),
      I4 => \^q_1\(6),
      O => \TEC[6]_i_4_n_0\
    );
\TEC[6]_i_5\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"55565555"
    )
        port map (
      I0 => \^q_1\(6),
      I1 => \^q_1\(3),
      I2 => \^q_1\(4),
      I3 => \^q_1\(5),
      I4 => \TEC[8]_i_12_n_0\,
      O => \TEC[6]_i_5_n_0\
    );
\TEC[6]_i_6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"01"
    )
        port map (
      I0 => \^q_1\(3),
      I1 => \^q_1\(4),
      I2 => \^q_1\(5),
      O => \TEC[6]_i_6_n_0\
    );
\TEC[6]_i_7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAAAAA82222222"
    )
        port map (
      I0 => \TEC[8]_i_16_n_0\,
      I1 => \^q_1\(6),
      I2 => \^q_1\(5),
      I3 => \^q_1\(4),
      I4 => \^q_1\(3),
      I5 => \^q_1\(8),
      O => \TEC[6]_i_7_n_0\
    );
\TEC[7]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFF55550151"
    )
        port map (
      I0 => \TEC[7]_i_2_n_0\,
      I1 => \TEC[7]_i_3_n_0\,
      I2 => \TEC[8]_i_7_n_0\,
      I3 => \TEC[7]_i_4_n_0\,
      I4 => \TEC[8]_i_6_n_0\,
      I5 => \TEC[7]_i_5_n_0\,
      O => \TEC[7]_i_1_n_0\
    );
\TEC[7]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFEFEFE"
    )
        port map (
      I0 => \TEC[8]_i_14_n_0\,
      I1 => \TEC[8]_i_19_n_0\,
      I2 => \TEC[7]_i_6_n_0\,
      I3 => \TEC[8]_i_16_n_0\,
      I4 => \TEC[7]_i_3_n_0\,
      O => \TEC[7]_i_2_n_0\
    );
\TEC[7]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"EAAAAAAABFFFFFFF"
    )
        port map (
      I0 => \^q_1\(8),
      I1 => \^q_1\(5),
      I2 => \^q_1\(4),
      I3 => \^q_1\(3),
      I4 => \^q_1\(6),
      I5 => \^q_1\(7),
      O => \TEC[7]_i_3_n_0\
    );
\TEC[7]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5555555655555555"
    )
        port map (
      I0 => \^q_1\(7),
      I1 => \^q_1\(5),
      I2 => \^q_1\(4),
      I3 => \^q_1\(3),
      I4 => \^q_1\(6),
      I5 => \TEC[8]_i_12_n_0\,
      O => \TEC[7]_i_4_n_0\
    );
\TEC[7]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2AAAAAAA80000000"
    )
        port map (
      I0 => \TEC[0]_i_2_n_0\,
      I1 => \^q_1\(5),
      I2 => \^q_1\(4),
      I3 => \^q_1\(3),
      I4 => \^q_1\(6),
      I5 => \^q_1\(7),
      O => \TEC[7]_i_5_n_0\
    );
\TEC[7]_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000002AAAAAAA8"
    )
        port map (
      I0 => \TEC[8]_i_15_n_0\,
      I1 => \^q_1\(5),
      I2 => \^q_1\(4),
      I3 => \^q_1\(3),
      I4 => \^q_1\(6),
      I5 => \^q_1\(7),
      O => \TEC[7]_i_6_n_0\
    );
\TEC[8]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8888888088888888"
    )
        port map (
      I0 => SRST_0,
      I1 => ack_error_reg_1,
      I2 => \TEC[8]_i_4_n_0\,
      I3 => \TEC[8]_i_5_n_0\,
      I4 => \TEC[8]_i_6_n_0\,
      I5 => \TEC[8]_i_7_n_0\,
      O => \TEC[8]_i_1_n_0\
    );
\TEC[8]_i_10\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"EAAAAAAAAAAAAAAA"
    )
        port map (
      I0 => \^q_1\(8),
      I1 => \^q_1\(7),
      I2 => \^q_1\(5),
      I3 => \^q_1\(4),
      I4 => \^q_1\(3),
      I5 => \^q_1\(6),
      O => \TEC[8]_i_10_n_0\
    );
\TEC[8]_i_11\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FD00FFFFFD00FD00"
    )
        port map (
      I0 => \State[0]_i_2_n_0\,
      I1 => \TEC[8]_i_17_n_0\,
      I2 => \State[1]_i_2_n_0\,
      I3 => \TEC[8]_i_19_n_0\,
      I4 => \TEC[8]_i_21_n_0\,
      I5 => \TEC[0]_i_2_n_0\,
      O => \TEC[8]_i_11_n_0\
    );
\TEC[8]_i_12\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"01"
    )
        port map (
      I0 => \^q_1\(1),
      I1 => \^q_1\(0),
      I2 => \^q_1\(2),
      O => \TEC[8]_i_12_n_0\
    );
\TEC[8]_i_13\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0001"
    )
        port map (
      I0 => \^q_1\(5),
      I1 => \^q_1\(4),
      I2 => \^q_1\(3),
      I3 => \^q_1\(6),
      O => \TEC[8]_i_13_n_0\
    );
\TEC[8]_i_14\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"AA02"
    )
        port map (
      I0 => \TEC_reg[0]_0\,
      I1 => \^state_reg[0]_0\(0),
      I2 => State(1),
      I3 => State(2),
      O => \TEC[8]_i_14_n_0\
    );
\TEC[8]_i_15\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0200000000000000"
    )
        port map (
      I0 => ack_error_i_4_n_0,
      I1 => \Cnt_reg_n_0_[0]\,
      I2 => \Cnt_reg_n_0_[2]\,
      I3 => ack_error_reg_n_0,
      I4 => nozero_reg_n_0,
      I5 => \Cnt[3]_i_9__0_n_0\,
      O => \TEC[8]_i_15_n_0\
    );
\TEC[8]_i_16\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"A0A8A0A000080000"
    )
        port map (
      I0 => imTX,
      I1 => \State[2]_i_6_n_0\,
      I2 => Sampled_din,
      I3 => \^state_reg[0]_0\(0),
      I4 => \REC[8]_i_15_n_0\,
      I5 => \Cnt[0]_i_5__0_n_0\,
      O => \TEC[8]_i_16_n_0\
    );
\TEC[8]_i_17\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B8BBB8BBB8BBB8B8"
    )
        port map (
      I0 => \State[2]_i_3_n_0\,
      I1 => State(2),
      I2 => \State[2]_i_4_n_0\,
      I3 => \TEC[8]_i_11_0\,
      I4 => \^q_1\(8),
      I5 => \State_reg[0]_4\,
      O => \TEC[8]_i_17_n_0\
    );
\TEC[8]_i_18\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"40"
    )
        port map (
      I0 => State(2),
      I1 => State(1),
      I2 => \^state_reg[0]_0\(0),
      O => \TEC[8]_i_18_n_0\
    );
\TEC[8]_i_19\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"04"
    )
        port map (
      I0 => \^state_reg[0]_0\(0),
      I1 => State(2),
      I2 => State(1),
      O => \TEC[8]_i_19_n_0\
    );
\TEC[8]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFF54555444"
    )
        port map (
      I0 => \TEC[8]_i_8_n_0\,
      I1 => \TEC[8]_i_6_n_0\,
      I2 => \TEC[8]_i_9_n_0\,
      I3 => \TEC[8]_i_7_n_0\,
      I4 => \TEC[8]_i_10_n_0\,
      I5 => \TEC[8]_i_11_n_0\,
      O => \TEC[8]_i_2_n_0\
    );
\TEC[8]_i_20\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAAAAAAAAAAAA9"
    )
        port map (
      I0 => \^q_1\(8),
      I1 => \^q_1\(7),
      I2 => \^q_1\(5),
      I3 => \^q_1\(4),
      I4 => \^q_1\(3),
      I5 => \^q_1\(6),
      O => \TEC[8]_i_20_n_0\
    );
\TEC[8]_i_21\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9555555555555555"
    )
        port map (
      I0 => \^q_1\(8),
      I1 => \^q_1\(7),
      I2 => \^q_1\(5),
      I3 => \^q_1\(4),
      I4 => \^q_1\(3),
      I5 => \^q_1\(6),
      O => \TEC[8]_i_21_n_0\
    );
\TEC[8]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000FFDF0000"
    )
        port map (
      I0 => \TEC[8]_i_12_n_0\,
      I1 => \^q_1\(7),
      I2 => \TEC[8]_i_13_n_0\,
      I3 => \^q_1\(8),
      I4 => \TEC_reg[0]_1\,
      I5 => donefromtxr_reg_n_0,
      O => \TEC[8]_i_4_n_0\
    );
\TEC[8]_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FF04"
    )
        port map (
      I0 => State(1),
      I1 => State(2),
      I2 => \^state_reg[0]_0\(0),
      I3 => \TEC[8]_i_14_n_0\,
      O => \TEC[8]_i_5_n_0\
    );
\TEC[8]_i_6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \TEC[8]_i_15_n_0\,
      I1 => \TEC[8]_i_16_n_0\,
      O => \TEC[8]_i_6_n_0\
    );
\TEC[8]_i_7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFEF0000FFFFFFFF"
    )
        port map (
      I0 => \TEC[8]_i_17_n_0\,
      I1 => \State[1]_i_2_n_0\,
      I2 => \TEC[8]_i_18_n_0\,
      I3 => \State[0]_i_2_n_0\,
      I4 => \REC[8]_i_4_n_0\,
      I5 => imTX,
      O => \TEC[8]_i_7_n_0\
    );
\TEC[8]_i_8\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"EFEEEFFFEEEEEEEE"
    )
        port map (
      I0 => \TEC[8]_i_14_n_0\,
      I1 => \TEC[8]_i_19_n_0\,
      I2 => \TEC[8]_i_10_n_0\,
      I3 => \TEC[8]_i_16_n_0\,
      I4 => \TEC[8]_i_20_n_0\,
      I5 => \TEC[8]_i_6_n_0\,
      O => \TEC[8]_i_8_n_0\
    );
\TEC[8]_i_9\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAAAAAAAAAAAA6"
    )
        port map (
      I0 => \^q_1\(8),
      I1 => \TEC[8]_i_13_n_0\,
      I2 => \^q_1\(7),
      I3 => \^q_1\(1),
      I4 => \^q_1\(0),
      I5 => \^q_1\(2),
      O => \TEC[8]_i_9_n_0\
    );
\TEC_reg[0]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TEC[8]_i_1_n_0\,
      CLR => ack_error_reg_0,
      D => \TEC[0]_i_1_n_0\,
      Q => \^q_1\(0)
    );
\TEC_reg[1]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TEC[8]_i_1_n_0\,
      CLR => ack_error_reg_0,
      D => \TEC[1]_i_1_n_0\,
      Q => \^q_1\(1)
    );
\TEC_reg[2]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TEC[8]_i_1_n_0\,
      CLR => ack_error_reg_0,
      D => \TEC[2]_i_1_n_0\,
      Q => \^q_1\(2)
    );
\TEC_reg[3]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TEC[8]_i_1_n_0\,
      CLR => ack_error_reg_0,
      D => \TEC[3]_i_1_n_0\,
      Q => \^q_1\(3)
    );
\TEC_reg[4]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TEC[8]_i_1_n_0\,
      CLR => ack_error_reg_0,
      D => \TEC[4]_i_1_n_0\,
      Q => \^q_1\(4)
    );
\TEC_reg[5]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TEC[8]_i_1_n_0\,
      CLR => ack_error_reg_0,
      D => \TEC[5]_i_1_n_0\,
      Q => \^q_1\(5)
    );
\TEC_reg[6]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TEC[8]_i_1_n_0\,
      CLR => ack_error_reg_0,
      D => \TEC[6]_i_1_n_0\,
      Q => \^q_1\(6)
    );
\TEC_reg[7]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TEC[8]_i_1_n_0\,
      CLR => ack_error_reg_0,
      D => \TEC[7]_i_1_n_0\,
      Q => \^q_1\(7)
    );
\TEC_reg[8]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TEC[8]_i_1_n_0\,
      CLR => ack_error_reg_0,
      D => \TEC[8]_i_2_n_0\,
      Q => \^q_1\(8)
    );
\TECin[8]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B0B0B0BB"
    )
        port map (
      I0 => ack_error_reg_1,
      I1 => SRST_0,
      I2 => \TECin[8]_i_2_n_0\,
      I3 => State(2),
      I4 => \TECin[8]_i_3_n_0\,
      O => RECin(0)
    );
\TECin[8]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0A100000FFFFFFFF"
    )
        port map (
      I0 => \^state_reg[0]_0\(0),
      I1 => \State[2]_i_6_n_0\,
      I2 => State(1),
      I3 => Sampled_din,
      I4 => State(2),
      I5 => SRST_0,
      O => \TECin[8]_i_2_n_0\
    );
\TECin[8]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFF0FFFFFFFF1111"
    )
        port map (
      I0 => req_Error_RX,
      I1 => \TEC_reg[0]_0\,
      I2 => \State[2]_i_8_n_0\,
      I3 => Sampled_din,
      I4 => \^state_reg[0]_0\(0),
      I5 => State(1),
      O => \TECin[8]_i_3_n_0\
    );
\TECin_reg[7]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => RECin(0),
      CLR => ack_error_reg_0,
      D => \^q_1\(7),
      Q => \TECin_reg_n_0_[7]\
    );
\TECin_reg[8]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => RECin(0),
      CLR => ack_error_reg_0,
      D => \^q_1\(8),
      Q => \TECin_reg_n_0_[8]\
    );
\TXSTATES[2]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"A8"
    )
        port map (
      I0 => SRST_0,
      I1 => \^state_reg[0]_1\,
      I2 => \TXSTATES_reg[2]\,
      O => D(0)
    );
\TXSTATES[3]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"A8"
    )
        port map (
      I0 => SRST_0,
      I1 => \^state_reg[0]_1\,
      I2 => \TXSTATES_reg[3]\,
      O => D(1)
    );
\TXSTATES[3]_i_3\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FF0E"
    )
        port map (
      I0 => \^state_reg[0]_0\(0),
      I1 => State(1),
      I2 => State(2),
      I3 => \TEC_reg[0]_0\,
      O => \^state_reg[0]_1\
    );
TXpin_i_1: unisim.vcomponents.LUT4
    generic map(
      INIT => X"57F7"
    )
        port map (
      I0 => SRST_0,
      I1 => TXpin_i_2_n_0,
      I2 => State(2),
      I3 => TXpin_i_3_n_0,
      O => TXpin_i_1_n_0
    );
TXpin_i_2: unisim.vcomponents.LUT6
    generic map(
      INIT => X"88B8BBBB88B88888"
    )
        port map (
      I0 => TXpin_i_4_n_0,
      I1 => State(1),
      I2 => \Cnt[3]_i_10__0_n_0\,
      I3 => \Cnt[3]_i_7__0_n_0\,
      I4 => \^state_reg[0]_0\(0),
      I5 => TXpin_reg_0,
      O => TXpin_i_2_n_0
    );
TXpin_i_3: unisim.vcomponents.LUT6
    generic map(
      INIT => X"300033030C080C08"
    )
        port map (
      I0 => \State[2]_i_6_n_0\,
      I1 => State(1),
      I2 => Sampled_din,
      I3 => \^rec_reg[7]_0\,
      I4 => \Cnt[3]_i_7__0_n_0\,
      I5 => \^state_reg[0]_0\(0),
      O => TXpin_i_3_n_0
    );
TXpin_i_4: unisim.vcomponents.LUT6
    generic map(
      INIT => X"4040404040404440"
    )
        port map (
      I0 => Sampled_din,
      I1 => \^state_reg[0]_0\(0),
      I2 => \State[2]_i_8_n_0\,
      I3 => \^rec_reg[8]_1\,
      I4 => \^q_1\(7),
      I5 => \^q_1\(8),
      O => TXpin_i_4_n_0
    );
TXpin_i_6: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0001"
    )
        port map (
      I0 => \^rec_reg[8]_0\(7),
      I1 => \^rec_reg[8]_0\(8),
      I2 => \^q_1\(7),
      I3 => \^q_1\(8),
      O => \^rec_reg[7]_0\
    );
TXpin_reg: unisim.vcomponents.FDPE
     port map (
      C => clk,
      CE => E(0),
      D => TXpin_i_1_n_0,
      PRE => ack_error_reg_0,
      Q => TX_from_Err
    );
ack_error_i_1: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FEFFAAAA0200AAAA"
    )
        port map (
      I0 => ack_error,
      I1 => ack_error_i_3_n_0,
      I2 => ack_error_i_4_n_0,
      I3 => ack_error_reg_1,
      I4 => SRST_0,
      I5 => ack_error_reg_n_0,
      O => ack_error_i_1_n_0
    );
ack_error_i_2: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000008"
    )
        port map (
      I0 => SRST_0,
      I1 => ack_error_reg_2,
      I2 => State(2),
      I3 => State(1),
      I4 => \^state_reg[0]_0\(0),
      I5 => ack_error_reg_3,
      O => ack_error
    );
ack_error_i_3: unisim.vcomponents.LUT3
    generic map(
      INIT => X"02"
    )
        port map (
      I0 => \^state_reg[0]_0\(0),
      I1 => State(1),
      I2 => State(2),
      O => ack_error_i_3_n_0
    );
ack_error_i_4: unisim.vcomponents.LUT3
    generic map(
      INIT => X"04"
    )
        port map (
      I0 => State(2),
      I1 => State(1),
      I2 => \^state_reg[0]_0\(0),
      O => ack_error_i_4_n_0
    );
ack_error_reg: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => '1',
      CLR => ack_error_reg_0,
      D => ack_error_i_1_n_0,
      Q => ack_error_reg_n_0
    );
donefromrxr_reg: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => E(0),
      CLR => ack_error_reg_0,
      D => donefromrxr,
      Q => donefromrxr_reg_n_0
    );
donefromtxr_reg: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => E(0),
      CLR => ack_error_reg_0,
      D => donefromtxr,
      Q => donefromtxr_reg_n_0
    );
lastvalue_reg: unisim.vcomponents.FDPE
     port map (
      C => clk,
      CE => E(0),
      D => lastvalue_reg_0,
      PRE => ack_error_reg_0,
      Q => \^lastvalue\
    );
nozero_i_1: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFEFEFEFFFFFFFFF"
    )
        port map (
      I0 => State(2),
      I1 => State(1),
      I2 => \^state_reg[0]_0\(0),
      I3 => Sampled_din,
      I4 => nozero_reg_n_0,
      I5 => SRST_0,
      O => nozero_i_1_n_0
    );
nozero_reg: unisim.vcomponents.FDPE
     port map (
      C => clk,
      CE => E(0),
      D => nozero_i_1_n_0,
      PRE => ack_error_reg_0,
      Q => nozero_reg_n_0
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1_FPGAPROJECT_0_0_ErrorHandler_3 is
  port (
    Q : out STD_LOGIC_VECTOR ( 8 downto 0 );
    \State_reg[2]_0\ : out STD_LOGIC_VECTOR ( 2 downto 0 );
    \TEC_reg[8]_0\ : out STD_LOGIC;
    \State_reg[2]_1\ : out STD_LOGIC;
    \REC_reg[8]_0\ : out STD_LOGIC_VECTOR ( 8 downto 0 );
    \State_reg[0]_0\ : out STD_LOGIC;
    D : out STD_LOGIC_VECTOR ( 3 downto 0 );
    \State_reg[0]_1\ : out STD_LOGIC;
    RXBUS : out STD_LOGIC;
    q_reg : out STD_LOGIC;
    TX : out STD_LOGIC;
    \Mode_1[1]\ : out STD_LOGIC;
    SRST_1 : out STD_LOGIC_VECTOR ( 0 to 0 );
    \REC_reg[8]_1\ : out STD_LOGIC;
    \State_reg[2]_2\ : out STD_LOGIC;
    req_Error_reg : out STD_LOGIC;
    \State_reg[2]_3\ : out STD_LOGIC;
    \State_reg[0]_2\ : out STD_LOGIC;
    \State_reg[0]_3\ : in STD_LOGIC;
    lastvalue_reg_0 : in STD_LOGIC;
    Tq : in STD_LOGIC;
    ack_error_reg_0 : in STD_LOGIC;
    donefromtxr : in STD_LOGIC;
    donefromrxr : in STD_LOGIC;
    \RECin_reg[7]_0\ : in STD_LOGIC;
    \TEC_reg[0]_0\ : in STD_LOGIC;
    SRST : in STD_LOGIC;
    ack_error_reg_1 : in STD_LOGIC;
    \State_reg[0]_4\ : in STD_LOGIC;
    req_Error_RX : in STD_LOGIC;
    \REC_reg[8]_2\ : in STD_LOGIC;
    imTX : in STD_LOGIC;
    \REC_reg[0]_0\ : in STD_LOGIC;
    E : in STD_LOGIC_VECTOR ( 0 to 0 );
    \REC[0]_i_3_0\ : in STD_LOGIC;
    \REC[0]_i_3_1\ : in STD_LOGIC;
    \State_reg[2]_i_2_0\ : in STD_LOGIC;
    \State_reg[0]_5\ : in STD_LOGIC;
    Sampled_din : in STD_LOGIC;
    \TXSTATES_reg[2]\ : in STD_LOGIC;
    \REC_reg[8]_3\ : in STD_LOGIC;
    \TXSTATES_reg[3]\ : in STD_LOGIC;
    ack_error_reg_2 : in STD_LOGIC;
    ack_error_reg_3 : in STD_LOGIC;
    RXBUSs : in STD_LOGIC;
    Mode : in STD_LOGIC_VECTOR ( 2 downto 0 );
    \RXSTATES_reg[1]\ : in STD_LOGIC;
    \REC_reg[6]_0\ : in STD_LOGIC;
    \TEC_reg[0]_1\ : in STD_LOGIC;
    AckTakeOver : in STD_LOGIC;
    IDE_i_2_0 : in STD_LOGIC;
    \TXSTATES_reg[0]\ : in STD_LOGIC;
    \TXSTATES_reg[1]\ : in STD_LOGIC
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of design_1_FPGAPROJECT_0_0_ErrorHandler_3 : entity is "ErrorHandler";
end design_1_FPGAPROJECT_0_0_ErrorHandler_3;

architecture STRUCTURE of design_1_FPGAPROJECT_0_0_ErrorHandler_3 is
  signal \Cnt[0]_i_2__1_n_0\ : STD_LOGIC;
  signal \Cnt[0]_i_3__1_n_0\ : STD_LOGIC;
  signal \Cnt[0]_i_4__1_n_0\ : STD_LOGIC;
  signal \Cnt[0]_i_5__1_n_0\ : STD_LOGIC;
  signal \Cnt[1]_i_2__1_n_0\ : STD_LOGIC;
  signal \Cnt[1]_i_3__1_n_0\ : STD_LOGIC;
  signal \Cnt[2]_i_2__1_n_0\ : STD_LOGIC;
  signal \Cnt[2]_i_3__1_n_0\ : STD_LOGIC;
  signal \Cnt[3]_i_10_n_0\ : STD_LOGIC;
  signal \Cnt[3]_i_3__1_n_0\ : STD_LOGIC;
  signal \Cnt[3]_i_4__1_n_0\ : STD_LOGIC;
  signal \Cnt[3]_i_5__0_n_0\ : STD_LOGIC;
  signal \Cnt[3]_i_6_n_0\ : STD_LOGIC;
  signal \Cnt[3]_i_7_n_0\ : STD_LOGIC;
  signal \Cnt[3]_i_8_n_0\ : STD_LOGIC;
  signal \Cnt[3]_i_9_n_0\ : STD_LOGIC;
  signal \Cnt_reg_n_0_[0]\ : STD_LOGIC;
  signal \Cnt_reg_n_0_[1]\ : STD_LOGIC;
  signal \Cnt_reg_n_0_[2]\ : STD_LOGIC;
  signal \Cnt_reg_n_0_[3]\ : STD_LOGIC;
  signal Cntr : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \^mode_1[1]\ : STD_LOGIC;
  signal \^q\ : STD_LOGIC_VECTOR ( 8 downto 0 );
  signal \REC[0]_i_1_n_0\ : STD_LOGIC;
  signal \REC[0]_i_3_n_0\ : STD_LOGIC;
  signal \REC[0]_i_4_n_0\ : STD_LOGIC;
  signal \REC[0]_i_5_n_0\ : STD_LOGIC;
  signal \REC[0]_i_8_n_0\ : STD_LOGIC;
  signal \REC[1]_i_1_n_0\ : STD_LOGIC;
  signal \REC[1]_i_2_n_0\ : STD_LOGIC;
  signal \REC[1]_i_3_n_0\ : STD_LOGIC;
  signal \REC[1]_i_4_n_0\ : STD_LOGIC;
  signal \REC[1]_i_5_n_0\ : STD_LOGIC;
  signal \REC[1]_i_6_n_0\ : STD_LOGIC;
  signal \REC[2]_i_1_n_0\ : STD_LOGIC;
  signal \REC[2]_i_2_n_0\ : STD_LOGIC;
  signal \REC[2]_i_3_n_0\ : STD_LOGIC;
  signal \REC[2]_i_4_n_0\ : STD_LOGIC;
  signal \REC[2]_i_5_n_0\ : STD_LOGIC;
  signal \REC[2]_i_6_n_0\ : STD_LOGIC;
  signal \REC[3]_i_1_n_0\ : STD_LOGIC;
  signal \REC[3]_i_2_n_0\ : STD_LOGIC;
  signal \REC[3]_i_3_n_0\ : STD_LOGIC;
  signal \REC[3]_i_4_n_0\ : STD_LOGIC;
  signal \REC[3]_i_5_n_0\ : STD_LOGIC;
  signal \REC[3]_i_6_n_0\ : STD_LOGIC;
  signal \REC[4]_i_1_n_0\ : STD_LOGIC;
  signal \REC[4]_i_2_n_0\ : STD_LOGIC;
  signal \REC[4]_i_3_n_0\ : STD_LOGIC;
  signal \REC[4]_i_4_n_0\ : STD_LOGIC;
  signal \REC[4]_i_5_n_0\ : STD_LOGIC;
  signal \REC[4]_i_6_n_0\ : STD_LOGIC;
  signal \REC[4]_i_7_n_0\ : STD_LOGIC;
  signal \REC[4]_i_8_n_0\ : STD_LOGIC;
  signal \REC[5]_i_1_n_0\ : STD_LOGIC;
  signal \REC[5]_i_2_n_0\ : STD_LOGIC;
  signal \REC[5]_i_3_n_0\ : STD_LOGIC;
  signal \REC[5]_i_4_n_0\ : STD_LOGIC;
  signal \REC[5]_i_5_n_0\ : STD_LOGIC;
  signal \REC[5]_i_6_n_0\ : STD_LOGIC;
  signal \REC[5]_i_7_n_0\ : STD_LOGIC;
  signal \REC[5]_i_8_n_0\ : STD_LOGIC;
  signal \REC[5]_i_9_n_0\ : STD_LOGIC;
  signal \REC[6]_i_1_n_0\ : STD_LOGIC;
  signal \REC[6]_i_2_n_0\ : STD_LOGIC;
  signal \REC[6]_i_3_n_0\ : STD_LOGIC;
  signal \REC[6]_i_4_n_0\ : STD_LOGIC;
  signal \REC[6]_i_5_n_0\ : STD_LOGIC;
  signal \REC[6]_i_6_n_0\ : STD_LOGIC;
  signal \REC[6]_i_8_n_0\ : STD_LOGIC;
  signal \REC[6]_i_9_n_0\ : STD_LOGIC;
  signal \REC[7]_i_1_n_0\ : STD_LOGIC;
  signal \REC[7]_i_2_n_0\ : STD_LOGIC;
  signal \REC[7]_i_3_n_0\ : STD_LOGIC;
  signal \REC[7]_i_4_n_0\ : STD_LOGIC;
  signal \REC[7]_i_5_n_0\ : STD_LOGIC;
  signal \REC[7]_i_6_n_0\ : STD_LOGIC;
  signal \REC[7]_i_7_n_0\ : STD_LOGIC;
  signal \REC[7]_i_8_n_0\ : STD_LOGIC;
  signal \REC[7]_i_9_n_0\ : STD_LOGIC;
  signal \REC[8]_i_10_n_0\ : STD_LOGIC;
  signal \REC[8]_i_11_n_0\ : STD_LOGIC;
  signal \REC[8]_i_13_n_0\ : STD_LOGIC;
  signal \REC[8]_i_14_n_0\ : STD_LOGIC;
  signal \REC[8]_i_15_n_0\ : STD_LOGIC;
  signal \REC[8]_i_16_n_0\ : STD_LOGIC;
  signal \REC[8]_i_1_n_0\ : STD_LOGIC;
  signal \REC[8]_i_2_n_0\ : STD_LOGIC;
  signal \REC[8]_i_3_n_0\ : STD_LOGIC;
  signal \REC[8]_i_4_n_0\ : STD_LOGIC;
  signal \REC[8]_i_6_n_0\ : STD_LOGIC;
  signal \REC[8]_i_7_n_0\ : STD_LOGIC;
  signal \REC[8]_i_8_n_0\ : STD_LOGIC;
  signal \REC[8]_i_9_n_0\ : STD_LOGIC;
  signal \^rec_reg[8]_0\ : STD_LOGIC_VECTOR ( 8 downto 0 );
  signal \^rec_reg[8]_1\ : STD_LOGIC;
  signal RECin : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \RECin_reg_n_0_[7]\ : STD_LOGIC;
  signal \RECin_reg_n_0_[8]\ : STD_LOGIC;
  signal Reck : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \Reck[4]_i_2_n_0\ : STD_LOGIC;
  signal \Reck[4]_i_3_n_0\ : STD_LOGIC;
  signal \Reck[5]_i_2_n_0\ : STD_LOGIC;
  signal \Reck[6]_i_3_n_0\ : STD_LOGIC;
  signal \Reck[6]_i_4_n_0\ : STD_LOGIC;
  signal \Reck_reg_n_0_[0]\ : STD_LOGIC;
  signal \Reck_reg_n_0_[1]\ : STD_LOGIC;
  signal \Reck_reg_n_0_[2]\ : STD_LOGIC;
  signal \Reck_reg_n_0_[3]\ : STD_LOGIC;
  signal \Reck_reg_n_0_[4]\ : STD_LOGIC;
  signal \Reck_reg_n_0_[5]\ : STD_LOGIC;
  signal \Reck_reg_n_0_[6]\ : STD_LOGIC;
  signal Reckr : STD_LOGIC_VECTOR ( 6 downto 0 );
  signal \State[0]_i_10_n_0\ : STD_LOGIC;
  signal \State[0]_i_1_n_0\ : STD_LOGIC;
  signal \State[0]_i_2_n_0\ : STD_LOGIC;
  signal \State[0]_i_3_n_0\ : STD_LOGIC;
  signal \State[0]_i_6_n_0\ : STD_LOGIC;
  signal \State[0]_i_9_n_0\ : STD_LOGIC;
  signal \State[1]_i_1_n_0\ : STD_LOGIC;
  signal \State[1]_i_2_n_0\ : STD_LOGIC;
  signal \State[1]_i_3_n_0\ : STD_LOGIC;
  signal \State[1]_i_4_n_0\ : STD_LOGIC;
  signal \State[1]_i_5_n_0\ : STD_LOGIC;
  signal \State[2]_i_1_n_0\ : STD_LOGIC;
  signal \State[2]_i_3_n_0\ : STD_LOGIC;
  signal \State[2]_i_4_n_0\ : STD_LOGIC;
  signal \^state_reg[0]_0\ : STD_LOGIC;
  signal \^state_reg[0]_1\ : STD_LOGIC;
  signal \^state_reg[2]_0\ : STD_LOGIC_VECTOR ( 2 downto 0 );
  signal \^state_reg[2]_1\ : STD_LOGIC;
  signal \State_reg[2]_i_2_n_0\ : STD_LOGIC;
  signal \TEC[0]_i_1_n_0\ : STD_LOGIC;
  signal \TEC[0]_i_2_n_0\ : STD_LOGIC;
  signal \TEC[0]_i_3_n_0\ : STD_LOGIC;
  signal \TEC[0]_i_4_n_0\ : STD_LOGIC;
  signal \TEC[0]_i_5_n_0\ : STD_LOGIC;
  signal \TEC[0]_i_6_n_0\ : STD_LOGIC;
  signal \TEC[1]_i_1_n_0\ : STD_LOGIC;
  signal \TEC[1]_i_2_n_0\ : STD_LOGIC;
  signal \TEC[1]_i_3_n_0\ : STD_LOGIC;
  signal \TEC[1]_i_4_n_0\ : STD_LOGIC;
  signal \TEC[1]_i_5_n_0\ : STD_LOGIC;
  signal \TEC[1]_i_6_n_0\ : STD_LOGIC;
  signal \TEC[2]_i_1_n_0\ : STD_LOGIC;
  signal \TEC[2]_i_2_n_0\ : STD_LOGIC;
  signal \TEC[2]_i_3_n_0\ : STD_LOGIC;
  signal \TEC[2]_i_4_n_0\ : STD_LOGIC;
  signal \TEC[2]_i_5_n_0\ : STD_LOGIC;
  signal \TEC[2]_i_6_n_0\ : STD_LOGIC;
  signal \TEC[3]_i_1_n_0\ : STD_LOGIC;
  signal \TEC[3]_i_2_n_0\ : STD_LOGIC;
  signal \TEC[3]_i_3_n_0\ : STD_LOGIC;
  signal \TEC[3]_i_4_n_0\ : STD_LOGIC;
  signal \TEC[3]_i_5_n_0\ : STD_LOGIC;
  signal \TEC[3]_i_6_n_0\ : STD_LOGIC;
  signal \TEC[4]_i_1_n_0\ : STD_LOGIC;
  signal \TEC[4]_i_2_n_0\ : STD_LOGIC;
  signal \TEC[4]_i_3_n_0\ : STD_LOGIC;
  signal \TEC[4]_i_4_n_0\ : STD_LOGIC;
  signal \TEC[4]_i_5_n_0\ : STD_LOGIC;
  signal \TEC[4]_i_6_n_0\ : STD_LOGIC;
  signal \TEC[4]_i_7_n_0\ : STD_LOGIC;
  signal \TEC[5]_i_1_n_0\ : STD_LOGIC;
  signal \TEC[5]_i_2_n_0\ : STD_LOGIC;
  signal \TEC[5]_i_3_n_0\ : STD_LOGIC;
  signal \TEC[5]_i_4_n_0\ : STD_LOGIC;
  signal \TEC[5]_i_5_n_0\ : STD_LOGIC;
  signal \TEC[5]_i_6_n_0\ : STD_LOGIC;
  signal \TEC[5]_i_7_n_0\ : STD_LOGIC;
  signal \TEC[6]_i_1_n_0\ : STD_LOGIC;
  signal \TEC[6]_i_2_n_0\ : STD_LOGIC;
  signal \TEC[6]_i_3_n_0\ : STD_LOGIC;
  signal \TEC[6]_i_4_n_0\ : STD_LOGIC;
  signal \TEC[6]_i_5_n_0\ : STD_LOGIC;
  signal \TEC[6]_i_6_n_0\ : STD_LOGIC;
  signal \TEC[6]_i_7_n_0\ : STD_LOGIC;
  signal \TEC[6]_i_8_n_0\ : STD_LOGIC;
  signal \TEC[7]_i_1_n_0\ : STD_LOGIC;
  signal \TEC[7]_i_2_n_0\ : STD_LOGIC;
  signal \TEC[7]_i_3_n_0\ : STD_LOGIC;
  signal \TEC[7]_i_4_n_0\ : STD_LOGIC;
  signal \TEC[7]_i_5_n_0\ : STD_LOGIC;
  signal \TEC[7]_i_6_n_0\ : STD_LOGIC;
  signal \TEC[7]_i_7_n_0\ : STD_LOGIC;
  signal \TEC[7]_i_8_n_0\ : STD_LOGIC;
  signal \TEC[8]_i_10_n_0\ : STD_LOGIC;
  signal \TEC[8]_i_11_n_0\ : STD_LOGIC;
  signal \TEC[8]_i_12_n_0\ : STD_LOGIC;
  signal \TEC[8]_i_13_n_0\ : STD_LOGIC;
  signal \TEC[8]_i_15_n_0\ : STD_LOGIC;
  signal \TEC[8]_i_16_n_0\ : STD_LOGIC;
  signal \TEC[8]_i_17_n_0\ : STD_LOGIC;
  signal \TEC[8]_i_18_n_0\ : STD_LOGIC;
  signal \TEC[8]_i_19_n_0\ : STD_LOGIC;
  signal \TEC[8]_i_1_n_0\ : STD_LOGIC;
  signal \TEC[8]_i_20_n_0\ : STD_LOGIC;
  signal \TEC[8]_i_21_n_0\ : STD_LOGIC;
  signal \TEC[8]_i_22_n_0\ : STD_LOGIC;
  signal \TEC[8]_i_2_n_0\ : STD_LOGIC;
  signal \TEC[8]_i_4_n_0\ : STD_LOGIC;
  signal \TEC[8]_i_5_n_0\ : STD_LOGIC;
  signal \TEC[8]_i_6_n_0\ : STD_LOGIC;
  signal \TEC[8]_i_7_n_0\ : STD_LOGIC;
  signal \TEC[8]_i_8_n_0\ : STD_LOGIC;
  signal \TEC[8]_i_9_n_0\ : STD_LOGIC;
  signal \^tec_reg[8]_0\ : STD_LOGIC;
  signal \TECin[8]_i_2_n_0\ : STD_LOGIC;
  signal \TECin[8]_i_3_n_0\ : STD_LOGIC;
  signal \TECin_reg_n_0_[7]\ : STD_LOGIC;
  signal \TECin_reg_n_0_[8]\ : STD_LOGIC;
  signal TX_INST_0_i_2_n_0 : STD_LOGIC;
  signal TX_from_Err : STD_LOGIC;
  signal TXpin_i_1_n_0 : STD_LOGIC;
  signal TXpin_i_2_n_0 : STD_LOGIC;
  signal TXpin_i_3_n_0 : STD_LOGIC;
  signal TXpin_i_4_n_0 : STD_LOGIC;
  signal TXpin_i_5_n_0 : STD_LOGIC;
  signal TXpin_i_6_n_0 : STD_LOGIC;
  signal ack_error : STD_LOGIC;
  signal ack_error_i_1_n_0 : STD_LOGIC;
  signal ack_error_i_3_n_0 : STD_LOGIC;
  signal ack_error_reg_n_0 : STD_LOGIC;
  signal donefromrxr_reg_n_0 : STD_LOGIC;
  signal donefromtxr_reg_n_0 : STD_LOGIC;
  signal lastvalue : STD_LOGIC;
  signal nozero_i_1_n_0 : STD_LOGIC;
  signal nozero_reg_n_0 : STD_LOGIC;
  signal \^q_reg\ : STD_LOGIC;
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \Cnt[0]_i_3__1\ : label is "soft_lutpair30";
  attribute SOFT_HLUTNM of \Cnt[0]_i_4__1\ : label is "soft_lutpair7";
  attribute SOFT_HLUTNM of \Cnt[1]_i_2__1\ : label is "soft_lutpair14";
  attribute SOFT_HLUTNM of \Cnt[1]_i_7\ : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of \Cnt[2]_i_2__1\ : label is "soft_lutpair11";
  attribute SOFT_HLUTNM of \Cnt[3]_i_3__1\ : label is "soft_lutpair17";
  attribute SOFT_HLUTNM of \Cnt[3]_i_4__1\ : label is "soft_lutpair8";
  attribute SOFT_HLUTNM of \Cnt[3]_i_5__0\ : label is "soft_lutpair30";
  attribute SOFT_HLUTNM of \Cnt[3]_i_6\ : label is "soft_lutpair11";
  attribute SOFT_HLUTNM of \Cnt[3]_i_7\ : label is "soft_lutpair8";
  attribute SOFT_HLUTNM of \Cnt[3]_i_9\ : label is "soft_lutpair29";
  attribute SOFT_HLUTNM of IDE_i_2 : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of \REC[0]_i_4\ : label is "soft_lutpair27";
  attribute SOFT_HLUTNM of \REC[0]_i_8\ : label is "soft_lutpair16";
  attribute SOFT_HLUTNM of \REC[1]_i_2\ : label is "soft_lutpair34";
  attribute SOFT_HLUTNM of \REC[1]_i_5\ : label is "soft_lutpair45";
  attribute SOFT_HLUTNM of \REC[2]_i_2\ : label is "soft_lutpair25";
  attribute SOFT_HLUTNM of \REC[2]_i_4\ : label is "soft_lutpair22";
  attribute SOFT_HLUTNM of \REC[2]_i_5\ : label is "soft_lutpair45";
  attribute SOFT_HLUTNM of \REC[3]_i_4\ : label is "soft_lutpair19";
  attribute SOFT_HLUTNM of \REC[3]_i_5\ : label is "soft_lutpair35";
  attribute SOFT_HLUTNM of \REC[3]_i_6\ : label is "soft_lutpair35";
  attribute SOFT_HLUTNM of \REC[4]_i_4\ : label is "soft_lutpair19";
  attribute SOFT_HLUTNM of \REC[4]_i_5\ : label is "soft_lutpair39";
  attribute SOFT_HLUTNM of \REC[4]_i_7\ : label is "soft_lutpair6";
  attribute SOFT_HLUTNM of \REC[5]_i_5\ : label is "soft_lutpair18";
  attribute SOFT_HLUTNM of \REC[5]_i_6\ : label is "soft_lutpair10";
  attribute SOFT_HLUTNM of \REC[5]_i_7\ : label is "soft_lutpair27";
  attribute SOFT_HLUTNM of \REC[5]_i_8\ : label is "soft_lutpair39";
  attribute SOFT_HLUTNM of \REC[5]_i_9\ : label is "soft_lutpair6";
  attribute SOFT_HLUTNM of \REC[6]_i_4\ : label is "soft_lutpair18";
  attribute SOFT_HLUTNM of \REC[6]_i_7\ : label is "soft_lutpair28";
  attribute SOFT_HLUTNM of \REC[7]_i_6\ : label is "soft_lutpair25";
  attribute SOFT_HLUTNM of \REC[7]_i_7\ : label is "soft_lutpair28";
  attribute SOFT_HLUTNM of \REC[7]_i_8\ : label is "soft_lutpair21";
  attribute SOFT_HLUTNM of \REC[7]_i_9\ : label is "soft_lutpair15";
  attribute SOFT_HLUTNM of \REC[8]_i_10\ : label is "soft_lutpair21";
  attribute SOFT_HLUTNM of \REC[8]_i_11\ : label is "soft_lutpair22";
  attribute SOFT_HLUTNM of \REC[8]_i_14\ : label is "soft_lutpair32";
  attribute SOFT_HLUTNM of \REC[8]_i_4\ : label is "soft_lutpair15";
  attribute SOFT_HLUTNM of \REC[8]_i_6\ : label is "soft_lutpair10";
  attribute SOFT_HLUTNM of \RXSTATES[0]_i_2\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \RXSTATES[0]_i_5\ : label is "soft_lutpair26";
  attribute SOFT_HLUTNM of \RXSTATES[3]_i_3\ : label is "soft_lutpair24";
  attribute SOFT_HLUTNM of \Reck[0]_i_1\ : label is "soft_lutpair37";
  attribute SOFT_HLUTNM of \Reck[1]_i_1\ : label is "soft_lutpair37";
  attribute SOFT_HLUTNM of \Reck[2]_i_1\ : label is "soft_lutpair9";
  attribute SOFT_HLUTNM of \Reck[3]_i_1\ : label is "soft_lutpair9";
  attribute SOFT_HLUTNM of \Reck[4]_i_2\ : label is "soft_lutpair26";
  attribute SOFT_HLUTNM of \Reck[5]_i_1\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \Reck[6]_i_2\ : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of \Reck[6]_i_3\ : label is "soft_lutpair29";
  attribute SOFT_HLUTNM of \State[0]_i_3\ : label is "soft_lutpair7";
  attribute SOFT_HLUTNM of \State[0]_i_6\ : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of \State[1]_i_4\ : label is "soft_lutpair17";
  attribute SOFT_HLUTNM of \State[2]_i_6\ : label is "soft_lutpair16";
  attribute SOFT_HLUTNM of \TEC[0]_i_2\ : label is "soft_lutpair46";
  attribute SOFT_HLUTNM of \TEC[0]_i_4\ : label is "soft_lutpair44";
  attribute SOFT_HLUTNM of \TEC[1]_i_2\ : label is "soft_lutpair46";
  attribute SOFT_HLUTNM of \TEC[1]_i_4\ : label is "soft_lutpair44";
  attribute SOFT_HLUTNM of \TEC[1]_i_6\ : label is "soft_lutpair38";
  attribute SOFT_HLUTNM of \TEC[2]_i_3\ : label is "soft_lutpair42";
  attribute SOFT_HLUTNM of \TEC[2]_i_6\ : label is "soft_lutpair12";
  attribute SOFT_HLUTNM of \TEC[3]_i_3\ : label is "soft_lutpair33";
  attribute SOFT_HLUTNM of \TEC[3]_i_5\ : label is "soft_lutpair40";
  attribute SOFT_HLUTNM of \TEC[3]_i_6\ : label is "soft_lutpair12";
  attribute SOFT_HLUTNM of \TEC[4]_i_2\ : label is "soft_lutpair40";
  attribute SOFT_HLUTNM of \TEC[4]_i_4\ : label is "soft_lutpair42";
  attribute SOFT_HLUTNM of \TEC[4]_i_6\ : label is "soft_lutpair31";
  attribute SOFT_HLUTNM of \TEC[5]_i_2\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \TEC[5]_i_3\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \TEC[5]_i_4\ : label is "soft_lutpair20";
  attribute SOFT_HLUTNM of \TEC[5]_i_7\ : label is "soft_lutpair13";
  attribute SOFT_HLUTNM of \TEC[6]_i_2\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \TEC[6]_i_4\ : label is "soft_lutpair20";
  attribute SOFT_HLUTNM of \TEC[6]_i_7\ : label is "soft_lutpair13";
  attribute SOFT_HLUTNM of \TEC[7]_i_8\ : label is "soft_lutpair14";
  attribute SOFT_HLUTNM of \TEC[8]_i_12\ : label is "soft_lutpair23";
  attribute SOFT_HLUTNM of \TEC[8]_i_15\ : label is "soft_lutpair38";
  attribute SOFT_HLUTNM of \TEC[8]_i_16\ : label is "soft_lutpair31";
  attribute SOFT_HLUTNM of \TEC[8]_i_17\ : label is "soft_lutpair41";
  attribute SOFT_HLUTNM of \TEC[8]_i_18\ : label is "soft_lutpair41";
  attribute SOFT_HLUTNM of \TEC[8]_i_21\ : label is "soft_lutpair23";
  attribute SOFT_HLUTNM of \TEC[8]_i_4\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \TXSTATES[0]_i_1\ : label is "soft_lutpair43";
  attribute SOFT_HLUTNM of \TXSTATES[1]_i_1\ : label is "soft_lutpair43";
  attribute SOFT_HLUTNM of \TXSTATES[2]_i_1\ : label is "soft_lutpair36";
  attribute SOFT_HLUTNM of \TXSTATES[3]_i_2\ : label is "soft_lutpair36";
  attribute SOFT_HLUTNM of \TXSTATES[3]_i_3\ : label is "soft_lutpair24";
  attribute SOFT_HLUTNM of TX_INST_0_i_1 : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of TX_INST_0_i_2 : label is "soft_lutpair33";
  attribute SOFT_HLUTNM of TXpin_i_1 : label is "soft_lutpair32";
  attribute SOFT_HLUTNM of TXpin_i_7 : label is "soft_lutpair34";
  attribute SOFT_HLUTNM of ack_error_i_3 : label is "soft_lutpair4";
begin
  \Mode_1[1]\ <= \^mode_1[1]\;
  Q(8 downto 0) <= \^q\(8 downto 0);
  \REC_reg[8]_0\(8 downto 0) <= \^rec_reg[8]_0\(8 downto 0);
  \REC_reg[8]_1\ <= \^rec_reg[8]_1\;
  \State_reg[0]_0\ <= \^state_reg[0]_0\;
  \State_reg[0]_1\ <= \^state_reg[0]_1\;
  \State_reg[2]_0\(2 downto 0) <= \^state_reg[2]_0\(2 downto 0);
  \State_reg[2]_1\ <= \^state_reg[2]_1\;
  \TEC_reg[8]_0\ <= \^tec_reg[8]_0\;
  q_reg <= \^q_reg\;
\Cnt[0]_i_1__1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"30007575"
    )
        port map (
      I0 => \Cnt[0]_i_2__1_n_0\,
      I1 => \Cnt[0]_i_3__1_n_0\,
      I2 => \Cnt[0]_i_4__1_n_0\,
      I3 => \Cnt[0]_i_5__1_n_0\,
      I4 => \Cnt_reg_n_0_[0]\,
      O => Cntr(0)
    );
\Cnt[0]_i_2__1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFAFF0FF03FFFF0F"
    )
        port map (
      I0 => \Cnt[3]_i_9_n_0\,
      I1 => \Reck[6]_i_3_n_0\,
      I2 => \^state_reg[2]_0\(1),
      I3 => \^state_reg[2]_0\(2),
      I4 => Sampled_din,
      I5 => \^state_reg[2]_0\(0),
      O => \Cnt[0]_i_2__1_n_0\
    );
\Cnt[0]_i_3__1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0008"
    )
        port map (
      I0 => \Cnt_reg_n_0_[0]\,
      I1 => \Cnt_reg_n_0_[2]\,
      I2 => \Cnt_reg_n_0_[3]\,
      I3 => \Cnt_reg_n_0_[1]\,
      O => \Cnt[0]_i_3__1_n_0\
    );
\Cnt[0]_i_4__1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"10"
    )
        port map (
      I0 => \^state_reg[2]_0\(1),
      I1 => \^state_reg[2]_0\(2),
      I2 => \^state_reg[2]_0\(0),
      O => \Cnt[0]_i_4__1_n_0\
    );
\Cnt[0]_i_5__1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000FFFEFFFE0000"
    )
        port map (
      I0 => \TECin_reg_n_0_[7]\,
      I1 => \RECin_reg_n_0_[8]\,
      I2 => \TECin_reg_n_0_[8]\,
      I3 => \RECin_reg_n_0_[7]\,
      I4 => lastvalue,
      I5 => Sampled_din,
      O => \Cnt[0]_i_5__1_n_0\
    );
\Cnt[1]_i_1__1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"66606666"
    )
        port map (
      I0 => \Cnt_reg_n_0_[1]\,
      I1 => \Cnt_reg_n_0_[0]\,
      I2 => \Cnt[1]_i_2__1_n_0\,
      I3 => \Cnt[1]_i_3__1_n_0\,
      I4 => \Cnt[2]_i_3__1_n_0\,
      O => Cntr(1)
    );
\Cnt[1]_i_2__1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0080"
    )
        port map (
      I0 => \^state_reg[2]_0\(1),
      I1 => \^state_reg[2]_0\(2),
      I2 => Sampled_din,
      I3 => \^state_reg[2]_0\(0),
      O => \Cnt[1]_i_2__1_n_0\
    );
\Cnt[1]_i_3__1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00040C0000040000"
    )
        port map (
      I0 => \Cnt[0]_i_3__1_n_0\,
      I1 => \^state_reg[2]_0\(2),
      I2 => \^state_reg[2]_0\(1),
      I3 => Sampled_din,
      I4 => \^state_reg[2]_0\(0),
      I5 => \Reck[6]_i_3_n_0\,
      O => \Cnt[1]_i_3__1_n_0\
    );
\Cnt[1]_i_7\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"54"
    )
        port map (
      I0 => \^state_reg[2]_0\(2),
      I1 => \^state_reg[2]_0\(1),
      I2 => \^state_reg[2]_0\(0),
      O => \^state_reg[2]_1\
    );
\Cnt[2]_i_1__1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00787878"
    )
        port map (
      I0 => \Cnt_reg_n_0_[0]\,
      I1 => \Cnt_reg_n_0_[1]\,
      I2 => \Cnt_reg_n_0_[2]\,
      I3 => \Cnt[2]_i_2__1_n_0\,
      I4 => \Cnt[2]_i_3__1_n_0\,
      O => Cntr(2)
    );
\Cnt[2]_i_2__1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"F0EFFFFF"
    )
        port map (
      I0 => \Cnt[0]_i_3__1_n_0\,
      I1 => \^state_reg[2]_0\(1),
      I2 => \^state_reg[2]_0\(0),
      I3 => Sampled_din,
      I4 => \^state_reg[2]_0\(2),
      O => \Cnt[2]_i_2__1_n_0\
    );
\Cnt[2]_i_3__1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAAAAAAAAAA8AA"
    )
        port map (
      I0 => \Cnt[3]_i_8_n_0\,
      I1 => \Cnt[3]_i_3__1_n_0\,
      I2 => \^state_reg[2]_0\(2),
      I3 => \^state_reg[2]_0\(1),
      I4 => \^state_reg[2]_0\(0),
      I5 => Sampled_din,
      O => \Cnt[2]_i_3__1_n_0\
    );
\Cnt[3]_i_10\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"14FF141414141455"
    )
        port map (
      I0 => TXpin_i_5_n_0,
      I1 => lastvalue,
      I2 => Sampled_din,
      I3 => \TEC[8]_i_22_n_0\,
      I4 => \Cnt_reg_n_0_[0]\,
      I5 => \Cnt_reg_n_0_[2]\,
      O => \Cnt[3]_i_10_n_0\
    );
\Cnt[3]_i_2__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FAF8FA00FAFAFAFA"
    )
        port map (
      I0 => \Cnt[3]_i_3__1_n_0\,
      I1 => \Cnt[3]_i_4__1_n_0\,
      I2 => \Cnt[3]_i_5__0_n_0\,
      I3 => \Cnt[3]_i_6_n_0\,
      I4 => \Cnt[3]_i_7_n_0\,
      I5 => \Cnt[3]_i_8_n_0\,
      O => Cntr(3)
    );
\Cnt[3]_i_3__1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"4000"
    )
        port map (
      I0 => \Cnt_reg_n_0_[3]\,
      I1 => \Cnt_reg_n_0_[2]\,
      I2 => \Cnt_reg_n_0_[1]\,
      I3 => \Cnt_reg_n_0_[0]\,
      O => \Cnt[3]_i_3__1_n_0\
    );
\Cnt[3]_i_4__1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00200000"
    )
        port map (
      I0 => \Reck[6]_i_3_n_0\,
      I1 => \^state_reg[2]_0\(0),
      I2 => Sampled_din,
      I3 => \^state_reg[2]_0\(1),
      I4 => \^state_reg[2]_0\(2),
      O => \Cnt[3]_i_4__1_n_0\
    );
\Cnt[3]_i_5__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2AAA"
    )
        port map (
      I0 => \Cnt_reg_n_0_[3]\,
      I1 => \Cnt_reg_n_0_[2]\,
      I2 => \Cnt_reg_n_0_[0]\,
      I3 => \Cnt_reg_n_0_[1]\,
      O => \Cnt[3]_i_5__0_n_0\
    );
\Cnt[3]_i_6\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000020"
    )
        port map (
      I0 => \^state_reg[2]_0\(2),
      I1 => \^state_reg[2]_0\(1),
      I2 => \^state_reg[2]_0\(0),
      I3 => Sampled_din,
      I4 => \Cnt[0]_i_3__1_n_0\,
      O => \Cnt[3]_i_6_n_0\
    );
\Cnt[3]_i_7\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"0000E00C"
    )
        port map (
      I0 => \Reck[6]_i_3_n_0\,
      I1 => \^state_reg[2]_0\(1),
      I2 => \^state_reg[2]_0\(2),
      I3 => Sampled_din,
      I4 => \^state_reg[2]_0\(0),
      O => \Cnt[3]_i_7_n_0\
    );
\Cnt[3]_i_8\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFDDF0FFFFFFFF"
    )
        port map (
      I0 => Sampled_din,
      I1 => \Cnt[3]_i_9_n_0\,
      I2 => \Cnt[3]_i_10_n_0\,
      I3 => \^state_reg[2]_0\(1),
      I4 => \^state_reg[2]_0\(2),
      I5 => \^state_reg[2]_0\(0),
      O => \Cnt[3]_i_8_n_0\
    );
\Cnt[3]_i_9\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0040"
    )
        port map (
      I0 => \Cnt_reg_n_0_[3]\,
      I1 => \Cnt_reg_n_0_[2]\,
      I2 => \Cnt_reg_n_0_[1]\,
      I3 => \Cnt_reg_n_0_[0]\,
      O => \Cnt[3]_i_9_n_0\
    );
\Cnt_reg[0]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => E(0),
      CLR => ack_error_reg_0,
      D => Cntr(0),
      Q => \Cnt_reg_n_0_[0]\
    );
\Cnt_reg[1]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => E(0),
      CLR => ack_error_reg_0,
      D => Cntr(1),
      Q => \Cnt_reg_n_0_[1]\
    );
\Cnt_reg[2]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => E(0),
      CLR => ack_error_reg_0,
      D => Cntr(2),
      Q => \Cnt_reg_n_0_[2]\
    );
\Cnt_reg[3]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => E(0),
      CLR => ack_error_reg_0,
      D => Cntr(3),
      Q => \Cnt_reg_n_0_[3]\
    );
IDE_i_2: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00003A33"
    )
        port map (
      I0 => TX_INST_0_i_2_n_0,
      I1 => RXBUSs,
      I2 => Mode(1),
      I3 => Mode(2),
      I4 => Mode(0),
      O => \^q_reg\
    );
\REC[0]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0051FFFF005100F3"
    )
        port map (
      I0 => \REC_reg[0]_0\,
      I1 => \REC_reg[8]_2\,
      I2 => \REC[0]_i_3_n_0\,
      I3 => \REC[0]_i_4_n_0\,
      I4 => \^rec_reg[8]_0\(0),
      I5 => \REC[1]_i_2_n_0\,
      O => \REC[0]_i_1_n_0\
    );
\REC[0]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000010FFEF0010"
    )
        port map (
      I0 => imTX,
      I1 => \State[0]_i_2_n_0\,
      I2 => \TEC[8]_i_17_n_0\,
      I3 => \REC[0]_i_5_n_0\,
      I4 => \^rec_reg[8]_0\(0),
      I5 => \^rec_reg[8]_0\(8),
      O => \REC[0]_i_3_n_0\
    );
\REC[0]_i_4\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FBAA"
    )
        port map (
      I0 => \REC[8]_i_6_n_0\,
      I1 => \^rec_reg[8]_0\(0),
      I2 => \REC[7]_i_7_n_0\,
      I3 => \REC_reg[8]_3\,
      O => \REC[0]_i_4_n_0\
    );
\REC[0]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFAEAAAAFFAE"
    )
        port map (
      I0 => \State[1]_i_2_n_0\,
      I1 => \REC[0]_i_3_0\,
      I2 => \REC[0]_i_3_1\,
      I3 => \REC[0]_i_8_n_0\,
      I4 => \^state_reg[2]_0\(2),
      I5 => \State[2]_i_4_n_0\,
      O => \REC[0]_i_5_n_0\
    );
\REC[0]_i_8\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"20202000"
    )
        port map (
      I0 => \^state_reg[2]_0\(0),
      I1 => Sampled_din,
      I2 => \^state_reg[2]_0\(1),
      I3 => \Cnt[3]_i_9_n_0\,
      I4 => \^q\(8),
      O => \REC[0]_i_8_n_0\
    );
\REC[1]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0A3B3A3B3B3B3A3B"
    )
        port map (
      I0 => \REC[1]_i_2_n_0\,
      I1 => \REC[1]_i_3_n_0\,
      I2 => \REC[1]_i_4_n_0\,
      I3 => \REC_reg[8]_2\,
      I4 => \REC[7]_i_2_n_0\,
      I5 => \REC[1]_i_5_n_0\,
      O => \REC[1]_i_1_n_0\
    );
\REC[1]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"01"
    )
        port map (
      I0 => \^rec_reg[8]_0\(7),
      I1 => \^rec_reg[8]_0\(8),
      I2 => \REC[4]_i_6_n_0\,
      O => \REC[1]_i_2_n_0\
    );
\REC[1]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AABAFFBFAABAAABA"
    )
        port map (
      I0 => \REC[8]_i_6_n_0\,
      I1 => \REC[1]_i_4_n_0\,
      I2 => req_Error_RX,
      I3 => \^state_reg[0]_1\,
      I4 => \REC[1]_i_6_n_0\,
      I5 => \REC_reg[8]_3\,
      O => \REC[1]_i_3_n_0\
    );
\REC[1]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \^rec_reg[8]_0\(1),
      I1 => \^rec_reg[8]_0\(0),
      O => \REC[1]_i_4_n_0\
    );
\REC[1]_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => \^rec_reg[8]_0\(8),
      I1 => \^rec_reg[8]_0\(1),
      O => \REC[1]_i_5_n_0\
    );
\REC[1]_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAAA2AAAAAAAAA"
    )
        port map (
      I0 => \^rec_reg[8]_0\(1),
      I1 => \^rec_reg[8]_0\(8),
      I2 => \Cnt[3]_i_3__1_n_0\,
      I3 => Sampled_din,
      I4 => \^state_reg[2]_0\(0),
      I5 => \REC[8]_i_14_n_0\,
      O => \REC[1]_i_6_n_0\
    );
\REC[2]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AABBBABBBBBBBABB"
    )
        port map (
      I0 => \REC[2]_i_2_n_0\,
      I1 => \REC[2]_i_3_n_0\,
      I2 => \REC[2]_i_4_n_0\,
      I3 => \REC_reg[8]_2\,
      I4 => \REC[7]_i_2_n_0\,
      I5 => \REC[2]_i_5_n_0\,
      O => \REC[2]_i_1_n_0\
    );
\REC[2]_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"A802"
    )
        port map (
      I0 => \REC[1]_i_2_n_0\,
      I1 => \^rec_reg[8]_0\(1),
      I2 => \^rec_reg[8]_0\(0),
      I3 => \^rec_reg[8]_0\(2),
      O => \REC[2]_i_2_n_0\
    );
\REC[2]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AABAFFBFAABAAABA"
    )
        port map (
      I0 => \REC[8]_i_6_n_0\,
      I1 => \REC[2]_i_4_n_0\,
      I2 => req_Error_RX,
      I3 => \^state_reg[0]_1\,
      I4 => \REC[2]_i_6_n_0\,
      I5 => \REC_reg[8]_3\,
      O => \REC[2]_i_3_n_0\
    );
\REC[2]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"6A"
    )
        port map (
      I0 => \^rec_reg[8]_0\(2),
      I1 => \^rec_reg[8]_0\(0),
      I2 => \^rec_reg[8]_0\(1),
      O => \REC[2]_i_4_n_0\
    );
\REC[2]_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => \^rec_reg[8]_0\(8),
      I1 => \^rec_reg[8]_0\(2),
      O => \REC[2]_i_5_n_0\
    );
\REC[2]_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAAA2AAAAAAAAA"
    )
        port map (
      I0 => \^rec_reg[8]_0\(2),
      I1 => \^rec_reg[8]_0\(8),
      I2 => \Cnt[3]_i_3__1_n_0\,
      I3 => Sampled_din,
      I4 => \^state_reg[2]_0\(0),
      I5 => \REC[8]_i_14_n_0\,
      O => \REC[2]_i_6_n_0\
    );
\REC[3]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AABBBABBBBBBBABB"
    )
        port map (
      I0 => \REC[3]_i_2_n_0\,
      I1 => \REC[3]_i_3_n_0\,
      I2 => \REC[3]_i_4_n_0\,
      I3 => \REC_reg[8]_2\,
      I4 => \REC[7]_i_2_n_0\,
      I5 => \REC[3]_i_5_n_0\,
      O => \REC[3]_i_1_n_0\
    );
\REC[3]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"4444444155555555"
    )
        port map (
      I0 => \REC[4]_i_6_n_0\,
      I1 => \^rec_reg[8]_0\(3),
      I2 => \^rec_reg[8]_0\(2),
      I3 => \^rec_reg[8]_0\(1),
      I4 => \^rec_reg[8]_0\(0),
      I5 => \^rec_reg[8]_1\,
      O => \REC[3]_i_2_n_0\
    );
\REC[3]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AABAFFBFAABAAABA"
    )
        port map (
      I0 => \REC[8]_i_6_n_0\,
      I1 => \REC[3]_i_4_n_0\,
      I2 => req_Error_RX,
      I3 => \^state_reg[0]_1\,
      I4 => \REC[3]_i_6_n_0\,
      I5 => \REC_reg[8]_3\,
      O => \REC[3]_i_3_n_0\
    );
\REC[3]_i_4\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6AAA"
    )
        port map (
      I0 => \^rec_reg[8]_0\(3),
      I1 => \^rec_reg[8]_0\(2),
      I2 => \^rec_reg[8]_0\(1),
      I3 => \^rec_reg[8]_0\(0),
      O => \REC[3]_i_4_n_0\
    );
\REC[3]_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \^rec_reg[8]_0\(8),
      I1 => \^rec_reg[8]_0\(3),
      O => \REC[3]_i_5_n_0\
    );
\REC[3]_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"00BF"
    )
        port map (
      I0 => imTX,
      I1 => \REC[8]_i_15_n_0\,
      I2 => \REC[8]_i_16_n_0\,
      I3 => \^rec_reg[8]_0\(3),
      O => \REC[3]_i_6_n_0\
    );
\REC[4]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AABBBABBBBBBBABB"
    )
        port map (
      I0 => \REC[4]_i_2_n_0\,
      I1 => \REC[4]_i_3_n_0\,
      I2 => \REC[4]_i_4_n_0\,
      I3 => \REC_reg[8]_2\,
      I4 => \REC[7]_i_2_n_0\,
      I5 => \REC[4]_i_5_n_0\,
      O => \REC[4]_i_1_n_0\
    );
\REC[4]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000DDDDD7DD"
    )
        port map (
      I0 => \^rec_reg[8]_1\,
      I1 => \^rec_reg[8]_0\(4),
      I2 => \^rec_reg[8]_0\(3),
      I3 => \REC[5]_i_7_n_0\,
      I4 => \^rec_reg[8]_0\(2),
      I5 => \REC[4]_i_6_n_0\,
      O => \REC[4]_i_2_n_0\
    );
\REC[4]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFAABA"
    )
        port map (
      I0 => \REC[8]_i_6_n_0\,
      I1 => \^state_reg[0]_1\,
      I2 => req_Error_RX,
      I3 => \REC[4]_i_4_n_0\,
      I4 => \REC[4]_i_7_n_0\,
      O => \REC[4]_i_3_n_0\
    );
\REC[4]_i_4\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"6AAAAAAA"
    )
        port map (
      I0 => \^rec_reg[8]_0\(4),
      I1 => \^rec_reg[8]_0\(0),
      I2 => \^rec_reg[8]_0\(1),
      I3 => \^rec_reg[8]_0\(2),
      I4 => \^rec_reg[8]_0\(3),
      O => \REC[4]_i_4_n_0\
    );
\REC[4]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"EB"
    )
        port map (
      I0 => \^rec_reg[8]_0\(8),
      I1 => \^rec_reg[8]_0\(3),
      I2 => \^rec_reg[8]_0\(4),
      O => \REC[4]_i_5_n_0\
    );
\REC[4]_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFF5575FFFF"
    )
        port map (
      I0 => \REC[4]_i_8_n_0\,
      I1 => \^state_reg[2]_0\(0),
      I2 => \^state_reg[2]_0\(2),
      I3 => \^state_reg[2]_0\(1),
      I4 => \REC_reg[6]_0\,
      I5 => donefromrxr_reg_n_0,
      O => \REC[4]_i_6_n_0\
    );
\REC[4]_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"A88A"
    )
        port map (
      I0 => \REC_reg[8]_3\,
      I1 => \REC[7]_i_7_n_0\,
      I2 => \^rec_reg[8]_0\(4),
      I3 => \^rec_reg[8]_0\(3),
      O => \REC[4]_i_7_n_0\
    );
\REC[4]_i_8\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFFFFB"
    )
        port map (
      I0 => \^rec_reg[8]_0\(6),
      I1 => \^rec_reg[8]_1\,
      I2 => \REC[5]_i_8_n_0\,
      I3 => \^rec_reg[8]_0\(1),
      I4 => \^rec_reg[8]_0\(0),
      I5 => \^rec_reg[8]_0\(5),
      O => \REC[4]_i_8_n_0\
    );
\REC[5]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AABBBABBBBBBBABB"
    )
        port map (
      I0 => \REC[5]_i_2_n_0\,
      I1 => \REC[5]_i_3_n_0\,
      I2 => \REC[5]_i_4_n_0\,
      I3 => \REC_reg[8]_2\,
      I4 => \REC[7]_i_2_n_0\,
      I5 => \REC[5]_i_5_n_0\,
      O => \REC[5]_i_1_n_0\
    );
\REC[5]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAA22AA2222A222"
    )
        port map (
      I0 => \REC[5]_i_6_n_0\,
      I1 => \^rec_reg[8]_1\,
      I2 => \^rec_reg[8]_0\(6),
      I3 => \REC[5]_i_7_n_0\,
      I4 => \REC[5]_i_8_n_0\,
      I5 => \^rec_reg[8]_0\(5),
      O => \REC[5]_i_2_n_0\
    );
\REC[5]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFAABA"
    )
        port map (
      I0 => \REC[8]_i_6_n_0\,
      I1 => \^state_reg[0]_1\,
      I2 => req_Error_RX,
      I3 => \REC[5]_i_4_n_0\,
      I4 => \REC[5]_i_9_n_0\,
      O => \REC[5]_i_3_n_0\
    );
\REC[5]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"6AAAAAAAAAAAAAAA"
    )
        port map (
      I0 => \^rec_reg[8]_0\(5),
      I1 => \^rec_reg[8]_0\(0),
      I2 => \^rec_reg[8]_0\(1),
      I3 => \^rec_reg[8]_0\(2),
      I4 => \^rec_reg[8]_0\(4),
      I5 => \^rec_reg[8]_0\(3),
      O => \REC[5]_i_4_n_0\
    );
\REC[5]_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"EABF"
    )
        port map (
      I0 => \^rec_reg[8]_0\(8),
      I1 => \^rec_reg[8]_0\(4),
      I2 => \^rec_reg[8]_0\(3),
      I3 => \^rec_reg[8]_0\(5),
      O => \REC[5]_i_5_n_0\
    );
\REC[5]_i_6\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"44444044"
    )
        port map (
      I0 => donefromrxr_reg_n_0,
      I1 => \REC_reg[6]_0\,
      I2 => \^state_reg[2]_0\(1),
      I3 => \^state_reg[2]_0\(2),
      I4 => \^state_reg[2]_0\(0),
      O => \REC[5]_i_6_n_0\
    );
\REC[5]_i_7\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \^rec_reg[8]_0\(1),
      I1 => \^rec_reg[8]_0\(0),
      O => \REC[5]_i_7_n_0\
    );
\REC[5]_i_8\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"FE"
    )
        port map (
      I0 => \^rec_reg[8]_0\(2),
      I1 => \^rec_reg[8]_0\(3),
      I2 => \^rec_reg[8]_0\(4),
      O => \REC[5]_i_8_n_0\
    );
\REC[5]_i_9\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"AAAA8222"
    )
        port map (
      I0 => \REC_reg[8]_3\,
      I1 => \^rec_reg[8]_0\(5),
      I2 => \^rec_reg[8]_0\(3),
      I3 => \^rec_reg[8]_0\(4),
      I4 => \REC[7]_i_7_n_0\,
      O => \REC[5]_i_9_n_0\
    );
\REC[6]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"ABBBABBBBBBBAABB"
    )
        port map (
      I0 => \REC[6]_i_2_n_0\,
      I1 => \REC[6]_i_3_n_0\,
      I2 => \REC[6]_i_4_n_0\,
      I3 => \REC_reg[8]_2\,
      I4 => \REC[6]_i_5_n_0\,
      I5 => \REC[7]_i_2_n_0\,
      O => \REC[6]_i_1_n_0\
    );
\REC[6]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000008A0000"
    )
        port map (
      I0 => \REC[6]_i_6_n_0\,
      I1 => \^rec_reg[8]_0\(6),
      I2 => \^rec_reg[8]_1\,
      I3 => donefromrxr_reg_n_0,
      I4 => \REC_reg[6]_0\,
      I5 => \TEC[8]_i_18_n_0\,
      O => \REC[6]_i_2_n_0\
    );
\REC[6]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFBAAAAABA"
    )
        port map (
      I0 => \REC[8]_i_6_n_0\,
      I1 => \^state_reg[0]_1\,
      I2 => req_Error_RX,
      I3 => \REC[6]_i_8_n_0\,
      I4 => \^rec_reg[8]_0\(6),
      I5 => \REC[6]_i_9_n_0\,
      O => \REC[6]_i_3_n_0\
    );
\REC[6]_i_4\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"EAAABFFF"
    )
        port map (
      I0 => \^rec_reg[8]_0\(8),
      I1 => \^rec_reg[8]_0\(3),
      I2 => \^rec_reg[8]_0\(4),
      I3 => \^rec_reg[8]_0\(5),
      I4 => \^rec_reg[8]_0\(6),
      O => \REC[6]_i_4_n_0\
    );
\REC[6]_i_5\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"6AAAAAAA"
    )
        port map (
      I0 => \^rec_reg[8]_0\(6),
      I1 => \REC[7]_i_6_n_0\,
      I2 => \^rec_reg[8]_0\(3),
      I3 => \^rec_reg[8]_0\(4),
      I4 => \^rec_reg[8]_0\(5),
      O => \REC[6]_i_5_n_0\
    );
\REC[6]_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFFFFE"
    )
        port map (
      I0 => \^rec_reg[8]_0\(5),
      I1 => \^rec_reg[8]_0\(0),
      I2 => \^rec_reg[8]_0\(1),
      I3 => \REC[5]_i_8_n_0\,
      I4 => \^rec_reg[8]_0\(7),
      I5 => \^rec_reg[8]_0\(8),
      O => \REC[6]_i_6_n_0\
    );
\REC[6]_i_7\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \^rec_reg[8]_0\(8),
      I1 => \^rec_reg[8]_0\(7),
      O => \^rec_reg[8]_1\
    );
\REC[6]_i_8\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8000000000000000"
    )
        port map (
      I0 => \^rec_reg[8]_0\(5),
      I1 => \^rec_reg[8]_0\(4),
      I2 => \^rec_reg[8]_0\(3),
      I3 => \^rec_reg[8]_0\(2),
      I4 => \^rec_reg[8]_0\(1),
      I5 => \^rec_reg[8]_0\(0),
      O => \REC[6]_i_8_n_0\
    );
\REC[6]_i_9\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAAAAA82222222"
    )
        port map (
      I0 => \REC_reg[8]_3\,
      I1 => \^rec_reg[8]_0\(6),
      I2 => \^rec_reg[8]_0\(5),
      I3 => \^rec_reg[8]_0\(4),
      I4 => \^rec_reg[8]_0\(3),
      I5 => \REC[7]_i_7_n_0\,
      O => \REC[6]_i_9_n_0\
    );
\REC[7]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000004FEF"
    )
        port map (
      I0 => \REC[7]_i_2_n_0\,
      I1 => \REC[7]_i_3_n_0\,
      I2 => \REC_reg[8]_2\,
      I3 => \REC[7]_i_4_n_0\,
      I4 => \REC[7]_i_5_n_0\,
      I5 => \REC[8]_i_6_n_0\,
      O => \REC[7]_i_1_n_0\
    );
\REC[7]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFEFFF"
    )
        port map (
      I0 => \State_reg[2]_i_2_n_0\,
      I1 => \State[1]_i_2_n_0\,
      I2 => \REC[8]_i_14_n_0\,
      I3 => \^state_reg[2]_0\(0),
      I4 => \State[0]_i_2_n_0\,
      I5 => imTX,
      O => \REC[7]_i_2_n_0\
    );
\REC[7]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"6AAAAAAAAAAAAAAA"
    )
        port map (
      I0 => \^rec_reg[8]_0\(7),
      I1 => \^rec_reg[8]_0\(6),
      I2 => \^rec_reg[8]_0\(5),
      I3 => \^rec_reg[8]_0\(4),
      I4 => \^rec_reg[8]_0\(3),
      I5 => \REC[7]_i_6_n_0\,
      O => \REC[7]_i_3_n_0\
    );
\REC[7]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"EAAAAAAABFFFFFFF"
    )
        port map (
      I0 => \^rec_reg[8]_0\(8),
      I1 => \^rec_reg[8]_0\(5),
      I2 => \^rec_reg[8]_0\(4),
      I3 => \^rec_reg[8]_0\(3),
      I4 => \^rec_reg[8]_0\(6),
      I5 => \^rec_reg[8]_0\(7),
      O => \REC[7]_i_4_n_0\
    );
\REC[7]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"E0E0E0E0E0FFE0E0"
    )
        port map (
      I0 => \REC[7]_i_7_n_0\,
      I1 => \REC[7]_i_8_n_0\,
      I2 => \REC_reg[8]_3\,
      I3 => \REC[7]_i_3_n_0\,
      I4 => req_Error_RX,
      I5 => \^state_reg[0]_1\,
      O => \REC[7]_i_5_n_0\
    );
\REC[7]_i_6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"80"
    )
        port map (
      I0 => \^rec_reg[8]_0\(0),
      I1 => \^rec_reg[8]_0\(1),
      I2 => \^rec_reg[8]_0\(2),
      O => \REC[7]_i_6_n_0\
    );
\REC[7]_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0800"
    )
        port map (
      I0 => \REC[8]_i_16_n_0\,
      I1 => \^rec_reg[8]_0\(8),
      I2 => imTX,
      I3 => \REC[7]_i_9_n_0\,
      O => \REC[7]_i_7_n_0\
    );
\REC[7]_i_8\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"95555555"
    )
        port map (
      I0 => \^rec_reg[8]_0\(7),
      I1 => \^rec_reg[8]_0\(6),
      I2 => \^rec_reg[8]_0\(3),
      I3 => \^rec_reg[8]_0\(4),
      I4 => \^rec_reg[8]_0\(5),
      O => \REC[7]_i_8_n_0\
    );
\REC[7]_i_9\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000200"
    )
        port map (
      I0 => \Cnt[3]_i_3__1_n_0\,
      I1 => Sampled_din,
      I2 => \^state_reg[2]_0\(0),
      I3 => \^state_reg[2]_0\(1),
      I4 => \^state_reg[2]_0\(2),
      O => \REC[7]_i_9_n_0\
    );
\REC[8]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAAAAA0222AAAA"
    )
        port map (
      I0 => E(0),
      I1 => imTX,
      I2 => \REC[8]_i_3_n_0\,
      I3 => \REC[8]_i_4_n_0\,
      I4 => \REC_reg[8]_2\,
      I5 => \REC[8]_i_6_n_0\,
      O => \REC[8]_i_1_n_0\
    );
\REC[8]_i_10\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"80000000"
    )
        port map (
      I0 => \^rec_reg[8]_0\(6),
      I1 => \^rec_reg[8]_0\(3),
      I2 => \^rec_reg[8]_0\(4),
      I3 => \^rec_reg[8]_0\(5),
      I4 => \^rec_reg[8]_0\(7),
      O => \REC[8]_i_10_n_0\
    );
\REC[8]_i_11\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"95555555"
    )
        port map (
      I0 => \^rec_reg[8]_0\(8),
      I1 => \^rec_reg[8]_0\(0),
      I2 => \^rec_reg[8]_0\(1),
      I3 => \^rec_reg[8]_0\(2),
      I4 => \REC[8]_i_10_n_0\,
      O => \REC[8]_i_11_n_0\
    );
\REC[8]_i_13\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"40FFFF4040404040"
    )
        port map (
      I0 => imTX,
      I1 => \REC[8]_i_15_n_0\,
      I2 => \REC[8]_i_16_n_0\,
      I3 => \^rec_reg[8]_0\(8),
      I4 => \REC[8]_i_10_n_0\,
      I5 => \REC_reg[8]_3\,
      O => \REC[8]_i_13_n_0\
    );
\REC[8]_i_14\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \^state_reg[2]_0\(1),
      I1 => \^state_reg[2]_0\(2),
      O => \REC[8]_i_14_n_0\
    );
\REC[8]_i_15\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0004000000000000"
    )
        port map (
      I0 => \^state_reg[2]_0\(2),
      I1 => \^state_reg[2]_0\(1),
      I2 => \^state_reg[2]_0\(0),
      I3 => Sampled_din,
      I4 => \Cnt[3]_i_3__1_n_0\,
      I5 => \^rec_reg[8]_0\(8),
      O => \REC[8]_i_15_n_0\
    );
\REC[8]_i_16\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFFFFE"
    )
        port map (
      I0 => \REC[5]_i_8_n_0\,
      I1 => \^rec_reg[8]_0\(5),
      I2 => \^rec_reg[8]_0\(0),
      I3 => \^rec_reg[8]_0\(1),
      I4 => \^rec_reg[8]_0\(7),
      I5 => \^rec_reg[8]_0\(6),
      O => \REC[8]_i_16_n_0\
    );
\REC[8]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"ABAABBBBBBBBBBBB"
    )
        port map (
      I0 => \REC[8]_i_7_n_0\,
      I1 => \REC[8]_i_8_n_0\,
      I2 => \REC[8]_i_9_n_0\,
      I3 => \REC[8]_i_10_n_0\,
      I4 => \REC[8]_i_11_n_0\,
      I5 => \REC_reg[8]_2\,
      O => \REC[8]_i_2_n_0\
    );
\REC[8]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFEFFFFFF"
    )
        port map (
      I0 => \State_reg[2]_i_2_n_0\,
      I1 => \State[1]_i_2_n_0\,
      I2 => \^state_reg[2]_0\(2),
      I3 => \^state_reg[2]_0\(1),
      I4 => \^state_reg[2]_0\(0),
      I5 => \State[0]_i_2_n_0\,
      O => \REC[8]_i_3_n_0\
    );
\REC[8]_i_4\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"DFFF"
    )
        port map (
      I0 => \^state_reg[2]_0\(0),
      I1 => \^state_reg[2]_0\(1),
      I2 => \^state_reg[2]_0\(2),
      I3 => Sampled_din,
      O => \REC[8]_i_4_n_0\
    );
\REC[8]_i_6\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"04FF0404"
    )
        port map (
      I0 => \^state_reg[2]_0\(1),
      I1 => \^state_reg[2]_0\(2),
      I2 => \^state_reg[2]_0\(0),
      I3 => donefromrxr_reg_n_0,
      I4 => \REC_reg[6]_0\,
      O => \REC[8]_i_6_n_0\
    );
\REC[8]_i_7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0404040004040404"
    )
        port map (
      I0 => \^state_reg[2]_0\(1),
      I1 => \^state_reg[2]_0\(2),
      I2 => \^state_reg[2]_0\(0),
      I3 => \State[1]_i_2_n_0\,
      I4 => \State_reg[2]_i_2_n_0\,
      I5 => \State[0]_i_2_n_0\,
      O => \REC[8]_i_7_n_0\
    );
\REC[8]_i_8\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAFFAEAAAAFBAA"
    )
        port map (
      I0 => \REC[8]_i_6_n_0\,
      I1 => req_Error_RX,
      I2 => \^state_reg[0]_1\,
      I3 => \REC_reg[8]_3\,
      I4 => \REC[8]_i_13_n_0\,
      I5 => \REC[8]_i_11_n_0\,
      O => \REC[8]_i_8_n_0\
    );
\REC[8]_i_9\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000001000"
    )
        port map (
      I0 => imTX,
      I1 => \State[0]_i_2_n_0\,
      I2 => \^state_reg[2]_0\(0),
      I3 => \REC[8]_i_14_n_0\,
      I4 => \State[1]_i_2_n_0\,
      I5 => \State_reg[2]_i_2_n_0\,
      O => \REC[8]_i_9_n_0\
    );
\REC_reg[0]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \REC[8]_i_1_n_0\,
      CLR => ack_error_reg_0,
      D => \REC[0]_i_1_n_0\,
      Q => \^rec_reg[8]_0\(0)
    );
\REC_reg[1]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \REC[8]_i_1_n_0\,
      CLR => ack_error_reg_0,
      D => \REC[1]_i_1_n_0\,
      Q => \^rec_reg[8]_0\(1)
    );
\REC_reg[2]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \REC[8]_i_1_n_0\,
      CLR => ack_error_reg_0,
      D => \REC[2]_i_1_n_0\,
      Q => \^rec_reg[8]_0\(2)
    );
\REC_reg[3]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \REC[8]_i_1_n_0\,
      CLR => ack_error_reg_0,
      D => \REC[3]_i_1_n_0\,
      Q => \^rec_reg[8]_0\(3)
    );
\REC_reg[4]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \REC[8]_i_1_n_0\,
      CLR => ack_error_reg_0,
      D => \REC[4]_i_1_n_0\,
      Q => \^rec_reg[8]_0\(4)
    );
\REC_reg[5]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \REC[8]_i_1_n_0\,
      CLR => ack_error_reg_0,
      D => \REC[5]_i_1_n_0\,
      Q => \^rec_reg[8]_0\(5)
    );
\REC_reg[6]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \REC[8]_i_1_n_0\,
      CLR => ack_error_reg_0,
      D => \REC[6]_i_1_n_0\,
      Q => \^rec_reg[8]_0\(6)
    );
\REC_reg[7]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \REC[8]_i_1_n_0\,
      CLR => ack_error_reg_0,
      D => \REC[7]_i_1_n_0\,
      Q => \^rec_reg[8]_0\(7)
    );
\REC_reg[8]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \REC[8]_i_1_n_0\,
      CLR => ack_error_reg_0,
      D => \REC[8]_i_2_n_0\,
      Q => \^rec_reg[8]_0\(8)
    );
\RECin_reg[7]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => RECin(0),
      CLR => ack_error_reg_0,
      D => \^rec_reg[8]_0\(7),
      Q => \RECin_reg_n_0_[7]\
    );
\RECin_reg[8]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => RECin(0),
      CLR => ack_error_reg_0,
      D => \^rec_reg[8]_0\(8),
      Q => \RECin_reg_n_0_[8]\
    );
RXBUS_d_i_1: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \^q_reg\,
      O => RXBUS
    );
\RXSTATES[0]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B7"
    )
        port map (
      I0 => \^state_reg[2]_0\(0),
      I1 => \^state_reg[2]_0\(2),
      I2 => \^state_reg[2]_0\(1),
      O => \State_reg[0]_2\
    );
\RXSTATES[0]_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"AAFE"
    )
        port map (
      I0 => req_Error_RX,
      I1 => \^state_reg[2]_0\(0),
      I2 => \^state_reg[2]_0\(1),
      I3 => \^state_reg[2]_0\(2),
      O => req_Error_reg
    );
\RXSTATES[1]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000000000800A"
    )
        port map (
      I0 => SRST,
      I1 => \^state_reg[2]_0\(2),
      I2 => \^state_reg[2]_0\(1),
      I3 => \^state_reg[2]_0\(0),
      I4 => req_Error_RX,
      I5 => \RXSTATES_reg[1]\,
      O => SRST_1(0)
    );
\RXSTATES[3]_i_3\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0083"
    )
        port map (
      I0 => \^state_reg[2]_0\(2),
      I1 => \^state_reg[2]_0\(1),
      I2 => \^state_reg[2]_0\(0),
      I3 => req_Error_RX,
      O => \State_reg[2]_2\
    );
\Reck[0]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \Reck[4]_i_2_n_0\,
      I1 => \Reck_reg_n_0_[0]\,
      O => Reckr(0)
    );
\Reck[1]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"28"
    )
        port map (
      I0 => \Reck[4]_i_2_n_0\,
      I1 => \Reck_reg_n_0_[1]\,
      I2 => \Reck_reg_n_0_[0]\,
      O => Reckr(1)
    );
\Reck[2]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2A80"
    )
        port map (
      I0 => \Reck[4]_i_2_n_0\,
      I1 => \Reck_reg_n_0_[0]\,
      I2 => \Reck_reg_n_0_[1]\,
      I3 => \Reck_reg_n_0_[2]\,
      O => Reckr(2)
    );
\Reck[3]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"2AAA8000"
    )
        port map (
      I0 => \Reck[4]_i_2_n_0\,
      I1 => \Reck_reg_n_0_[1]\,
      I2 => \Reck_reg_n_0_[0]\,
      I3 => \Reck_reg_n_0_[2]\,
      I4 => \Reck_reg_n_0_[3]\,
      O => Reckr(3)
    );
\Reck[4]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2AAAAAAA80000000"
    )
        port map (
      I0 => \Reck[4]_i_2_n_0\,
      I1 => \Reck_reg_n_0_[3]\,
      I2 => \Reck_reg_n_0_[2]\,
      I3 => \Reck_reg_n_0_[0]\,
      I4 => \Reck_reg_n_0_[1]\,
      I5 => \Reck_reg_n_0_[4]\,
      O => Reckr(4)
    );
\Reck[4]_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0400"
    )
        port map (
      I0 => \^state_reg[2]_0\(1),
      I1 => \^state_reg[2]_0\(2),
      I2 => \^state_reg[2]_0\(0),
      I3 => \Reck[4]_i_3_n_0\,
      O => \Reck[4]_i_2_n_0\
    );
\Reck[4]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFF7FFFFFFFFFFFF"
    )
        port map (
      I0 => \Cnt_reg_n_0_[1]\,
      I1 => \Cnt_reg_n_0_[3]\,
      I2 => \Cnt_reg_n_0_[2]\,
      I3 => \Cnt_reg_n_0_[0]\,
      I4 => \Reck[6]_i_4_n_0\,
      I5 => \Reck_reg_n_0_[6]\,
      O => \Reck[4]_i_3_n_0\
    );
\Reck[5]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00101000"
    )
        port map (
      I0 => \^state_reg[2]_0\(1),
      I1 => \^state_reg[2]_0\(0),
      I2 => \^state_reg[2]_0\(2),
      I3 => \Reck_reg_n_0_[5]\,
      I4 => \Reck[5]_i_2_n_0\,
      O => Reckr(5)
    );
\Reck[5]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"80000000"
    )
        port map (
      I0 => \Reck_reg_n_0_[4]\,
      I1 => \Reck_reg_n_0_[1]\,
      I2 => \Reck_reg_n_0_[0]\,
      I3 => \Reck_reg_n_0_[2]\,
      I4 => \Reck_reg_n_0_[3]\,
      O => \Reck[5]_i_2_n_0\
    );
\Reck[6]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAAAAAAA08AAAA"
    )
        port map (
      I0 => E(0),
      I1 => Sampled_din,
      I2 => \Reck[6]_i_3_n_0\,
      I3 => \^state_reg[2]_0\(0),
      I4 => \^state_reg[2]_0\(2),
      I5 => \^state_reg[2]_0\(1),
      O => Reck(0)
    );
\Reck[6]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"01100000"
    )
        port map (
      I0 => \^state_reg[2]_0\(1),
      I1 => \^state_reg[2]_0\(0),
      I2 => \Reck_reg_n_0_[6]\,
      I3 => \Reck[6]_i_4_n_0\,
      I4 => \^state_reg[2]_0\(2),
      O => Reckr(6)
    );
\Reck[6]_i_3\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"EFFF"
    )
        port map (
      I0 => \Cnt_reg_n_0_[0]\,
      I1 => \Cnt_reg_n_0_[2]\,
      I2 => \Cnt_reg_n_0_[3]\,
      I3 => \Cnt_reg_n_0_[1]\,
      O => \Reck[6]_i_3_n_0\
    );
\Reck[6]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8000000000000000"
    )
        port map (
      I0 => \Reck_reg_n_0_[3]\,
      I1 => \Reck_reg_n_0_[2]\,
      I2 => \Reck_reg_n_0_[0]\,
      I3 => \Reck_reg_n_0_[1]\,
      I4 => \Reck_reg_n_0_[4]\,
      I5 => \Reck_reg_n_0_[5]\,
      O => \Reck[6]_i_4_n_0\
    );
\Reck_reg[0]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => Reck(0),
      CLR => ack_error_reg_0,
      D => Reckr(0),
      Q => \Reck_reg_n_0_[0]\
    );
\Reck_reg[1]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => Reck(0),
      CLR => ack_error_reg_0,
      D => Reckr(1),
      Q => \Reck_reg_n_0_[1]\
    );
\Reck_reg[2]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => Reck(0),
      CLR => ack_error_reg_0,
      D => Reckr(2),
      Q => \Reck_reg_n_0_[2]\
    );
\Reck_reg[3]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => Reck(0),
      CLR => ack_error_reg_0,
      D => Reckr(3),
      Q => \Reck_reg_n_0_[3]\
    );
\Reck_reg[4]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => Reck(0),
      CLR => ack_error_reg_0,
      D => Reckr(4),
      Q => \Reck_reg_n_0_[4]\
    );
\Reck_reg[5]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => Reck(0),
      CLR => ack_error_reg_0,
      D => Reckr(5),
      Q => \Reck_reg_n_0_[5]\
    );
\Reck_reg[6]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => Reck(0),
      CLR => ack_error_reg_0,
      D => Reckr(6),
      Q => \Reck_reg_n_0_[6]\
    );
\State[0]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0404040404440404"
    )
        port map (
      I0 => \State[0]_i_2_n_0\,
      I1 => SRST,
      I2 => \^q\(8),
      I3 => \^state_reg[2]_0\(1),
      I4 => \^state_reg[2]_0\(2),
      I5 => \^state_reg[2]_0\(0),
      O => \State[0]_i_1_n_0\
    );
\State[0]_i_10\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFF0F0DDD0CCC0"
    )
        port map (
      I0 => \Cnt[3]_i_3__1_n_0\,
      I1 => \^state_reg[2]_0\(0),
      I2 => \^state_reg[2]_0\(1),
      I3 => \Cnt[0]_i_3__1_n_0\,
      I4 => \^q\(8),
      I5 => Sampled_din,
      O => \State[0]_i_10_n_0\
    );
\State[0]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000AABABBBA"
    )
        port map (
      I0 => \State[0]_i_3_n_0\,
      I1 => \^state_reg[2]_0\(0),
      I2 => \^q\(8),
      I3 => \State_reg[0]_5\,
      I4 => \State_reg[0]_4\,
      I5 => \State[0]_i_6_n_0\,
      O => \State[0]_i_2_n_0\
    );
\State[0]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFFF08"
    )
        port map (
      I0 => \^state_reg[2]_0\(0),
      I1 => \Cnt[0]_i_3__1_n_0\,
      I2 => \Cnt[0]_i_5__1_n_0\,
      I3 => \^state_reg[2]_0\(1),
      I4 => \^state_reg[2]_0\(2),
      O => \State[0]_i_3_n_0\
    );
\State[0]_i_6\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"BABABAAA"
    )
        port map (
      I0 => \State[0]_i_9_n_0\,
      I1 => \State[0]_i_10_n_0\,
      I2 => \^state_reg[2]_0\(2),
      I3 => \^state_reg[2]_0\(1),
      I4 => \^state_reg[2]_0\(0),
      O => \State[0]_i_6_n_0\
    );
\State[0]_i_9\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0440404004444040"
    )
        port map (
      I0 => \^state_reg[2]_0\(2),
      I1 => \^state_reg[2]_0\(1),
      I2 => Sampled_din,
      I3 => \Cnt[3]_i_9_n_0\,
      I4 => \^state_reg[2]_0\(0),
      I5 => \^q\(8),
      O => \State[0]_i_9_n_0\
    );
\State[1]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0808080808880808"
    )
        port map (
      I0 => \State[1]_i_2_n_0\,
      I1 => SRST,
      I2 => \^q\(8),
      I3 => \^state_reg[2]_0\(1),
      I4 => \^state_reg[2]_0\(2),
      I5 => \^state_reg[2]_0\(0),
      O => \State[1]_i_1_n_0\
    );
\State[1]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFF32023232"
    )
        port map (
      I0 => \State[1]_i_3_n_0\,
      I1 => \^state_reg[2]_0\(2),
      I2 => \^state_reg[2]_0\(1),
      I3 => \State[1]_i_4_n_0\,
      I4 => \^state_reg[2]_0\(0),
      I5 => \State[1]_i_5_n_0\,
      O => \State[1]_i_2_n_0\
    );
\State[1]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"F9000000"
    )
        port map (
      I0 => Sampled_din,
      I1 => lastvalue,
      I2 => TXpin_i_5_n_0,
      I3 => \Cnt[0]_i_3__1_n_0\,
      I4 => \^state_reg[2]_0\(0),
      O => \State[1]_i_3_n_0\
    );
\State[1]_i_4\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"AAAA8AAA"
    )
        port map (
      I0 => Sampled_din,
      I1 => \Cnt_reg_n_0_[0]\,
      I2 => \Cnt_reg_n_0_[1]\,
      I3 => \Cnt_reg_n_0_[2]\,
      I4 => \Cnt_reg_n_0_[3]\,
      O => \State[1]_i_4_n_0\
    );
\State[1]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00500C0000000000"
    )
        port map (
      I0 => \Cnt[3]_i_3__1_n_0\,
      I1 => \Cnt[0]_i_3__1_n_0\,
      I2 => Sampled_din,
      I3 => \^state_reg[2]_0\(0),
      I4 => \^state_reg[2]_0\(1),
      I5 => \^state_reg[2]_0\(2),
      O => \State[1]_i_5_n_0\
    );
\State[2]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAAAAA88888088"
    )
        port map (
      I0 => SRST,
      I1 => \^q\(8),
      I2 => \^state_reg[2]_0\(1),
      I3 => \^state_reg[2]_0\(2),
      I4 => \^state_reg[2]_0\(0),
      I5 => \State_reg[2]_i_2_n_0\,
      O => \State[2]_i_1_n_0\
    );
\State[2]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FBAAEAAAFBAAEAAA"
    )
        port map (
      I0 => \REC[0]_i_8_n_0\,
      I1 => \State_reg[2]_i_2_0\,
      I2 => \State_reg[0]_4\,
      I3 => \^state_reg[0]_0\,
      I4 => \^q\(8),
      I5 => \^state_reg[2]_0\(2),
      O => \State[2]_i_3_n_0\
    );
\State[2]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"050E050ECFFFC0FF"
    )
        port map (
      I0 => \Cnt[3]_i_3__1_n_0\,
      I1 => \^q\(8),
      I2 => \^state_reg[2]_0\(0),
      I3 => Sampled_din,
      I4 => \Reck[4]_i_3_n_0\,
      I5 => \^state_reg[2]_0\(1),
      O => \State[2]_i_4_n_0\
    );
\State[2]_i_6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \^state_reg[2]_0\(0),
      I1 => \^state_reg[2]_0\(1),
      O => \^state_reg[0]_0\
    );
\State_reg[0]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \State_reg[0]_3\,
      CLR => ack_error_reg_0,
      D => \State[0]_i_1_n_0\,
      Q => \^state_reg[2]_0\(0)
    );
\State_reg[1]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \State_reg[0]_3\,
      CLR => ack_error_reg_0,
      D => \State[1]_i_1_n_0\,
      Q => \^state_reg[2]_0\(1)
    );
\State_reg[2]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \State_reg[0]_3\,
      CLR => ack_error_reg_0,
      D => \State[2]_i_1_n_0\,
      Q => \^state_reg[2]_0\(2)
    );
\State_reg[2]_i_2\: unisim.vcomponents.MUXF7
     port map (
      I0 => \State[2]_i_3_n_0\,
      I1 => \State[2]_i_4_n_0\,
      O => \State_reg[2]_i_2_n_0\,
      S => \^state_reg[2]_0\(2)
    );
\TEC[0]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BBBBBBBBABAABBBB"
    )
        port map (
      I0 => \TEC[0]_i_2_n_0\,
      I1 => \TEC[0]_i_3_n_0\,
      I2 => \TEC[0]_i_4_n_0\,
      I3 => \TEC[8]_i_7_n_0\,
      I4 => \TEC[8]_i_5_n_0\,
      I5 => \TEC[0]_i_5_n_0\,
      O => \TEC[0]_i_1_n_0\
    );
\TEC[0]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \TEC[8]_i_21_n_0\,
      I1 => \^q\(0),
      O => \TEC[0]_i_2_n_0\
    );
\TEC[0]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFF8FFF8FFF8FFFF"
    )
        port map (
      I0 => \TEC_reg[0]_0\,
      I1 => \^q\(8),
      I2 => \TEC[8]_i_18_n_0\,
      I3 => \TEC[8]_i_12_n_0\,
      I4 => \TEC[8]_i_5_n_0\,
      I5 => \^q\(0),
      O => \TEC[0]_i_3_n_0\
    );
\TEC[0]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => \^q\(8),
      I1 => \^q\(0),
      O => \TEC[0]_i_4_n_0\
    );
\TEC[0]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000FFFFFDFF"
    )
        port map (
      I0 => imTX,
      I1 => \State_reg[2]_i_2_n_0\,
      I2 => \State[1]_i_2_n_0\,
      I3 => \TEC[8]_i_17_n_0\,
      I4 => \State[0]_i_2_n_0\,
      I5 => \TEC[0]_i_6_n_0\,
      O => \TEC[0]_i_5_n_0\
    );
\TEC[0]_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AEAAAAAAAAAAAAAA"
    )
        port map (
      I0 => \^q\(0),
      I1 => \^state_reg[2]_0\(0),
      I2 => \^state_reg[2]_0\(1),
      I3 => \^state_reg[2]_0\(2),
      I4 => Sampled_din,
      I5 => imTX,
      O => \TEC[0]_i_6_n_0\
    );
\TEC[1]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BBBBBBBBABAABBBB"
    )
        port map (
      I0 => \TEC[1]_i_2_n_0\,
      I1 => \TEC[1]_i_3_n_0\,
      I2 => \TEC[1]_i_4_n_0\,
      I3 => \TEC[8]_i_7_n_0\,
      I4 => \TEC[8]_i_5_n_0\,
      I5 => \TEC[1]_i_5_n_0\,
      O => \TEC[1]_i_1_n_0\
    );
\TEC[1]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \TEC[8]_i_21_n_0\,
      I1 => \^q\(1),
      O => \TEC[1]_i_2_n_0\
    );
\TEC[1]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFF8FFF8FFF8FFFF"
    )
        port map (
      I0 => \TEC_reg[0]_0\,
      I1 => \^q\(8),
      I2 => \TEC[8]_i_18_n_0\,
      I3 => \TEC[8]_i_12_n_0\,
      I4 => \TEC[8]_i_5_n_0\,
      I5 => \^q\(1),
      O => \TEC[1]_i_3_n_0\
    );
\TEC[1]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => \^q\(8),
      I1 => \^q\(1),
      O => \TEC[1]_i_4_n_0\
    );
\TEC[1]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000FFFFFDFF"
    )
        port map (
      I0 => imTX,
      I1 => \State_reg[2]_i_2_n_0\,
      I2 => \State[1]_i_2_n_0\,
      I3 => \TEC[8]_i_17_n_0\,
      I4 => \State[0]_i_2_n_0\,
      I5 => \TEC[1]_i_6_n_0\,
      O => \TEC[1]_i_5_n_0\
    );
\TEC[1]_i_6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"BE"
    )
        port map (
      I0 => \TEC[7]_i_8_n_0\,
      I1 => \^q\(1),
      I2 => \^q\(0),
      O => \TEC[1]_i_6_n_0\
    );
\TEC[2]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFF55551055"
    )
        port map (
      I0 => \TEC[2]_i_2_n_0\,
      I1 => \TEC[2]_i_3_n_0\,
      I2 => \TEC[8]_i_7_n_0\,
      I3 => \TEC[8]_i_5_n_0\,
      I4 => \TEC[2]_i_4_n_0\,
      I5 => \TEC[2]_i_5_n_0\,
      O => \TEC[2]_i_1_n_0\
    );
\TEC[2]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFF8FFF8FFF8FFFF"
    )
        port map (
      I0 => \TEC_reg[0]_0\,
      I1 => \^q\(8),
      I2 => \TEC[8]_i_18_n_0\,
      I3 => \TEC[8]_i_12_n_0\,
      I4 => \TEC[8]_i_5_n_0\,
      I5 => \^q\(2),
      O => \TEC[2]_i_2_n_0\
    );
\TEC[2]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => \^q\(8),
      I1 => \^q\(2),
      O => \TEC[2]_i_3_n_0\
    );
\TEC[2]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000FFFFFDFF"
    )
        port map (
      I0 => imTX,
      I1 => \State_reg[2]_i_2_n_0\,
      I2 => \State[1]_i_2_n_0\,
      I3 => \TEC[8]_i_17_n_0\,
      I4 => \State[0]_i_2_n_0\,
      I5 => \TEC[2]_i_6_n_0\,
      O => \TEC[2]_i_4_n_0\
    );
\TEC[2]_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \TEC[8]_i_21_n_0\,
      I1 => \^q\(2),
      O => \TEC[2]_i_5_n_0\
    );
\TEC[2]_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"ABFE"
    )
        port map (
      I0 => \TEC[7]_i_8_n_0\,
      I1 => \^q\(0),
      I2 => \^q\(1),
      I3 => \^q\(2),
      O => \TEC[2]_i_6_n_0\
    );
\TEC[3]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFF55551055"
    )
        port map (
      I0 => \TEC[3]_i_2_n_0\,
      I1 => \TEC[3]_i_3_n_0\,
      I2 => \TEC[8]_i_7_n_0\,
      I3 => \TEC[8]_i_5_n_0\,
      I4 => \TEC[3]_i_4_n_0\,
      I5 => \TEC[3]_i_5_n_0\,
      O => \TEC[3]_i_1_n_0\
    );
\TEC[3]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"EEEEEEEEFFFEFEFE"
    )
        port map (
      I0 => \TEC[8]_i_12_n_0\,
      I1 => \TEC[8]_i_18_n_0\,
      I2 => \^q\(3),
      I3 => \^q\(8),
      I4 => \TEC_reg[0]_0\,
      I5 => \TEC[8]_i_5_n_0\,
      O => \TEC[3]_i_2_n_0\
    );
\TEC[3]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \^q\(8),
      I1 => \^q\(3),
      O => \TEC[3]_i_3_n_0\
    );
\TEC[3]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000FFFFFDFF"
    )
        port map (
      I0 => imTX,
      I1 => \State_reg[2]_i_2_n_0\,
      I2 => \State[1]_i_2_n_0\,
      I3 => \TEC[8]_i_17_n_0\,
      I4 => \State[0]_i_2_n_0\,
      I5 => \TEC[3]_i_6_n_0\,
      O => \TEC[3]_i_4_n_0\
    );
\TEC[3]_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \TEC[8]_i_21_n_0\,
      I1 => \^q\(3),
      O => \TEC[3]_i_5_n_0\
    );
\TEC[3]_i_6\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"AAABFFFE"
    )
        port map (
      I0 => \TEC[7]_i_8_n_0\,
      I1 => \^q\(1),
      I2 => \^q\(0),
      I3 => \^q\(2),
      I4 => \^q\(3),
      O => \TEC[3]_i_6_n_0\
    );
\TEC[4]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BBBBBBBBABAABBBB"
    )
        port map (
      I0 => \TEC[4]_i_2_n_0\,
      I1 => \TEC[4]_i_3_n_0\,
      I2 => \TEC[4]_i_4_n_0\,
      I3 => \TEC[8]_i_7_n_0\,
      I4 => \TEC[8]_i_5_n_0\,
      I5 => \TEC[4]_i_5_n_0\,
      O => \TEC[4]_i_1_n_0\
    );
\TEC[4]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"28"
    )
        port map (
      I0 => \TEC[8]_i_21_n_0\,
      I1 => \^q\(3),
      I2 => \^q\(4),
      O => \TEC[4]_i_2_n_0\
    );
\TEC[4]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFEEEEFEFFEEE"
    )
        port map (
      I0 => \TEC[8]_i_12_n_0\,
      I1 => \TEC[8]_i_18_n_0\,
      I2 => \TEC[4]_i_6_n_0\,
      I3 => \TEC[8]_i_13_n_0\,
      I4 => \TEC_reg[0]_0\,
      I5 => \^q\(8),
      O => \TEC[4]_i_3_n_0\
    );
\TEC[4]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"EB"
    )
        port map (
      I0 => \^q\(8),
      I1 => \^q\(3),
      I2 => \^q\(4),
      O => \TEC[4]_i_4_n_0\
    );
\TEC[4]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000FFFFFDFF"
    )
        port map (
      I0 => imTX,
      I1 => \State_reg[2]_i_2_n_0\,
      I2 => \State[1]_i_2_n_0\,
      I3 => \TEC[8]_i_17_n_0\,
      I4 => \State[0]_i_2_n_0\,
      I5 => \TEC[4]_i_7_n_0\,
      O => \TEC[4]_i_5_n_0\
    );
\TEC[4]_i_6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \^q\(4),
      I1 => \^q\(3),
      O => \TEC[4]_i_6_n_0\
    );
\TEC[4]_i_7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAAAABFFFFFFFE"
    )
        port map (
      I0 => \TEC[7]_i_8_n_0\,
      I1 => \^q\(2),
      I2 => \^q\(0),
      I3 => \^q\(1),
      I4 => \^q\(3),
      I5 => \^q\(4),
      O => \TEC[4]_i_7_n_0\
    );
\TEC[5]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BBBBBBBBBAAABBBB"
    )
        port map (
      I0 => \TEC[5]_i_2_n_0\,
      I1 => \TEC[5]_i_3_n_0\,
      I2 => \TEC[5]_i_4_n_0\,
      I3 => \TEC[8]_i_7_n_0\,
      I4 => \TEC[8]_i_5_n_0\,
      I5 => \TEC[5]_i_5_n_0\,
      O => \TEC[5]_i_1_n_0\
    );
\TEC[5]_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2A80"
    )
        port map (
      I0 => \TEC[8]_i_21_n_0\,
      I1 => \^q\(4),
      I2 => \^q\(3),
      I3 => \^q\(5),
      O => \TEC[5]_i_2_n_0\
    );
\TEC[5]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFAABA"
    )
        port map (
      I0 => \TEC[8]_i_12_n_0\,
      I1 => \^state_reg[2]_0\(0),
      I2 => \^state_reg[2]_0\(2),
      I3 => \^state_reg[2]_0\(1),
      I4 => \TEC[5]_i_6_n_0\,
      O => \TEC[5]_i_3_n_0\
    );
\TEC[5]_i_4\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"1540"
    )
        port map (
      I0 => \^q\(8),
      I1 => \^q\(4),
      I2 => \^q\(3),
      I3 => \^q\(5),
      O => \TEC[5]_i_4_n_0\
    );
\TEC[5]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000FFFFFDFF"
    )
        port map (
      I0 => imTX,
      I1 => \State_reg[2]_i_2_n_0\,
      I2 => \State[1]_i_2_n_0\,
      I3 => \TEC[8]_i_17_n_0\,
      I4 => \State[0]_i_2_n_0\,
      I5 => \TEC[5]_i_7_n_0\,
      O => \TEC[5]_i_5_n_0\
    );
\TEC[5]_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FCCEEFFF000AAAA0"
    )
        port map (
      I0 => \TEC[8]_i_13_n_0\,
      I1 => \^q\(8),
      I2 => \^q\(4),
      I3 => \^q\(3),
      I4 => \^q\(5),
      I5 => \TEC_reg[0]_0\,
      O => \TEC[5]_i_6_n_0\
    );
\TEC[5]_i_7\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"AAAEFFFB"
    )
        port map (
      I0 => \TEC[7]_i_8_n_0\,
      I1 => \TEC[8]_i_15_n_0\,
      I2 => \^q\(3),
      I3 => \^q\(4),
      I4 => \^q\(5),
      O => \TEC[5]_i_7_n_0\
    );
\TEC[6]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BBBBBBBBBAAABBBB"
    )
        port map (
      I0 => \TEC[6]_i_2_n_0\,
      I1 => \TEC[6]_i_3_n_0\,
      I2 => \TEC[6]_i_4_n_0\,
      I3 => \TEC[8]_i_7_n_0\,
      I4 => \TEC[8]_i_5_n_0\,
      I5 => \TEC[6]_i_5_n_0\,
      O => \TEC[6]_i_1_n_0\
    );
\TEC[6]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"2AAA8000"
    )
        port map (
      I0 => \TEC[8]_i_21_n_0\,
      I1 => \^q\(3),
      I2 => \^q\(4),
      I3 => \^q\(5),
      I4 => \^q\(6),
      O => \TEC[6]_i_2_n_0\
    );
\TEC[6]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFEFEFEFEFEFFFE"
    )
        port map (
      I0 => \TEC[8]_i_12_n_0\,
      I1 => \TEC[8]_i_18_n_0\,
      I2 => \TEC[6]_i_6_n_0\,
      I3 => \TEC[8]_i_13_n_0\,
      I4 => \TEC[6]_i_7_n_0\,
      I5 => \^q\(6),
      O => \TEC[6]_i_3_n_0\
    );
\TEC[6]_i_4\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"15554000"
    )
        port map (
      I0 => \^q\(8),
      I1 => \^q\(3),
      I2 => \^q\(4),
      I3 => \^q\(5),
      I4 => \^q\(6),
      O => \TEC[6]_i_4_n_0\
    );
\TEC[6]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000FFFFFDFF"
    )
        port map (
      I0 => imTX,
      I1 => \State_reg[2]_i_2_n_0\,
      I2 => \State[1]_i_2_n_0\,
      I3 => \TEC[8]_i_17_n_0\,
      I4 => \State[0]_i_2_n_0\,
      I5 => \TEC[6]_i_8_n_0\,
      O => \TEC[6]_i_5_n_0\
    );
\TEC[6]_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAAAAA82222222"
    )
        port map (
      I0 => \TEC_reg[0]_0\,
      I1 => \^q\(6),
      I2 => \^q\(5),
      I3 => \^q\(4),
      I4 => \^q\(3),
      I5 => \^q\(8),
      O => \TEC[6]_i_6_n_0\
    );
\TEC[6]_i_7\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"01"
    )
        port map (
      I0 => \^q\(3),
      I1 => \^q\(4),
      I2 => \^q\(5),
      O => \TEC[6]_i_7_n_0\
    );
\TEC[6]_i_8\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAAAAEFFFFFFFB"
    )
        port map (
      I0 => \TEC[7]_i_8_n_0\,
      I1 => \TEC[8]_i_15_n_0\,
      I2 => \^q\(5),
      I3 => \^q\(4),
      I4 => \^q\(3),
      I5 => \^q\(6),
      O => \TEC[6]_i_8_n_0\
    );
\TEC[7]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFF55554055"
    )
        port map (
      I0 => \TEC[7]_i_2_n_0\,
      I1 => \TEC[7]_i_3_n_0\,
      I2 => \TEC[8]_i_7_n_0\,
      I3 => \TEC[8]_i_5_n_0\,
      I4 => \TEC[7]_i_4_n_0\,
      I5 => \TEC[7]_i_5_n_0\,
      O => \TEC[7]_i_1_n_0\
    );
\TEC[7]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFEEFE"
    )
        port map (
      I0 => \TEC[8]_i_12_n_0\,
      I1 => \TEC[8]_i_18_n_0\,
      I2 => \TEC_reg[0]_0\,
      I3 => \TEC[7]_i_3_n_0\,
      I4 => \TEC[7]_i_6_n_0\,
      O => \TEC[7]_i_2_n_0\
    );
\TEC[7]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"1555555540000000"
    )
        port map (
      I0 => \^q\(8),
      I1 => \^q\(5),
      I2 => \^q\(4),
      I3 => \^q\(3),
      I4 => \^q\(6),
      I5 => \^q\(7),
      O => \TEC[7]_i_3_n_0\
    );
\TEC[7]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000FFFFFDFF"
    )
        port map (
      I0 => imTX,
      I1 => \State_reg[2]_i_2_n_0\,
      I2 => \State[1]_i_2_n_0\,
      I3 => \TEC[8]_i_17_n_0\,
      I4 => \State[0]_i_2_n_0\,
      I5 => \TEC[7]_i_7_n_0\,
      O => \TEC[7]_i_4_n_0\
    );
\TEC[7]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2AAAAAAA80000000"
    )
        port map (
      I0 => \TEC[8]_i_21_n_0\,
      I1 => \^q\(5),
      I2 => \^q\(4),
      I3 => \^q\(3),
      I4 => \^q\(6),
      I5 => \^q\(7),
      O => \TEC[7]_i_5_n_0\
    );
\TEC[7]_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000002AAAAAAA8"
    )
        port map (
      I0 => \TEC[8]_i_13_n_0\,
      I1 => \^q\(5),
      I2 => \^q\(4),
      I3 => \^q\(3),
      I4 => \^q\(6),
      I5 => \^q\(7),
      O => \TEC[7]_i_6_n_0\
    );
\TEC[7]_i_7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAABAAAAFFFEFFFF"
    )
        port map (
      I0 => \TEC[7]_i_8_n_0\,
      I1 => \^q\(2),
      I2 => \^q\(0),
      I3 => \^q\(1),
      I4 => \TEC[8]_i_16_n_0\,
      I5 => \^q\(7),
      O => \TEC[7]_i_7_n_0\
    );
\TEC[7]_i_8\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00800000"
    )
        port map (
      I0 => imTX,
      I1 => Sampled_din,
      I2 => \^state_reg[2]_0\(2),
      I3 => \^state_reg[2]_0\(1),
      I4 => \^state_reg[2]_0\(0),
      O => \TEC[7]_i_8_n_0\
    );
\TEC[8]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8888888888888088"
    )
        port map (
      I0 => SRST,
      I1 => ack_error_reg_1,
      I2 => \TEC[8]_i_4_n_0\,
      I3 => \TEC[8]_i_5_n_0\,
      I4 => \TEC[8]_i_6_n_0\,
      I5 => \TEC[8]_i_7_n_0\,
      O => \TEC[8]_i_1_n_0\
    );
\TEC[8]_i_10\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"1555555555555555"
    )
        port map (
      I0 => \^q\(8),
      I1 => \^q\(7),
      I2 => \^q\(5),
      I3 => \^q\(4),
      I4 => \^q\(3),
      I5 => \^q\(6),
      O => \TEC[8]_i_10_n_0\
    );
\TEC[8]_i_11\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FD00FFFFFD00FD00"
    )
        port map (
      I0 => \State[0]_i_2_n_0\,
      I1 => \State_reg[2]_i_2_n_0\,
      I2 => \State[1]_i_2_n_0\,
      I3 => \TEC[8]_i_18_n_0\,
      I4 => \TEC[8]_i_20_n_0\,
      I5 => \TEC[8]_i_21_n_0\,
      O => \TEC[8]_i_11_n_0\
    );
\TEC[8]_i_12\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"AA02"
    )
        port map (
      I0 => \RECin_reg[7]_0\,
      I1 => \^state_reg[2]_0\(0),
      I2 => \^state_reg[2]_0\(1),
      I3 => \^state_reg[2]_0\(2),
      O => \TEC[8]_i_12_n_0\
    );
\TEC[8]_i_13\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000002000"
    )
        port map (
      I0 => ack_error_i_3_n_0,
      I1 => \TEC[8]_i_22_n_0\,
      I2 => ack_error_reg_n_0,
      I3 => nozero_reg_n_0,
      I4 => \Cnt_reg_n_0_[2]\,
      I5 => \Cnt_reg_n_0_[0]\,
      O => \TEC[8]_i_13_n_0\
    );
\TEC[8]_i_15\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"01"
    )
        port map (
      I0 => \^q\(1),
      I1 => \^q\(0),
      I2 => \^q\(2),
      O => \TEC[8]_i_15_n_0\
    );
\TEC[8]_i_16\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0001"
    )
        port map (
      I0 => \^q\(5),
      I1 => \^q\(4),
      I2 => \^q\(3),
      I3 => \^q\(6),
      O => \TEC[8]_i_16_n_0\
    );
\TEC[8]_i_17\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"40"
    )
        port map (
      I0 => \^state_reg[2]_0\(2),
      I1 => \^state_reg[2]_0\(1),
      I2 => \^state_reg[2]_0\(0),
      O => \TEC[8]_i_17_n_0\
    );
\TEC[8]_i_18\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"04"
    )
        port map (
      I0 => \^state_reg[2]_0\(0),
      I1 => \^state_reg[2]_0\(2),
      I2 => \^state_reg[2]_0\(1),
      O => \TEC[8]_i_18_n_0\
    );
\TEC[8]_i_19\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5555555555555556"
    )
        port map (
      I0 => \^q\(8),
      I1 => \^q\(7),
      I2 => \^q\(5),
      I3 => \^q\(4),
      I4 => \^q\(3),
      I5 => \^q\(6),
      O => \TEC[8]_i_19_n_0\
    );
\TEC[8]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFF11155515"
    )
        port map (
      I0 => \TEC[8]_i_8_n_0\,
      I1 => \TEC[8]_i_5_n_0\,
      I2 => \TEC[8]_i_9_n_0\,
      I3 => \TEC[8]_i_7_n_0\,
      I4 => \TEC[8]_i_10_n_0\,
      I5 => \TEC[8]_i_11_n_0\,
      O => \TEC[8]_i_2_n_0\
    );
\TEC[8]_i_20\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9555555555555555"
    )
        port map (
      I0 => \^q\(8),
      I1 => \^q\(7),
      I2 => \^q\(5),
      I3 => \^q\(4),
      I4 => \^q\(3),
      I5 => \^q\(6),
      O => \TEC[8]_i_20_n_0\
    );
\TEC[8]_i_21\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"A082"
    )
        port map (
      I0 => \RECin_reg[7]_0\,
      I1 => \^state_reg[2]_0\(1),
      I2 => \^state_reg[2]_0\(2),
      I3 => \^state_reg[2]_0\(0),
      O => \TEC[8]_i_21_n_0\
    );
\TEC[8]_i_22\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \Cnt_reg_n_0_[1]\,
      I1 => \Cnt_reg_n_0_[3]\,
      O => \TEC[8]_i_22_n_0\
    );
\TEC[8]_i_23\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FDFFFFCFFDFFFFFF"
    )
        port map (
      I0 => TXpin_i_5_n_0,
      I1 => \^state_reg[2]_0\(2),
      I2 => \^state_reg[2]_0\(1),
      I3 => \^state_reg[2]_0\(0),
      I4 => Sampled_din,
      I5 => \Cnt[3]_i_3__1_n_0\,
      O => \State_reg[2]_3\
    );
\TEC[8]_i_4\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FF04"
    )
        port map (
      I0 => \^state_reg[2]_0\(1),
      I1 => \^state_reg[2]_0\(2),
      I2 => \^state_reg[2]_0\(0),
      I3 => \TEC[8]_i_12_n_0\,
      O => \TEC[8]_i_4_n_0\
    );
\TEC[8]_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \TEC[8]_i_13_n_0\,
      I1 => \TEC_reg[0]_0\,
      O => \TEC[8]_i_5_n_0\
    );
\TEC[8]_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000FFDF0000"
    )
        port map (
      I0 => \TEC[8]_i_15_n_0\,
      I1 => \^q\(7),
      I2 => \TEC[8]_i_16_n_0\,
      I3 => \^q\(8),
      I4 => \TEC_reg[0]_1\,
      I5 => donefromtxr_reg_n_0,
      O => \TEC[8]_i_6_n_0\
    );
\TEC[8]_i_7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000200AAAAAAAA"
    )
        port map (
      I0 => imTX,
      I1 => \State_reg[2]_i_2_n_0\,
      I2 => \State[1]_i_2_n_0\,
      I3 => \TEC[8]_i_17_n_0\,
      I4 => \State[0]_i_2_n_0\,
      I5 => \REC[8]_i_4_n_0\,
      O => \TEC[8]_i_7_n_0\
    );
\TEC[8]_i_8\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FEFFEEEEFEEEFEEE"
    )
        port map (
      I0 => \TEC[8]_i_12_n_0\,
      I1 => \TEC[8]_i_18_n_0\,
      I2 => \TEC[8]_i_19_n_0\,
      I3 => \TEC[8]_i_13_n_0\,
      I4 => \TEC[8]_i_10_n_0\,
      I5 => \TEC_reg[0]_0\,
      O => \TEC[8]_i_8_n_0\
    );
\TEC[8]_i_9\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5555555555555559"
    )
        port map (
      I0 => \^q\(8),
      I1 => \TEC[8]_i_16_n_0\,
      I2 => \^q\(7),
      I3 => \^q\(1),
      I4 => \^q\(0),
      I5 => \^q\(2),
      O => \TEC[8]_i_9_n_0\
    );
\TEC_reg[0]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TEC[8]_i_1_n_0\,
      CLR => ack_error_reg_0,
      D => \TEC[0]_i_1_n_0\,
      Q => \^q\(0)
    );
\TEC_reg[1]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TEC[8]_i_1_n_0\,
      CLR => ack_error_reg_0,
      D => \TEC[1]_i_1_n_0\,
      Q => \^q\(1)
    );
\TEC_reg[2]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TEC[8]_i_1_n_0\,
      CLR => ack_error_reg_0,
      D => \TEC[2]_i_1_n_0\,
      Q => \^q\(2)
    );
\TEC_reg[3]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TEC[8]_i_1_n_0\,
      CLR => ack_error_reg_0,
      D => \TEC[3]_i_1_n_0\,
      Q => \^q\(3)
    );
\TEC_reg[4]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TEC[8]_i_1_n_0\,
      CLR => ack_error_reg_0,
      D => \TEC[4]_i_1_n_0\,
      Q => \^q\(4)
    );
\TEC_reg[5]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TEC[8]_i_1_n_0\,
      CLR => ack_error_reg_0,
      D => \TEC[5]_i_1_n_0\,
      Q => \^q\(5)
    );
\TEC_reg[6]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TEC[8]_i_1_n_0\,
      CLR => ack_error_reg_0,
      D => \TEC[6]_i_1_n_0\,
      Q => \^q\(6)
    );
\TEC_reg[7]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TEC[8]_i_1_n_0\,
      CLR => ack_error_reg_0,
      D => \TEC[7]_i_1_n_0\,
      Q => \^q\(7)
    );
\TEC_reg[8]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TEC[8]_i_1_n_0\,
      CLR => ack_error_reg_0,
      D => \TEC[8]_i_2_n_0\,
      Q => \^q\(8)
    );
\TECin[8]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B0B0B0BB"
    )
        port map (
      I0 => ack_error_reg_1,
      I1 => SRST,
      I2 => \TECin[8]_i_2_n_0\,
      I3 => \^state_reg[2]_0\(2),
      I4 => \TECin[8]_i_3_n_0\,
      O => RECin(0)
    );
\TECin[8]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0C100000FFFFFFFF"
    )
        port map (
      I0 => \Cnt[3]_i_3__1_n_0\,
      I1 => \^state_reg[2]_0\(0),
      I2 => \^state_reg[2]_0\(1),
      I3 => Sampled_din,
      I4 => \^state_reg[2]_0\(2),
      I5 => SRST,
      O => \TECin[8]_i_2_n_0\
    );
\TECin[8]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFF0FFFF11FF11"
    )
        port map (
      I0 => req_Error_RX,
      I1 => \RECin_reg[7]_0\,
      I2 => \Cnt[3]_i_9_n_0\,
      I3 => \^state_reg[2]_0\(1),
      I4 => Sampled_din,
      I5 => \^state_reg[2]_0\(0),
      O => \TECin[8]_i_3_n_0\
    );
\TECin_reg[7]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => RECin(0),
      CLR => ack_error_reg_0,
      D => \^q\(7),
      Q => \TECin_reg_n_0_[7]\
    );
\TECin_reg[8]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => RECin(0),
      CLR => ack_error_reg_0,
      D => \^q\(8),
      Q => \TECin_reg_n_0_[8]\
    );
\TXSTATES[0]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"40"
    )
        port map (
      I0 => \^state_reg[0]_1\,
      I1 => SRST,
      I2 => \TXSTATES_reg[0]\,
      O => D(0)
    );
\TXSTATES[1]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"40"
    )
        port map (
      I0 => \^state_reg[0]_1\,
      I1 => SRST,
      I2 => \TXSTATES_reg[1]\,
      O => D(1)
    );
\TXSTATES[2]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"A8"
    )
        port map (
      I0 => SRST,
      I1 => \^state_reg[0]_1\,
      I2 => \TXSTATES_reg[2]\,
      O => D(2)
    );
\TXSTATES[3]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"A8"
    )
        port map (
      I0 => SRST,
      I1 => \^state_reg[0]_1\,
      I2 => \TXSTATES_reg[3]\,
      O => D(3)
    );
\TXSTATES[3]_i_3\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FF0E"
    )
        port map (
      I0 => \^state_reg[2]_0\(0),
      I1 => \^state_reg[2]_0\(1),
      I2 => \^state_reg[2]_0\(2),
      I3 => \RECin_reg[7]_0\,
      O => \^state_reg[0]_1\
    );
TX_INST_0: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \^mode_1[1]\,
      O => TX
    );
TX_INST_0_i_1: unisim.vcomponents.LUT4
    generic map(
      INIT => X"00A2"
    )
        port map (
      I0 => TX_INST_0_i_2_n_0,
      I1 => Mode(1),
      I2 => Mode(2),
      I3 => Mode(0),
      O => \^mode_1[1]\
    );
TX_INST_0_i_2: unisim.vcomponents.LUT4
    generic map(
      INIT => X"5515"
    )
        port map (
      I0 => \^q\(8),
      I1 => TX_from_Err,
      I2 => AckTakeOver,
      I3 => IDE_i_2_0,
      O => TX_INST_0_i_2_n_0
    );
TXpin_i_1: unisim.vcomponents.LUT4
    generic map(
      INIT => X"E2FF"
    )
        port map (
      I0 => TXpin_i_2_n_0,
      I1 => \^state_reg[2]_0\(2),
      I2 => TXpin_i_3_n_0,
      I3 => SRST,
      O => TXpin_i_1_n_0
    );
TXpin_i_2: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B8BBBBBBB8BB8888"
    )
        port map (
      I0 => TXpin_i_4_n_0,
      I1 => \^state_reg[2]_0\(1),
      I2 => \Cnt[0]_i_3__1_n_0\,
      I3 => TXpin_i_5_n_0,
      I4 => \^state_reg[2]_0\(0),
      I5 => TXpin_i_6_n_0,
      O => TXpin_i_2_n_0
    );
TXpin_i_3: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CFCFF3C3FFFFF7C7"
    )
        port map (
      I0 => \Cnt[3]_i_3__1_n_0\,
      I1 => \^state_reg[2]_0\(1),
      I2 => \^state_reg[2]_0\(0),
      I3 => \Cnt[0]_i_3__1_n_0\,
      I4 => Sampled_din,
      I5 => \^tec_reg[8]_0\,
      O => TXpin_i_3_n_0
    );
TXpin_i_4: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFF5545FFFFFFFF"
    )
        port map (
      I0 => \Cnt[3]_i_9_n_0\,
      I1 => \^q\(8),
      I2 => \^rec_reg[8]_1\,
      I3 => \^q\(7),
      I4 => Sampled_din,
      I5 => \^state_reg[2]_0\(0),
      O => TXpin_i_4_n_0
    );
TXpin_i_5: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0001"
    )
        port map (
      I0 => \RECin_reg_n_0_[7]\,
      I1 => \TECin_reg_n_0_[8]\,
      I2 => \RECin_reg_n_0_[8]\,
      I3 => \TECin_reg_n_0_[7]\,
      O => TXpin_i_5_n_0
    );
TXpin_i_6: unisim.vcomponents.LUT5
    generic map(
      INIT => X"35353533"
    )
        port map (
      I0 => \^tec_reg[8]_0\,
      I1 => \State_reg[0]_4\,
      I2 => \^state_reg[2]_1\,
      I3 => \RECin_reg[7]_0\,
      I4 => req_Error_RX,
      O => TXpin_i_6_n_0
    );
TXpin_i_7: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0001"
    )
        port map (
      I0 => \^q\(8),
      I1 => \^rec_reg[8]_0\(8),
      I2 => \^rec_reg[8]_0\(7),
      I3 => \^q\(7),
      O => \^tec_reg[8]_0\
    );
TXpin_reg: unisim.vcomponents.FDPE
     port map (
      C => Tq,
      CE => \State_reg[0]_3\,
      D => TXpin_i_1_n_0,
      PRE => ack_error_reg_0,
      Q => TX_from_Err
    );
ack_error_i_1: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FEFFAAAA0200AAAA"
    )
        port map (
      I0 => ack_error,
      I1 => \Cnt[0]_i_4__1_n_0\,
      I2 => ack_error_i_3_n_0,
      I3 => ack_error_reg_1,
      I4 => SRST,
      I5 => ack_error_reg_n_0,
      O => ack_error_i_1_n_0
    );
ack_error_i_2: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000020000"
    )
        port map (
      I0 => SRST,
      I1 => \^state_reg[2]_0\(2),
      I2 => \^state_reg[2]_0\(1),
      I3 => \^state_reg[2]_0\(0),
      I4 => ack_error_reg_2,
      I5 => ack_error_reg_3,
      O => ack_error
    );
ack_error_i_3: unisim.vcomponents.LUT3
    generic map(
      INIT => X"04"
    )
        port map (
      I0 => \^state_reg[2]_0\(2),
      I1 => \^state_reg[2]_0\(1),
      I2 => \^state_reg[2]_0\(0),
      O => ack_error_i_3_n_0
    );
ack_error_reg: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => '1',
      CLR => ack_error_reg_0,
      D => ack_error_i_1_n_0,
      Q => ack_error_reg_n_0
    );
donefromrxr_reg: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \State_reg[0]_3\,
      CLR => ack_error_reg_0,
      D => donefromrxr,
      Q => donefromrxr_reg_n_0
    );
donefromtxr_reg: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \State_reg[0]_3\,
      CLR => ack_error_reg_0,
      D => donefromtxr,
      Q => donefromtxr_reg_n_0
    );
lastvalue_reg: unisim.vcomponents.FDPE
     port map (
      C => Tq,
      CE => \State_reg[0]_3\,
      D => lastvalue_reg_0,
      PRE => ack_error_reg_0,
      Q => lastvalue
    );
nozero_i_1: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFDFDFDFFFFFFFF"
    )
        port map (
      I0 => \^state_reg[2]_0\(0),
      I1 => \^state_reg[2]_0\(2),
      I2 => \^state_reg[2]_0\(1),
      I3 => Sampled_din,
      I4 => nozero_reg_n_0,
      I5 => SRST,
      O => nozero_i_1_n_0
    );
nozero_reg: unisim.vcomponents.FDPE
     port map (
      C => Tq,
      CE => \State_reg[0]_3\,
      D => nozero_i_1_n_0,
      PRE => ack_error_reg_0,
      Q => nozero_reg_n_0
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1_FPGAPROJECT_0_0_Prescaler is
  port (
    \count_reg[4]_0\ : out STD_LOGIC_VECTOR ( 1 downto 0 );
    clk : out STD_LOGIC;
    \count_reg[0]_0\ : out STD_LOGIC;
    CAN_CLK : in STD_LOGIC;
    \count_reg[0]_1\ : in STD_LOGIC;
    Tq_reg_0 : in STD_LOGIC;
    BRP_0 : in STD_LOGIC_VECTOR ( 4 downto 0 )
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of design_1_FPGAPROJECT_0_0_Prescaler : entity is "Prescaler";
end design_1_FPGAPROJECT_0_0_Prescaler;

architecture STRUCTURE of design_1_FPGAPROJECT_0_0_Prescaler is
  signal \count[0]_i_1_n_0\ : STD_LOGIC;
  signal \count[4]_i_3_n_0\ : STD_LOGIC;
  signal count_reg : STD_LOGIC_VECTOR ( 2 downto 0 );
  signal \^count_reg[4]_0\ : STD_LOGIC_VECTOR ( 1 downto 0 );
  signal ncount : STD_LOGIC_VECTOR ( 4 downto 1 );
  signal \ncount1__20\ : STD_LOGIC;
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \count[0]_i_1\ : label is "soft_lutpair161";
  attribute SOFT_HLUTNM of \count[1]_i_1\ : label is "soft_lutpair161";
  attribute SOFT_HLUTNM of \count[2]_i_1\ : label is "soft_lutpair160";
  attribute SOFT_HLUTNM of \count[3]_i_1\ : label is "soft_lutpair160";
begin
  \count_reg[4]_0\(1 downto 0) <= \^count_reg[4]_0\(1 downto 0);
Tq_i_2: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9009000000009009"
    )
        port map (
      I0 => count_reg(0),
      I1 => BRP_0(0),
      I2 => BRP_0(2),
      I3 => count_reg(2),
      I4 => BRP_0(1),
      I5 => count_reg(1),
      O => \count_reg[0]_0\
    );
Tq_reg: unisim.vcomponents.FDCE
     port map (
      C => CAN_CLK,
      CE => '1',
      CLR => \count_reg[0]_1\,
      D => Tq_reg_0,
      Q => clk
    );
\count[0]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \ncount1__20\,
      I1 => count_reg(0),
      O => \count[0]_i_1_n_0\
    );
\count[1]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"60"
    )
        port map (
      I0 => count_reg(1),
      I1 => count_reg(0),
      I2 => \ncount1__20\,
      O => ncount(1)
    );
\count[2]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6A00"
    )
        port map (
      I0 => count_reg(2),
      I1 => count_reg(1),
      I2 => count_reg(0),
      I3 => \ncount1__20\,
      O => ncount(2)
    );
\count[3]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"6AAA0000"
    )
        port map (
      I0 => \^count_reg[4]_0\(0),
      I1 => count_reg(2),
      I2 => count_reg(0),
      I3 => count_reg(1),
      I4 => \ncount1__20\,
      O => ncount(3)
    );
\count[4]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"6AAAAAAA00000000"
    )
        port map (
      I0 => \^count_reg[4]_0\(1),
      I1 => \^count_reg[4]_0\(0),
      I2 => count_reg(1),
      I3 => count_reg(0),
      I4 => count_reg(2),
      I5 => \ncount1__20\,
      O => ncount(4)
    );
\count[4]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B2FF00B2"
    )
        port map (
      I0 => \count[4]_i_3_n_0\,
      I1 => \^count_reg[4]_0\(0),
      I2 => BRP_0(3),
      I3 => \^count_reg[4]_0\(1),
      I4 => BRP_0(4),
      O => \ncount1__20\
    );
\count[4]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2F02FFFF00002F02"
    )
        port map (
      I0 => BRP_0(0),
      I1 => count_reg(0),
      I2 => count_reg(1),
      I3 => BRP_0(1),
      I4 => count_reg(2),
      I5 => BRP_0(2),
      O => \count[4]_i_3_n_0\
    );
\count_reg[0]\: unisim.vcomponents.FDCE
     port map (
      C => CAN_CLK,
      CE => '1',
      CLR => \count_reg[0]_1\,
      D => \count[0]_i_1_n_0\,
      Q => count_reg(0)
    );
\count_reg[1]\: unisim.vcomponents.FDCE
     port map (
      C => CAN_CLK,
      CE => '1',
      CLR => \count_reg[0]_1\,
      D => ncount(1),
      Q => count_reg(1)
    );
\count_reg[2]\: unisim.vcomponents.FDCE
     port map (
      C => CAN_CLK,
      CE => '1',
      CLR => \count_reg[0]_1\,
      D => ncount(2),
      Q => count_reg(2)
    );
\count_reg[3]\: unisim.vcomponents.FDCE
     port map (
      C => CAN_CLK,
      CE => '1',
      CLR => \count_reg[0]_1\,
      D => ncount(3),
      Q => \^count_reg[4]_0\(0)
    );
\count_reg[4]\: unisim.vcomponents.FDCE
     port map (
      C => CAN_CLK,
      CE => '1',
      CLR => \count_reg[0]_1\,
      D => ncount(4),
      Q => \^count_reg[4]_0\(1)
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1_FPGAPROJECT_0_0_Prescaler_4 is
  port (
    Tq : out STD_LOGIC;
    CAN_CLK : in STD_LOGIC;
    \count_reg[0]_0\ : in STD_LOGIC;
    BRP : in STD_LOGIC_VECTOR ( 4 downto 0 )
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of design_1_FPGAPROJECT_0_0_Prescaler_4 : entity is "Prescaler";
end design_1_FPGAPROJECT_0_0_Prescaler_4;

architecture STRUCTURE of design_1_FPGAPROJECT_0_0_Prescaler_4 is
  signal \^tq\ : STD_LOGIC;
  signal Tq_i_1_n_0 : STD_LOGIC;
  signal Tq_i_2_n_0 : STD_LOGIC;
  signal \count[0]_i_1_n_0\ : STD_LOGIC;
  signal \count[4]_i_3_n_0\ : STD_LOGIC;
  signal count_reg : STD_LOGIC_VECTOR ( 4 downto 0 );
  signal ncount : STD_LOGIC_VECTOR ( 4 downto 1 );
  signal \ncount1__20\ : STD_LOGIC;
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \count[0]_i_1\ : label is "soft_lutpair48";
  attribute SOFT_HLUTNM of \count[1]_i_1\ : label is "soft_lutpair48";
  attribute SOFT_HLUTNM of \count[2]_i_1\ : label is "soft_lutpair47";
  attribute SOFT_HLUTNM of \count[3]_i_1\ : label is "soft_lutpair47";
begin
  Tq <= \^tq\;
Tq_i_1: unisim.vcomponents.LUT6
    generic map(
      INIT => X"6FFFFF6F90000090"
    )
        port map (
      I0 => count_reg(4),
      I1 => BRP(4),
      I2 => Tq_i_2_n_0,
      I3 => BRP(3),
      I4 => count_reg(3),
      I5 => \^tq\,
      O => Tq_i_1_n_0
    );
Tq_i_2: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9009000000009009"
    )
        port map (
      I0 => count_reg(0),
      I1 => BRP(0),
      I2 => BRP(2),
      I3 => count_reg(2),
      I4 => BRP(1),
      I5 => count_reg(1),
      O => Tq_i_2_n_0
    );
Tq_reg: unisim.vcomponents.FDCE
     port map (
      C => CAN_CLK,
      CE => '1',
      CLR => \count_reg[0]_0\,
      D => Tq_i_1_n_0,
      Q => \^tq\
    );
\count[0]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \ncount1__20\,
      I1 => count_reg(0),
      O => \count[0]_i_1_n_0\
    );
\count[1]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"60"
    )
        port map (
      I0 => count_reg(1),
      I1 => count_reg(0),
      I2 => \ncount1__20\,
      O => ncount(1)
    );
\count[2]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6A00"
    )
        port map (
      I0 => count_reg(2),
      I1 => count_reg(1),
      I2 => count_reg(0),
      I3 => \ncount1__20\,
      O => ncount(2)
    );
\count[3]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"6AAA0000"
    )
        port map (
      I0 => count_reg(3),
      I1 => count_reg(2),
      I2 => count_reg(0),
      I3 => count_reg(1),
      I4 => \ncount1__20\,
      O => ncount(3)
    );
\count[4]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"6AAAAAAA00000000"
    )
        port map (
      I0 => count_reg(4),
      I1 => count_reg(3),
      I2 => count_reg(1),
      I3 => count_reg(0),
      I4 => count_reg(2),
      I5 => \ncount1__20\,
      O => ncount(4)
    );
\count[4]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B2FF00B2"
    )
        port map (
      I0 => \count[4]_i_3_n_0\,
      I1 => count_reg(3),
      I2 => BRP(3),
      I3 => count_reg(4),
      I4 => BRP(4),
      O => \ncount1__20\
    );
\count[4]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2F02FFFF00002F02"
    )
        port map (
      I0 => BRP(0),
      I1 => count_reg(0),
      I2 => count_reg(1),
      I3 => BRP(1),
      I4 => count_reg(2),
      I5 => BRP(2),
      O => \count[4]_i_3_n_0\
    );
\count_reg[0]\: unisim.vcomponents.FDCE
     port map (
      C => CAN_CLK,
      CE => '1',
      CLR => \count_reg[0]_0\,
      D => \count[0]_i_1_n_0\,
      Q => count_reg(0)
    );
\count_reg[1]\: unisim.vcomponents.FDCE
     port map (
      C => CAN_CLK,
      CE => '1',
      CLR => \count_reg[0]_0\,
      D => ncount(1),
      Q => count_reg(1)
    );
\count_reg[2]\: unisim.vcomponents.FDCE
     port map (
      C => CAN_CLK,
      CE => '1',
      CLR => \count_reg[0]_0\,
      D => ncount(2),
      Q => count_reg(2)
    );
\count_reg[3]\: unisim.vcomponents.FDCE
     port map (
      C => CAN_CLK,
      CE => '1',
      CLR => \count_reg[0]_0\,
      D => ncount(3),
      Q => count_reg(3)
    );
\count_reg[4]\: unisim.vcomponents.FDCE
     port map (
      C => CAN_CLK,
      CE => '1',
      CLR => \count_reg[0]_0\,
      D => ncount(4),
      Q => count_reg(4)
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1_FPGAPROJECT_0_0_Rengine is
  port (
    RXBUS_d : out STD_LOGIC;
    Sampled_din : out STD_LOGIC;
    \CNT1_reg[4]_0\ : out STD_LOGIC;
    E : out STD_LOGIC_VECTOR ( 0 to 0 );
    \CNT1_reg[4]_1\ : out STD_LOGIC;
    SRST_0_0 : out STD_LOGIC_VECTOR ( 0 to 0 );
    \CNT2_reg[0]_0\ : out STD_LOGIC;
    SRST_0_1 : out STD_LOGIC_VECTOR ( 0 to 0 );
    RXOUT_reg_0 : out STD_LOGIC;
    RXBUS_d_reg_0 : out STD_LOGIC;
    \CNT1_reg[3]_0\ : out STD_LOGIC;
    SRST_0_2 : out STD_LOGIC_VECTOR ( 0 to 0 );
    RXOUT_reg_1 : out STD_LOGIC;
    RXOUT_reg_2 : out STD_LOGIC;
    RXBUS : in STD_LOGIC;
    clk : in STD_LOGIC;
    RXOUT_reg_3 : in STD_LOGIC;
    \CNT2_reg[1]_0\ : in STD_LOGIC;
    \CNT2_reg[0]_1\ : in STD_LOGIC;
    SRST_0 : in STD_LOGIC;
    lastvalue : in STD_LOGIC;
    \CNT1_reg[0]_0\ : in STD_LOGIC;
    \CNT1_reg[3]_1\ : in STD_LOGIC;
    \RXSTATES_reg[3]\ : in STD_LOGIC;
    \RXSTATES_reg[3]_0\ : in STD_LOGIC;
    \REC[0]_i_3\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \CNT2_reg[3]_0\ : in STD_LOGIC_VECTOR ( 0 to 0 )
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of design_1_FPGAPROJECT_0_0_Rengine : entity is "Rengine";
end design_1_FPGAPROJECT_0_0_Rengine;

architecture STRUCTURE of design_1_FPGAPROJECT_0_0_Rengine is
  signal \CNT1[1]_i_2_n_0\ : STD_LOGIC;
  signal \CNT1[3]_i_2_n_0\ : STD_LOGIC;
  signal \CNT1[3]_i_3_n_0\ : STD_LOGIC;
  signal \CNT1[3]_i_4_n_0\ : STD_LOGIC;
  signal \CNT1[4]_i_1_n_0\ : STD_LOGIC;
  signal \CNT1[4]_i_4_n_0\ : STD_LOGIC;
  signal \CNT1[4]_i_5_n_0\ : STD_LOGIC;
  signal \CNT1[4]_i_7_n_0\ : STD_LOGIC;
  signal \^cnt1_reg[3]_0\ : STD_LOGIC;
  signal \^cnt1_reg[4]_0\ : STD_LOGIC;
  signal \^cnt1_reg[4]_1\ : STD_LOGIC;
  signal \CNT1_reg_n_0_[0]\ : STD_LOGIC;
  signal \CNT1_reg_n_0_[1]\ : STD_LOGIC;
  signal \CNT1_reg_n_0_[2]\ : STD_LOGIC;
  signal \CNT1_reg_n_0_[3]\ : STD_LOGIC;
  signal \CNT1_reg_n_0_[4]\ : STD_LOGIC;
  signal CNT1r : STD_LOGIC_VECTOR ( 4 downto 0 );
  signal CNT1r1 : STD_LOGIC;
  signal \CNT1r1_inferred__0/i__carry_n_3\ : STD_LOGIC;
  signal CNT2 : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \CNT2[0]_i_2_n_0\ : STD_LOGIC;
  signal \CNT2[1]_i_2_n_0\ : STD_LOGIC;
  signal \CNT2[1]_i_3_n_0\ : STD_LOGIC;
  signal \CNT2[2]_i_2_n_0\ : STD_LOGIC;
  signal \CNT2[2]_i_3_n_0\ : STD_LOGIC;
  signal \CNT2[3]_i_3_n_0\ : STD_LOGIC;
  signal \CNT2[3]_i_4_n_0\ : STD_LOGIC;
  signal \^cnt2_reg[0]_0\ : STD_LOGIC;
  signal CNT2r : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \^rxbus_d\ : STD_LOGIC;
  signal \^rxbus_d_reg_0\ : STD_LOGIC;
  signal \^sampled_din\ : STD_LOGIC;
  signal \i__carry_i_1_n_0\ : STD_LOGIC;
  signal \i__carry_i_2_n_0\ : STD_LOGIC;
  signal \NLW_CNT1r1_inferred__0/i__carry_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_CNT1r1_inferred__0/i__carry_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \CNT1[1]_i_2\ : label is "soft_lutpair162";
  attribute SOFT_HLUTNM of \CNT1[2]_i_2\ : label is "soft_lutpair163";
  attribute SOFT_HLUTNM of \CNT1[3]_i_2\ : label is "soft_lutpair162";
  attribute SOFT_HLUTNM of \CNT1[3]_i_3\ : label is "soft_lutpair165";
  attribute SOFT_HLUTNM of \CNT1[4]_i_4\ : label is "soft_lutpair164";
  attribute SOFT_HLUTNM of \CNT1[4]_i_5\ : label is "soft_lutpair163";
  attribute SOFT_HLUTNM of \CNT1[4]_i_6\ : label is "soft_lutpair165";
  attribute SOFT_HLUTNM of \CNT2[1]_i_3\ : label is "soft_lutpair167";
  attribute SOFT_HLUTNM of \CNT2[3]_i_3\ : label is "soft_lutpair167";
  attribute SOFT_HLUTNM of \Cnt[3]_i_1__1\ : label is "soft_lutpair168";
  attribute SOFT_HLUTNM of \Cnt[3]_i_8__0\ : label is "soft_lutpair170";
  attribute SOFT_HLUTNM of \Cnt[5]_i_1__0\ : label is "soft_lutpair168";
  attribute SOFT_HLUTNM of \REC[0]_i_5\ : label is "soft_lutpair170";
  attribute SOFT_HLUTNM of RTR_i_2 : label is "soft_lutpair166";
  attribute SOFT_HLUTNM of \RXSTATES[3]_i_1\ : label is "soft_lutpair166";
  attribute SOFT_HLUTNM of \TEC[8]_i_3\ : label is "soft_lutpair164";
  attribute SOFT_HLUTNM of \TXSTATES[3]_i_1\ : label is "soft_lutpair169";
  attribute SOFT_HLUTNM of lastvalue_i_1 : label is "soft_lutpair169";
begin
  \CNT1_reg[3]_0\ <= \^cnt1_reg[3]_0\;
  \CNT1_reg[4]_0\ <= \^cnt1_reg[4]_0\;
  \CNT1_reg[4]_1\ <= \^cnt1_reg[4]_1\;
  \CNT2_reg[0]_0\ <= \^cnt2_reg[0]_0\;
  RXBUS_d <= \^rxbus_d\;
  RXBUS_d_reg_0 <= \^rxbus_d_reg_0\;
  Sampled_din <= \^sampled_din\;
\CNT1[0]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0C110C1100000C11"
    )
        port map (
      I0 => \^cnt1_reg[3]_0\,
      I1 => \CNT1_reg_n_0_[0]\,
      I2 => \CNT1[1]_i_2_n_0\,
      I3 => \CNT1_reg[0]_0\,
      I4 => \CNT2_reg[1]_0\,
      I5 => \^rxbus_d_reg_0\,
      O => CNT1r(0)
    );
\CNT1[1]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000093039"
    )
        port map (
      I0 => \CNT1_reg_n_0_[0]\,
      I1 => \CNT1_reg_n_0_[1]\,
      I2 => \CNT1_reg[0]_0\,
      I3 => \^cnt1_reg[3]_0\,
      I4 => \CNT1[1]_i_2_n_0\,
      I5 => \CNT1[3]_i_3_n_0\,
      O => CNT1r(1)
    );
\CNT1[1]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00010081"
    )
        port map (
      I0 => \CNT1_reg_n_0_[2]\,
      I1 => \CNT1_reg_n_0_[1]\,
      I2 => \CNT1_reg_n_0_[0]\,
      I3 => \CNT1_reg_n_0_[4]\,
      I4 => \CNT1_reg_n_0_[3]\,
      O => \CNT1[1]_i_2_n_0\
    );
\CNT1[2]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000005AE1"
    )
        port map (
      I0 => \CNT1_reg_n_0_[1]\,
      I1 => \CNT1_reg_n_0_[0]\,
      I2 => \CNT1_reg_n_0_[2]\,
      I3 => \CNT1_reg[0]_0\,
      I4 => \CNT1[3]_i_3_n_0\,
      I5 => \^cnt1_reg[3]_0\,
      O => CNT1r(2)
    );
\CNT1[2]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000001"
    )
        port map (
      I0 => \CNT1_reg_n_0_[3]\,
      I1 => \CNT1_reg_n_0_[0]\,
      I2 => \CNT1_reg_n_0_[1]\,
      I3 => \CNT1_reg_n_0_[2]\,
      I4 => \CNT1_reg_n_0_[4]\,
      O => \^cnt1_reg[3]_0\
    );
\CNT1[3]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FCFEFFFEFFFEFCFE"
    )
        port map (
      I0 => \CNT1[3]_i_2_n_0\,
      I1 => \^cnt2_reg[0]_0\,
      I2 => \CNT1[3]_i_3_n_0\,
      I3 => \CNT1_reg[0]_0\,
      I4 => \CNT1[3]_i_4_n_0\,
      I5 => \CNT1_reg_n_0_[3]\,
      O => CNT1r(3)
    );
\CNT1[3]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFC0002"
    )
        port map (
      I0 => \CNT1_reg_n_0_[4]\,
      I1 => \CNT1_reg_n_0_[0]\,
      I2 => \CNT1_reg_n_0_[1]\,
      I3 => \CNT1_reg_n_0_[2]\,
      I4 => \CNT1_reg_n_0_[3]\,
      O => \CNT1[3]_i_2_n_0\
    );
\CNT1[3]_i_3\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"8000"
    )
        port map (
      I0 => \CNT2_reg[1]_0\,
      I1 => \^sampled_din\,
      I2 => \^rxbus_d\,
      I3 => \CNT1_reg[3]_1\,
      O => \CNT1[3]_i_3_n_0\
    );
\CNT1[3]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \CNT1_reg_n_0_[1]\,
      I1 => \CNT1_reg_n_0_[2]\,
      O => \CNT1[3]_i_4_n_0\
    );
\CNT1[4]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FDFF"
    )
        port map (
      I0 => \CNT1_reg[0]_0\,
      I1 => \CNT2_reg[1]_0\,
      I2 => \CNT1[4]_i_4_n_0\,
      I3 => \^cnt1_reg[4]_0\,
      O => \CNT1[4]_i_1_n_0\
    );
\CNT1[4]_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"88B8"
    )
        port map (
      I0 => \CNT1[4]_i_5_n_0\,
      I1 => \^rxbus_d_reg_0\,
      I2 => \CNT1[4]_i_7_n_0\,
      I3 => \CNT2_reg[1]_0\,
      O => CNT1r(4)
    );
\CNT1[4]_i_4\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0001"
    )
        port map (
      I0 => CNT2(3),
      I1 => CNT2(1),
      I2 => CNT2(2),
      I3 => CNT2(0),
      O => \CNT1[4]_i_4_n_0\
    );
\CNT1[4]_i_5\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"AAAAAAA8"
    )
        port map (
      I0 => \CNT1_reg_n_0_[4]\,
      I1 => \CNT1_reg_n_0_[3]\,
      I2 => \CNT1_reg_n_0_[0]\,
      I3 => \CNT1_reg_n_0_[1]\,
      I4 => \CNT1_reg_n_0_[2]\,
      O => \CNT1[4]_i_5_n_0\
    );
\CNT1[4]_i_6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"7F"
    )
        port map (
      I0 => \CNT1_reg[3]_1\,
      I1 => \^rxbus_d\,
      I2 => \^sampled_din\,
      O => \^rxbus_d_reg_0\
    );
\CNT1[4]_i_7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"C3F0F0F0F0F0F0B0"
    )
        port map (
      I0 => \CNT1_reg_n_0_[0]\,
      I1 => \CNT2_reg[0]_1\,
      I2 => \CNT1_reg_n_0_[4]\,
      I3 => \CNT1_reg_n_0_[3]\,
      I4 => \CNT1_reg_n_0_[1]\,
      I5 => \CNT1_reg_n_0_[2]\,
      O => \CNT1[4]_i_7_n_0\
    );
\CNT1_reg[0]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \CNT1[4]_i_1_n_0\,
      CLR => RXOUT_reg_3,
      D => CNT1r(0),
      Q => \CNT1_reg_n_0_[0]\
    );
\CNT1_reg[1]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \CNT1[4]_i_1_n_0\,
      CLR => RXOUT_reg_3,
      D => CNT1r(1),
      Q => \CNT1_reg_n_0_[1]\
    );
\CNT1_reg[2]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \CNT1[4]_i_1_n_0\,
      CLR => RXOUT_reg_3,
      D => CNT1r(2),
      Q => \CNT1_reg_n_0_[2]\
    );
\CNT1_reg[3]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \CNT1[4]_i_1_n_0\,
      CLR => RXOUT_reg_3,
      D => CNT1r(3),
      Q => \CNT1_reg_n_0_[3]\
    );
\CNT1_reg[4]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \CNT1[4]_i_1_n_0\,
      CLR => RXOUT_reg_3,
      D => CNT1r(4),
      Q => \CNT1_reg_n_0_[4]\
    );
\CNT1r1_inferred__0/i__carry\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3 downto 2) => \NLW_CNT1r1_inferred__0/i__carry_CO_UNCONNECTED\(3 downto 2),
      CO(1) => CNT1r1,
      CO(0) => \CNT1r1_inferred__0/i__carry_n_3\,
      CYINIT => '1',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => \NLW_CNT1r1_inferred__0/i__carry_O_UNCONNECTED\(3 downto 0),
      S(3 downto 2) => B"00",
      S(1) => \i__carry_i_1_n_0\,
      S(0) => \i__carry_i_2_n_0\
    );
\CNT2[0]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"74"
    )
        port map (
      I0 => CNT2(0),
      I1 => \^rxbus_d_reg_0\,
      I2 => \CNT2[0]_i_2_n_0\,
      O => CNT2r(0)
    );
\CNT2[0]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFFAAFFAFFFFAEBE"
    )
        port map (
      I0 => \CNT2_reg[1]_0\,
      I1 => CNT1r1,
      I2 => CNT2(0),
      I3 => \CNT2[1]_i_3_n_0\,
      I4 => \^cnt2_reg[0]_0\,
      I5 => \CNT2_reg[0]_1\,
      O => \CNT2[0]_i_2_n_0\
    );
\CNT2[1]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"9F9F9F90"
    )
        port map (
      I0 => CNT2(1),
      I1 => CNT2(0),
      I2 => \^rxbus_d_reg_0\,
      I3 => \CNT2_reg[1]_0\,
      I4 => \CNT2[1]_i_2_n_0\,
      O => CNT2r(1)
    );
\CNT2[1]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"554E444FE4FFE4EF"
    )
        port map (
      I0 => \CNT2_reg[0]_1\,
      I1 => \^cnt2_reg[0]_0\,
      I2 => \CNT2[1]_i_3_n_0\,
      I3 => CNT2(1),
      I4 => CNT1r1,
      I5 => CNT2(0),
      O => \CNT2[1]_i_2_n_0\
    );
\CNT2[1]_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"01"
    )
        port map (
      I0 => CNT2(2),
      I1 => CNT2(1),
      I2 => CNT2(3),
      O => \CNT2[1]_i_3_n_0\
    );
\CNT2[2]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FC02FFFFFC020000"
    )
        port map (
      I0 => CNT2(3),
      I1 => CNT2(1),
      I2 => CNT2(0),
      I3 => CNT2(2),
      I4 => \^rxbus_d_reg_0\,
      I5 => \CNT2[2]_i_2_n_0\,
      O => CNT2r(2)
    );
\CNT2[2]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5151010101015101"
    )
        port map (
      I0 => \CNT2_reg[1]_0\,
      I1 => \CNT2[2]_i_3_n_0\,
      I2 => \CNT2_reg[0]_1\,
      I3 => CNT2(3),
      I4 => CNT2(1),
      I5 => CNT2(2),
      O => \CNT2[2]_i_2_n_0\
    );
\CNT2[2]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAFFAFFBAFFAAFFB"
    )
        port map (
      I0 => \^cnt2_reg[0]_0\,
      I1 => CNT2(3),
      I2 => CNT2(1),
      I3 => CNT2(2),
      I4 => CNT1r1,
      I5 => CNT2(0),
      O => \CNT2[2]_i_3_n_0\
    );
\CNT2[3]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8A008A008A008AFF"
    )
        port map (
      I0 => CNT2(3),
      I1 => CNT2(0),
      I2 => \CNT2[3]_i_3_n_0\,
      I3 => \^rxbus_d_reg_0\,
      I4 => \CNT2_reg[1]_0\,
      I5 => \CNT2[3]_i_4_n_0\,
      O => CNT2r(3)
    );
\CNT2[3]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => CNT2(1),
      I1 => CNT2(2),
      O => \CNT2[3]_i_3_n_0\
    );
\CNT2[3]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"EF4FFF4FFE4FFF4F"
    )
        port map (
      I0 => \CNT2_reg[0]_1\,
      I1 => \^cnt2_reg[0]_0\,
      I2 => CNT2(3),
      I3 => \CNT2[3]_i_3_n_0\,
      I4 => CNT1r1,
      I5 => CNT2(0),
      O => \CNT2[3]_i_4_n_0\
    );
\CNT2_reg[0]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \CNT2_reg[3]_0\(0),
      CLR => RXOUT_reg_3,
      D => CNT2r(0),
      Q => CNT2(0)
    );
\CNT2_reg[1]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \CNT2_reg[3]_0\(0),
      CLR => RXOUT_reg_3,
      D => CNT2r(1),
      Q => CNT2(1)
    );
\CNT2_reg[2]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \CNT2_reg[3]_0\(0),
      CLR => RXOUT_reg_3,
      D => CNT2r(2),
      Q => CNT2(2)
    );
\CNT2_reg[3]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \CNT2_reg[3]_0\(0),
      CLR => RXOUT_reg_3,
      D => CNT2r(3),
      Q => CNT2(3)
    );
\Cnt[3]_i_1__1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \^cnt2_reg[0]_0\,
      I1 => SRST_0,
      O => SRST_0_0(0)
    );
\Cnt[3]_i_8__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^sampled_din\,
      I1 => lastvalue,
      O => RXOUT_reg_0
    );
\Cnt[5]_i_1__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => \^cnt1_reg[4]_1\,
      I1 => SRST_0,
      O => E(0)
    );
\REC[0]_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \^sampled_din\,
      I1 => \REC[0]_i_3\(0),
      O => RXOUT_reg_2
    );
RTR_i_2: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \^cnt1_reg[4]_0\,
      I1 => \RXSTATES_reg[3]\,
      O => \^cnt1_reg[4]_1\
    );
RXBUS_d_reg: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => '1',
      CLR => RXOUT_reg_3,
      D => RXBUS,
      Q => \^rxbus_d\
    );
RXOUT_i_1: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000100000000"
    )
        port map (
      I0 => \CNT1_reg_n_0_[4]\,
      I1 => \CNT1_reg_n_0_[2]\,
      I2 => \CNT1_reg_n_0_[1]\,
      I3 => \CNT1_reg_n_0_[0]\,
      I4 => \CNT1_reg_n_0_[3]\,
      I5 => CNT1r1,
      O => \^cnt1_reg[4]_0\
    );
RXOUT_reg: unisim.vcomponents.FDPE
     port map (
      C => clk,
      CE => \^cnt1_reg[4]_0\,
      D => RXBUS,
      PRE => RXOUT_reg_3,
      Q => \^sampled_din\
    );
\RXSTATES[3]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2FAF"
    )
        port map (
      I0 => \^cnt1_reg[4]_0\,
      I1 => \RXSTATES_reg[3]_0\,
      I2 => SRST_0,
      I3 => \RXSTATES_reg[3]\,
      O => SRST_0_2(0)
    );
\TEC[8]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00010000"
    )
        port map (
      I0 => CNT2(0),
      I1 => CNT2(2),
      I2 => CNT2(1),
      I3 => CNT2(3),
      I4 => \^cnt1_reg[3]_0\,
      O => \^cnt2_reg[0]_0\
    );
\TXSTATES[3]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => \^cnt2_reg[0]_0\,
      I1 => SRST_0,
      O => SRST_0_1(0)
    );
\i__carry_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => CNT2(3),
      O => \i__carry_i_1_n_0\
    );
\i__carry_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"40"
    )
        port map (
      I0 => CNT2(2),
      I1 => CNT2(0),
      I2 => CNT2(1),
      O => \i__carry_i_2_n_0\
    );
lastvalue_i_1: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => \^sampled_din\,
      I1 => SRST_0,
      O => RXOUT_reg_1
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1_FPGAPROJECT_0_0_Rengine_5 is
  port (
    Sampled_din : out STD_LOGIC;
    E : out STD_LOGIC_VECTOR ( 0 to 0 );
    RXBUS_d_reg_0 : out STD_LOGIC;
    \CNT1_reg[3]_0\ : out STD_LOGIC;
    \CNT2_reg[3]_0\ : out STD_LOGIC;
    \RXSTATES_reg[3]\ : out STD_LOGIC;
    \CNT1_reg[3]_1\ : out STD_LOGIC;
    SRST_1 : out STD_LOGIC_VECTOR ( 0 to 0 );
    RXOUT_reg_0 : out STD_LOGIC;
    SRST_1_0 : out STD_LOGIC_VECTOR ( 0 to 0 );
    SRST_1_1 : out STD_LOGIC_VECTOR ( 0 to 0 );
    SRST_1_2 : out STD_LOGIC_VECTOR ( 0 to 0 );
    RXBUS : in STD_LOGIC;
    Tq : in STD_LOGIC;
    RXOUT_reg_1 : in STD_LOGIC;
    \CNT1_reg[4]_0\ : in STD_LOGIC;
    \CNT1_reg[4]_1\ : in STD_LOGIC;
    \CNT1_reg[4]_2\ : in STD_LOGIC;
    Q : in STD_LOGIC_VECTOR ( 0 to 0 );
    \RXSTATES_reg[3]_0\ : in STD_LOGIC;
    \RXSTATES_reg[3]_1\ : in STD_LOGIC;
    SRST : in STD_LOGIC;
    TPROP : in STD_LOGIC_VECTOR ( 3 downto 0 );
    TSEG1 : in STD_LOGIC_VECTOR ( 3 downto 0 );
    TSEG2 : in STD_LOGIC_VECTOR ( 3 downto 0 );
    SJW : in STD_LOGIC_VECTOR ( 2 downto 0 );
    \CNT2_reg[3]_1\ : in STD_LOGIC_VECTOR ( 0 to 0 )
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of design_1_FPGAPROJECT_0_0_Rengine_5 : entity is "Rengine";
end design_1_FPGAPROJECT_0_0_Rengine_5;

architecture STRUCTURE of design_1_FPGAPROJECT_0_0_Rengine_5 is
  signal \CNT1[0]_i_10_n_0\ : STD_LOGIC;
  signal \CNT1[0]_i_11_n_0\ : STD_LOGIC;
  signal \CNT1[0]_i_12_n_0\ : STD_LOGIC;
  signal \CNT1[0]_i_13_n_0\ : STD_LOGIC;
  signal \CNT1[0]_i_14_n_0\ : STD_LOGIC;
  signal \CNT1[0]_i_15_n_0\ : STD_LOGIC;
  signal \CNT1[0]_i_16_n_0\ : STD_LOGIC;
  signal \CNT1[0]_i_17_n_0\ : STD_LOGIC;
  signal \CNT1[0]_i_18_n_0\ : STD_LOGIC;
  signal \CNT1[0]_i_19_n_0\ : STD_LOGIC;
  signal \CNT1[0]_i_20_n_0\ : STD_LOGIC;
  signal \CNT1[0]_i_21_n_0\ : STD_LOGIC;
  signal \CNT1[0]_i_2_n_0\ : STD_LOGIC;
  signal \CNT1[0]_i_3_n_0\ : STD_LOGIC;
  signal \CNT1[0]_i_4_n_0\ : STD_LOGIC;
  signal \CNT1[0]_i_5_n_0\ : STD_LOGIC;
  signal \CNT1[0]_i_6_n_0\ : STD_LOGIC;
  signal \CNT1[0]_i_7_n_0\ : STD_LOGIC;
  signal \CNT1[0]_i_8_n_0\ : STD_LOGIC;
  signal \CNT1[0]_i_9_n_0\ : STD_LOGIC;
  signal \CNT1[1]_i_10_n_0\ : STD_LOGIC;
  signal \CNT1[1]_i_11_n_0\ : STD_LOGIC;
  signal \CNT1[1]_i_12_n_0\ : STD_LOGIC;
  signal \CNT1[1]_i_13_n_0\ : STD_LOGIC;
  signal \CNT1[1]_i_2_n_0\ : STD_LOGIC;
  signal \CNT1[1]_i_3_n_0\ : STD_LOGIC;
  signal \CNT1[1]_i_4_n_0\ : STD_LOGIC;
  signal \CNT1[1]_i_5_n_0\ : STD_LOGIC;
  signal \CNT1[1]_i_6_n_0\ : STD_LOGIC;
  signal \CNT1[1]_i_7_n_0\ : STD_LOGIC;
  signal \CNT1[1]_i_8_n_0\ : STD_LOGIC;
  signal \CNT1[1]_i_9_n_0\ : STD_LOGIC;
  signal \CNT1[2]_i_2_n_0\ : STD_LOGIC;
  signal \CNT1[2]_i_3_n_0\ : STD_LOGIC;
  signal \CNT1[2]_i_4_n_0\ : STD_LOGIC;
  signal \CNT1[2]_i_5_n_0\ : STD_LOGIC;
  signal \CNT1[2]_i_6_n_0\ : STD_LOGIC;
  signal \CNT1[2]_i_7_n_0\ : STD_LOGIC;
  signal \CNT1[2]_i_8_n_0\ : STD_LOGIC;
  signal \CNT1[2]_i_9_n_0\ : STD_LOGIC;
  signal \CNT1[3]_i_2_n_0\ : STD_LOGIC;
  signal \CNT1[3]_i_3_n_0\ : STD_LOGIC;
  signal \CNT1[3]_i_4_n_0\ : STD_LOGIC;
  signal \CNT1[3]_i_5_n_0\ : STD_LOGIC;
  signal \CNT1[3]_i_6_n_0\ : STD_LOGIC;
  signal \CNT1[4]_i_10_n_0\ : STD_LOGIC;
  signal \CNT1[4]_i_11_n_0\ : STD_LOGIC;
  signal \CNT1[4]_i_12_n_0\ : STD_LOGIC;
  signal \CNT1[4]_i_13_n_0\ : STD_LOGIC;
  signal \CNT1[4]_i_14_n_0\ : STD_LOGIC;
  signal \CNT1[4]_i_15_n_0\ : STD_LOGIC;
  signal \CNT1[4]_i_1_n_0\ : STD_LOGIC;
  signal \CNT1[4]_i_4_n_0\ : STD_LOGIC;
  signal \CNT1[4]_i_6_n_0\ : STD_LOGIC;
  signal \CNT1[4]_i_7_n_0\ : STD_LOGIC;
  signal \CNT1[4]_i_8_n_0\ : STD_LOGIC;
  signal \CNT1[4]_i_9_n_0\ : STD_LOGIC;
  signal \^cnt1_reg[3]_0\ : STD_LOGIC;
  signal \^cnt1_reg[3]_1\ : STD_LOGIC;
  signal \CNT1_reg_n_0_[0]\ : STD_LOGIC;
  signal \CNT1_reg_n_0_[1]\ : STD_LOGIC;
  signal \CNT1_reg_n_0_[2]\ : STD_LOGIC;
  signal \CNT1_reg_n_0_[3]\ : STD_LOGIC;
  signal \CNT1_reg_n_0_[4]\ : STD_LOGIC;
  signal CNT1r : STD_LOGIC_VECTOR ( 4 downto 0 );
  signal \CNT1r1_inferred__0/i__carry_n_2\ : STD_LOGIC;
  signal \CNT1r1_inferred__0/i__carry_n_3\ : STD_LOGIC;
  signal CNT2 : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \CNT2[0]_i_2_n_0\ : STD_LOGIC;
  signal \CNT2[0]_i_3_n_0\ : STD_LOGIC;
  signal \CNT2[0]_i_4_n_0\ : STD_LOGIC;
  signal \CNT2[0]_i_5_n_0\ : STD_LOGIC;
  signal \CNT2[1]_i_2_n_0\ : STD_LOGIC;
  signal \CNT2[1]_i_3_n_0\ : STD_LOGIC;
  signal \CNT2[1]_i_4_n_0\ : STD_LOGIC;
  signal \CNT2[1]_i_5_n_0\ : STD_LOGIC;
  signal \CNT2[1]_i_6_n_0\ : STD_LOGIC;
  signal \CNT2[2]_i_2_n_0\ : STD_LOGIC;
  signal \CNT2[2]_i_3_n_0\ : STD_LOGIC;
  signal \CNT2[2]_i_4_n_0\ : STD_LOGIC;
  signal \CNT2[2]_i_5_n_0\ : STD_LOGIC;
  signal \CNT2[2]_i_6_n_0\ : STD_LOGIC;
  signal \CNT2[2]_i_7_n_0\ : STD_LOGIC;
  signal \CNT2[3]_i_3_n_0\ : STD_LOGIC;
  signal \CNT2[3]_i_4_n_0\ : STD_LOGIC;
  signal \CNT2[3]_i_5_n_0\ : STD_LOGIC;
  signal \^cnt2_reg[3]_0\ : STD_LOGIC;
  signal CNT2r : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \^e\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal RXBUS_d : STD_LOGIC;
  signal \^rxbus_d_reg_0\ : STD_LOGIC;
  signal \^sampled_din\ : STD_LOGIC;
  signal \i__carry_i_1_n_0\ : STD_LOGIC;
  signal \i__carry_i_2_n_0\ : STD_LOGIC;
  signal \i__carry_i_3_n_0\ : STD_LOGIC;
  signal \NLW_CNT1r1_inferred__0/i__carry_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_CNT1r1_inferred__0/i__carry_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \CNT1[0]_i_17\ : label is "soft_lutpair55";
  attribute SOFT_HLUTNM of \CNT1[0]_i_18\ : label is "soft_lutpair56";
  attribute SOFT_HLUTNM of \CNT1[0]_i_2\ : label is "soft_lutpair57";
  attribute SOFT_HLUTNM of \CNT1[0]_i_20\ : label is "soft_lutpair56";
  attribute SOFT_HLUTNM of \CNT1[0]_i_21\ : label is "soft_lutpair55";
  attribute SOFT_HLUTNM of \CNT1[0]_i_9\ : label is "soft_lutpair62";
  attribute SOFT_HLUTNM of \CNT1[1]_i_12\ : label is "soft_lutpair57";
  attribute SOFT_HLUTNM of \CNT1[1]_i_13\ : label is "soft_lutpair62";
  attribute SOFT_HLUTNM of \CNT1[1]_i_6\ : label is "soft_lutpair61";
  attribute SOFT_HLUTNM of \CNT1[2]_i_5\ : label is "soft_lutpair50";
  attribute SOFT_HLUTNM of \CNT1[2]_i_7\ : label is "soft_lutpair54";
  attribute SOFT_HLUTNM of \CNT1[2]_i_8\ : label is "soft_lutpair61";
  attribute SOFT_HLUTNM of \CNT1[3]_i_3\ : label is "soft_lutpair54";
  attribute SOFT_HLUTNM of \CNT1[4]_i_10\ : label is "soft_lutpair63";
  attribute SOFT_HLUTNM of \CNT1[4]_i_15\ : label is "soft_lutpair53";
  attribute SOFT_HLUTNM of \CNT1[4]_i_4\ : label is "soft_lutpair51";
  attribute SOFT_HLUTNM of \CNT1[4]_i_5\ : label is "soft_lutpair50";
  attribute SOFT_HLUTNM of \CNT1[4]_i_6\ : label is "soft_lutpair53";
  attribute SOFT_HLUTNM of \CNT2[0]_i_4\ : label is "soft_lutpair59";
  attribute SOFT_HLUTNM of \CNT2[1]_i_6\ : label is "soft_lutpair59";
  attribute SOFT_HLUTNM of \CNT2[2]_i_3\ : label is "soft_lutpair58";
  attribute SOFT_HLUTNM of \CNT2[2]_i_4\ : label is "soft_lutpair52";
  attribute SOFT_HLUTNM of \CNT2[2]_i_6\ : label is "soft_lutpair52";
  attribute SOFT_HLUTNM of \CNT2[2]_i_7\ : label is "soft_lutpair60";
  attribute SOFT_HLUTNM of \CNT2[3]_i_4\ : label is "soft_lutpair60";
  attribute SOFT_HLUTNM of \Cnt[3]_i_1__1\ : label is "soft_lutpair63";
  attribute SOFT_HLUTNM of \Cnt[5]_i_1__0\ : label is "soft_lutpair64";
  attribute SOFT_HLUTNM of RTR_i_2 : label is "soft_lutpair49";
  attribute SOFT_HLUTNM of \RXSTATES[3]_i_1\ : label is "soft_lutpair49";
  attribute SOFT_HLUTNM of \TEC[8]_i_3\ : label is "soft_lutpair51";
  attribute SOFT_HLUTNM of \TOFILTERI[28]_i_7\ : label is "soft_lutpair64";
  attribute SOFT_HLUTNM of \TXSTATES[3]_i_1\ : label is "soft_lutpair65";
  attribute SOFT_HLUTNM of \i__carry_i_3\ : label is "soft_lutpair58";
  attribute SOFT_HLUTNM of lastvalue_i_1 : label is "soft_lutpair65";
begin
  \CNT1_reg[3]_0\ <= \^cnt1_reg[3]_0\;
  \CNT1_reg[3]_1\ <= \^cnt1_reg[3]_1\;
  \CNT2_reg[3]_0\ <= \^cnt2_reg[3]_0\;
  E(0) <= \^e\(0);
  RXBUS_d_reg_0 <= \^rxbus_d_reg_0\;
  Sampled_din <= \^sampled_din\;
\CNT1[0]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BBB8FFFF8B880000"
    )
        port map (
      I0 => \CNT1[0]_i_2_n_0\,
      I1 => \CNT1_reg[4]_0\,
      I2 => \CNT1_reg[4]_1\,
      I3 => \CNT1[0]_i_3_n_0\,
      I4 => \^rxbus_d_reg_0\,
      I5 => \CNT1[0]_i_4_n_0\,
      O => CNT1r(0)
    );
\CNT1[0]_i_10\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"EEFE00F0FFFFEEFE"
    )
        port map (
      I0 => SJW(0),
      I1 => \CNT1[1]_i_5_n_0\,
      I2 => SJW(2),
      I3 => \CNT1[0]_i_17_n_0\,
      I4 => SJW(1),
      I5 => \CNT1[1]_i_6_n_0\,
      O => \CNT1[0]_i_10_n_0\
    );
\CNT1[0]_i_11\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"010101FF01010101"
    )
        port map (
      I0 => SJW(2),
      I1 => SJW(0),
      I2 => SJW(1),
      I3 => TSEG1(2),
      I4 => \CNT1[1]_i_5_n_0\,
      I5 => \CNT1[0]_i_10_n_0\,
      O => \CNT1[0]_i_11_n_0\
    );
\CNT1[0]_i_12\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"18E700009EF71086"
    )
        port map (
      I0 => \CNT1[1]_i_5_n_0\,
      I1 => \CNT1_reg_n_0_[0]\,
      I2 => \CNT1[0]_i_9_n_0\,
      I3 => \CNT1[0]_i_18_n_0\,
      I4 => \CNT1[1]_i_10_n_0\,
      I5 => \CNT1[0]_i_6_n_0\,
      O => \CNT1[0]_i_12_n_0\
    );
\CNT1[0]_i_13\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9696699669699669"
    )
        port map (
      I0 => \CNT1[0]_i_19_n_0\,
      I1 => \CNT1[0]_i_20_n_0\,
      I2 => \CNT1_reg_n_0_[2]\,
      I3 => TPROP(2),
      I4 => TPROP(3),
      I5 => \CNT1[0]_i_17_n_0\,
      O => \CNT1[0]_i_13_n_0\
    );
\CNT1[0]_i_14\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FF44502B00BBAFD4"
    )
        port map (
      I0 => \CNT1_reg_n_0_[2]\,
      I1 => TPROP(2),
      I2 => TSEG1(2),
      I3 => TPROP(3),
      I4 => TSEG1(3),
      I5 => \CNT1_reg_n_0_[3]\,
      O => \CNT1[0]_i_14_n_0\
    );
\CNT1[0]_i_15\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E8EE88EE8E88EE8"
    )
        port map (
      I0 => \CNT1[0]_i_19_n_0\,
      I1 => \CNT1[0]_i_20_n_0\,
      I2 => \CNT1_reg_n_0_[2]\,
      I3 => TPROP(2),
      I4 => TPROP(3),
      I5 => \CNT1[0]_i_17_n_0\,
      O => \CNT1[0]_i_15_n_0\
    );
\CNT1[0]_i_16\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"E87E7E17178181E8"
    )
        port map (
      I0 => \CNT1[0]_i_21_n_0\,
      I1 => \CNT1[0]_i_15_n_0\,
      I2 => \CNT1_reg_n_0_[3]\,
      I3 => TSEG1(3),
      I4 => TPROP(3),
      I5 => \CNT1_reg_n_0_[4]\,
      O => \CNT1[0]_i_16_n_0\
    );
\CNT1[0]_i_17\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => TSEG1(2),
      I1 => TSEG1(3),
      O => \CNT1[0]_i_17_n_0\
    );
\CNT1[0]_i_18\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"BB4B44B4"
    )
        port map (
      I0 => TPROP(3),
      I1 => TPROP(1),
      I2 => TSEG1(1),
      I3 => TSEG1(3),
      I4 => \CNT1_reg_n_0_[1]\,
      O => \CNT1[0]_i_18_n_0\
    );
\CNT1[0]_i_19\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"96FF969696960096"
    )
        port map (
      I0 => \CNT1[1]_i_13_n_0\,
      I1 => \CNT1[1]_i_6_n_0\,
      I2 => \CNT1_reg_n_0_[1]\,
      I3 => \CNT1[0]_i_9_n_0\,
      I4 => \CNT1_reg_n_0_[0]\,
      I5 => \CNT1[1]_i_5_n_0\,
      O => \CNT1[0]_i_19_n_0\
    );
\CNT1[0]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"5555AA56"
    )
        port map (
      I0 => \CNT1[1]_i_5_n_0\,
      I1 => TPROP(1),
      I2 => TPROP(2),
      I3 => TPROP(0),
      I4 => TPROP(3),
      O => \CNT1[0]_i_2_n_0\
    );
\CNT1[0]_i_20\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FBFFB0BB"
    )
        port map (
      I0 => TSEG1(3),
      I1 => TSEG1(1),
      I2 => TPROP(3),
      I3 => TPROP(1),
      I4 => \CNT1_reg_n_0_[1]\,
      O => \CNT1[0]_i_20_n_0\
    );
\CNT1[0]_i_21\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FBFFB0BB"
    )
        port map (
      I0 => TSEG1(3),
      I1 => TSEG1(2),
      I2 => TPROP(3),
      I3 => TPROP(2),
      I4 => \CNT1_reg_n_0_[2]\,
      O => \CNT1[0]_i_21_n_0\
    );
\CNT1[0]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAAAAAEEEBBBEB"
    )
        port map (
      I0 => \CNT1[0]_i_5_n_0\,
      I1 => \CNT1_reg_n_0_[0]\,
      I2 => \CNT1[0]_i_6_n_0\,
      I3 => \CNT1[0]_i_7_n_0\,
      I4 => \CNT1[0]_i_8_n_0\,
      I5 => \^cnt1_reg[3]_0\,
      O => \CNT1[0]_i_3_n_0\
    );
\CNT1[0]_i_4\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"F11F1111"
    )
        port map (
      I0 => \^cnt1_reg[3]_0\,
      I1 => \CNT1_reg_n_0_[0]\,
      I2 => \CNT1[1]_i_5_n_0\,
      I3 => \CNT1[0]_i_9_n_0\,
      I4 => \^cnt2_reg[3]_0\,
      O => \CNT1[0]_i_4_n_0\
    );
\CNT1[0]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"202020228A8A8A88"
    )
        port map (
      I0 => \^cnt2_reg[3]_0\,
      I1 => TPROP(3),
      I2 => TPROP(0),
      I3 => TPROP(2),
      I4 => TPROP(1),
      I5 => \CNT1[1]_i_5_n_0\,
      O => \CNT1[0]_i_5_n_0\
    );
\CNT1[0]_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000BBBBBBFB"
    )
        port map (
      I0 => SJW(2),
      I1 => SJW(0),
      I2 => \CNT1[0]_i_10_n_0\,
      I3 => TSEG1(2),
      I4 => TSEG1(3),
      I5 => \CNT1[0]_i_11_n_0\,
      O => \CNT1[0]_i_6_n_0\
    );
\CNT1[0]_i_7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000032000032"
    )
        port map (
      I0 => \CNT1[0]_i_12_n_0\,
      I1 => \CNT1[0]_i_13_n_0\,
      I2 => \CNT1[2]_i_8_n_0\,
      I3 => \CNT1[0]_i_14_n_0\,
      I4 => \CNT1[0]_i_15_n_0\,
      I5 => \CNT1[0]_i_16_n_0\,
      O => \CNT1[0]_i_7_n_0\
    );
\CNT1[0]_i_8\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00F1FF0EFF0E00F1"
    )
        port map (
      I0 => TPROP(1),
      I1 => TPROP(2),
      I2 => TPROP(0),
      I3 => TPROP(3),
      I4 => \CNT1[1]_i_5_n_0\,
      I5 => \CNT1_reg_n_0_[0]\,
      O => \CNT1[0]_i_8_n_0\
    );
\CNT1[0]_i_9\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"4445"
    )
        port map (
      I0 => TPROP(3),
      I1 => TPROP(0),
      I2 => TPROP(2),
      I3 => TPROP(1),
      O => \CNT1[0]_i_9_n_0\
    );
\CNT1[1]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BBB8FFFF8B880000"
    )
        port map (
      I0 => \CNT1[1]_i_2_n_0\,
      I1 => \CNT1_reg[4]_0\,
      I2 => \CNT1_reg[4]_1\,
      I3 => \CNT1[1]_i_3_n_0\,
      I4 => \^rxbus_d_reg_0\,
      I5 => \CNT1[1]_i_4_n_0\,
      O => CNT1r(1)
    );
\CNT1[1]_i_10\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00FF08FB00000808"
    )
        port map (
      I0 => TSEG1(1),
      I1 => \CNT1[0]_i_10_n_0\,
      I2 => TSEG1(2),
      I3 => SJW(2),
      I4 => TSEG1(3),
      I5 => SJW(1),
      O => \CNT1[1]_i_10_n_0\
    );
\CNT1[1]_i_11\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"6996696969699669"
    )
        port map (
      I0 => \CNT1_reg_n_0_[1]\,
      I1 => \CNT1[1]_i_6_n_0\,
      I2 => \CNT1[1]_i_13_n_0\,
      I3 => \CNT1[0]_i_9_n_0\,
      I4 => \CNT1_reg_n_0_[0]\,
      I5 => \CNT1[1]_i_5_n_0\,
      O => \CNT1[1]_i_11_n_0\
    );
\CNT1[1]_i_12\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"000000F1"
    )
        port map (
      I0 => TPROP(1),
      I1 => TPROP(2),
      I2 => TPROP(0),
      I3 => TPROP(3),
      I4 => \CNT1[1]_i_5_n_0\,
      O => \CNT1[1]_i_12_n_0\
    );
\CNT1[1]_i_13\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => TPROP(1),
      I1 => TPROP(3),
      O => \CNT1[1]_i_13_n_0\
    );
\CNT1[1]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFF44BA0000BB45"
    )
        port map (
      I0 => \CNT1[1]_i_5_n_0\,
      I1 => TPROP(0),
      I2 => TPROP(2),
      I3 => TPROP(1),
      I4 => TPROP(3),
      I5 => \CNT1[1]_i_6_n_0\,
      O => \CNT1[1]_i_2_n_0\
    );
\CNT1[1]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FF141414"
    )
        port map (
      I0 => \^cnt1_reg[3]_0\,
      I1 => \CNT1[1]_i_7_n_0\,
      I2 => \CNT1[1]_i_8_n_0\,
      I3 => \CNT1[1]_i_2_n_0\,
      I4 => \^cnt2_reg[3]_0\,
      O => \CNT1[1]_i_3_n_0\
    );
\CNT1[1]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFF99999998"
    )
        port map (
      I0 => \CNT1_reg_n_0_[1]\,
      I1 => \CNT1_reg_n_0_[0]\,
      I2 => \CNT1_reg_n_0_[3]\,
      I3 => \CNT1_reg_n_0_[2]\,
      I4 => \CNT1_reg_n_0_[4]\,
      I5 => \CNT1[1]_i_9_n_0\,
      O => \CNT1[1]_i_4_n_0\
    );
\CNT1[1]_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"BBBA"
    )
        port map (
      I0 => TSEG1(3),
      I1 => TSEG1(0),
      I2 => TSEG1(2),
      I3 => TSEG1(1),
      O => \CNT1[1]_i_5_n_0\
    );
\CNT1[1]_i_6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => TSEG1(1),
      I1 => TSEG1(3),
      O => \CNT1[1]_i_6_n_0\
    );
\CNT1[1]_i_7\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"10D0D010"
    )
        port map (
      I0 => \CNT1[0]_i_6_n_0\,
      I1 => \CNT1[0]_i_7_n_0\,
      I2 => \CNT1_reg_n_0_[0]\,
      I3 => \CNT1[1]_i_5_n_0\,
      I4 => \CNT1[0]_i_9_n_0\,
      O => \CNT1[1]_i_7_n_0\
    );
\CNT1[1]_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"A656"
    )
        port map (
      I0 => \CNT1_reg_n_0_[1]\,
      I1 => \CNT1[1]_i_10_n_0\,
      I2 => \CNT1[0]_i_7_n_0\,
      I3 => \CNT1[1]_i_11_n_0\,
      O => \CNT1[1]_i_8_n_0\
    );
\CNT1[1]_i_9\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8A208A8A208A2020"
    )
        port map (
      I0 => \^cnt2_reg[3]_0\,
      I1 => TSEG1(3),
      I2 => TSEG1(1),
      I3 => TPROP(3),
      I4 => TPROP(1),
      I5 => \CNT1[1]_i_12_n_0\,
      O => \CNT1[1]_i_9_n_0\
    );
\CNT1[2]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"EEEBEEEBEEEBEEEA"
    )
        port map (
      I0 => \CNT1[2]_i_4_n_0\,
      I1 => \CNT1_reg_n_0_[2]\,
      I2 => \CNT1_reg_n_0_[0]\,
      I3 => \CNT1_reg_n_0_[1]\,
      I4 => \CNT1_reg_n_0_[3]\,
      I5 => \CNT1_reg_n_0_[4]\,
      O => \CNT1[2]_i_2_n_0\
    );
\CNT1[2]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000088FFFFFFF8FF"
    )
        port map (
      I0 => \CNT1_reg[4]_1\,
      I1 => \CNT1[2]_i_5_n_0\,
      I2 => \^cnt2_reg[3]_0\,
      I3 => \CNT1[2]_i_6_n_0\,
      I4 => \CNT1_reg[4]_0\,
      I5 => \CNT1[2]_i_7_n_0\,
      O => \CNT1[2]_i_3_n_0\
    );
\CNT1[2]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2822828828222822"
    )
        port map (
      I0 => \^cnt2_reg[3]_0\,
      I1 => \CNT1[3]_i_6_n_0\,
      I2 => TSEG1(3),
      I3 => TSEG1(2),
      I4 => TPROP(3),
      I5 => TPROP(2),
      O => \CNT1[2]_i_4_n_0\
    );
\CNT1[2]_i_5\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFF0000E"
    )
        port map (
      I0 => \CNT1_reg_n_0_[4]\,
      I1 => \CNT1_reg_n_0_[3]\,
      I2 => \CNT1_reg_n_0_[1]\,
      I3 => \CNT1_reg_n_0_[0]\,
      I4 => \CNT1_reg_n_0_[2]\,
      O => \CNT1[2]_i_5_n_0\
    );
\CNT1[2]_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"EFEFFEEFFEFEEFFE"
    )
        port map (
      I0 => \^cnt1_reg[3]_0\,
      I1 => \CNT1_reg[4]_1\,
      I2 => \CNT1_reg_n_0_[2]\,
      I3 => \CNT1[2]_i_8_n_0\,
      I4 => \CNT1[0]_i_7_n_0\,
      I5 => \CNT1[2]_i_9_n_0\,
      O => \CNT1[2]_i_6_n_0\
    );
\CNT1[2]_i_7\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"DD2D22D2"
    )
        port map (
      I0 => TPROP(2),
      I1 => TPROP(3),
      I2 => TSEG1(2),
      I3 => TSEG1(3),
      I4 => \CNT1[3]_i_6_n_0\,
      O => \CNT1[2]_i_7_n_0\
    );
\CNT1[2]_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"A8AA"
    )
        port map (
      I0 => SJW(2),
      I1 => TSEG1(2),
      I2 => TSEG1(3),
      I3 => \CNT1[0]_i_10_n_0\,
      O => \CNT1[2]_i_8_n_0\
    );
\CNT1[2]_i_9\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8BFF008B8BFF8BFF"
    )
        port map (
      I0 => \CNT1[1]_i_11_n_0\,
      I1 => \CNT1[0]_i_7_n_0\,
      I2 => \CNT1[1]_i_10_n_0\,
      I3 => \CNT1_reg_n_0_[1]\,
      I4 => \CNT1[4]_i_12_n_0\,
      I5 => \CNT1_reg_n_0_[0]\,
      O => \CNT1[2]_i_9_n_0\
    );
\CNT1[3]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0FEEFFFF0F440000"
    )
        port map (
      I0 => \CNT1_reg[4]_1\,
      I1 => \CNT1[3]_i_2_n_0\,
      I2 => \CNT1[3]_i_3_n_0\,
      I3 => \CNT1_reg[4]_0\,
      I4 => \^rxbus_d_reg_0\,
      I5 => \CNT1[3]_i_4_n_0\,
      O => CNT1r(3)
    );
\CNT1[3]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"BE"
    )
        port map (
      I0 => \CNT1[3]_i_5_n_0\,
      I1 => \CNT1[4]_i_9_n_0\,
      I2 => \CNT1_reg_n_0_[3]\,
      O => \CNT1[3]_i_2_n_0\
    );
\CNT1[3]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"CC13CC01"
    )
        port map (
      I0 => TPROP(2),
      I1 => TPROP(3),
      I2 => TSEG1(2),
      I3 => TSEG1(3),
      I4 => \CNT1[3]_i_6_n_0\,
      O => \CNT1[3]_i_3_n_0\
    );
\CNT1[3]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"EEEEEEEBEEEEEEEA"
    )
        port map (
      I0 => \CNT1[3]_i_5_n_0\,
      I1 => \CNT1_reg_n_0_[3]\,
      I2 => \CNT1_reg_n_0_[0]\,
      I3 => \CNT1_reg_n_0_[1]\,
      I4 => \CNT1_reg_n_0_[2]\,
      I5 => \CNT1_reg_n_0_[4]\,
      O => \CNT1[3]_i_4_n_0\
    );
\CNT1[3]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0A0AAAA20A0AA2A0"
    )
        port map (
      I0 => \^cnt2_reg[3]_0\,
      I1 => \CNT1[3]_i_6_n_0\,
      I2 => TSEG1(3),
      I3 => TSEG1(2),
      I4 => TPROP(3),
      I5 => TPROP(2),
      O => \CNT1[3]_i_5_n_0\
    );
\CNT1[3]_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"DFDFDFDFCDCDDFDD"
    )
        port map (
      I0 => \CNT1[1]_i_6_n_0\,
      I1 => TPROP(3),
      I2 => TPROP(1),
      I3 => TPROP(2),
      I4 => TPROP(0),
      I5 => \CNT1[1]_i_5_n_0\,
      O => \CNT1[3]_i_6_n_0\
    );
\CNT1[4]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFDFFFFFF"
    )
        port map (
      I0 => \^rxbus_d_reg_0\,
      I1 => \CNT1_reg[4]_0\,
      I2 => \CNT1[4]_i_4_n_0\,
      I3 => \CNT1r1_inferred__0/i__carry_n_2\,
      I4 => \^cnt1_reg[3]_0\,
      I5 => \CNT1_reg[4]_1\,
      O => \CNT1[4]_i_1_n_0\
    );
\CNT1[4]_i_10\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"80"
    )
        port map (
      I0 => \^cnt2_reg[3]_0\,
      I1 => TSEG1(3),
      I2 => TPROP(3),
      O => \CNT1[4]_i_10_n_0\
    );
\CNT1[4]_i_11\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000002FFFFFFFE"
    )
        port map (
      I0 => \CNT1[1]_i_11_n_0\,
      I1 => \CNT1[0]_i_13_n_0\,
      I2 => \CNT1[4]_i_14_n_0\,
      I3 => \CNT1[4]_i_15_n_0\,
      I4 => \CNT1[0]_i_16_n_0\,
      I5 => \CNT1[1]_i_10_n_0\,
      O => \CNT1[4]_i_11_n_0\
    );
\CNT1[4]_i_12\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFE00000002"
    )
        port map (
      I0 => \CNT1[0]_i_8_n_0\,
      I1 => \CNT1[0]_i_13_n_0\,
      I2 => \CNT1[4]_i_14_n_0\,
      I3 => \CNT1[4]_i_15_n_0\,
      I4 => \CNT1[0]_i_16_n_0\,
      I5 => \CNT1[0]_i_6_n_0\,
      O => \CNT1[4]_i_12_n_0\
    );
\CNT1[4]_i_13\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00410041FFFFFFFF"
    )
        port map (
      I0 => \CNT1[0]_i_16_n_0\,
      I1 => \CNT1[0]_i_15_n_0\,
      I2 => \CNT1[0]_i_14_n_0\,
      I3 => \CNT1[0]_i_13_n_0\,
      I4 => \CNT1[0]_i_12_n_0\,
      I5 => \CNT1[2]_i_8_n_0\,
      O => \CNT1[4]_i_13_n_0\
    );
\CNT1[4]_i_14\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000D0DDD0DDDDDD"
    )
        port map (
      I0 => \CNT1[2]_i_8_n_0\,
      I1 => \CNT1[0]_i_13_n_0\,
      I2 => \CNT1[0]_i_6_n_0\,
      I3 => \CNT1[0]_i_8_n_0\,
      I4 => \CNT1[1]_i_10_n_0\,
      I5 => \CNT1[1]_i_11_n_0\,
      O => \CNT1[4]_i_14_n_0\
    );
\CNT1[4]_i_15\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"69969669"
    )
        port map (
      I0 => \CNT1[0]_i_15_n_0\,
      I1 => \CNT1_reg_n_0_[3]\,
      I2 => TSEG1(3),
      I3 => TPROP(3),
      I4 => \CNT1[0]_i_21_n_0\,
      O => \CNT1[4]_i_15_n_0\
    );
\CNT1[4]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BBB8FFFF8B880000"
    )
        port map (
      I0 => \CNT1[4]_i_6_n_0\,
      I1 => \CNT1_reg[4]_0\,
      I2 => \CNT1_reg[4]_1\,
      I3 => \CNT1[4]_i_7_n_0\,
      I4 => \^rxbus_d_reg_0\,
      I5 => \CNT1[4]_i_8_n_0\,
      O => CNT1r(4)
    );
\CNT1[4]_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"80"
    )
        port map (
      I0 => \CNT1_reg[4]_2\,
      I1 => RXBUS_d,
      I2 => \^sampled_din\,
      O => \^rxbus_d_reg_0\
    );
\CNT1[4]_i_4\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0001"
    )
        port map (
      I0 => CNT2(2),
      I1 => CNT2(0),
      I2 => CNT2(1),
      I3 => CNT2(3),
      O => \CNT1[4]_i_4_n_0\
    );
\CNT1[4]_i_5\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000001"
    )
        port map (
      I0 => \CNT1_reg_n_0_[3]\,
      I1 => \CNT1_reg_n_0_[0]\,
      I2 => \CNT1_reg_n_0_[1]\,
      I3 => \CNT1_reg_n_0_[2]\,
      I4 => \CNT1_reg_n_0_[4]\,
      O => \^cnt1_reg[3]_0\
    );
\CNT1[4]_i_6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => TPROP(3),
      I1 => TSEG1(3),
      O => \CNT1[4]_i_6_n_0\
    );
\CNT1[4]_i_7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"80FFFFFFFF808080"
    )
        port map (
      I0 => TPROP(3),
      I1 => TSEG1(3),
      I2 => \^cnt2_reg[3]_0\,
      I3 => \CNT1[4]_i_9_n_0\,
      I4 => \CNT1_reg_n_0_[3]\,
      I5 => \CNT1_reg_n_0_[4]\,
      O => \CNT1[4]_i_7_n_0\
    );
\CNT1[4]_i_8\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFEAAAAAAAA"
    )
        port map (
      I0 => \CNT1[4]_i_10_n_0\,
      I1 => \CNT1_reg_n_0_[2]\,
      I2 => \CNT1_reg_n_0_[1]\,
      I3 => \CNT1_reg_n_0_[0]\,
      I4 => \CNT1_reg_n_0_[3]\,
      I5 => \CNT1_reg_n_0_[4]\,
      O => \CNT1[4]_i_8_n_0\
    );
\CNT1[4]_i_9\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"4D44FFFF00000000"
    )
        port map (
      I0 => \CNT1[4]_i_11_n_0\,
      I1 => \CNT1_reg_n_0_[1]\,
      I2 => \CNT1[4]_i_12_n_0\,
      I3 => \CNT1_reg_n_0_[0]\,
      I4 => \CNT1[4]_i_13_n_0\,
      I5 => \CNT1_reg_n_0_[2]\,
      O => \CNT1[4]_i_9_n_0\
    );
\CNT1_reg[0]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \CNT1[4]_i_1_n_0\,
      CLR => RXOUT_reg_1,
      D => CNT1r(0),
      Q => \CNT1_reg_n_0_[0]\
    );
\CNT1_reg[1]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \CNT1[4]_i_1_n_0\,
      CLR => RXOUT_reg_1,
      D => CNT1r(1),
      Q => \CNT1_reg_n_0_[1]\
    );
\CNT1_reg[2]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \CNT1[4]_i_1_n_0\,
      CLR => RXOUT_reg_1,
      D => CNT1r(2),
      Q => \CNT1_reg_n_0_[2]\
    );
\CNT1_reg[2]_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => \CNT1[2]_i_2_n_0\,
      I1 => \CNT1[2]_i_3_n_0\,
      O => CNT1r(2),
      S => \^rxbus_d_reg_0\
    );
\CNT1_reg[3]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \CNT1[4]_i_1_n_0\,
      CLR => RXOUT_reg_1,
      D => CNT1r(3),
      Q => \CNT1_reg_n_0_[3]\
    );
\CNT1_reg[4]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \CNT1[4]_i_1_n_0\,
      CLR => RXOUT_reg_1,
      D => CNT1r(4),
      Q => \CNT1_reg_n_0_[4]\
    );
\CNT1r1_inferred__0/i__carry\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3 downto 2) => \NLW_CNT1r1_inferred__0/i__carry_CO_UNCONNECTED\(3 downto 2),
      CO(1) => \CNT1r1_inferred__0/i__carry_n_2\,
      CO(0) => \CNT1r1_inferred__0/i__carry_n_3\,
      CYINIT => '1',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => \NLW_CNT1r1_inferred__0/i__carry_O_UNCONNECTED\(3 downto 0),
      S(3 downto 2) => B"00",
      S(1) => \i__carry_i_1_n_0\,
      S(0) => \i__carry_i_2_n_0\
    );
\CNT2[0]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"40EF40E040EF4FEF"
    )
        port map (
      I0 => \CNT1_reg[4]_0\,
      I1 => \CNT2[0]_i_2_n_0\,
      I2 => \^rxbus_d_reg_0\,
      I3 => \CNT2[0]_i_3_n_0\,
      I4 => \CNT1[4]_i_4_n_0\,
      I5 => CNT2(0),
      O => CNT2r(0)
    );
\CNT2[0]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"A0EFAFEFA0EFA0E0"
    )
        port map (
      I0 => \CNT2[0]_i_4_n_0\,
      I1 => \CNT1[4]_i_4_n_0\,
      I2 => \CNT1_reg[4]_1\,
      I3 => \CNT2[0]_i_3_n_0\,
      I4 => \^cnt2_reg[3]_0\,
      I5 => \CNT2[0]_i_5_n_0\,
      O => \CNT2[0]_i_2_n_0\
    );
\CNT2[0]_i_3\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"4445"
    )
        port map (
      I0 => TSEG2(3),
      I1 => TSEG2(0),
      I2 => TSEG2(2),
      I3 => TSEG2(1),
      O => \CNT2[0]_i_3_n_0\
    );
\CNT2[0]_i_4\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9990"
    )
        port map (
      I0 => \CNT1[0]_i_6_n_0\,
      I1 => CNT2(0),
      I2 => \CNT2[3]_i_5_n_0\,
      I3 => CNT2(3),
      O => \CNT2[0]_i_4_n_0\
    );
\CNT2[0]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"74"
    )
        port map (
      I0 => CNT2(0),
      I1 => \CNT1r1_inferred__0/i__carry_n_2\,
      I2 => \CNT2[0]_i_4_n_0\,
      O => \CNT2[0]_i_5_n_0\
    );
\CNT2[1]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"65FF6500650065FF"
    )
        port map (
      I0 => \CNT2[0]_i_3_n_0\,
      I1 => TSEG2(3),
      I2 => TSEG2(1),
      I3 => \CNT1[4]_i_4_n_0\,
      I4 => CNT2(0),
      I5 => CNT2(1),
      O => \CNT2[1]_i_2_n_0\
    );
\CNT2[1]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"4F4E5F5F4F4E0A0A"
    )
        port map (
      I0 => \CNT1_reg[4]_0\,
      I1 => \CNT2[1]_i_4_n_0\,
      I2 => \i__carry_i_3_n_0\,
      I3 => \CNT1[4]_i_4_n_0\,
      I4 => \CNT1_reg[4]_1\,
      I5 => \CNT2[1]_i_5_n_0\,
      O => \CNT2[1]_i_3_n_0\
    );
\CNT2[1]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9696969602960002"
    )
        port map (
      I0 => CNT2(1),
      I1 => \CNT1[1]_i_10_n_0\,
      I2 => \CNT2[1]_i_6_n_0\,
      I3 => \CNT1[2]_i_8_n_0\,
      I4 => CNT2(2),
      I5 => CNT2(3),
      O => \CNT2[1]_i_4_n_0\
    );
\CNT2[1]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"7447777774474444"
    )
        port map (
      I0 => \i__carry_i_3_n_0\,
      I1 => \^cnt2_reg[3]_0\,
      I2 => CNT2(1),
      I3 => CNT2(0),
      I4 => \CNT1r1_inferred__0/i__carry_n_2\,
      I5 => \CNT2[1]_i_4_n_0\,
      O => \CNT2[1]_i_5_n_0\
    );
\CNT2[1]_i_6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => CNT2(0),
      I1 => \CNT1[0]_i_6_n_0\,
      O => \CNT2[1]_i_6_n_0\
    );
\CNT2[2]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"EF40EF4FEF40E040"
    )
        port map (
      I0 => \CNT1_reg[4]_0\,
      I1 => \CNT2[2]_i_2_n_0\,
      I2 => \^rxbus_d_reg_0\,
      I3 => \CNT2[2]_i_3_n_0\,
      I4 => \CNT1[4]_i_4_n_0\,
      I5 => \CNT2[2]_i_4_n_0\,
      O => CNT2r(2)
    );
\CNT2[2]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"EFC0EFCFEFC0E0C0"
    )
        port map (
      I0 => \CNT1[4]_i_4_n_0\,
      I1 => \CNT2[2]_i_5_n_0\,
      I2 => \CNT1_reg[4]_1\,
      I3 => \CNT2[2]_i_3_n_0\,
      I4 => \^cnt2_reg[3]_0\,
      I5 => \CNT2[2]_i_6_n_0\,
      O => \CNT2[2]_i_2_n_0\
    );
\CNT2[2]_i_3\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FEF0"
    )
        port map (
      I0 => TSEG2(1),
      I1 => TSEG2(0),
      I2 => TSEG2(3),
      I3 => TSEG2(2),
      O => \CNT2[2]_i_3_n_0\
    );
\CNT2[2]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"A9"
    )
        port map (
      I0 => CNT2(2),
      I1 => CNT2(1),
      I2 => CNT2(0),
      O => \CNT2[2]_i_4_n_0\
    );
\CNT2[2]_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2C82"
    )
        port map (
      I0 => CNT2(3),
      I1 => CNT2(2),
      I2 => \CNT1[2]_i_8_n_0\,
      I3 => \CNT2[2]_i_7_n_0\,
      O => \CNT2[2]_i_5_n_0\
    );
\CNT2[2]_i_6\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"A9FFA900"
    )
        port map (
      I0 => CNT2(2),
      I1 => CNT2(1),
      I2 => CNT2(0),
      I3 => \CNT1r1_inferred__0/i__carry_n_2\,
      I4 => \CNT2[2]_i_5_n_0\,
      O => \CNT2[2]_i_6_n_0\
    );
\CNT2[2]_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"BBB2"
    )
        port map (
      I0 => CNT2(1),
      I1 => \CNT1[1]_i_10_n_0\,
      I2 => CNT2(0),
      I3 => \CNT1[0]_i_6_n_0\,
      O => \CNT2[2]_i_7_n_0\
    );
\CNT2[3]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"10101F10"
    )
        port map (
      I0 => \CNT1_reg[4]_0\,
      I1 => \CNT2[3]_i_3_n_0\,
      I2 => \^rxbus_d_reg_0\,
      I3 => CNT2(3),
      I4 => \CNT2[3]_i_4_n_0\,
      O => CNT2r(3)
    );
\CNT2[3]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"7F7A7F777F757F77"
    )
        port map (
      I0 => CNT2(3),
      I1 => \CNT2[3]_i_5_n_0\,
      I2 => \CNT1_reg[4]_1\,
      I3 => \^cnt2_reg[3]_0\,
      I4 => \CNT1r1_inferred__0/i__carry_n_2\,
      I5 => \CNT2[3]_i_4_n_0\,
      O => \CNT2[3]_i_3_n_0\
    );
\CNT2[3]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"01"
    )
        port map (
      I0 => CNT2(1),
      I1 => CNT2(0),
      I2 => CNT2(2),
      O => \CNT2[3]_i_4_n_0\
    );
\CNT2[3]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BBB2FFFF0000BBB2"
    )
        port map (
      I0 => CNT2(1),
      I1 => \CNT1[1]_i_10_n_0\,
      I2 => CNT2(0),
      I3 => \CNT1[0]_i_6_n_0\,
      I4 => \CNT1[2]_i_8_n_0\,
      I5 => CNT2(2),
      O => \CNT2[3]_i_5_n_0\
    );
\CNT2_reg[0]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \CNT2_reg[3]_1\(0),
      CLR => RXOUT_reg_1,
      D => CNT2r(0),
      Q => CNT2(0)
    );
\CNT2_reg[1]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \CNT2_reg[3]_1\(0),
      CLR => RXOUT_reg_1,
      D => CNT2r(1),
      Q => CNT2(1)
    );
\CNT2_reg[1]_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => \CNT2[1]_i_2_n_0\,
      I1 => \CNT2[1]_i_3_n_0\,
      O => CNT2r(1),
      S => \^rxbus_d_reg_0\
    );
\CNT2_reg[2]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \CNT2_reg[3]_1\(0),
      CLR => RXOUT_reg_1,
      D => CNT2r(2),
      Q => CNT2(2)
    );
\CNT2_reg[3]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \CNT2_reg[3]_1\(0),
      CLR => RXOUT_reg_1,
      D => CNT2r(3),
      Q => CNT2(3)
    );
\Cnt[3]_i_1__1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \^cnt2_reg[3]_0\,
      I1 => SRST,
      O => SRST_1_1(0)
    );
\Cnt[5]_i_1__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => \^cnt1_reg[3]_1\,
      I1 => SRST,
      O => SRST_1_0(0)
    );
RTR_i_2: unisim.vcomponents.LUT3
    generic map(
      INIT => X"08"
    )
        port map (
      I0 => \CNT1r1_inferred__0/i__carry_n_2\,
      I1 => \^cnt1_reg[3]_0\,
      I2 => \RXSTATES_reg[3]_0\,
      O => \^cnt1_reg[3]_1\
    );
RXBUS_d_reg: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => '1',
      CLR => RXOUT_reg_1,
      D => RXBUS,
      Q => RXBUS_d
    );
RXOUT_i_1: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000100000000"
    )
        port map (
      I0 => \CNT1_reg_n_0_[4]\,
      I1 => \CNT1_reg_n_0_[2]\,
      I2 => \CNT1_reg_n_0_[1]\,
      I3 => \CNT1_reg_n_0_[0]\,
      I4 => \CNT1_reg_n_0_[3]\,
      I5 => \CNT1r1_inferred__0/i__carry_n_2\,
      O => \^e\(0)
    );
RXOUT_reg: unisim.vcomponents.FDPE
     port map (
      C => Tq,
      CE => \^e\(0),
      D => RXBUS,
      PRE => RXOUT_reg_1,
      Q => \^sampled_din\
    );
\RXSTATES[3]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"08FF88FF"
    )
        port map (
      I0 => \^cnt1_reg[3]_0\,
      I1 => \CNT1r1_inferred__0/i__carry_n_2\,
      I2 => \RXSTATES_reg[3]_1\,
      I3 => SRST,
      I4 => \RXSTATES_reg[3]_0\,
      O => SRST_1(0)
    );
\TEC[8]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00010000"
    )
        port map (
      I0 => CNT2(3),
      I1 => CNT2(1),
      I2 => CNT2(0),
      I3 => CNT2(2),
      I4 => \^cnt1_reg[3]_0\,
      O => \^cnt2_reg[3]_0\
    );
\TOFILTERI[28]_i_7\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \^cnt1_reg[3]_1\,
      I1 => Q(0),
      O => \RXSTATES_reg[3]\
    );
\TXSTATES[3]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => \^cnt2_reg[3]_0\,
      I1 => SRST,
      O => SRST_1_2(0)
    );
\i__carry_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => CNT2(3),
      O => \i__carry_i_1_n_0\
    );
\i__carry_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000099009900000"
    )
        port map (
      I0 => \CNT2[2]_i_3_n_0\,
      I1 => CNT2(2),
      I2 => CNT2(1),
      I3 => \i__carry_i_3_n_0\,
      I4 => CNT2(0),
      I5 => \CNT2[0]_i_3_n_0\,
      O => \i__carry_i_2_n_0\
    );
\i__carry_i_3\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"030D"
    )
        port map (
      I0 => TSEG2(2),
      I1 => TSEG2(0),
      I2 => TSEG2(3),
      I3 => TSEG2(1),
      O => \i__carry_i_3_n_0\
    );
lastvalue_i_1: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => \^sampled_din\,
      I1 => SRST,
      O => RXOUT_reg_0
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1_FPGAPROJECT_0_0_bitstuffer is
  port (
    E : out STD_LOGIC_VECTOR ( 0 to 0 );
    done_reg : out STD_LOGIC;
    req_Error_reg : out STD_LOGIC;
    req_Error_reg_0 : out STD_LOGIC;
    req_Error_reg_1 : out STD_LOGIC;
    \TXSTATES_reg[0]\ : out STD_LOGIC;
    req_Errorr : out STD_LOGIC;
    \TXSTATES_reg[1]\ : out STD_LOGIC;
    D : out STD_LOGIC_VECTOR ( 1 downto 0 );
    RXOUT_reg : out STD_LOGIC;
    SRST_0_0 : out STD_LOGIC_VECTOR ( 5 downto 0 );
    imTX0_out : out STD_LOGIC;
    \TXSTATES_reg[0]_0\ : out STD_LOGIC;
    \TXSTATES_reg[2]\ : out STD_LOGIC;
    \TXSTATES_reg[3]\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    SRST_0 : in STD_LOGIC;
    Q : in STD_LOGIC_VECTOR ( 3 downto 0 );
    done_reg_0 : in STD_LOGIC;
    done_reg_1 : in STD_LOGIC;
    \Cnt_reg[4]\ : in STD_LOGIC;
    \Cnt_reg[4]_0\ : in STD_LOGIC;
    IDE_TX_0 : in STD_LOGIC;
    done_i_4_0 : in STD_LOGIC;
    done_i_4_1 : in STD_LOGIC;
    \Cnt[0]_i_2_0\ : in STD_LOGIC;
    done_i_4_2 : in STD_LOGIC;
    \serial_reg[4]_0\ : in STD_LOGIC;
    \Cnt_reg[1]\ : in STD_LOGIC;
    \Cnt_reg[1]_0\ : in STD_LOGIC;
    done_reg_2 : in STD_LOGIC;
    done_reg_3 : in STD_LOGIC;
    done_reg_4 : in STD_LOGIC;
    \REC[8]_i_12\ : in STD_LOGIC;
    \State[0]_i_2\ : in STD_LOGIC;
    req_Error_RX : in STD_LOGIC;
    \TEC[8]_i_17\ : in STD_LOGIC;
    \TEC[8]_i_17_0\ : in STD_LOGIC;
    Sampled_din : in STD_LOGIC;
    req_Errorr_reg : in STD_LOGIC;
    \TXSTATES_reg[0]_1\ : in STD_LOGIC;
    \D_Len[0]_i_3\ : in STD_LOGIC;
    \serial_reg[0]_0\ : in STD_LOGIC;
    \State[0]_i_4_0\ : in STD_LOGIC;
    \Cnt_reg[4]_1\ : in STD_LOGIC;
    \Cnt_reg[5]\ : in STD_LOGIC;
    imTX_reg : in STD_LOGIC;
    imTX : in STD_LOGIC;
    done_reg_5 : in STD_LOGIC;
    done_i_4_3 : in STD_LOGIC;
    done_i_4_4 : in STD_LOGIC;
    \Cnt_reg[3]\ : in STD_LOGIC;
    \Cnt_reg[3]_0\ : in STD_LOGIC;
    \Cnt_reg[3]_1\ : in STD_LOGIC;
    \Cnt_reg[2]\ : in STD_LOGIC;
    \Cnt_reg[2]_0\ : in STD_LOGIC;
    \Cnt_reg[2]_1\ : in STD_LOGIC;
    \Cnt_reg[5]_0\ : in STD_LOGIC;
    \Cnt_reg[0]\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \Cnt[0]_i_2_1\ : in STD_LOGIC;
    \Cnt[0]_i_3_0\ : in STD_LOGIC_VECTOR ( 1 downto 0 );
    \Cnt[0]_i_3_1\ : in STD_LOGIC;
    \CRC_RG_reg[14]\ : in STD_LOGIC;
    \CRC_RG_reg[14]_0\ : in STD_LOGIC;
    \TXSTATES_reg[2]_0\ : in STD_LOGIC;
    clk : in STD_LOGIC;
    \serial_reg[0]_1\ : in STD_LOGIC
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of design_1_FPGAPROJECT_0_0_bitstuffer : entity is "bitstuffer";
end design_1_FPGAPROJECT_0_0_bitstuffer;

architecture STRUCTURE of design_1_FPGAPROJECT_0_0_bitstuffer is
  signal \CRC_RG[14]_i_5_n_0\ : STD_LOGIC;
  signal \Cnt[0]_i_2_n_0\ : STD_LOGIC;
  signal \Cnt[0]_i_3_n_0\ : STD_LOGIC;
  signal \Cnt[0]_i_4_n_0\ : STD_LOGIC;
  signal \Cnt[1]_i_2_n_0\ : STD_LOGIC;
  signal \Cnt[1]_i_3__0_n_0\ : STD_LOGIC;
  signal \Cnt[2]_i_3_n_0\ : STD_LOGIC;
  signal \Cnt[2]_i_4__0_n_0\ : STD_LOGIC;
  signal \Cnt[3]_i_3__1_n_0\ : STD_LOGIC;
  signal \Cnt[3]_i_7_n_0\ : STD_LOGIC;
  signal \Cnt[3]_i_8_n_0\ : STD_LOGIC;
  signal \Cnt[3]_i_9_n_0\ : STD_LOGIC;
  signal \Cnt[4]_i_2__0_n_0\ : STD_LOGIC;
  signal \Cnt[4]_i_5__0_n_0\ : STD_LOGIC;
  signal \Cnt[5]_i_3__0_n_0\ : STD_LOGIC;
  signal \Cnt[5]_i_5_n_0\ : STD_LOGIC;
  signal \Cnt[5]_i_6_n_0\ : STD_LOGIC;
  signal \Cnt[5]_i_7__0_n_0\ : STD_LOGIC;
  signal \State[0]_i_7_n_0\ : STD_LOGIC;
  signal \TEC[8]_i_23_n_0\ : STD_LOGIC;
  signal \TXSTATES[0]_i_2_n_0\ : STD_LOGIC;
  signal \TXSTATES[0]_i_3_n_0\ : STD_LOGIC;
  signal \TXSTATES[1]_i_2_n_0\ : STD_LOGIC;
  signal \TXSTATES[3]_i_5_n_0\ : STD_LOGIC;
  signal \^txstates_reg[0]\ : STD_LOGIC;
  signal \^txstates_reg[0]_0\ : STD_LOGIC;
  signal \^txstates_reg[1]\ : STD_LOGIC;
  signal \^txstates_reg[2]\ : STD_LOGIC;
  signal done_i_10_n_0 : STD_LOGIC;
  signal done_i_11_n_0 : STD_LOGIC;
  signal done_i_3_n_0 : STD_LOGIC;
  signal done_i_4_n_0 : STD_LOGIC;
  signal done_i_5_n_0 : STD_LOGIC;
  signal done_i_7_n_0 : STD_LOGIC;
  signal done_i_8_n_0 : STD_LOGIC;
  signal req_Errorr_i_2_n_0 : STD_LOGIC;
  signal serial : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \serial[0]_i_1_n_0\ : STD_LOGIC;
  signal \serial[0]_i_2_n_0\ : STD_LOGIC;
  signal \serial[1]_i_1_n_0\ : STD_LOGIC;
  signal \serial[2]_i_1_n_0\ : STD_LOGIC;
  signal \serial[3]_i_1_n_0\ : STD_LOGIC;
  signal \serial[4]_i_1_n_0\ : STD_LOGIC;
  signal \serial[4]_i_2_n_0\ : STD_LOGIC;
  signal \serial_reg_n_0_[4]\ : STD_LOGIC;
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \CRC_RG[14]_i_5\ : label is "soft_lutpair193";
  attribute SOFT_HLUTNM of \Cnt[0]_i_3\ : label is "soft_lutpair198";
  attribute SOFT_HLUTNM of \Cnt[1]_i_1__0\ : label is "soft_lutpair197";
  attribute SOFT_HLUTNM of \Cnt[2]_i_3\ : label is "soft_lutpair195";
  attribute SOFT_HLUTNM of \Cnt[3]_i_7\ : label is "soft_lutpair196";
  attribute SOFT_HLUTNM of \Cnt[3]_i_8\ : label is "soft_lutpair193";
  attribute SOFT_HLUTNM of \Cnt[4]_i_5__0\ : label is "soft_lutpair194";
  attribute SOFT_HLUTNM of \Cnt[5]_i_1\ : label is "soft_lutpair199";
  attribute SOFT_HLUTNM of \Cnt[5]_i_7__0\ : label is "soft_lutpair198";
  attribute SOFT_HLUTNM of \D_Len[0]_i_4\ : label is "soft_lutpair196";
  attribute SOFT_HLUTNM of \TXSTATES[0]_i_1\ : label is "soft_lutpair200";
  attribute SOFT_HLUTNM of \TXSTATES[1]_i_1\ : label is "soft_lutpair200";
  attribute SOFT_HLUTNM of \TXSTATES[2]_i_2\ : label is "soft_lutpair199";
  attribute SOFT_HLUTNM of \TXSTATES[3]_i_4\ : label is "soft_lutpair195";
  attribute SOFT_HLUTNM of done_i_7 : label is "soft_lutpair194";
  attribute SOFT_HLUTNM of \serial[0]_i_1\ : label is "soft_lutpair197";
  attribute SOFT_HLUTNM of \serial[1]_i_1\ : label is "soft_lutpair202";
  attribute SOFT_HLUTNM of \serial[2]_i_1\ : label is "soft_lutpair202";
  attribute SOFT_HLUTNM of \serial[3]_i_1\ : label is "soft_lutpair201";
  attribute SOFT_HLUTNM of \serial[4]_i_2\ : label is "soft_lutpair201";
begin
  \TXSTATES_reg[0]\ <= \^txstates_reg[0]\;
  \TXSTATES_reg[0]_0\ <= \^txstates_reg[0]_0\;
  \TXSTATES_reg[1]\ <= \^txstates_reg[1]\;
  \TXSTATES_reg[2]\ <= \^txstates_reg[2]\;
\CRC_RG[14]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5D555D5D5D5D5D5D"
    )
        port map (
      I0 => \CRC_RG_reg[14]\,
      I1 => \CRC_RG_reg[14]_0\,
      I2 => \CRC_RG[14]_i_5_n_0\,
      I3 => Q(3),
      I4 => \Cnt_reg[4]_1\,
      I5 => Q(0),
      O => \TXSTATES_reg[3]\(0)
    );
\CRC_RG[14]_i_5\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"80000001"
    )
        port map (
      I0 => \serial_reg_n_0_[4]\,
      I1 => serial(3),
      I2 => serial(0),
      I3 => serial(1),
      I4 => serial(2),
      O => \CRC_RG[14]_i_5_n_0\
    );
\Cnt[0]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"020202020202028A"
    )
        port map (
      I0 => SRST_0,
      I1 => Q(3),
      I2 => \Cnt[0]_i_2_n_0\,
      I3 => \Cnt[0]_i_3_n_0\,
      I4 => Q(2),
      I5 => \Cnt_reg[0]\(0),
      O => SRST_0_0(0)
    );
\Cnt[0]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00E000E0FFE0FFEF"
    )
        port map (
      I0 => \Cnt_reg[0]\(0),
      I1 => done_reg_1,
      I2 => Q(2),
      I3 => Q(1),
      I4 => Q(0),
      I5 => \Cnt[0]_i_4_n_0\,
      O => \Cnt[0]_i_2_n_0\
    );
\Cnt[0]_i_3\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"55CF"
    )
        port map (
      I0 => \TXSTATES[3]_i_5_n_0\,
      I1 => done_reg_1,
      I2 => Q(0),
      I3 => Q(1),
      O => \Cnt[0]_i_3_n_0\
    );
\Cnt[0]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000F10000"
    )
        port map (
      I0 => \Cnt[0]_i_2_1\,
      I1 => \Cnt_reg[0]\(0),
      I2 => \Cnt[0]_i_2_0\,
      I3 => Q(2),
      I4 => Q(1),
      I5 => \Cnt[5]_i_7__0_n_0\,
      O => \Cnt[0]_i_4_n_0\
    );
\Cnt[1]_i_1__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"02A2"
    )
        port map (
      I0 => SRST_0,
      I1 => \Cnt[1]_i_2_n_0\,
      I2 => Q(3),
      I3 => \Cnt[1]_i_3__0_n_0\,
      O => SRST_0_0(1)
    );
\Cnt[1]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFBBFFC0BABB"
    )
        port map (
      I0 => \Cnt[5]_i_7__0_n_0\,
      I1 => Q(0),
      I2 => done_reg_1,
      I3 => Q(1),
      I4 => Q(2),
      I5 => \Cnt_reg[1]_0\,
      O => \Cnt[1]_i_2_n_0\
    );
\Cnt[1]_i_3__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFBABAFAF0BAB0"
    )
        port map (
      I0 => Q(2),
      I1 => \TXSTATES[3]_i_5_n_0\,
      I2 => Q(1),
      I3 => \Cnt_reg[1]\,
      I4 => \Cnt_reg[1]_0\,
      I5 => Q(0),
      O => \Cnt[1]_i_3__0_n_0\
    );
\Cnt[2]_i_1__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000AA02AA"
    )
        port map (
      I0 => SRST_0,
      I1 => \Cnt_reg[2]\,
      I2 => Q(2),
      I3 => Q(3),
      I4 => \Cnt[2]_i_3_n_0\,
      I5 => \Cnt[2]_i_4__0_n_0\,
      O => SRST_0_0(2)
    );
\Cnt[2]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => Q(1),
      I1 => \TXSTATES[3]_i_5_n_0\,
      O => \Cnt[2]_i_3_n_0\
    );
\Cnt[2]_i_4__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FF700000FF77FF77"
    )
        port map (
      I0 => done_reg_0,
      I1 => IDE_TX_0,
      I2 => \Cnt[4]_i_5__0_n_0\,
      I3 => Q(2),
      I4 => \Cnt_reg[2]_0\,
      I5 => \Cnt_reg[2]_1\,
      O => \Cnt[2]_i_4__0_n_0\
    );
\Cnt[3]_i_1__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000A8AAAAAAAA"
    )
        port map (
      I0 => SRST_0,
      I1 => \Cnt_reg[3]\,
      I2 => \Cnt[3]_i_3__1_n_0\,
      I3 => \Cnt_reg[3]_0\,
      I4 => Q(2),
      I5 => \Cnt_reg[3]_1\,
      O => SRST_0_0(3)
    );
\Cnt[3]_i_3__1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \Cnt[3]_i_7_n_0\,
      I1 => Q(1),
      O => \Cnt[3]_i_3__1_n_0\
    );
\Cnt[3]_i_7\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"999AAAAA"
    )
        port map (
      I0 => Sampled_din,
      I1 => \Cnt[3]_i_8_n_0\,
      I2 => \serial_reg[0]_0\,
      I3 => \Cnt[3]_i_9_n_0\,
      I4 => \D_Len[0]_i_3\,
      O => \Cnt[3]_i_7_n_0\
    );
\Cnt[3]_i_8\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000001"
    )
        port map (
      I0 => serial(0),
      I1 => serial(3),
      I2 => \serial_reg_n_0_[4]\,
      I3 => serial(1),
      I4 => serial(2),
      O => \Cnt[3]_i_8_n_0\
    );
\Cnt[3]_i_9\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"80000000"
    )
        port map (
      I0 => serial(2),
      I1 => serial(1),
      I2 => serial(0),
      I3 => serial(3),
      I4 => \serial_reg_n_0_[4]\,
      O => \Cnt[3]_i_9_n_0\
    );
\Cnt[4]_i_1__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"20AA20AA20222020"
    )
        port map (
      I0 => SRST_0,
      I1 => Q(3),
      I2 => \Cnt[4]_i_2__0_n_0\,
      I3 => \Cnt_reg[4]\,
      I4 => \Cnt_reg[4]_1\,
      I5 => \Cnt[5]_i_5_n_0\,
      O => SRST_0_0(4)
    );
\Cnt[4]_i_2__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5555005100510051"
    )
        port map (
      I0 => Q(2),
      I1 => \Cnt_reg[4]\,
      I2 => \Cnt_reg[4]_0\,
      I3 => \Cnt[4]_i_5__0_n_0\,
      I4 => IDE_TX_0,
      I5 => done_reg_0,
      O => \Cnt[4]_i_2__0_n_0\
    );
\Cnt[4]_i_5__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => \Cnt[5]_i_7__0_n_0\,
      I1 => Q(1),
      O => \Cnt[4]_i_5__0_n_0\
    );
\Cnt[5]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"4F"
    )
        port map (
      I0 => \Cnt[5]_i_3__0_n_0\,
      I1 => \serial_reg[4]_0\,
      I2 => SRST_0,
      O => E(0)
    );
\Cnt[5]_i_2__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"80888080AAAAAAAA"
    )
        port map (
      I0 => SRST_0,
      I1 => \Cnt_reg[5]\,
      I2 => \Cnt[5]_i_5_n_0\,
      I3 => Q(3),
      I4 => \Cnt_reg[4]_1\,
      I5 => \Cnt[5]_i_6_n_0\,
      O => SRST_0_0(5)
    );
\Cnt[5]_i_3__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8000000000000002"
    )
        port map (
      I0 => \CRC_RG_reg[14]_0\,
      I1 => serial(2),
      I2 => serial(1),
      I3 => serial(0),
      I4 => serial(3),
      I5 => \serial_reg_n_0_[4]\,
      O => \Cnt[5]_i_3__0_n_0\
    );
\Cnt[5]_i_5\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"20202220"
    )
        port map (
      I0 => Q(3),
      I1 => Q(2),
      I2 => \Cnt[3]_i_3__1_n_0\,
      I3 => Q(0),
      I4 => Q(1),
      O => \Cnt[5]_i_5_n_0\
    );
\Cnt[5]_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFEFFFEFFFEFFFFF"
    )
        port map (
      I0 => \Cnt[5]_i_7__0_n_0\,
      I1 => Q(3),
      I2 => Q(1),
      I3 => Q(2),
      I4 => \Cnt_reg[5]\,
      I5 => \Cnt_reg[5]_0\,
      O => \Cnt[5]_i_6_n_0\
    );
\Cnt[5]_i_7__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => Q(0),
      I1 => \Cnt[3]_i_7_n_0\,
      O => \Cnt[5]_i_7__0_n_0\
    );
\D_Len[0]_i_4\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"00A8"
    )
        port map (
      I0 => \D_Len[0]_i_3\,
      I1 => \Cnt[3]_i_9_n_0\,
      I2 => \serial_reg[0]_0\,
      I3 => \Cnt[3]_i_8_n_0\,
      O => \^txstates_reg[0]\
    );
\REC[8]_i_16\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5555555545554514"
    )
        port map (
      I0 => req_Error_RX,
      I1 => \^txstates_reg[0]\,
      I2 => Sampled_din,
      I3 => \State[0]_i_2\,
      I4 => done_reg_2,
      I5 => \REC[8]_i_12\,
      O => req_Error_reg_1
    );
\State[0]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAAAAAFEFFFEFE"
    )
        port map (
      I0 => \Cnt_reg[1]\,
      I1 => \REC[8]_i_12\,
      I2 => \State[0]_i_7_n_0\,
      I3 => \State[0]_i_2\,
      I4 => \Cnt[3]_i_7_n_0\,
      I5 => req_Error_RX,
      O => req_Error_reg
    );
\State[0]_i_7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000005555DDD5"
    )
        port map (
      I0 => Sampled_din,
      I1 => \D_Len[0]_i_3\,
      I2 => \Cnt[3]_i_9_n_0\,
      I3 => \serial_reg[0]_0\,
      I4 => \Cnt[3]_i_8_n_0\,
      I5 => \State[0]_i_4_0\,
      O => \State[0]_i_7_n_0\
    );
\TEC[0]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"171C00000800171C"
    )
        port map (
      I0 => Q(1),
      I1 => Q(2),
      I2 => Q(3),
      I3 => Q(0),
      I4 => Sampled_din,
      I5 => \^txstates_reg[0]\,
      O => \^txstates_reg[1]\
    );
\TEC[8]_i_22\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00005554FFFFFFFF"
    )
        port map (
      I0 => req_Error_RX,
      I1 => \TEC[8]_i_23_n_0\,
      I2 => \State[0]_i_7_n_0\,
      I3 => \REC[8]_i_12\,
      I4 => \TEC[8]_i_17\,
      I5 => \TEC[8]_i_17_0\,
      O => req_Error_reg_0
    );
\TEC[8]_i_23\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000FF5700A8"
    )
        port map (
      I0 => \D_Len[0]_i_3\,
      I1 => \Cnt[3]_i_9_n_0\,
      I2 => \serial_reg[0]_0\,
      I3 => \Cnt[3]_i_8_n_0\,
      I4 => Sampled_din,
      I5 => \State[0]_i_2\,
      O => \TEC[8]_i_23_n_0\
    );
\TXSTATES[0]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"08"
    )
        port map (
      I0 => \TXSTATES[0]_i_2_n_0\,
      I1 => SRST_0,
      I2 => \TXSTATES_reg[0]_1\,
      O => D(0)
    );
\TXSTATES[0]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFAB00AB"
    )
        port map (
      I0 => done_i_11_n_0,
      I1 => Q(3),
      I2 => \TXSTATES[0]_i_3_n_0\,
      I3 => \Cnt[5]_i_3__0_n_0\,
      I4 => Q(0),
      I5 => done_reg_5,
      O => \TXSTATES[0]_i_2_n_0\
    );
\TXSTATES[0]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F0F0EEEFF00FFFFF"
    )
        port map (
      I0 => \Cnt[5]_i_7__0_n_0\,
      I1 => \Cnt[0]_i_2_0\,
      I2 => Q(0),
      I3 => done_reg_1,
      I4 => Q(2),
      I5 => Q(1),
      O => \TXSTATES[0]_i_3_n_0\
    );
\TXSTATES[1]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"04"
    )
        port map (
      I0 => \TXSTATES[1]_i_2_n_0\,
      I1 => SRST_0,
      I2 => \TXSTATES_reg[0]_1\,
      O => D(1)
    );
\TXSTATES[1]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"74777444"
    )
        port map (
      I0 => Q(1),
      I1 => \Cnt[5]_i_3__0_n_0\,
      I2 => done_i_8_n_0,
      I3 => Q(3),
      I4 => done_i_7_n_0,
      O => \TXSTATES[1]_i_2_n_0\
    );
\TXSTATES[2]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => Q(2),
      I1 => \Cnt[5]_i_3__0_n_0\,
      I2 => \TXSTATES_reg[2]_0\,
      O => \^txstates_reg[2]\
    );
\TXSTATES[3]_i_4\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"0CA030F0"
    )
        port map (
      I0 => \TXSTATES[3]_i_5_n_0\,
      I1 => Q(0),
      I2 => Q(3),
      I3 => Q(2),
      I4 => Q(1),
      O => \^txstates_reg[0]_0\
    );
\TXSTATES[3]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"22202222AAAAAAAA"
    )
        port map (
      I0 => \Cnt[3]_i_7_n_0\,
      I1 => Q(0),
      I2 => \Cnt[0]_i_3_0\(1),
      I3 => \Cnt[0]_i_3_0\(0),
      I4 => \Cnt[0]_i_3_1\,
      I5 => done_reg_1,
      O => \TXSTATES[3]_i_5_n_0\
    );
ack_error_i_6: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FBF0F000F0F0FB0F"
    )
        port map (
      I0 => \^txstates_reg[0]\,
      I1 => Sampled_din,
      I2 => Q(3),
      I3 => Q(1),
      I4 => Q(2),
      I5 => Q(0),
      O => RXOUT_reg
    );
done_i_1: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FF08FFFFFF080000"
    )
        port map (
      I0 => done_reg_2,
      I1 => done_i_3_n_0,
      I2 => done_i_4_n_0,
      I3 => done_i_5_n_0,
      I4 => done_reg_3,
      I5 => done_reg_4,
      O => done_reg
    );
done_i_10: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000155555555"
    )
        port map (
      I0 => Q(3),
      I1 => done_i_4_0,
      I2 => done_i_4_1,
      I3 => \Cnt[0]_i_2_0\,
      I4 => \Cnt[5]_i_7__0_n_0\,
      I5 => done_i_4_2,
      O => done_i_10_n_0
    );
done_i_11: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000222F2F2F"
    )
        port map (
      I0 => \Cnt[3]_i_3__1_n_0\,
      I1 => done_i_4_3,
      I2 => Q(1),
      I3 => Q(0),
      I4 => done_reg_1,
      I5 => done_i_4_4,
      O => done_i_11_n_0
    );
done_i_3: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000E2FFE2"
    )
        port map (
      I0 => done_i_7_n_0,
      I1 => Q(3),
      I2 => done_i_8_n_0,
      I3 => \Cnt[5]_i_3__0_n_0\,
      I4 => Q(1),
      I5 => \^txstates_reg[2]\,
      O => done_i_3_n_0
    );
done_i_4: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFEFEFEFEA"
    )
        port map (
      I0 => done_reg_5,
      I1 => Q(0),
      I2 => \Cnt[5]_i_3__0_n_0\,
      I3 => done_i_10_n_0,
      I4 => done_i_11_n_0,
      I5 => \^txstates_reg[0]_0\,
      O => done_i_4_n_0
    );
done_i_5: unisim.vcomponents.LUT6
    generic map(
      INIT => X"20000000FFFFFFFF"
    )
        port map (
      I0 => Q(3),
      I1 => Q(2),
      I2 => done_reg_0,
      I3 => done_reg_1,
      I4 => req_Errorr_i_2_n_0,
      I5 => SRST_0,
      O => done_i_5_n_0
    );
done_i_7: unisim.vcomponents.LUT5
    generic map(
      INIT => X"C3F3EBAB"
    )
        port map (
      I0 => \Cnt[5]_i_7__0_n_0\,
      I1 => Q(1),
      I2 => Q(0),
      I3 => done_reg_1,
      I4 => Q(2),
      O => done_i_7_n_0
    );
done_i_8: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F3F5F3FFF3F5F30F"
    )
        port map (
      I0 => done_reg_1,
      I1 => \TXSTATES[3]_i_5_n_0\,
      I2 => Q(2),
      I3 => Q(1),
      I4 => Q(0),
      I5 => \Cnt_reg[1]\,
      O => done_i_8_n_0
    );
imTX_i_1: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FF44F4FF00000000"
    )
        port map (
      I0 => imTX_reg,
      I1 => imTX,
      I2 => \TXSTATES[0]_i_2_n_0\,
      I3 => done_i_3_n_0,
      I4 => \^txstates_reg[0]_0\,
      I5 => SRST_0,
      O => imTX0_out
    );
req_Errorr_i_1: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000CFFE0000"
    )
        port map (
      I0 => Q(0),
      I1 => Q(2),
      I2 => Q(3),
      I3 => Q(1),
      I4 => SRST_0,
      I5 => req_Errorr_i_2_n_0,
      O => req_Errorr
    );
req_Errorr_i_2: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => req_Errorr_reg,
      I1 => \^txstates_reg[1]\,
      O => req_Errorr_i_2_n_0
    );
\serial[0]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => \serial[0]_i_2_n_0\,
      I1 => SRST_0,
      O => \serial[0]_i_1_n_0\
    );
\serial[0]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"1555555555555557"
    )
        port map (
      I0 => \serial_reg[0]_0\,
      I1 => serial(2),
      I2 => serial(1),
      I3 => serial(0),
      I4 => serial(3),
      I5 => \serial_reg_n_0_[4]\,
      O => \serial[0]_i_2_n_0\
    );
\serial[1]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => SRST_0,
      I1 => serial(0),
      O => \serial[1]_i_1_n_0\
    );
\serial[2]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => SRST_0,
      I1 => serial(1),
      O => \serial[2]_i_1_n_0\
    );
\serial[3]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => SRST_0,
      I1 => serial(2),
      O => \serial[3]_i_1_n_0\
    );
\serial[4]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000AA8FFFFFFFF"
    )
        port map (
      I0 => \serial_reg[4]_0\,
      I1 => Q(0),
      I2 => Q(2),
      I3 => Q(1),
      I4 => Q(3),
      I5 => SRST_0,
      O => \serial[4]_i_1_n_0\
    );
\serial[4]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => SRST_0,
      I1 => serial(3),
      O => \serial[4]_i_2_n_0\
    );
\serial_reg[0]\: unisim.vcomponents.FDPE
     port map (
      C => clk,
      CE => \serial[4]_i_1_n_0\,
      D => \serial[0]_i_1_n_0\,
      PRE => \serial_reg[0]_1\,
      Q => serial(0)
    );
\serial_reg[1]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \serial[4]_i_1_n_0\,
      CLR => \serial_reg[0]_1\,
      D => \serial[1]_i_1_n_0\,
      Q => serial(1)
    );
\serial_reg[2]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \serial[4]_i_1_n_0\,
      CLR => \serial_reg[0]_1\,
      D => \serial[2]_i_1_n_0\,
      Q => serial(2)
    );
\serial_reg[3]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \serial[4]_i_1_n_0\,
      CLR => \serial_reg[0]_1\,
      D => \serial[3]_i_1_n_0\,
      Q => serial(3)
    );
\serial_reg[4]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \serial[4]_i_1_n_0\,
      CLR => \serial_reg[0]_1\,
      D => \serial[4]_i_2_n_0\,
      Q => \serial_reg_n_0_[4]\
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1_FPGAPROJECT_0_0_bitstuffer_8 is
  port (
    \TEC_reg[8]\ : out STD_LOGIC;
    req_Error_reg : out STD_LOGIC;
    req_Error_reg_0 : out STD_LOGIC;
    req_Error_reg_1 : out STD_LOGIC;
    \TXSTATES_reg[3]\ : out STD_LOGIC;
    req_Errorr : out STD_LOGIC;
    \TXSTATES_reg[1]\ : out STD_LOGIC;
    RXOUT_reg : out STD_LOGIC;
    imTX0_out : out STD_LOGIC;
    \TXSTATES_reg[3]_0\ : out STD_LOGIC;
    \TXSTATES_reg[3]_1\ : out STD_LOGIC;
    \TXSTATES_reg[2]\ : out STD_LOGIC;
    \TXSTATES_reg[1]_0\ : out STD_LOGIC;
    E : out STD_LOGIC_VECTOR ( 0 to 0 );
    D : out STD_LOGIC_VECTOR ( 5 downto 0 );
    \Cnt_reg[2]\ : out STD_LOGIC;
    \TXSTATES_reg[1]_1\ : out STD_LOGIC;
    \Cnt_reg[3]\ : out STD_LOGIC;
    \ID_TX_1[8]\ : out STD_LOGIC;
    \ID_TX_1[28]\ : out STD_LOGIC;
    \Cnt_reg[4]\ : out STD_LOGIC;
    \D_Len_TX_1[3]\ : out STD_LOGIC;
    \ID_TX_1[10]\ : out STD_LOGIC;
    \ID_TX_1[28]_0\ : out STD_LOGIC;
    \Cnt_reg[4]_0\ : out STD_LOGIC;
    done_reg : out STD_LOGIC;
    SRST_1 : out STD_LOGIC_VECTOR ( 0 to 0 );
    TEC : in STD_LOGIC_VECTOR ( 1 downto 0 );
    req_Error_RX : in STD_LOGIC;
    \State[2]_i_3\ : in STD_LOGIC;
    \Cnt_reg[1]\ : in STD_LOGIC;
    \State[0]_i_2\ : in STD_LOGIC;
    \REC[0]_i_5\ : in STD_LOGIC;
    \REC[0]_i_5_0\ : in STD_LOGIC;
    Sampled_din : in STD_LOGIC;
    done_reg_0 : in STD_LOGIC;
    Q : in STD_LOGIC_VECTOR ( 3 downto 0 );
    SRST : in STD_LOGIC;
    req_Errorr_reg : in STD_LOGIC;
    imTX_reg : in STD_LOGIC;
    \CRC_RG_reg[14]\ : in STD_LOGIC;
    \CRC_RG_reg[14]_0\ : in STD_LOGIC;
    \CRC_RG_reg[14]_1\ : in STD_LOGIC;
    \Cnt_reg[1]_0\ : in STD_LOGIC;
    \Cnt_reg[1]_1\ : in STD_LOGIC;
    \Cnt_reg[1]_2\ : in STD_LOGIC;
    TX_INST_0_i_2 : in STD_LOGIC;
    \State[0]_i_4_0\ : in STD_LOGIC;
    \REC[0]_i_6_0\ : in STD_LOGIC;
    done_reg_1 : in STD_LOGIC;
    \Cnt_reg[3]_0\ : in STD_LOGIC;
    \Cnt_reg[5]\ : in STD_LOGIC;
    \Cnt_reg[4]_1\ : in STD_LOGIC;
    \Cnt_reg[2]_0\ : in STD_LOGIC;
    \Cnt_reg[4]_2\ : in STD_LOGIC;
    IDE_TX : in STD_LOGIC;
    \Cnt_reg[2]_1\ : in STD_LOGIC;
    \Cnt_reg[0]\ : in STD_LOGIC;
    \Cnt_reg[0]_0\ : in STD_LOGIC;
    \serial[0]_i_12_0\ : in STD_LOGIC_VECTOR ( 5 downto 0 );
    \Cnt_reg[3]_1\ : in STD_LOGIC;
    done_reg_2 : in STD_LOGIC;
    \Cnt_reg[5]_0\ : in STD_LOGIC;
    done_reg_3 : in STD_LOGIC;
    \Cnt_reg[1]_3\ : in STD_LOGIC;
    \Cnt[0]_i_2_0\ : in STD_LOGIC;
    TX_INST_0_i_2_0 : in STD_LOGIC;
    \serial_reg[0]_0\ : in STD_LOGIC;
    imTX_reg_0 : in STD_LOGIC;
    \serial[0]_i_2_0\ : in STD_LOGIC;
    RTR_TX : in STD_LOGIC;
    ID_TX : in STD_LOGIC_VECTOR ( 28 downto 0 );
    D_Len_TX : in STD_LOGIC_VECTOR ( 3 downto 0 );
    done_reg_4 : in STD_LOGIC;
    done_reg_5 : in STD_LOGIC;
    \Cnt_reg[4]_3\ : in STD_LOGIC;
    done_i_4_0 : in STD_LOGIC;
    done_i_4_1 : in STD_LOGIC;
    done_i_4_2 : in STD_LOGIC;
    \Cnt_reg[5]_1\ : in STD_LOGIC;
    done_i_4_3 : in STD_LOGIC;
    Tq : in STD_LOGIC;
    \serial_reg[0]_1\ : in STD_LOGIC
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of design_1_FPGAPROJECT_0_0_bitstuffer_8 : entity is "bitstuffer";
end design_1_FPGAPROJECT_0_0_bitstuffer_8;

architecture STRUCTURE of design_1_FPGAPROJECT_0_0_bitstuffer_8 is
  signal \CRC_RG[14]_i_5_n_0\ : STD_LOGIC;
  signal \Cnt[0]_i_2_n_0\ : STD_LOGIC;
  signal \Cnt[0]_i_4_n_0\ : STD_LOGIC;
  signal \Cnt[1]_i_2_n_0\ : STD_LOGIC;
  signal \Cnt[1]_i_3_n_0\ : STD_LOGIC;
  signal \Cnt[2]_i_3__0_n_0\ : STD_LOGIC;
  signal \Cnt[2]_i_4_n_0\ : STD_LOGIC;
  signal \Cnt[2]_i_5__0_n_0\ : STD_LOGIC;
  signal \Cnt[3]_i_3_n_0\ : STD_LOGIC;
  signal \Cnt[3]_i_5_n_0\ : STD_LOGIC;
  signal \Cnt[3]_i_6__0_n_0\ : STD_LOGIC;
  signal \Cnt[4]_i_2__0_n_0\ : STD_LOGIC;
  signal \Cnt[4]_i_4__0_n_0\ : STD_LOGIC;
  signal \Cnt[4]_i_6__0_n_0\ : STD_LOGIC;
  signal \Cnt[5]_i_3_n_0\ : STD_LOGIC;
  signal \Cnt[5]_i_4__0_n_0\ : STD_LOGIC;
  signal \Cnt[5]_i_6_n_0\ : STD_LOGIC;
  signal \Cnt[5]_i_7_n_0\ : STD_LOGIC;
  signal \Cnt[5]_i_8_n_0\ : STD_LOGIC;
  signal \^cnt_reg[2]\ : STD_LOGIC;
  signal \^cnt_reg[3]\ : STD_LOGIC;
  signal \^cnt_reg[4]\ : STD_LOGIC;
  signal \^cnt_reg[4]_0\ : STD_LOGIC;
  signal \^d_len_tx_1[3]\ : STD_LOGIC;
  signal \^id_tx_1[10]\ : STD_LOGIC;
  signal \^id_tx_1[28]\ : STD_LOGIC;
  signal \^id_tx_1[28]_0\ : STD_LOGIC;
  signal \^id_tx_1[8]\ : STD_LOGIC;
  signal \REC[0]_i_9_n_0\ : STD_LOGIC;
  signal \State[0]_i_8_n_0\ : STD_LOGIC;
  signal \TXSTATES[0]_i_3_n_0\ : STD_LOGIC;
  signal \TXSTATES[1]_i_3_n_0\ : STD_LOGIC;
  signal \TXSTATES[3]_i_6_n_0\ : STD_LOGIC;
  signal \^txstates_reg[1]\ : STD_LOGIC;
  signal \^txstates_reg[1]_0\ : STD_LOGIC;
  signal \^txstates_reg[1]_1\ : STD_LOGIC;
  signal \^txstates_reg[2]\ : STD_LOGIC;
  signal \^txstates_reg[3]\ : STD_LOGIC;
  signal \^txstates_reg[3]_0\ : STD_LOGIC;
  signal \^txstates_reg[3]_1\ : STD_LOGIC;
  signal done_i_11_n_0 : STD_LOGIC;
  signal done_i_12_n_0 : STD_LOGIC;
  signal \done_i_3__0_n_0\ : STD_LOGIC;
  signal done_i_4_n_0 : STD_LOGIC;
  signal done_i_5_n_0 : STD_LOGIC;
  signal done_i_7_n_0 : STD_LOGIC;
  signal done_i_8_n_0 : STD_LOGIC;
  signal req_Errorr_i_2_n_0 : STD_LOGIC;
  signal serial : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \serial[0]_i_12_n_0\ : STD_LOGIC;
  signal \serial[0]_i_1_n_0\ : STD_LOGIC;
  signal \serial[0]_i_25_n_0\ : STD_LOGIC;
  signal \serial[0]_i_27_n_0\ : STD_LOGIC;
  signal \serial[0]_i_2_n_0\ : STD_LOGIC;
  signal \serial[0]_i_31_n_0\ : STD_LOGIC;
  signal \serial[0]_i_3_n_0\ : STD_LOGIC;
  signal \serial[0]_i_4_n_0\ : STD_LOGIC;
  signal \serial[0]_i_55_n_0\ : STD_LOGIC;
  signal \serial[0]_i_56_n_0\ : STD_LOGIC;
  signal \serial[0]_i_57_n_0\ : STD_LOGIC;
  signal \serial[0]_i_58_n_0\ : STD_LOGIC;
  signal \serial[0]_i_59_n_0\ : STD_LOGIC;
  signal \serial[0]_i_60_n_0\ : STD_LOGIC;
  signal \serial[0]_i_61_n_0\ : STD_LOGIC;
  signal \serial[0]_i_62_n_0\ : STD_LOGIC;
  signal \serial[0]_i_63_n_0\ : STD_LOGIC;
  signal \serial[0]_i_64_n_0\ : STD_LOGIC;
  signal \serial[0]_i_65_n_0\ : STD_LOGIC;
  signal \serial[0]_i_66_n_0\ : STD_LOGIC;
  signal \serial[0]_i_67_n_0\ : STD_LOGIC;
  signal \serial[0]_i_68_n_0\ : STD_LOGIC;
  signal \serial[0]_i_69_n_0\ : STD_LOGIC;
  signal \serial[0]_i_6_n_0\ : STD_LOGIC;
  signal \serial[0]_i_70_n_0\ : STD_LOGIC;
  signal \serial[1]_i_1_n_0\ : STD_LOGIC;
  signal \serial[2]_i_1_n_0\ : STD_LOGIC;
  signal \serial[3]_i_1_n_0\ : STD_LOGIC;
  signal \serial[4]_i_1_n_0\ : STD_LOGIC;
  signal \serial[4]_i_2_n_0\ : STD_LOGIC;
  signal \serial_reg_n_0_[4]\ : STD_LOGIC;
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \CRC_RG[14]_i_5\ : label is "soft_lutpair91";
  attribute SOFT_HLUTNM of \Cnt[2]_i_3__0\ : label is "soft_lutpair90";
  attribute SOFT_HLUTNM of \Cnt[2]_i_5__0\ : label is "soft_lutpair96";
  attribute SOFT_HLUTNM of \Cnt[3]_i_5\ : label is "soft_lutpair93";
  attribute SOFT_HLUTNM of \Cnt[3]_i_6__0\ : label is "soft_lutpair92";
  attribute SOFT_HLUTNM of \Cnt[4]_i_4__0\ : label is "soft_lutpair88";
  attribute SOFT_HLUTNM of \Cnt[4]_i_6__0\ : label is "soft_lutpair93";
  attribute SOFT_HLUTNM of \Cnt[5]_i_1\ : label is "soft_lutpair95";
  attribute SOFT_HLUTNM of \Cnt[5]_i_4__0\ : label is "soft_lutpair88";
  attribute SOFT_HLUTNM of \TXSTATES[1]_i_3\ : label is "soft_lutpair89";
  attribute SOFT_HLUTNM of \TXSTATES[2]_i_2\ : label is "soft_lutpair95";
  attribute SOFT_HLUTNM of \TXSTATES[3]_i_4\ : label is "soft_lutpair89";
  attribute SOFT_HLUTNM of done_i_8 : label is "soft_lutpair90";
  attribute SOFT_HLUTNM of \serial[0]_i_27\ : label is "soft_lutpair96";
  attribute SOFT_HLUTNM of \serial[0]_i_33\ : label is "soft_lutpair92";
  attribute SOFT_HLUTNM of \serial[0]_i_4\ : label is "soft_lutpair91";
  attribute SOFT_HLUTNM of \serial[0]_i_57\ : label is "soft_lutpair94";
  attribute SOFT_HLUTNM of \serial[0]_i_59\ : label is "soft_lutpair94";
  attribute SOFT_HLUTNM of \serial[1]_i_1\ : label is "soft_lutpair98";
  attribute SOFT_HLUTNM of \serial[2]_i_1\ : label is "soft_lutpair98";
  attribute SOFT_HLUTNM of \serial[3]_i_1\ : label is "soft_lutpair97";
  attribute SOFT_HLUTNM of \serial[4]_i_2\ : label is "soft_lutpair97";
begin
  \Cnt_reg[2]\ <= \^cnt_reg[2]\;
  \Cnt_reg[3]\ <= \^cnt_reg[3]\;
  \Cnt_reg[4]\ <= \^cnt_reg[4]\;
  \Cnt_reg[4]_0\ <= \^cnt_reg[4]_0\;
  \D_Len_TX_1[3]\ <= \^d_len_tx_1[3]\;
  \ID_TX_1[10]\ <= \^id_tx_1[10]\;
  \ID_TX_1[28]\ <= \^id_tx_1[28]\;
  \ID_TX_1[28]_0\ <= \^id_tx_1[28]_0\;
  \ID_TX_1[8]\ <= \^id_tx_1[8]\;
  \TXSTATES_reg[1]\ <= \^txstates_reg[1]\;
  \TXSTATES_reg[1]_0\ <= \^txstates_reg[1]_0\;
  \TXSTATES_reg[1]_1\ <= \^txstates_reg[1]_1\;
  \TXSTATES_reg[2]\ <= \^txstates_reg[2]\;
  \TXSTATES_reg[3]\ <= \^txstates_reg[3]\;
  \TXSTATES_reg[3]_0\ <= \^txstates_reg[3]_0\;
  \TXSTATES_reg[3]_1\ <= \^txstates_reg[3]_1\;
\CRC_RG[14]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5D555D5D5D5D5D5D"
    )
        port map (
      I0 => \CRC_RG_reg[14]\,
      I1 => \CRC_RG_reg[14]_0\,
      I2 => \CRC_RG[14]_i_5_n_0\,
      I3 => Q(3),
      I4 => Q(0),
      I5 => \CRC_RG_reg[14]_1\,
      O => E(0)
    );
\CRC_RG[14]_i_5\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"80000001"
    )
        port map (
      I0 => serial(0),
      I1 => \serial_reg_n_0_[4]\,
      I2 => serial(3),
      I3 => serial(1),
      I4 => serial(2),
      O => \CRC_RG[14]_i_5_n_0\
    );
\Cnt[0]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8A8888888A8A8A8A"
    )
        port map (
      I0 => SRST,
      I1 => \Cnt[0]_i_2_n_0\,
      I2 => Q(3),
      I3 => \Cnt_reg[0]_0\,
      I4 => \CRC_RG_reg[14]_1\,
      I5 => \Cnt[0]_i_4_n_0\,
      O => D(0)
    );
\Cnt[0]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000000000EC20"
    )
        port map (
      I0 => \^cnt_reg[2]\,
      I1 => Q(1),
      I2 => Q(0),
      I3 => \TXSTATES[3]_i_6_n_0\,
      I4 => done_reg_3,
      I5 => \serial[0]_i_12_0\(0),
      O => \Cnt[0]_i_2_n_0\
    );
\Cnt[0]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BBAABAAAAAAABAAA"
    )
        port map (
      I0 => \Cnt[3]_i_5_n_0\,
      I1 => \Cnt_reg[0]\,
      I2 => Q(0),
      I3 => Q(1),
      I4 => \^cnt_reg[2]\,
      I5 => \serial[0]_i_12_0\(0),
      O => \Cnt[0]_i_4_n_0\
    );
\Cnt[1]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000AAAA222A"
    )
        port map (
      I0 => \Cnt[1]_i_2_n_0\,
      I1 => \Cnt[1]_i_3_n_0\,
      I2 => \Cnt_reg[1]_0\,
      I3 => \Cnt_reg[1]_1\,
      I4 => Q(3),
      I5 => \Cnt_reg[1]_2\,
      O => D(1)
    );
\Cnt[1]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFF55FF5D5D5555"
    )
        port map (
      I0 => Q(3),
      I1 => Q(2),
      I2 => \Cnt_reg[1]\,
      I3 => \Cnt_reg[1]_0\,
      I4 => \Cnt_reg[1]_3\,
      I5 => \TXSTATES[1]_i_3_n_0\,
      O => \Cnt[1]_i_2_n_0\
    );
\Cnt[1]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FEFEFFFFFAFAFBFF"
    )
        port map (
      I0 => \Cnt[5]_i_8_n_0\,
      I1 => Q(1),
      I2 => Q(2),
      I3 => \^cnt_reg[2]\,
      I4 => Q(0),
      I5 => \Cnt_reg[1]_0\,
      O => \Cnt[1]_i_3_n_0\
    );
\Cnt[2]_i_1__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000AA02AA"
    )
        port map (
      I0 => SRST,
      I1 => \Cnt_reg[2]_0\,
      I2 => Q(2),
      I3 => Q(3),
      I4 => \Cnt[2]_i_3__0_n_0\,
      I5 => \Cnt[2]_i_4_n_0\,
      O => D(2)
    );
\Cnt[2]_i_3__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => Q(1),
      I1 => \TXSTATES[3]_i_6_n_0\,
      O => \Cnt[2]_i_3__0_n_0\
    );
\Cnt[2]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FF77FF770070FF70"
    )
        port map (
      I0 => \Cnt_reg[4]_2\,
      I1 => IDE_TX,
      I2 => \Cnt[4]_i_6__0_n_0\,
      I3 => Q(2),
      I4 => \Cnt_reg[2]_1\,
      I5 => \Cnt[2]_i_5__0_n_0\,
      O => \Cnt[2]_i_4_n_0\
    );
\Cnt[2]_i_5__0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"56"
    )
        port map (
      I0 => \serial[0]_i_12_0\(2),
      I1 => \serial[0]_i_12_0\(1),
      I2 => \serial[0]_i_12_0\(0),
      O => \Cnt[2]_i_5__0_n_0\
    );
\Cnt[3]_i_1__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"008000000080AAAA"
    )
        port map (
      I0 => SRST,
      I1 => \Cnt[5]_i_4__0_n_0\,
      I2 => \Cnt_reg[3]_0\,
      I3 => Q(2),
      I4 => Q(3),
      I5 => \Cnt[3]_i_3_n_0\,
      O => D(3)
    );
\Cnt[3]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FF080000FF88FF88"
    )
        port map (
      I0 => \Cnt_reg[3]_1\,
      I1 => Q(1),
      I2 => \^cnt_reg[2]\,
      I3 => \Cnt[3]_i_5_n_0\,
      I4 => \Cnt_reg[1]_1\,
      I5 => \Cnt[3]_i_6__0_n_0\,
      O => \Cnt[3]_i_3_n_0\
    );
\Cnt[3]_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFAB"
    )
        port map (
      I0 => \Cnt[5]_i_8_n_0\,
      I1 => Q(0),
      I2 => Q(1),
      I3 => Q(2),
      O => \Cnt[3]_i_5_n_0\
    );
\Cnt[3]_i_6__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"AAA9"
    )
        port map (
      I0 => \serial[0]_i_12_0\(3),
      I1 => \serial[0]_i_12_0\(0),
      I2 => \serial[0]_i_12_0\(1),
      I3 => \serial[0]_i_12_0\(2),
      O => \Cnt[3]_i_6__0_n_0\
    );
\Cnt[4]_i_1__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00008A88AAAA8A88"
    )
        port map (
      I0 => SRST,
      I1 => \Cnt[4]_i_2__0_n_0\,
      I2 => \Cnt_reg[4]_1\,
      I3 => \CRC_RG_reg[14]_1\,
      I4 => Q(3),
      I5 => \Cnt[4]_i_4__0_n_0\,
      O => D(4)
    );
\Cnt[4]_i_2__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5555001500150015"
    )
        port map (
      I0 => Q(2),
      I1 => \Cnt_reg[4]_3\,
      I2 => \Cnt_reg[4]_1\,
      I3 => \Cnt[4]_i_6__0_n_0\,
      I4 => IDE_TX,
      I5 => \Cnt_reg[4]_2\,
      O => \Cnt[4]_i_2__0_n_0\
    );
\Cnt[4]_i_4__0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFF4F7"
    )
        port map (
      I0 => \Cnt[5]_i_7_n_0\,
      I1 => Q(1),
      I2 => \Cnt_reg[4]_1\,
      I3 => Q(0),
      I4 => Q(2),
      O => \Cnt[4]_i_4__0_n_0\
    );
\Cnt[4]_i_6__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => \Cnt[5]_i_8_n_0\,
      I1 => Q(1),
      O => \Cnt[4]_i_6__0_n_0\
    );
\Cnt[5]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"4F"
    )
        port map (
      I0 => \Cnt[5]_i_3_n_0\,
      I1 => \Cnt_reg[5]_1\,
      I2 => SRST,
      O => SRST_1(0)
    );
\Cnt[5]_i_2__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00080000AAAAAAAA"
    )
        port map (
      I0 => SRST,
      I1 => \Cnt[5]_i_4__0_n_0\,
      I2 => \Cnt_reg[5]\,
      I3 => Q(2),
      I4 => Q(3),
      I5 => \Cnt[5]_i_6_n_0\,
      O => D(5)
    );
\Cnt[5]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8000000100000000"
    )
        port map (
      I0 => serial(2),
      I1 => serial(1),
      I2 => serial(3),
      I3 => \serial_reg_n_0_[4]\,
      I4 => serial(0),
      I5 => \CRC_RG_reg[14]_0\,
      O => \Cnt[5]_i_3_n_0\
    );
\Cnt[5]_i_4__0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \Cnt[5]_i_7_n_0\,
      I1 => Q(1),
      I2 => Q(0),
      O => \Cnt[5]_i_4__0_n_0\
    );
\Cnt[5]_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFEEFEFAFAFFFF"
    )
        port map (
      I0 => Q(3),
      I1 => \Cnt[5]_i_8_n_0\,
      I2 => \Cnt_reg[5]\,
      I3 => \Cnt_reg[5]_0\,
      I4 => Q(2),
      I5 => Q(1),
      O => \Cnt[5]_i_6_n_0\
    );
\Cnt[5]_i_7\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"9A99AAAA"
    )
        port map (
      I0 => Sampled_din,
      I1 => \serial[0]_i_3_n_0\,
      I2 => \serial[0]_i_4_n_0\,
      I3 => \State[0]_i_4_0\,
      I4 => TX_INST_0_i_2,
      O => \Cnt[5]_i_7_n_0\
    );
\Cnt[5]_i_8\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => Q(0),
      I1 => \Cnt[5]_i_7_n_0\,
      O => \Cnt[5]_i_8_n_0\
    );
\REC[0]_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFBBBBBBBA"
    )
        port map (
      I0 => TEC(1),
      I1 => req_Error_RX,
      I2 => \REC[0]_i_9_n_0\,
      I3 => \State[0]_i_8_n_0\,
      I4 => \State[2]_i_3\,
      I5 => \Cnt_reg[1]\,
      O => \TEC_reg[8]\
    );
\REC[0]_i_7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00005554FFFFFFFF"
    )
        port map (
      I0 => req_Error_RX,
      I1 => \REC[0]_i_9_n_0\,
      I2 => \State[0]_i_8_n_0\,
      I3 => \State[2]_i_3\,
      I4 => \REC[0]_i_5\,
      I5 => \REC[0]_i_5_0\,
      O => req_Error_reg_0
    );
\REC[0]_i_9\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000FF5D00A2"
    )
        port map (
      I0 => TX_INST_0_i_2,
      I1 => \State[0]_i_4_0\,
      I2 => \serial[0]_i_4_n_0\,
      I3 => \serial[0]_i_3_n_0\,
      I4 => Sampled_din,
      I5 => \State[0]_i_2\,
      O => \REC[0]_i_9_n_0\
    );
\State[0]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAAAAAFEFFFEFE"
    )
        port map (
      I0 => \Cnt_reg[1]\,
      I1 => \State[2]_i_3\,
      I2 => \State[0]_i_8_n_0\,
      I3 => \State[0]_i_2\,
      I4 => \Cnt[5]_i_7_n_0\,
      I5 => req_Error_RX,
      O => req_Error_reg
    );
\State[0]_i_8\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000005555DD5D"
    )
        port map (
      I0 => Sampled_din,
      I1 => TX_INST_0_i_2,
      I2 => \State[0]_i_4_0\,
      I3 => \serial[0]_i_4_n_0\,
      I4 => \serial[0]_i_3_n_0\,
      I5 => \REC[0]_i_6_0\,
      O => \State[0]_i_8_n_0\
    );
\State[2]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5555555545554514"
    )
        port map (
      I0 => req_Error_RX,
      I1 => \^txstates_reg[3]\,
      I2 => Sampled_din,
      I3 => \State[0]_i_2\,
      I4 => done_reg_0,
      I5 => \State[2]_i_3\,
      O => req_Error_reg_1
    );
\TXSTATES[0]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFAB00AB"
    )
        port map (
      I0 => done_i_12_n_0,
      I1 => Q(3),
      I2 => \TXSTATES[0]_i_3_n_0\,
      I3 => \Cnt[5]_i_3_n_0\,
      I4 => Q(0),
      I5 => done_reg_1,
      O => \^txstates_reg[3]_1\
    );
\TXSTATES[0]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FF00EEFE0FF0FFFF"
    )
        port map (
      I0 => \Cnt[5]_i_8_n_0\,
      I1 => \Cnt_reg[0]\,
      I2 => \^cnt_reg[2]\,
      I3 => Q(0),
      I4 => Q(2),
      I5 => Q(1),
      O => \TXSTATES[0]_i_3_n_0\
    );
\TXSTATES[1]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"88888888B8B8BBB8"
    )
        port map (
      I0 => Q(1),
      I1 => \Cnt[5]_i_3_n_0\,
      I2 => done_reg_2,
      I3 => \TXSTATES[1]_i_3_n_0\,
      I4 => \Cnt_reg[2]_1\,
      I5 => done_i_7_n_0,
      O => \^txstates_reg[1]_0\
    );
\TXSTATES[1]_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"45"
    )
        port map (
      I0 => Q(2),
      I1 => \TXSTATES[3]_i_6_n_0\,
      I2 => Q(1),
      O => \TXSTATES[1]_i_3_n_0\
    );
\TXSTATES[2]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => Q(2),
      I1 => \Cnt[5]_i_3_n_0\,
      I2 => imTX_reg_0,
      O => \^txstates_reg[2]\
    );
\TXSTATES[3]_i_4\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"30880CCC"
    )
        port map (
      I0 => \TXSTATES[3]_i_6_n_0\,
      I1 => Q(3),
      I2 => Q(0),
      I3 => Q(2),
      I4 => Q(1),
      O => \^txstates_reg[3]_0\
    );
\TXSTATES[3]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"117C00000080117C"
    )
        port map (
      I0 => Q(1),
      I1 => Q(2),
      I2 => Q(0),
      I3 => Q(3),
      I4 => Sampled_din,
      I5 => \^txstates_reg[3]\,
      O => \^txstates_reg[1]\
    );
\TXSTATES[3]_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAAAAA22222022"
    )
        port map (
      I0 => \Cnt[5]_i_7_n_0\,
      I1 => Q(0),
      I2 => TEC(0),
      I3 => \Cnt[0]_i_2_0\,
      I4 => TEC(1),
      I5 => \^cnt_reg[2]\,
      O => \TXSTATES[3]_i_6_n_0\
    );
TX_INST_0_i_3: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000AAAA00A2"
    )
        port map (
      I0 => TX_INST_0_i_2,
      I1 => TX_INST_0_i_2_0,
      I2 => \serial_reg[0]_0\,
      I3 => Q(3),
      I4 => \serial[0]_i_4_n_0\,
      I5 => \serial[0]_i_3_n_0\,
      O => \^txstates_reg[3]\
    );
ack_error_i_5: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFB0FF00FF0B000F"
    )
        port map (
      I0 => \^txstates_reg[3]\,
      I1 => Sampled_din,
      I2 => Q(0),
      I3 => Q(3),
      I4 => Q(1),
      I5 => Q(2),
      O => RXOUT_reg
    );
done_i_1: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FF08FFFFFF080000"
    )
        port map (
      I0 => done_reg_0,
      I1 => \done_i_3__0_n_0\,
      I2 => done_i_4_n_0,
      I3 => done_i_5_n_0,
      I4 => done_reg_4,
      I5 => done_reg_5,
      O => done_reg
    );
done_i_11: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000155555555"
    )
        port map (
      I0 => Q(3),
      I1 => done_i_4_0,
      I2 => done_i_4_1,
      I3 => \Cnt_reg[0]\,
      I4 => \Cnt[5]_i_8_n_0\,
      I5 => done_i_4_2,
      O => done_i_11_n_0
    );
done_i_12: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000003B083B3B"
    )
        port map (
      I0 => \Cnt[5]_i_7_n_0\,
      I1 => Q(1),
      I2 => done_i_4_3,
      I3 => \^cnt_reg[2]\,
      I4 => Q(0),
      I5 => done_reg_3,
      O => done_i_12_n_0
    );
done_i_14: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFFFFE"
    )
        port map (
      I0 => \serial[0]_i_12_0\(2),
      I1 => \serial[0]_i_12_0\(1),
      I2 => \serial[0]_i_12_0\(0),
      I3 => \serial[0]_i_12_0\(3),
      I4 => \serial[0]_i_12_0\(5),
      I5 => \serial[0]_i_12_0\(4),
      O => \^cnt_reg[2]\
    );
\done_i_3__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000444555554445"
    )
        port map (
      I0 => \^txstates_reg[2]\,
      I1 => done_i_7_n_0,
      I2 => done_i_8_n_0,
      I3 => done_reg_2,
      I4 => \Cnt[5]_i_3_n_0\,
      I5 => Q(1),
      O => \done_i_3__0_n_0\
    );
done_i_4: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FEFFFEFFFEFFFEEE"
    )
        port map (
      I0 => \^txstates_reg[3]_0\,
      I1 => done_reg_1,
      I2 => Q(0),
      I3 => \Cnt[5]_i_3_n_0\,
      I4 => done_i_11_n_0,
      I5 => done_i_12_n_0,
      O => done_i_4_n_0
    );
done_i_5: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00100000FFFFFFFF"
    )
        port map (
      I0 => done_reg_3,
      I1 => \^cnt_reg[2]\,
      I2 => Q(0),
      I3 => Q(1),
      I4 => req_Errorr_i_2_n_0,
      I5 => SRST,
      O => done_i_5_n_0
    );
done_i_7: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000CCF30000AEBB"
    )
        port map (
      I0 => \Cnt[5]_i_8_n_0\,
      I1 => Q(0),
      I2 => \^cnt_reg[2]\,
      I3 => Q(1),
      I4 => Q(3),
      I5 => Q(2),
      O => done_i_7_n_0
    );
done_i_8: unisim.vcomponents.LUT5
    generic map(
      INIT => X"22220030"
    )
        port map (
      I0 => \TXSTATES[3]_i_6_n_0\,
      I1 => Q(2),
      I2 => Q(0),
      I3 => \^cnt_reg[2]\,
      I4 => Q(1),
      O => done_i_8_n_0
    );
imTX_i_1: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BBBBBBFEAAAAAAAA"
    )
        port map (
      I0 => imTX_reg,
      I1 => \^txstates_reg[3]_0\,
      I2 => \^txstates_reg[3]_1\,
      I3 => \^txstates_reg[2]\,
      I4 => \^txstates_reg[1]_0\,
      I5 => SRST,
      O => imTX0_out
    );
req_Errorr_i_1: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000CFFE0000"
    )
        port map (
      I0 => Q(0),
      I1 => Q(2),
      I2 => Q(3),
      I3 => Q(1),
      I4 => SRST,
      I5 => req_Errorr_i_2_n_0,
      O => req_Errorr
    );
req_Errorr_i_2: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => req_Errorr_reg,
      I1 => \^txstates_reg[1]\,
      O => req_Errorr_i_2_n_0
    );
\serial[0]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => \serial[0]_i_2_n_0\,
      I1 => SRST,
      O => \serial[0]_i_1_n_0\
    );
\serial[0]_i_10\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8888888888088888"
    )
        port map (
      I0 => \^d_len_tx_1[3]\,
      I1 => Q(1),
      I2 => \serial[0]_i_25_n_0\,
      I3 => \serial[0]_i_12_0\(3),
      I4 => \serial[0]_i_12_0\(2),
      I5 => \serial[0]_i_12_0\(1),
      O => \^txstates_reg[1]_1\
    );
\serial[0]_i_11\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000FEAB02A8"
    )
        port map (
      I0 => \^id_tx_1[10]\,
      I1 => \serial[0]_i_12_0\(3),
      I2 => \serial[0]_i_27_n_0\,
      I3 => \serial[0]_i_12_0\(4),
      I4 => \^id_tx_1[28]_0\,
      I5 => \^cnt_reg[4]_0\,
      O => \^cnt_reg[3]\
    );
\serial[0]_i_12\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00450045000300CF"
    )
        port map (
      I0 => \^id_tx_1[8]\,
      I1 => \^cnt_reg[2]\,
      I2 => RTR_TX,
      I3 => \serial[0]_i_31_n_0\,
      I4 => \^id_tx_1[28]\,
      I5 => \^cnt_reg[4]\,
      O => \serial[0]_i_12_n_0\
    );
\serial[0]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BABBBABBBABBBABA"
    )
        port map (
      I0 => \serial[0]_i_3_n_0\,
      I1 => \serial[0]_i_4_n_0\,
      I2 => Q(3),
      I3 => \serial_reg[0]_0\,
      I4 => Q(2),
      I5 => \serial[0]_i_6_n_0\,
      O => \serial[0]_i_2_n_0\
    );
\serial[0]_i_24\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => D_Len_TX(3),
      I1 => D_Len_TX(2),
      I2 => \serial[0]_i_12_0\(1),
      I3 => D_Len_TX(1),
      I4 => \serial[0]_i_12_0\(0),
      I5 => D_Len_TX(0),
      O => \^d_len_tx_1[3]\
    );
\serial[0]_i_25\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \serial[0]_i_12_0\(4),
      I1 => \serial[0]_i_12_0\(5),
      O => \serial[0]_i_25_n_0\
    );
\serial[0]_i_26\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \serial[0]_i_55_n_0\,
      I1 => \serial[0]_i_56_n_0\,
      I2 => \serial[0]_i_57_n_0\,
      I3 => \serial[0]_i_58_n_0\,
      I4 => \serial[0]_i_59_n_0\,
      I5 => \serial[0]_i_60_n_0\,
      O => \^id_tx_1[10]\
    );
\serial[0]_i_27\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"EA"
    )
        port map (
      I0 => \serial[0]_i_12_0\(2),
      I1 => \serial[0]_i_12_0\(1),
      I2 => \serial[0]_i_12_0\(0),
      O => \serial[0]_i_27_n_0\
    );
\serial[0]_i_28\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \serial[0]_i_61_n_0\,
      I1 => ID_TX(28),
      I2 => \serial[0]_i_57_n_0\,
      I3 => \serial[0]_i_62_n_0\,
      I4 => \serial[0]_i_59_n_0\,
      I5 => \serial[0]_i_63_n_0\,
      O => \^id_tx_1[28]_0\
    );
\serial[0]_i_29\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000005555777F"
    )
        port map (
      I0 => \serial[0]_i_12_0\(4),
      I1 => \serial[0]_i_12_0\(2),
      I2 => \serial[0]_i_12_0\(1),
      I3 => \serial[0]_i_12_0\(0),
      I4 => \serial[0]_i_12_0\(3),
      I5 => \serial[0]_i_12_0\(5),
      O => \^cnt_reg[4]_0\
    );
\serial[0]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000001"
    )
        port map (
      I0 => serial(3),
      I1 => serial(0),
      I2 => serial(2),
      I3 => \serial_reg_n_0_[4]\,
      I4 => serial(1),
      O => \serial[0]_i_3_n_0\
    );
\serial[0]_i_30\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \serial[0]_i_64_n_0\,
      I1 => \serial[0]_i_65_n_0\,
      I2 => \Cnt[3]_i_6__0_n_0\,
      I3 => \serial[0]_i_66_n_0\,
      I4 => \Cnt[2]_i_5__0_n_0\,
      I5 => \serial[0]_i_67_n_0\,
      O => \^id_tx_1[8]\
    );
\serial[0]_i_31\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0004000000000400"
    )
        port map (
      I0 => \serial[0]_i_12_0\(3),
      I1 => \serial[0]_i_12_0\(4),
      I2 => \serial[0]_i_12_0\(5),
      I3 => \serial[0]_i_12_0\(2),
      I4 => \serial[0]_i_12_0\(1),
      I5 => \serial[0]_i_12_0\(0),
      O => \serial[0]_i_31_n_0\
    );
\serial[0]_i_32\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CFC0AFAFCFC0A0A0"
    )
        port map (
      I0 => ID_TX(28),
      I1 => \serial[0]_i_68_n_0\,
      I2 => \Cnt[3]_i_6__0_n_0\,
      I3 => \serial[0]_i_69_n_0\,
      I4 => \Cnt[2]_i_5__0_n_0\,
      I5 => \serial[0]_i_70_n_0\,
      O => \^id_tx_1[28]\
    );
\serial[0]_i_33\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"55555556"
    )
        port map (
      I0 => \serial[0]_i_12_0\(4),
      I1 => \serial[0]_i_12_0\(2),
      I2 => \serial[0]_i_12_0\(1),
      I3 => \serial[0]_i_12_0\(0),
      I4 => \serial[0]_i_12_0\(3),
      O => \^cnt_reg[4]\
    );
\serial[0]_i_4\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"80000000"
    )
        port map (
      I0 => serial(2),
      I1 => serial(1),
      I2 => serial(3),
      I3 => \serial_reg_n_0_[4]\,
      I4 => serial(0),
      O => \serial[0]_i_4_n_0\
    );
\serial[0]_i_55\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FCAF0CAFFCA00CA0"
    )
        port map (
      I0 => ID_TX(10),
      I1 => ID_TX(11),
      I2 => \serial[0]_i_12_0\(0),
      I3 => \serial[0]_i_12_0\(1),
      I4 => ID_TX(8),
      I5 => ID_TX(9),
      O => \serial[0]_i_55_n_0\
    );
\serial[0]_i_56\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FCAF0CAFFCA00CA0"
    )
        port map (
      I0 => ID_TX(14),
      I1 => ID_TX(15),
      I2 => \serial[0]_i_12_0\(0),
      I3 => \serial[0]_i_12_0\(1),
      I4 => ID_TX(12),
      I5 => ID_TX(13),
      O => \serial[0]_i_56_n_0\
    );
\serial[0]_i_57\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"AA95"
    )
        port map (
      I0 => \serial[0]_i_12_0\(3),
      I1 => \serial[0]_i_12_0\(0),
      I2 => \serial[0]_i_12_0\(1),
      I3 => \serial[0]_i_12_0\(2),
      O => \serial[0]_i_57_n_0\
    );
\serial[0]_i_58\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FCAF0CAFFCA00CA0"
    )
        port map (
      I0 => ID_TX(2),
      I1 => ID_TX(3),
      I2 => \serial[0]_i_12_0\(0),
      I3 => \serial[0]_i_12_0\(1),
      I4 => ID_TX(0),
      I5 => ID_TX(1),
      O => \serial[0]_i_58_n_0\
    );
\serial[0]_i_59\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"6A"
    )
        port map (
      I0 => \serial[0]_i_12_0\(2),
      I1 => \serial[0]_i_12_0\(1),
      I2 => \serial[0]_i_12_0\(0),
      O => \serial[0]_i_59_n_0\
    );
\serial[0]_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AACFAACFAACFAAFF"
    )
        port map (
      I0 => \^txstates_reg[1]_1\,
      I1 => \^cnt_reg[3]\,
      I2 => Q(1),
      I3 => Q(0),
      I4 => \serial[0]_i_12_n_0\,
      I5 => \serial[0]_i_2_0\,
      O => \serial[0]_i_6_n_0\
    );
\serial[0]_i_60\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FCAF0CAFFCA00CA0"
    )
        port map (
      I0 => ID_TX(6),
      I1 => ID_TX(7),
      I2 => \serial[0]_i_12_0\(0),
      I3 => \serial[0]_i_12_0\(1),
      I4 => ID_TX(4),
      I5 => ID_TX(5),
      O => \serial[0]_i_60_n_0\
    );
\serial[0]_i_61\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FCAF0CAFFCA00CA0"
    )
        port map (
      I0 => ID_TX(26),
      I1 => ID_TX(27),
      I2 => \serial[0]_i_12_0\(0),
      I3 => \serial[0]_i_12_0\(1),
      I4 => ID_TX(24),
      I5 => ID_TX(25),
      O => \serial[0]_i_61_n_0\
    );
\serial[0]_i_62\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FCAF0CAFFCA00CA0"
    )
        port map (
      I0 => ID_TX(18),
      I1 => ID_TX(19),
      I2 => \serial[0]_i_12_0\(0),
      I3 => \serial[0]_i_12_0\(1),
      I4 => ID_TX(16),
      I5 => ID_TX(17),
      O => \serial[0]_i_62_n_0\
    );
\serial[0]_i_63\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FCAF0CAFFCA00CA0"
    )
        port map (
      I0 => ID_TX(22),
      I1 => ID_TX(23),
      I2 => \serial[0]_i_12_0\(0),
      I3 => \serial[0]_i_12_0\(1),
      I4 => ID_TX(20),
      I5 => ID_TX(21),
      O => \serial[0]_i_63_n_0\
    );
\serial[0]_i_64\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FCAF0CAFFCA00CA0"
    )
        port map (
      I0 => ID_TX(8),
      I1 => ID_TX(9),
      I2 => \serial[0]_i_12_0\(0),
      I3 => \serial[0]_i_12_0\(1),
      I4 => ID_TX(10),
      I5 => ID_TX(11),
      O => \serial[0]_i_64_n_0\
    );
\serial[0]_i_65\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FCAF0CAFFCA00CA0"
    )
        port map (
      I0 => ID_TX(12),
      I1 => ID_TX(13),
      I2 => \serial[0]_i_12_0\(0),
      I3 => \serial[0]_i_12_0\(1),
      I4 => ID_TX(14),
      I5 => ID_TX(15),
      O => \serial[0]_i_65_n_0\
    );
\serial[0]_i_66\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FCAF0CAFFCA00CA0"
    )
        port map (
      I0 => ID_TX(0),
      I1 => ID_TX(1),
      I2 => \serial[0]_i_12_0\(0),
      I3 => \serial[0]_i_12_0\(1),
      I4 => ID_TX(2),
      I5 => ID_TX(3),
      O => \serial[0]_i_66_n_0\
    );
\serial[0]_i_67\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FCAF0CAFFCA00CA0"
    )
        port map (
      I0 => ID_TX(4),
      I1 => ID_TX(5),
      I2 => \serial[0]_i_12_0\(0),
      I3 => \serial[0]_i_12_0\(1),
      I4 => ID_TX(6),
      I5 => ID_TX(7),
      O => \serial[0]_i_67_n_0\
    );
\serial[0]_i_68\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FCAF0CAFFCA00CA0"
    )
        port map (
      I0 => ID_TX(24),
      I1 => ID_TX(25),
      I2 => \serial[0]_i_12_0\(0),
      I3 => \serial[0]_i_12_0\(1),
      I4 => ID_TX(26),
      I5 => ID_TX(27),
      O => \serial[0]_i_68_n_0\
    );
\serial[0]_i_69\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FCAF0CAFFCA00CA0"
    )
        port map (
      I0 => ID_TX(16),
      I1 => ID_TX(17),
      I2 => \serial[0]_i_12_0\(0),
      I3 => \serial[0]_i_12_0\(1),
      I4 => ID_TX(18),
      I5 => ID_TX(19),
      O => \serial[0]_i_69_n_0\
    );
\serial[0]_i_70\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FCAF0CAFFCA00CA0"
    )
        port map (
      I0 => ID_TX(20),
      I1 => ID_TX(21),
      I2 => \serial[0]_i_12_0\(0),
      I3 => \serial[0]_i_12_0\(1),
      I4 => ID_TX(22),
      I5 => ID_TX(23),
      O => \serial[0]_i_70_n_0\
    );
\serial[1]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => SRST,
      I1 => serial(0),
      O => \serial[1]_i_1_n_0\
    );
\serial[2]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => SRST,
      I1 => serial(1),
      O => \serial[2]_i_1_n_0\
    );
\serial[3]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => SRST,
      I1 => serial(2),
      O => \serial[3]_i_1_n_0\
    );
\serial[4]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000AA8FFFFFFFF"
    )
        port map (
      I0 => \Cnt_reg[5]_1\,
      I1 => Q(0),
      I2 => Q(2),
      I3 => Q(1),
      I4 => Q(3),
      I5 => SRST,
      O => \serial[4]_i_1_n_0\
    );
\serial[4]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => SRST,
      I1 => serial(3),
      O => \serial[4]_i_2_n_0\
    );
\serial_reg[0]\: unisim.vcomponents.FDPE
     port map (
      C => Tq,
      CE => \serial[4]_i_1_n_0\,
      D => \serial[0]_i_1_n_0\,
      PRE => \serial_reg[0]_1\,
      Q => serial(0)
    );
\serial_reg[1]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \serial[4]_i_1_n_0\,
      CLR => \serial_reg[0]_1\,
      D => \serial[1]_i_1_n_0\,
      Q => serial(1)
    );
\serial_reg[2]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \serial[4]_i_1_n_0\,
      CLR => \serial_reg[0]_1\,
      D => \serial[2]_i_1_n_0\,
      Q => serial(2)
    );
\serial_reg[3]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \serial[4]_i_1_n_0\,
      CLR => \serial_reg[0]_1\,
      D => \serial[3]_i_1_n_0\,
      Q => serial(3)
    );
\serial_reg[4]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \serial[4]_i_1_n_0\,
      CLR => \serial_reg[0]_1\,
      D => \serial[4]_i_2_n_0\,
      Q => \serial_reg_n_0_[4]\
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1_FPGAPROJECT_0_0_dff is
  port (
    q_reg_0 : out STD_LOGIC;
    RX : in STD_LOGIC;
    clk : in STD_LOGIC;
    q_reg_1 : in STD_LOGIC
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of design_1_FPGAPROJECT_0_0_dff : entity is "dff";
end design_1_FPGAPROJECT_0_0_dff;

architecture STRUCTURE of design_1_FPGAPROJECT_0_0_dff is
begin
q_reg: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => '1',
      CLR => q_reg_1,
      D => RX,
      Q => q_reg_0
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1_FPGAPROJECT_0_0_dff_1 is
  port (
    q : out STD_LOGIC;
    q_reg_0 : in STD_LOGIC;
    clk : in STD_LOGIC;
    q_reg_1 : in STD_LOGIC
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of design_1_FPGAPROJECT_0_0_dff_1 : entity is "dff";
end design_1_FPGAPROJECT_0_0_dff_1;

architecture STRUCTURE of design_1_FPGAPROJECT_0_0_dff_1 is
begin
q_reg: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => '1',
      CLR => q_reg_1,
      D => q_reg_0,
      Q => q
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1_FPGAPROJECT_0_0_dff_11 is
  port (
    q_reg_0 : out STD_LOGIC;
    RX : in STD_LOGIC;
    Tq : in STD_LOGIC;
    q_reg_1 : in STD_LOGIC
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of design_1_FPGAPROJECT_0_0_dff_11 : entity is "dff";
end design_1_FPGAPROJECT_0_0_dff_11;

architecture STRUCTURE of design_1_FPGAPROJECT_0_0_dff_11 is
begin
q_reg: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => '1',
      CLR => q_reg_1,
      D => RX,
      Q => q_reg_0
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1_FPGAPROJECT_0_0_dff_12 is
  port (
    RXBUSs : out STD_LOGIC;
    q_reg_0 : in STD_LOGIC;
    Tq : in STD_LOGIC;
    q_reg_1 : in STD_LOGIC
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of design_1_FPGAPROJECT_0_0_dff_12 : entity is "dff";
end design_1_FPGAPROJECT_0_0_dff_12;

architecture STRUCTURE of design_1_FPGAPROJECT_0_0_dff_12 is
begin
q_reg: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => '1',
      CLR => q_reg_1,
      D => q_reg_0,
      Q => RXBUSs
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1_FPGAPROJECT_0_0_RXMachine is
  port (
    AckTakeOver : out STD_LOGIC;
    CAN_RST_0 : out STD_LOGIC;
    RTR_rec_0 : out STD_LOGIC;
    req_Error_RX : out STD_LOGIC;
    IDE_rec_0 : out STD_LOGIC;
    done_reg_0 : out STD_LOGIC;
    RXOUT_reg : out STD_LOGIC;
    \RXSTATES_reg[2]_0\ : out STD_LOGIC;
    req_Error_reg_0 : out STD_LOGIC;
    Q : out STD_LOGIC_VECTOR ( 3 downto 0 );
    \RXSTATES_reg[2]_1\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    \RXSTATES_reg[1]_0\ : out STD_LOGIC;
    \RXSTATES_reg[3]_0\ : out STD_LOGIC;
    TOFILTERd_0 : out STD_LOGIC_VECTOR ( 63 downto 0 );
    \bs_reg[1]_0\ : out STD_LOGIC;
    TOFILTERI_0 : out STD_LOGIC_VECTOR ( 28 downto 0 );
    donefromrxr : out STD_LOGIC;
    E : in STD_LOGIC_VECTOR ( 0 to 0 );
    clk : in STD_LOGIC;
    SRST_0 : in STD_LOGIC;
    \TOFILTERd_reg[0]_0\ : in STD_LOGIC;
    \CRC_RG_reg[14]\ : in STD_LOGIC;
    Sampled_din : in STD_LOGIC;
    \bs_reg[0]_0\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \RXSTATES_reg[0]_0\ : in STD_LOGIC;
    TXpin_i_2 : in STD_LOGIC;
    TXpin_i_2_0 : in STD_LOGIC;
    \RXSTATES_reg[0]_1\ : in STD_LOGIC;
    \CNT2_reg[3]\ : in STD_LOGIC;
    \CNT2_reg[3]_0\ : in STD_LOGIC;
    \RXSTATES_reg[3]_1\ : in STD_LOGIC;
    imTX : in STD_LOGIC;
    CAN_RST : in STD_LOGIC;
    \RXSTATES_reg[3]_2\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    D : in STD_LOGIC_VECTOR ( 0 to 0 );
    \Cnt_reg[0]_0\ : in STD_LOGIC_VECTOR ( 0 to 0 )
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of design_1_FPGAPROJECT_0_0_RXMachine : entity is "RXMachine";
end design_1_FPGAPROJECT_0_0_RXMachine;

architecture STRUCTURE of design_1_FPGAPROJECT_0_0_RXMachine is
  signal AckTakeOver_i_1_n_0 : STD_LOGIC;
  signal AckTakeOver_i_2_n_0 : STD_LOGIC;
  signal \^can_rst_0\ : STD_LOGIC;
  signal \Cnt[0]_i_1__0_n_0\ : STD_LOGIC;
  signal \Cnt[0]_i_2__0_n_0\ : STD_LOGIC;
  signal \Cnt[0]_i_3__0_n_0\ : STD_LOGIC;
  signal \Cnt[0]_i_4__0_n_0\ : STD_LOGIC;
  signal \Cnt[0]_i_5_n_0\ : STD_LOGIC;
  signal \Cnt[1]_i_1_n_0\ : STD_LOGIC;
  signal \Cnt[1]_i_2__0_n_0\ : STD_LOGIC;
  signal \Cnt[1]_i_3_n_0\ : STD_LOGIC;
  signal \Cnt[1]_i_4__0_n_0\ : STD_LOGIC;
  signal \Cnt[1]_i_5_n_0\ : STD_LOGIC;
  signal \Cnt[1]_i_6_n_0\ : STD_LOGIC;
  signal \Cnt[2]_i_1_n_0\ : STD_LOGIC;
  signal \Cnt[2]_i_2__0_n_0\ : STD_LOGIC;
  signal \Cnt[2]_i_3__0_n_0\ : STD_LOGIC;
  signal \Cnt[2]_i_4_n_0\ : STD_LOGIC;
  signal \Cnt[2]_i_5_n_0\ : STD_LOGIC;
  signal \Cnt[2]_i_6_n_0\ : STD_LOGIC;
  signal \Cnt[3]_i_1_n_0\ : STD_LOGIC;
  signal \Cnt[3]_i_2_n_0\ : STD_LOGIC;
  signal \Cnt[3]_i_3_n_0\ : STD_LOGIC;
  signal \Cnt[3]_i_4__0_n_0\ : STD_LOGIC;
  signal \Cnt[4]_i_1_n_0\ : STD_LOGIC;
  signal \Cnt[4]_i_2_n_0\ : STD_LOGIC;
  signal \Cnt[4]_i_3_n_0\ : STD_LOGIC;
  signal \Cnt[4]_i_4__0_n_0\ : STD_LOGIC;
  signal \Cnt[4]_i_5_n_0\ : STD_LOGIC;
  signal \Cnt[4]_i_6_n_0\ : STD_LOGIC;
  signal \Cnt[4]_i_7_n_0\ : STD_LOGIC;
  signal \Cnt[5]_i_2_n_0\ : STD_LOGIC;
  signal \Cnt[5]_i_3_n_0\ : STD_LOGIC;
  signal \Cnt[5]_i_4__0_n_0\ : STD_LOGIC;
  signal \Cnt[5]_i_5__0_n_0\ : STD_LOGIC;
  signal \Cnt[5]_i_6__0_n_0\ : STD_LOGIC;
  signal \Cnt[5]_i_7_n_0\ : STD_LOGIC;
  signal \Cnt_reg_n_0_[0]\ : STD_LOGIC;
  signal \Cnt_reg_n_0_[1]\ : STD_LOGIC;
  signal \Cnt_reg_n_0_[2]\ : STD_LOGIC;
  signal \Cnt_reg_n_0_[3]\ : STD_LOGIC;
  signal \Cnt_reg_n_0_[4]\ : STD_LOGIC;
  signal \Cnt_reg_n_0_[5]\ : STD_LOGIC;
  signal \D_Len[0]_i_1_n_0\ : STD_LOGIC;
  signal \D_Len[1]_i_1_n_0\ : STD_LOGIC;
  signal \D_Len[2]_i_1_n_0\ : STD_LOGIC;
  signal \D_Len[3]_i_1_n_0\ : STD_LOGIC;
  signal \D_Len[3]_i_2_n_0\ : STD_LOGIC;
  signal \D_Len[3]_i_3_n_0\ : STD_LOGIC;
  signal I56 : STD_LOGIC_VECTOR ( 5 downto 0 );
  signal I59 : STD_LOGIC;
  signal IDE1_out : STD_LOGIC;
  signal IDE_i_1_n_0 : STD_LOGIC;
  signal IDE_i_2_n_0 : STD_LOGIC;
  signal IDE_i_3_n_0 : STD_LOGIC;
  signal IDE_i_4_n_0 : STD_LOGIC;
  signal IDE_i_5_n_0 : STD_LOGIC;
  signal \^ide_rec_0\ : STD_LOGIC;
  signal \^q\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal RTR_i_1_n_0 : STD_LOGIC;
  signal RTR_i_4_n_0 : STD_LOGIC;
  signal \^rtr_rec_0\ : STD_LOGIC;
  signal \^rxout_reg\ : STD_LOGIC;
  signal RXSTATES : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \RXSTATES[0]_i_10_n_0\ : STD_LOGIC;
  signal \RXSTATES[0]_i_1_n_0\ : STD_LOGIC;
  signal \RXSTATES[0]_i_3_n_0\ : STD_LOGIC;
  signal \RXSTATES[0]_i_4_n_0\ : STD_LOGIC;
  signal \RXSTATES[0]_i_6_n_0\ : STD_LOGIC;
  signal \RXSTATES[0]_i_7_n_0\ : STD_LOGIC;
  signal \RXSTATES[0]_i_8_n_0\ : STD_LOGIC;
  signal \RXSTATES[0]_i_9_n_0\ : STD_LOGIC;
  signal \RXSTATES[2]_i_1_n_0\ : STD_LOGIC;
  signal \RXSTATES[2]_i_2_n_0\ : STD_LOGIC;
  signal \RXSTATES[2]_i_3_n_0\ : STD_LOGIC;
  signal \RXSTATES[2]_i_4_n_0\ : STD_LOGIC;
  signal \RXSTATES[3]_i_2_n_0\ : STD_LOGIC;
  signal \^rxstates_reg[2]_0\ : STD_LOGIC;
  signal \TOFILTERI[10]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERI[11]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERI[12]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERI[13]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERI[14]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERI[15]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERI[16]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERI[17]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERI[18]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERI[19]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERI[1]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERI[20]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERI[21]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERI[22]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERI[23]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERI[24]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERI[25]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERI[26]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERI[27]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERI[28]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERI[28]_i_2_n_0\ : STD_LOGIC;
  signal \TOFILTERI[28]_i_3_n_0\ : STD_LOGIC;
  signal \TOFILTERI[28]_i_4_n_0\ : STD_LOGIC;
  signal \TOFILTERI[2]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERI[3]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERI[4]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERI[5]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERI[6]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERI[7]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERI[8]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERI[9]_i_1_n_0\ : STD_LOGIC;
  signal \^tofilteri_0\ : STD_LOGIC_VECTOR ( 28 downto 0 );
  signal \TOFILTERd[0]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[10]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[11]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[12]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[13]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[14]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[15]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[16]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[17]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[18]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[19]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[1]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[20]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[21]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[22]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[23]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[24]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[25]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[26]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[27]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[28]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[29]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[2]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[30]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[31]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[32]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[33]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[34]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[35]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[36]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[37]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[38]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[39]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[3]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[40]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[41]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[42]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[43]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[44]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[45]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[46]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[47]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[48]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[49]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[4]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[50]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[51]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[52]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[53]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[54]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[55]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[56]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[57]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[58]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[59]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[5]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[60]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[61]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[62]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[63]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[63]_i_2_n_0\ : STD_LOGIC;
  signal \TOFILTERd[6]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[7]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[8]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[9]_i_1_n_0\ : STD_LOGIC;
  signal \^tofilterd_0\ : STD_LOGIC_VECTOR ( 63 downto 0 );
  signal bs : STD_LOGIC_VECTOR ( 5 downto 0 );
  signal \done_i_1__0_n_0\ : STD_LOGIC;
  signal \done_i_3__0_n_0\ : STD_LOGIC;
  signal \^done_reg_0\ : STD_LOGIC;
  signal \^req_error_rx\ : STD_LOGIC;
  signal req_Error_i_2_n_0 : STD_LOGIC;
  signal req_Error_i_4_n_0 : STD_LOGIC;
  signal req_Error_i_5_n_0 : STD_LOGIC;
  signal req_Error_i_6_n_0 : STD_LOGIC;
  signal req_Error_i_8_n_0 : STD_LOGIC;
  signal rxcrc_n_0 : STD_LOGIC;
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of AckTakeOver_i_2 : label is "soft_lutpair192";
  attribute SOFT_HLUTNM of \Cnt[0]_i_3__0\ : label is "soft_lutpair190";
  attribute SOFT_HLUTNM of \Cnt[1]_i_2__0\ : label is "soft_lutpair187";
  attribute SOFT_HLUTNM of \Cnt[1]_i_5\ : label is "soft_lutpair189";
  attribute SOFT_HLUTNM of \Cnt[1]_i_6\ : label is "soft_lutpair191";
  attribute SOFT_HLUTNM of \Cnt[2]_i_3__0\ : label is "soft_lutpair187";
  attribute SOFT_HLUTNM of \Cnt[2]_i_4\ : label is "soft_lutpair175";
  attribute SOFT_HLUTNM of \Cnt[2]_i_5\ : label is "soft_lutpair180";
  attribute SOFT_HLUTNM of \Cnt[4]_i_2\ : label is "soft_lutpair189";
  attribute SOFT_HLUTNM of \Cnt[4]_i_4__0\ : label is "soft_lutpair175";
  attribute SOFT_HLUTNM of \Cnt[4]_i_5\ : label is "soft_lutpair186";
  attribute SOFT_HLUTNM of \Cnt[4]_i_6\ : label is "soft_lutpair177";
  attribute SOFT_HLUTNM of \Cnt[5]_i_5__0\ : label is "soft_lutpair182";
  attribute SOFT_HLUTNM of \Cnt[5]_i_6__0\ : label is "soft_lutpair177";
  attribute SOFT_HLUTNM of \Cnt[5]_i_7\ : label is "soft_lutpair183";
  attribute SOFT_HLUTNM of IDE_i_2 : label is "soft_lutpair188";
  attribute SOFT_HLUTNM of IDE_i_3 : label is "soft_lutpair191";
  attribute SOFT_HLUTNM of IDE_i_5 : label is "soft_lutpair184";
  attribute SOFT_HLUTNM of \RXSTATES[0]_i_6\ : label is "soft_lutpair190";
  attribute SOFT_HLUTNM of \RXSTATES[0]_i_7\ : label is "soft_lutpair186";
  attribute SOFT_HLUTNM of \RXSTATES[2]_i_4\ : label is "soft_lutpair188";
  attribute SOFT_HLUTNM of \State[2]_i_10\ : label is "soft_lutpair176";
  attribute SOFT_HLUTNM of \TOFILTERI[28]_i_4\ : label is "soft_lutpair192";
  attribute SOFT_HLUTNM of \bs[0]_i_1\ : label is "soft_lutpair179";
  attribute SOFT_HLUTNM of \bs[2]_i_1\ : label is "soft_lutpair180";
  attribute SOFT_HLUTNM of \bs[3]_i_1\ : label is "soft_lutpair181";
  attribute SOFT_HLUTNM of \bs[4]_i_1\ : label is "soft_lutpair182";
  attribute SOFT_HLUTNM of \bs[5]_i_1\ : label is "soft_lutpair183";
  attribute SOFT_HLUTNM of done_i_14 : label is "soft_lutpair179";
  attribute SOFT_HLUTNM of \done_i_1__0\ : label is "soft_lutpair178";
  attribute SOFT_HLUTNM of \done_i_4__0\ : label is "soft_lutpair181";
  attribute SOFT_HLUTNM of donefromrxr_i_1 : label is "soft_lutpair178";
  attribute SOFT_HLUTNM of req_Error_i_4 : label is "soft_lutpair184";
  attribute SOFT_HLUTNM of req_Error_i_5 : label is "soft_lutpair185";
  attribute SOFT_HLUTNM of req_Error_i_6 : label is "soft_lutpair185";
  attribute SOFT_HLUTNM of req_Error_i_8 : label is "soft_lutpair176";
begin
  CAN_RST_0 <= \^can_rst_0\;
  IDE_rec_0 <= \^ide_rec_0\;
  Q(3 downto 0) <= \^q\(3 downto 0);
  RTR_rec_0 <= \^rtr_rec_0\;
  RXOUT_reg <= \^rxout_reg\;
  \RXSTATES_reg[2]_0\ <= \^rxstates_reg[2]_0\;
  TOFILTERI_0(28 downto 0) <= \^tofilteri_0\(28 downto 0);
  TOFILTERd_0(63 downto 0) <= \^tofilterd_0\(63 downto 0);
  done_reg_0 <= \^done_reg_0\;
  req_Error_RX <= \^req_error_rx\;
AckTakeOver_i_1: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFDFFF"
    )
        port map (
      I0 => RXSTATES(2),
      I1 => RXSTATES(3),
      I2 => AckTakeOver_i_2_n_0,
      I3 => SRST_0,
      I4 => imTX,
      I5 => \^req_error_rx\,
      O => AckTakeOver_i_1_n_0
    );
AckTakeOver_i_2: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => RXSTATES(0),
      I1 => RXSTATES(1),
      O => AckTakeOver_i_2_n_0
    );
AckTakeOver_reg: unisim.vcomponents.FDPE
     port map (
      C => clk,
      CE => E(0),
      D => AckTakeOver_i_1_n_0,
      PRE => \^can_rst_0\,
      Q => AckTakeOver
    );
\CNT2[3]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAAAAAAAAAAAAB"
    )
        port map (
      I0 => \CNT2_reg[3]\,
      I1 => \CNT2_reg[3]_0\,
      I2 => RXSTATES(2),
      I3 => RXSTATES(3),
      I4 => RXSTATES(1),
      I5 => RXSTATES(0),
      O => \RXSTATES_reg[2]_1\(0)
    );
\Cnt[0]_i_1__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"88888A88AAAAAAAA"
    )
        port map (
      I0 => SRST_0,
      I1 => \Cnt[0]_i_2__0_n_0\,
      I2 => \Cnt[0]_i_3__0_n_0\,
      I3 => \Cnt[5]_i_6__0_n_0\,
      I4 => \Cnt_reg_n_0_[0]\,
      I5 => \Cnt[0]_i_4__0_n_0\,
      O => \Cnt[0]_i_1__0_n_0\
    );
\Cnt[0]_i_2__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000C0008000800"
    )
        port map (
      I0 => \RXSTATES_reg[0]_1\,
      I1 => RXSTATES(3),
      I2 => RXSTATES(1),
      I3 => RXSTATES(2),
      I4 => \RXSTATES_reg[0]_0\,
      I5 => RXSTATES(0),
      O => \Cnt[0]_i_2__0_n_0\
    );
\Cnt[0]_i_3__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \RXSTATES[2]_i_3_n_0\,
      I1 => RXSTATES(0),
      O => \Cnt[0]_i_3__0_n_0\
    );
\Cnt[0]_i_4__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFBABABAAA"
    )
        port map (
      I0 => \Cnt[0]_i_5_n_0\,
      I1 => RXSTATES(1),
      I2 => RXSTATES(2),
      I3 => \RXSTATES[2]_i_3_n_0\,
      I4 => \Cnt_reg_n_0_[0]\,
      I5 => RXSTATES(3),
      O => \Cnt[0]_i_4__0_n_0\
    );
\Cnt[0]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FF2E0000FFAA00FF"
    )
        port map (
      I0 => \Cnt_reg_n_0_[0]\,
      I1 => \RXSTATES[2]_i_3_n_0\,
      I2 => \RXSTATES[0]_i_9_n_0\,
      I3 => RXSTATES(2),
      I4 => RXSTATES(1),
      I5 => RXSTATES(0),
      O => \Cnt[0]_i_5_n_0\
    );
\Cnt[1]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000AA08AAAAAAAA"
    )
        port map (
      I0 => SRST_0,
      I1 => \Cnt[4]_i_4__0_n_0\,
      I2 => \Cnt[1]_i_2__0_n_0\,
      I3 => \Cnt[4]_i_2_n_0\,
      I4 => \Cnt[1]_i_3_n_0\,
      I5 => \Cnt[1]_i_4__0_n_0\,
      O => \Cnt[1]_i_1_n_0\
    );
\Cnt[1]_i_2__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6F66"
    )
        port map (
      I0 => \Cnt_reg_n_0_[0]\,
      I1 => \Cnt_reg_n_0_[1]\,
      I2 => RXSTATES(0),
      I3 => \RXSTATES[2]_i_3_n_0\,
      O => \Cnt[1]_i_2__0_n_0\
    );
\Cnt[1]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BBBBAFFAAAAAAAAA"
    )
        port map (
      I0 => RXSTATES(3),
      I1 => \Cnt[1]_i_5_n_0\,
      I2 => \Cnt_reg_n_0_[1]\,
      I3 => \Cnt_reg_n_0_[0]\,
      I4 => \RXSTATES[2]_i_3_n_0\,
      I5 => \Cnt[1]_i_6_n_0\,
      O => \Cnt[1]_i_3_n_0\
    );
\Cnt[1]_i_4__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFDFFDDFFD5555"
    )
        port map (
      I0 => \RXSTATES[0]_i_7_n_0\,
      I1 => \RXSTATES[2]_i_3_n_0\,
      I2 => \Cnt_reg_n_0_[0]\,
      I3 => \Cnt_reg_n_0_[1]\,
      I4 => RXSTATES(0),
      I5 => RXSTATES(1),
      O => \Cnt[1]_i_4__0_n_0\
    );
\Cnt[1]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8A"
    )
        port map (
      I0 => RXSTATES(2),
      I1 => RXSTATES(1),
      I2 => RXSTATES(0),
      O => \Cnt[1]_i_5_n_0\
    );
\Cnt[1]_i_6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => RXSTATES(2),
      I1 => RXSTATES(1),
      O => \Cnt[1]_i_6_n_0\
    );
\Cnt[2]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"A8AAAAAA88888888"
    )
        port map (
      I0 => SRST_0,
      I1 => \Cnt[2]_i_2__0_n_0\,
      I2 => \Cnt[2]_i_3__0_n_0\,
      I3 => RXSTATES(1),
      I4 => \Cnt[2]_i_4_n_0\,
      I5 => \Cnt[2]_i_5_n_0\,
      O => \Cnt[2]_i_1_n_0\
    );
\Cnt[2]_i_2__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"1515010122220200"
    )
        port map (
      I0 => RXSTATES(2),
      I1 => RXSTATES(1),
      I2 => RXSTATES(0),
      I3 => \RXSTATES[2]_i_3_n_0\,
      I4 => \Cnt[2]_i_6_n_0\,
      I5 => RXSTATES(3),
      O => \Cnt[2]_i_2__0_n_0\
    );
\Cnt[2]_i_3__0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"A9"
    )
        port map (
      I0 => \Cnt_reg_n_0_[2]\,
      I1 => \Cnt_reg_n_0_[0]\,
      I2 => \Cnt_reg_n_0_[1]\,
      O => \Cnt[2]_i_3__0_n_0\
    );
\Cnt[2]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"DF"
    )
        port map (
      I0 => \TOFILTERd_reg[0]_0\,
      I1 => RXSTATES(0),
      I2 => \RXSTATES[0]_i_10_n_0\,
      O => \Cnt[2]_i_4_n_0\
    );
\Cnt[2]_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"1110"
    )
        port map (
      I0 => RXSTATES(2),
      I1 => RXSTATES(3),
      I2 => RXSTATES(1),
      I3 => RXSTATES(0),
      O => \Cnt[2]_i_5_n_0\
    );
\Cnt[2]_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFF0000FFFF0000E"
    )
        port map (
      I0 => \Cnt_reg_n_0_[5]\,
      I1 => \Cnt_reg_n_0_[3]\,
      I2 => \Cnt_reg_n_0_[0]\,
      I3 => \Cnt_reg_n_0_[1]\,
      I4 => \Cnt_reg_n_0_[2]\,
      I5 => \Cnt_reg_n_0_[4]\,
      O => \Cnt[2]_i_6_n_0\
    );
\Cnt[3]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00AA88AA000088A8"
    )
        port map (
      I0 => SRST_0,
      I1 => \Cnt[3]_i_2_n_0\,
      I2 => \Cnt[4]_i_4__0_n_0\,
      I3 => \Cnt[3]_i_3_n_0\,
      I4 => \Cnt[3]_i_4__0_n_0\,
      I5 => \Cnt[5]_i_6__0_n_0\,
      O => \Cnt[3]_i_1_n_0\
    );
\Cnt[3]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"08FC00FC08FC08FC"
    )
        port map (
      I0 => \RXSTATES[2]_i_3_n_0\,
      I1 => RXSTATES(0),
      I2 => RXSTATES(2),
      I3 => RXSTATES(1),
      I4 => \TOFILTERd_reg[0]_0\,
      I5 => \RXSTATES[0]_i_9_n_0\,
      O => \Cnt[3]_i_2_n_0\
    );
\Cnt[3]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000FFFFFFFF1"
    )
        port map (
      I0 => \Cnt_reg_n_0_[5]\,
      I1 => \Cnt_reg_n_0_[4]\,
      I2 => \Cnt_reg_n_0_[0]\,
      I3 => \Cnt_reg_n_0_[1]\,
      I4 => \Cnt_reg_n_0_[2]\,
      I5 => \Cnt_reg_n_0_[3]\,
      O => \Cnt[3]_i_3_n_0\
    );
\Cnt[3]_i_4__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AEAAAEAEAAAAAAAA"
    )
        port map (
      I0 => RXSTATES(3),
      I1 => RXSTATES(2),
      I2 => RXSTATES(1),
      I3 => RXSTATES(0),
      I4 => \RXSTATES[2]_i_3_n_0\,
      I5 => \Cnt[3]_i_3_n_0\,
      O => \Cnt[3]_i_4__0_n_0\
    );
\Cnt[4]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000A888AAAAAAAA"
    )
        port map (
      I0 => SRST_0,
      I1 => \Cnt[4]_i_2_n_0\,
      I2 => \Cnt[4]_i_3_n_0\,
      I3 => \Cnt[4]_i_4__0_n_0\,
      I4 => \Cnt[4]_i_5_n_0\,
      I5 => \Cnt[4]_i_6_n_0\,
      O => \Cnt[4]_i_1_n_0\
    );
\Cnt[4]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"32"
    )
        port map (
      I0 => RXSTATES(0),
      I1 => RXSTATES(1),
      I2 => RXSTATES(2),
      O => \Cnt[4]_i_2_n_0\
    );
\Cnt[4]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BEAAAAAAAAAAAAAA"
    )
        port map (
      I0 => \Cnt[4]_i_7_n_0\,
      I1 => \^q\(0),
      I2 => \TOFILTERd_reg[0]_0\,
      I3 => \RXSTATES[0]_i_9_n_0\,
      I4 => \RXSTATES[2]_i_3_n_0\,
      I5 => RXSTATES(0),
      O => \Cnt[4]_i_3_n_0\
    );
\Cnt[4]_i_4__0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00DF0000"
    )
        port map (
      I0 => \RXSTATES[0]_i_10_n_0\,
      I1 => RXSTATES(0),
      I2 => \TOFILTERd_reg[0]_0\,
      I3 => RXSTATES(2),
      I4 => RXSTATES(1),
      O => \Cnt[4]_i_4__0_n_0\
    );
\Cnt[4]_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"AABA"
    )
        port map (
      I0 => RXSTATES(3),
      I1 => \Cnt[4]_i_7_n_0\,
      I2 => RXSTATES(2),
      I3 => RXSTATES(1),
      O => \Cnt[4]_i_5_n_0\
    );
\Cnt[4]_i_6\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"F9FFFFFF"
    )
        port map (
      I0 => RXSTATES(0),
      I1 => RXSTATES(1),
      I2 => RXSTATES(2),
      I3 => RXSTATES(3),
      I4 => \Cnt[4]_i_7_n_0\,
      O => \Cnt[4]_i_6_n_0\
    );
\Cnt[4]_i_7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFC00000002"
    )
        port map (
      I0 => \Cnt_reg_n_0_[5]\,
      I1 => \Cnt_reg_n_0_[3]\,
      I2 => \Cnt_reg_n_0_[0]\,
      I3 => \Cnt_reg_n_0_[1]\,
      I4 => \Cnt_reg_n_0_[2]\,
      I5 => \Cnt_reg_n_0_[4]\,
      O => \Cnt[4]_i_7_n_0\
    );
\Cnt[5]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"A0A8A0A8A0A800A8"
    )
        port map (
      I0 => SRST_0,
      I1 => \Cnt[5]_i_3_n_0\,
      I2 => \Cnt[5]_i_4__0_n_0\,
      I3 => \Cnt[5]_i_5__0_n_0\,
      I4 => \Cnt[5]_i_6__0_n_0\,
      I5 => \Cnt[5]_i_7_n_0\,
      O => \Cnt[5]_i_2_n_0\
    );
\Cnt[5]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8000808000800000"
    )
        port map (
      I0 => RXSTATES(0),
      I1 => \RXSTATES[2]_i_3_n_0\,
      I2 => \RXSTATES[0]_i_9_n_0\,
      I3 => \^q\(0),
      I4 => \TOFILTERd_reg[0]_0\,
      I5 => \^q\(1),
      O => \Cnt[5]_i_3_n_0\
    );
\Cnt[5]_i_4__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAAAAAAAAAAAA8"
    )
        port map (
      I0 => \Cnt_reg_n_0_[5]\,
      I1 => \Cnt_reg_n_0_[4]\,
      I2 => \Cnt_reg_n_0_[2]\,
      I3 => \Cnt_reg_n_0_[1]\,
      I4 => \Cnt_reg_n_0_[0]\,
      I5 => \Cnt_reg_n_0_[3]\,
      O => \Cnt[5]_i_4__0_n_0\
    );
\Cnt[5]_i_5__0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"EF"
    )
        port map (
      I0 => RXSTATES(3),
      I1 => RXSTATES(2),
      I2 => RXSTATES(1),
      O => \Cnt[5]_i_5__0_n_0\
    );
\Cnt[5]_i_6__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0220"
    )
        port map (
      I0 => RXSTATES(3),
      I1 => RXSTATES(2),
      I2 => RXSTATES(1),
      I3 => RXSTATES(0),
      O => \Cnt[5]_i_6__0_n_0\
    );
\Cnt[5]_i_7\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"04"
    )
        port map (
      I0 => RXSTATES(1),
      I1 => RXSTATES(2),
      I2 => RXSTATES(3),
      O => \Cnt[5]_i_7_n_0\
    );
\Cnt_reg[0]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \Cnt_reg[0]_0\(0),
      CLR => \^can_rst_0\,
      D => \Cnt[0]_i_1__0_n_0\,
      Q => \Cnt_reg_n_0_[0]\
    );
\Cnt_reg[1]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \Cnt_reg[0]_0\(0),
      CLR => \^can_rst_0\,
      D => \Cnt[1]_i_1_n_0\,
      Q => \Cnt_reg_n_0_[1]\
    );
\Cnt_reg[2]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \Cnt_reg[0]_0\(0),
      CLR => \^can_rst_0\,
      D => \Cnt[2]_i_1_n_0\,
      Q => \Cnt_reg_n_0_[2]\
    );
\Cnt_reg[3]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \Cnt_reg[0]_0\(0),
      CLR => \^can_rst_0\,
      D => \Cnt[3]_i_1_n_0\,
      Q => \Cnt_reg_n_0_[3]\
    );
\Cnt_reg[4]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \Cnt_reg[0]_0\(0),
      CLR => \^can_rst_0\,
      D => \Cnt[4]_i_1_n_0\,
      Q => \Cnt_reg_n_0_[4]\
    );
\Cnt_reg[5]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \Cnt_reg[0]_0\(0),
      CLR => \^can_rst_0\,
      D => \Cnt[5]_i_2_n_0\,
      Q => \Cnt_reg_n_0_[5]\
    );
\D_Len[0]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000004000000"
    )
        port map (
      I0 => \TOFILTERd_reg[0]_0\,
      I1 => SRST_0,
      I2 => RXSTATES(3),
      I3 => RXSTATES(1),
      I4 => RXSTATES(0),
      I5 => RXSTATES(2),
      O => \D_Len[0]_i_1_n_0\
    );
\D_Len[1]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000008000000"
    )
        port map (
      I0 => \^q\(0),
      I1 => SRST_0,
      I2 => RXSTATES(3),
      I3 => RXSTATES(1),
      I4 => RXSTATES(0),
      I5 => RXSTATES(2),
      O => \D_Len[1]_i_1_n_0\
    );
\D_Len[2]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000008000000"
    )
        port map (
      I0 => \^q\(1),
      I1 => SRST_0,
      I2 => RXSTATES(3),
      I3 => RXSTATES(1),
      I4 => RXSTATES(0),
      I5 => RXSTATES(2),
      O => \D_Len[2]_i_1_n_0\
    );
\D_Len[3]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"4F"
    )
        port map (
      I0 => \D_Len[3]_i_3_n_0\,
      I1 => \CRC_RG_reg[14]\,
      I2 => SRST_0,
      O => \D_Len[3]_i_1_n_0\
    );
\D_Len[3]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000008000000"
    )
        port map (
      I0 => \^q\(2),
      I1 => SRST_0,
      I2 => RXSTATES(3),
      I3 => RXSTATES(1),
      I4 => RXSTATES(0),
      I5 => RXSTATES(2),
      O => \D_Len[3]_i_2_n_0\
    );
\D_Len[3]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFF4FFF0FFFFFFF0"
    )
        port map (
      I0 => \Cnt_reg_n_0_[1]\,
      I1 => \Cnt_reg_n_0_[2]\,
      I2 => RXSTATES(3),
      I3 => RXSTATES(2),
      I4 => RXSTATES(1),
      I5 => RXSTATES(0),
      O => \D_Len[3]_i_3_n_0\
    );
\D_Len_reg[0]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \D_Len[3]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \D_Len[0]_i_1_n_0\,
      Q => \^q\(0)
    );
\D_Len_reg[1]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \D_Len[3]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \D_Len[1]_i_1_n_0\,
      Q => \^q\(1)
    );
\D_Len_reg[2]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \D_Len[3]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \D_Len[2]_i_1_n_0\,
      Q => \^q\(2)
    );
\D_Len_reg[3]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \D_Len[3]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \D_Len[3]_i_2_n_0\,
      Q => \^q\(3)
    );
IDE_i_1: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFBFBBBB00808888"
    )
        port map (
      I0 => IDE1_out,
      I1 => IDE_i_2_n_0,
      I2 => IDE_i_3_n_0,
      I3 => IDE_i_4_n_0,
      I4 => IDE_i_5_n_0,
      I5 => \^ide_rec_0\,
      O => IDE_i_1_n_0
    );
IDE_i_2: unisim.vcomponents.LUT3
    generic map(
      INIT => X"4F"
    )
        port map (
      I0 => RXSTATES(3),
      I1 => \CRC_RG_reg[14]\,
      I2 => SRST_0,
      O => IDE_i_2_n_0
    );
IDE_i_3: unisim.vcomponents.LUT3
    generic map(
      INIT => X"04"
    )
        port map (
      I0 => RXSTATES(2),
      I1 => RXSTATES(1),
      I2 => RXSTATES(0),
      O => IDE_i_3_n_0
    );
IDE_i_4: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFBFFFFFF"
    )
        port map (
      I0 => \Cnt_reg_n_0_[5]\,
      I1 => \Cnt_reg_n_0_[4]\,
      I2 => \Cnt_reg_n_0_[3]\,
      I3 => \Cnt_reg_n_0_[1]\,
      I4 => \Cnt_reg_n_0_[0]\,
      I5 => \Cnt_reg_n_0_[2]\,
      O => IDE_i_4_n_0
    );
IDE_i_5: unisim.vcomponents.LUT4
    generic map(
      INIT => X"AAA8"
    )
        port map (
      I0 => SRST_0,
      I1 => RXSTATES(1),
      I2 => RXSTATES(3),
      I3 => RXSTATES(2),
      O => IDE_i_5_n_0
    );
IDE_reg: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => '1',
      CLR => \^can_rst_0\,
      D => IDE_i_1_n_0,
      Q => \^ide_rec_0\
    );
RTR_i_1: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F0F0FFF4F0F000B0"
    )
        port map (
      I0 => \CRC_RG_reg[14]\,
      I1 => SRST_0,
      I2 => I59,
      I3 => IDE_i_5_n_0,
      I4 => RTR_i_4_n_0,
      I5 => \^rtr_rec_0\,
      O => RTR_i_1_n_0
    );
RTR_i_3: unisim.vcomponents.LUT6
    generic map(
      INIT => X"555557575555575F"
    )
        port map (
      I0 => SRST_0,
      I1 => RXSTATES(1),
      I2 => RXSTATES(2),
      I3 => \TOFILTERd_reg[0]_0\,
      I4 => RXSTATES(3),
      I5 => RXSTATES(0),
      O => I59
    );
RTR_i_4: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000400"
    )
        port map (
      I0 => RXSTATES(3),
      I1 => \CRC_RG_reg[14]\,
      I2 => RXSTATES(2),
      I3 => RXSTATES(1),
      I4 => RXSTATES(0),
      I5 => \TOFILTERI[28]_i_3_n_0\,
      O => RTR_i_4_n_0
    );
RTR_reg: unisim.vcomponents.FDPE
     port map (
      C => clk,
      CE => '1',
      D => RTR_i_1_n_0,
      PRE => \^can_rst_0\,
      Q => \^rtr_rec_0\
    );
\RXSTATES[0]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAAAAAAAAA8088"
    )
        port map (
      I0 => SRST_0,
      I1 => \RXSTATES_reg[0]_1\,
      I2 => \RXSTATES[0]_i_3_n_0\,
      I3 => \RXSTATES[0]_i_4_n_0\,
      I4 => \^req_error_rx\,
      I5 => \RXSTATES_reg[0]_0\,
      O => \RXSTATES[0]_i_1_n_0\
    );
\RXSTATES[0]_i_10\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000100000"
    )
        port map (
      I0 => \Cnt_reg_n_0_[1]\,
      I1 => \Cnt_reg_n_0_[0]\,
      I2 => \Cnt_reg_n_0_[2]\,
      I3 => \Cnt_reg_n_0_[5]\,
      I4 => \Cnt_reg_n_0_[4]\,
      I5 => \Cnt_reg_n_0_[3]\,
      O => \RXSTATES[0]_i_10_n_0\
    );
\RXSTATES[0]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFC0FFE0FFC0"
    )
        port map (
      I0 => AckTakeOver_i_2_n_0,
      I1 => \RXSTATES[0]_i_6_n_0\,
      I2 => \RXSTATES[0]_i_7_n_0\,
      I3 => \RXSTATES[0]_i_8_n_0\,
      I4 => \TOFILTERd_reg[0]_0\,
      I5 => \^rxstates_reg[2]_0\,
      O => \RXSTATES[0]_i_3_n_0\
    );
\RXSTATES[0]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"EAAAEBABEBABEBAB"
    )
        port map (
      I0 => \Cnt[5]_i_5__0_n_0\,
      I1 => RXSTATES(0),
      I2 => \RXSTATES[2]_i_3_n_0\,
      I3 => \RXSTATES[0]_i_9_n_0\,
      I4 => \TOFILTERd_reg[0]_0\,
      I5 => \RXSTATES[0]_i_10_n_0\,
      O => \RXSTATES[0]_i_4_n_0\
    );
\RXSTATES[0]_i_6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"47"
    )
        port map (
      I0 => RXSTATES(0),
      I1 => \RXSTATES[2]_i_3_n_0\,
      I2 => RXSTATES(1),
      O => \RXSTATES[0]_i_6_n_0\
    );
\RXSTATES[0]_i_7\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => RXSTATES(3),
      I1 => RXSTATES(2),
      O => \RXSTATES[0]_i_7_n_0\
    );
\RXSTATES[0]_i_8\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"220003FC00000000"
    )
        port map (
      I0 => \RXSTATES_reg[0]_0\,
      I1 => RXSTATES(1),
      I2 => \RXSTATES[2]_i_3_n_0\,
      I3 => RXSTATES(0),
      I4 => RXSTATES(3),
      I5 => RXSTATES(2),
      O => \RXSTATES[0]_i_8_n_0\
    );
\RXSTATES[0]_i_9\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"55555554"
    )
        port map (
      I0 => \^rtr_rec_0\,
      I1 => \^q\(0),
      I2 => \^q\(2),
      I3 => \^q\(1),
      I4 => \^q\(3),
      O => \RXSTATES[0]_i_9_n_0\
    );
\RXSTATES[1]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"EECFCFC0CC333333"
    )
        port map (
      I0 => \RXSTATES_reg[0]_0\,
      I1 => RXSTATES(1),
      I2 => \RXSTATES[2]_i_3_n_0\,
      I3 => RXSTATES(3),
      I4 => RXSTATES(2),
      I5 => RXSTATES(0),
      O => \RXSTATES_reg[1]_0\
    );
\RXSTATES[2]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"A888888888888888"
    )
        port map (
      I0 => SRST_0,
      I1 => \RXSTATES[2]_i_2_n_0\,
      I2 => RXSTATES(1),
      I3 => RXSTATES(0),
      I4 => \RXSTATES[2]_i_3_n_0\,
      I5 => \RXSTATES[2]_i_4_n_0\,
      O => \RXSTATES[2]_i_1_n_0\
    );
\RXSTATES[2]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"55F5757555757575"
    )
        port map (
      I0 => \RXSTATES_reg[3]_1\,
      I1 => RXSTATES(3),
      I2 => RXSTATES(2),
      I3 => RXSTATES(1),
      I4 => RXSTATES(0),
      I5 => \RXSTATES_reg[0]_0\,
      O => \RXSTATES[2]_i_2_n_0\
    );
\RXSTATES[2]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000001"
    )
        port map (
      I0 => \Cnt_reg_n_0_[4]\,
      I1 => \Cnt_reg_n_0_[2]\,
      I2 => \Cnt_reg_n_0_[1]\,
      I3 => \Cnt_reg_n_0_[0]\,
      I4 => \Cnt_reg_n_0_[3]\,
      I5 => \Cnt_reg_n_0_[5]\,
      O => \RXSTATES[2]_i_3_n_0\
    );
\RXSTATES[2]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => RXSTATES(3),
      I1 => RXSTATES(2),
      O => \RXSTATES[2]_i_4_n_0\
    );
\RXSTATES[3]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"282020A0AAAAAAAA"
    )
        port map (
      I0 => SRST_0,
      I1 => RXSTATES(1),
      I2 => RXSTATES(3),
      I3 => RXSTATES(0),
      I4 => RXSTATES(2),
      I5 => \RXSTATES_reg[3]_1\,
      O => \RXSTATES[3]_i_2_n_0\
    );
\RXSTATES_reg[0]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \RXSTATES_reg[3]_2\(0),
      CLR => \^can_rst_0\,
      D => \RXSTATES[0]_i_1_n_0\,
      Q => RXSTATES(0)
    );
\RXSTATES_reg[1]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \RXSTATES_reg[3]_2\(0),
      CLR => \^can_rst_0\,
      D => D(0),
      Q => RXSTATES(1)
    );
\RXSTATES_reg[2]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \RXSTATES_reg[3]_2\(0),
      CLR => \^can_rst_0\,
      D => \RXSTATES[2]_i_1_n_0\,
      Q => RXSTATES(2)
    );
\RXSTATES_reg[3]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \RXSTATES_reg[3]_2\(0),
      CLR => \^can_rst_0\,
      D => \RXSTATES[3]_i_2_n_0\,
      Q => RXSTATES(3)
    );
\State[2]_i_10\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000400"
    )
        port map (
      I0 => Sampled_din,
      I1 => RXSTATES(1),
      I2 => RXSTATES(0),
      I3 => RXSTATES(3),
      I4 => RXSTATES(2),
      O => \^rxout_reg\
    );
\TOFILTERI[0]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000400000000"
    )
        port map (
      I0 => \TOFILTERd_reg[0]_0\,
      I1 => SRST_0,
      I2 => RXSTATES(2),
      I3 => RXSTATES(3),
      I4 => RXSTATES(0),
      I5 => RXSTATES(1),
      O => IDE1_out
    );
\TOFILTERI[10]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000800000000"
    )
        port map (
      I0 => \^tofilteri_0\(9),
      I1 => SRST_0,
      I2 => RXSTATES(2),
      I3 => RXSTATES(3),
      I4 => RXSTATES(0),
      I5 => RXSTATES(1),
      O => \TOFILTERI[10]_i_1_n_0\
    );
\TOFILTERI[11]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000800000000"
    )
        port map (
      I0 => \^tofilteri_0\(10),
      I1 => SRST_0,
      I2 => RXSTATES(2),
      I3 => RXSTATES(3),
      I4 => RXSTATES(0),
      I5 => RXSTATES(1),
      O => \TOFILTERI[11]_i_1_n_0\
    );
\TOFILTERI[12]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000800000000"
    )
        port map (
      I0 => \^tofilteri_0\(11),
      I1 => SRST_0,
      I2 => RXSTATES(2),
      I3 => RXSTATES(3),
      I4 => RXSTATES(0),
      I5 => RXSTATES(1),
      O => \TOFILTERI[12]_i_1_n_0\
    );
\TOFILTERI[13]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000800000000"
    )
        port map (
      I0 => \^tofilteri_0\(12),
      I1 => SRST_0,
      I2 => RXSTATES(2),
      I3 => RXSTATES(3),
      I4 => RXSTATES(0),
      I5 => RXSTATES(1),
      O => \TOFILTERI[13]_i_1_n_0\
    );
\TOFILTERI[14]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000800000000"
    )
        port map (
      I0 => \^tofilteri_0\(13),
      I1 => SRST_0,
      I2 => RXSTATES(2),
      I3 => RXSTATES(3),
      I4 => RXSTATES(0),
      I5 => RXSTATES(1),
      O => \TOFILTERI[14]_i_1_n_0\
    );
\TOFILTERI[15]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000800000000"
    )
        port map (
      I0 => \^tofilteri_0\(14),
      I1 => SRST_0,
      I2 => RXSTATES(2),
      I3 => RXSTATES(3),
      I4 => RXSTATES(0),
      I5 => RXSTATES(1),
      O => \TOFILTERI[15]_i_1_n_0\
    );
\TOFILTERI[16]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000800000000"
    )
        port map (
      I0 => \^tofilteri_0\(15),
      I1 => SRST_0,
      I2 => RXSTATES(2),
      I3 => RXSTATES(3),
      I4 => RXSTATES(0),
      I5 => RXSTATES(1),
      O => \TOFILTERI[16]_i_1_n_0\
    );
\TOFILTERI[17]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000800000000"
    )
        port map (
      I0 => \^tofilteri_0\(16),
      I1 => SRST_0,
      I2 => RXSTATES(2),
      I3 => RXSTATES(3),
      I4 => RXSTATES(0),
      I5 => RXSTATES(1),
      O => \TOFILTERI[17]_i_1_n_0\
    );
\TOFILTERI[18]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000800000000"
    )
        port map (
      I0 => \^tofilteri_0\(17),
      I1 => SRST_0,
      I2 => RXSTATES(2),
      I3 => RXSTATES(3),
      I4 => RXSTATES(0),
      I5 => RXSTATES(1),
      O => \TOFILTERI[18]_i_1_n_0\
    );
\TOFILTERI[19]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000800000000"
    )
        port map (
      I0 => \^tofilteri_0\(18),
      I1 => SRST_0,
      I2 => RXSTATES(2),
      I3 => RXSTATES(3),
      I4 => RXSTATES(0),
      I5 => RXSTATES(1),
      O => \TOFILTERI[19]_i_1_n_0\
    );
\TOFILTERI[1]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000800000000"
    )
        port map (
      I0 => \^tofilteri_0\(0),
      I1 => SRST_0,
      I2 => RXSTATES(2),
      I3 => RXSTATES(3),
      I4 => RXSTATES(0),
      I5 => RXSTATES(1),
      O => \TOFILTERI[1]_i_1_n_0\
    );
\TOFILTERI[20]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000800000000"
    )
        port map (
      I0 => \^tofilteri_0\(19),
      I1 => SRST_0,
      I2 => RXSTATES(2),
      I3 => RXSTATES(3),
      I4 => RXSTATES(0),
      I5 => RXSTATES(1),
      O => \TOFILTERI[20]_i_1_n_0\
    );
\TOFILTERI[21]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000800000000"
    )
        port map (
      I0 => \^tofilteri_0\(20),
      I1 => SRST_0,
      I2 => RXSTATES(2),
      I3 => RXSTATES(3),
      I4 => RXSTATES(0),
      I5 => RXSTATES(1),
      O => \TOFILTERI[21]_i_1_n_0\
    );
\TOFILTERI[22]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000800000000"
    )
        port map (
      I0 => \^tofilteri_0\(21),
      I1 => SRST_0,
      I2 => RXSTATES(2),
      I3 => RXSTATES(3),
      I4 => RXSTATES(0),
      I5 => RXSTATES(1),
      O => \TOFILTERI[22]_i_1_n_0\
    );
\TOFILTERI[23]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000800000000"
    )
        port map (
      I0 => \^tofilteri_0\(22),
      I1 => SRST_0,
      I2 => RXSTATES(2),
      I3 => RXSTATES(3),
      I4 => RXSTATES(0),
      I5 => RXSTATES(1),
      O => \TOFILTERI[23]_i_1_n_0\
    );
\TOFILTERI[24]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000800000000"
    )
        port map (
      I0 => \^tofilteri_0\(23),
      I1 => SRST_0,
      I2 => RXSTATES(2),
      I3 => RXSTATES(3),
      I4 => RXSTATES(0),
      I5 => RXSTATES(1),
      O => \TOFILTERI[24]_i_1_n_0\
    );
\TOFILTERI[25]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000800000000"
    )
        port map (
      I0 => \^tofilteri_0\(24),
      I1 => SRST_0,
      I2 => RXSTATES(2),
      I3 => RXSTATES(3),
      I4 => RXSTATES(0),
      I5 => RXSTATES(1),
      O => \TOFILTERI[25]_i_1_n_0\
    );
\TOFILTERI[26]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000800000000"
    )
        port map (
      I0 => \^tofilteri_0\(25),
      I1 => SRST_0,
      I2 => RXSTATES(2),
      I3 => RXSTATES(3),
      I4 => RXSTATES(0),
      I5 => RXSTATES(1),
      O => \TOFILTERI[26]_i_1_n_0\
    );
\TOFILTERI[27]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000800000000"
    )
        port map (
      I0 => \^tofilteri_0\(26),
      I1 => SRST_0,
      I2 => RXSTATES(2),
      I3 => RXSTATES(3),
      I4 => RXSTATES(0),
      I5 => RXSTATES(1),
      O => \TOFILTERI[27]_i_1_n_0\
    );
\TOFILTERI[28]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00008000AAAAAAAA"
    )
        port map (
      I0 => IDE_i_2_n_0,
      I1 => IDE_i_4_n_0,
      I2 => \TOFILTERI[28]_i_3_n_0\,
      I3 => \TOFILTERI[28]_i_4_n_0\,
      I4 => RXSTATES(0),
      I5 => IDE_i_5_n_0,
      O => \TOFILTERI[28]_i_1_n_0\
    );
\TOFILTERI[28]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000800000000"
    )
        port map (
      I0 => \^tofilteri_0\(27),
      I1 => SRST_0,
      I2 => RXSTATES(2),
      I3 => RXSTATES(3),
      I4 => RXSTATES(0),
      I5 => RXSTATES(1),
      O => \TOFILTERI[28]_i_2_n_0\
    );
\TOFILTERI[28]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFFBFE"
    )
        port map (
      I0 => \Cnt_reg_n_0_[3]\,
      I1 => \Cnt_reg_n_0_[4]\,
      I2 => \Cnt_reg_n_0_[5]\,
      I3 => \Cnt_reg_n_0_[2]\,
      I4 => \Cnt_reg_n_0_[0]\,
      I5 => \Cnt_reg_n_0_[1]\,
      O => \TOFILTERI[28]_i_3_n_0\
    );
\TOFILTERI[28]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => RXSTATES(1),
      I1 => RXSTATES(2),
      O => \TOFILTERI[28]_i_4_n_0\
    );
\TOFILTERI[2]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000800000000"
    )
        port map (
      I0 => \^tofilteri_0\(1),
      I1 => SRST_0,
      I2 => RXSTATES(2),
      I3 => RXSTATES(3),
      I4 => RXSTATES(0),
      I5 => RXSTATES(1),
      O => \TOFILTERI[2]_i_1_n_0\
    );
\TOFILTERI[3]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000800000000"
    )
        port map (
      I0 => \^tofilteri_0\(2),
      I1 => SRST_0,
      I2 => RXSTATES(2),
      I3 => RXSTATES(3),
      I4 => RXSTATES(0),
      I5 => RXSTATES(1),
      O => \TOFILTERI[3]_i_1_n_0\
    );
\TOFILTERI[4]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000800000000"
    )
        port map (
      I0 => \^tofilteri_0\(3),
      I1 => SRST_0,
      I2 => RXSTATES(2),
      I3 => RXSTATES(3),
      I4 => RXSTATES(0),
      I5 => RXSTATES(1),
      O => \TOFILTERI[4]_i_1_n_0\
    );
\TOFILTERI[5]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000800000000"
    )
        port map (
      I0 => \^tofilteri_0\(4),
      I1 => SRST_0,
      I2 => RXSTATES(2),
      I3 => RXSTATES(3),
      I4 => RXSTATES(0),
      I5 => RXSTATES(1),
      O => \TOFILTERI[5]_i_1_n_0\
    );
\TOFILTERI[6]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000800000000"
    )
        port map (
      I0 => \^tofilteri_0\(5),
      I1 => SRST_0,
      I2 => RXSTATES(2),
      I3 => RXSTATES(3),
      I4 => RXSTATES(0),
      I5 => RXSTATES(1),
      O => \TOFILTERI[6]_i_1_n_0\
    );
\TOFILTERI[7]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000800000000"
    )
        port map (
      I0 => \^tofilteri_0\(6),
      I1 => SRST_0,
      I2 => RXSTATES(2),
      I3 => RXSTATES(3),
      I4 => RXSTATES(0),
      I5 => RXSTATES(1),
      O => \TOFILTERI[7]_i_1_n_0\
    );
\TOFILTERI[8]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000800000000"
    )
        port map (
      I0 => \^tofilteri_0\(7),
      I1 => SRST_0,
      I2 => RXSTATES(2),
      I3 => RXSTATES(3),
      I4 => RXSTATES(0),
      I5 => RXSTATES(1),
      O => \TOFILTERI[8]_i_1_n_0\
    );
\TOFILTERI[9]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000800000000"
    )
        port map (
      I0 => \^tofilteri_0\(8),
      I1 => SRST_0,
      I2 => RXSTATES(2),
      I3 => RXSTATES(3),
      I4 => RXSTATES(0),
      I5 => RXSTATES(1),
      O => \TOFILTERI[9]_i_1_n_0\
    );
\TOFILTERI_reg[0]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERI[28]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => IDE1_out,
      Q => \^tofilteri_0\(0)
    );
\TOFILTERI_reg[10]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERI[28]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERI[10]_i_1_n_0\,
      Q => \^tofilteri_0\(10)
    );
\TOFILTERI_reg[11]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERI[28]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERI[11]_i_1_n_0\,
      Q => \^tofilteri_0\(11)
    );
\TOFILTERI_reg[12]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERI[28]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERI[12]_i_1_n_0\,
      Q => \^tofilteri_0\(12)
    );
\TOFILTERI_reg[13]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERI[28]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERI[13]_i_1_n_0\,
      Q => \^tofilteri_0\(13)
    );
\TOFILTERI_reg[14]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERI[28]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERI[14]_i_1_n_0\,
      Q => \^tofilteri_0\(14)
    );
\TOFILTERI_reg[15]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERI[28]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERI[15]_i_1_n_0\,
      Q => \^tofilteri_0\(15)
    );
\TOFILTERI_reg[16]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERI[28]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERI[16]_i_1_n_0\,
      Q => \^tofilteri_0\(16)
    );
\TOFILTERI_reg[17]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERI[28]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERI[17]_i_1_n_0\,
      Q => \^tofilteri_0\(17)
    );
\TOFILTERI_reg[18]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERI[28]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERI[18]_i_1_n_0\,
      Q => \^tofilteri_0\(18)
    );
\TOFILTERI_reg[19]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERI[28]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERI[19]_i_1_n_0\,
      Q => \^tofilteri_0\(19)
    );
\TOFILTERI_reg[1]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERI[28]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERI[1]_i_1_n_0\,
      Q => \^tofilteri_0\(1)
    );
\TOFILTERI_reg[20]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERI[28]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERI[20]_i_1_n_0\,
      Q => \^tofilteri_0\(20)
    );
\TOFILTERI_reg[21]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERI[28]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERI[21]_i_1_n_0\,
      Q => \^tofilteri_0\(21)
    );
\TOFILTERI_reg[22]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERI[28]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERI[22]_i_1_n_0\,
      Q => \^tofilteri_0\(22)
    );
\TOFILTERI_reg[23]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERI[28]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERI[23]_i_1_n_0\,
      Q => \^tofilteri_0\(23)
    );
\TOFILTERI_reg[24]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERI[28]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERI[24]_i_1_n_0\,
      Q => \^tofilteri_0\(24)
    );
\TOFILTERI_reg[25]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERI[28]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERI[25]_i_1_n_0\,
      Q => \^tofilteri_0\(25)
    );
\TOFILTERI_reg[26]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERI[28]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERI[26]_i_1_n_0\,
      Q => \^tofilteri_0\(26)
    );
\TOFILTERI_reg[27]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERI[28]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERI[27]_i_1_n_0\,
      Q => \^tofilteri_0\(27)
    );
\TOFILTERI_reg[28]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERI[28]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERI[28]_i_2_n_0\,
      Q => \^tofilteri_0\(28)
    );
\TOFILTERI_reg[2]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERI[28]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERI[2]_i_1_n_0\,
      Q => \^tofilteri_0\(2)
    );
\TOFILTERI_reg[3]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERI[28]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERI[3]_i_1_n_0\,
      Q => \^tofilteri_0\(3)
    );
\TOFILTERI_reg[4]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERI[28]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERI[4]_i_1_n_0\,
      Q => \^tofilteri_0\(4)
    );
\TOFILTERI_reg[5]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERI[28]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERI[5]_i_1_n_0\,
      Q => \^tofilteri_0\(5)
    );
\TOFILTERI_reg[6]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERI[28]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERI[6]_i_1_n_0\,
      Q => \^tofilteri_0\(6)
    );
\TOFILTERI_reg[7]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERI[28]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERI[7]_i_1_n_0\,
      Q => \^tofilteri_0\(7)
    );
\TOFILTERI_reg[8]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERI[28]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERI[8]_i_1_n_0\,
      Q => \^tofilteri_0\(8)
    );
\TOFILTERI_reg[9]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERI[28]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERI[9]_i_1_n_0\,
      Q => \^tofilteri_0\(9)
    );
\TOFILTERd[0]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000010000000000"
    )
        port map (
      I0 => \TOFILTERd_reg[0]_0\,
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST_0,
      I4 => RXSTATES(3),
      I5 => RXSTATES(2),
      O => \TOFILTERd[0]_i_1_n_0\
    );
\TOFILTERd[10]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd_0\(9),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST_0,
      I4 => RXSTATES(3),
      I5 => RXSTATES(2),
      O => \TOFILTERd[10]_i_1_n_0\
    );
\TOFILTERd[11]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd_0\(10),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST_0,
      I4 => RXSTATES(3),
      I5 => RXSTATES(2),
      O => \TOFILTERd[11]_i_1_n_0\
    );
\TOFILTERd[12]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd_0\(11),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST_0,
      I4 => RXSTATES(3),
      I5 => RXSTATES(2),
      O => \TOFILTERd[12]_i_1_n_0\
    );
\TOFILTERd[13]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd_0\(12),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST_0,
      I4 => RXSTATES(3),
      I5 => RXSTATES(2),
      O => \TOFILTERd[13]_i_1_n_0\
    );
\TOFILTERd[14]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd_0\(13),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST_0,
      I4 => RXSTATES(3),
      I5 => RXSTATES(2),
      O => \TOFILTERd[14]_i_1_n_0\
    );
\TOFILTERd[15]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd_0\(14),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST_0,
      I4 => RXSTATES(3),
      I5 => RXSTATES(2),
      O => \TOFILTERd[15]_i_1_n_0\
    );
\TOFILTERd[16]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd_0\(15),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST_0,
      I4 => RXSTATES(3),
      I5 => RXSTATES(2),
      O => \TOFILTERd[16]_i_1_n_0\
    );
\TOFILTERd[17]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd_0\(16),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST_0,
      I4 => RXSTATES(3),
      I5 => RXSTATES(2),
      O => \TOFILTERd[17]_i_1_n_0\
    );
\TOFILTERd[18]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd_0\(17),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST_0,
      I4 => RXSTATES(3),
      I5 => RXSTATES(2),
      O => \TOFILTERd[18]_i_1_n_0\
    );
\TOFILTERd[19]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd_0\(18),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST_0,
      I4 => RXSTATES(3),
      I5 => RXSTATES(2),
      O => \TOFILTERd[19]_i_1_n_0\
    );
\TOFILTERd[1]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd_0\(0),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST_0,
      I4 => RXSTATES(3),
      I5 => RXSTATES(2),
      O => \TOFILTERd[1]_i_1_n_0\
    );
\TOFILTERd[20]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd_0\(19),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST_0,
      I4 => RXSTATES(3),
      I5 => RXSTATES(2),
      O => \TOFILTERd[20]_i_1_n_0\
    );
\TOFILTERd[21]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd_0\(20),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST_0,
      I4 => RXSTATES(3),
      I5 => RXSTATES(2),
      O => \TOFILTERd[21]_i_1_n_0\
    );
\TOFILTERd[22]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd_0\(21),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST_0,
      I4 => RXSTATES(3),
      I5 => RXSTATES(2),
      O => \TOFILTERd[22]_i_1_n_0\
    );
\TOFILTERd[23]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd_0\(22),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST_0,
      I4 => RXSTATES(3),
      I5 => RXSTATES(2),
      O => \TOFILTERd[23]_i_1_n_0\
    );
\TOFILTERd[24]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd_0\(23),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST_0,
      I4 => RXSTATES(3),
      I5 => RXSTATES(2),
      O => \TOFILTERd[24]_i_1_n_0\
    );
\TOFILTERd[25]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd_0\(24),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST_0,
      I4 => RXSTATES(3),
      I5 => RXSTATES(2),
      O => \TOFILTERd[25]_i_1_n_0\
    );
\TOFILTERd[26]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd_0\(25),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST_0,
      I4 => RXSTATES(3),
      I5 => RXSTATES(2),
      O => \TOFILTERd[26]_i_1_n_0\
    );
\TOFILTERd[27]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd_0\(26),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST_0,
      I4 => RXSTATES(3),
      I5 => RXSTATES(2),
      O => \TOFILTERd[27]_i_1_n_0\
    );
\TOFILTERd[28]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd_0\(27),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST_0,
      I4 => RXSTATES(3),
      I5 => RXSTATES(2),
      O => \TOFILTERd[28]_i_1_n_0\
    );
\TOFILTERd[29]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd_0\(28),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST_0,
      I4 => RXSTATES(3),
      I5 => RXSTATES(2),
      O => \TOFILTERd[29]_i_1_n_0\
    );
\TOFILTERd[2]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd_0\(1),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST_0,
      I4 => RXSTATES(3),
      I5 => RXSTATES(2),
      O => \TOFILTERd[2]_i_1_n_0\
    );
\TOFILTERd[30]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd_0\(29),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST_0,
      I4 => RXSTATES(3),
      I5 => RXSTATES(2),
      O => \TOFILTERd[30]_i_1_n_0\
    );
\TOFILTERd[31]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd_0\(30),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST_0,
      I4 => RXSTATES(3),
      I5 => RXSTATES(2),
      O => \TOFILTERd[31]_i_1_n_0\
    );
\TOFILTERd[32]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd_0\(31),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST_0,
      I4 => RXSTATES(3),
      I5 => RXSTATES(2),
      O => \TOFILTERd[32]_i_1_n_0\
    );
\TOFILTERd[33]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd_0\(32),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST_0,
      I4 => RXSTATES(3),
      I5 => RXSTATES(2),
      O => \TOFILTERd[33]_i_1_n_0\
    );
\TOFILTERd[34]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd_0\(33),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST_0,
      I4 => RXSTATES(3),
      I5 => RXSTATES(2),
      O => \TOFILTERd[34]_i_1_n_0\
    );
\TOFILTERd[35]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd_0\(34),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST_0,
      I4 => RXSTATES(3),
      I5 => RXSTATES(2),
      O => \TOFILTERd[35]_i_1_n_0\
    );
\TOFILTERd[36]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd_0\(35),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST_0,
      I4 => RXSTATES(3),
      I5 => RXSTATES(2),
      O => \TOFILTERd[36]_i_1_n_0\
    );
\TOFILTERd[37]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd_0\(36),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST_0,
      I4 => RXSTATES(3),
      I5 => RXSTATES(2),
      O => \TOFILTERd[37]_i_1_n_0\
    );
\TOFILTERd[38]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd_0\(37),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST_0,
      I4 => RXSTATES(3),
      I5 => RXSTATES(2),
      O => \TOFILTERd[38]_i_1_n_0\
    );
\TOFILTERd[39]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd_0\(38),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST_0,
      I4 => RXSTATES(3),
      I5 => RXSTATES(2),
      O => \TOFILTERd[39]_i_1_n_0\
    );
\TOFILTERd[3]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd_0\(2),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST_0,
      I4 => RXSTATES(3),
      I5 => RXSTATES(2),
      O => \TOFILTERd[3]_i_1_n_0\
    );
\TOFILTERd[40]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd_0\(39),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST_0,
      I4 => RXSTATES(3),
      I5 => RXSTATES(2),
      O => \TOFILTERd[40]_i_1_n_0\
    );
\TOFILTERd[41]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd_0\(40),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST_0,
      I4 => RXSTATES(3),
      I5 => RXSTATES(2),
      O => \TOFILTERd[41]_i_1_n_0\
    );
\TOFILTERd[42]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd_0\(41),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST_0,
      I4 => RXSTATES(3),
      I5 => RXSTATES(2),
      O => \TOFILTERd[42]_i_1_n_0\
    );
\TOFILTERd[43]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd_0\(42),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST_0,
      I4 => RXSTATES(3),
      I5 => RXSTATES(2),
      O => \TOFILTERd[43]_i_1_n_0\
    );
\TOFILTERd[44]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd_0\(43),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST_0,
      I4 => RXSTATES(3),
      I5 => RXSTATES(2),
      O => \TOFILTERd[44]_i_1_n_0\
    );
\TOFILTERd[45]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd_0\(44),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST_0,
      I4 => RXSTATES(3),
      I5 => RXSTATES(2),
      O => \TOFILTERd[45]_i_1_n_0\
    );
\TOFILTERd[46]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd_0\(45),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST_0,
      I4 => RXSTATES(3),
      I5 => RXSTATES(2),
      O => \TOFILTERd[46]_i_1_n_0\
    );
\TOFILTERd[47]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd_0\(46),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST_0,
      I4 => RXSTATES(3),
      I5 => RXSTATES(2),
      O => \TOFILTERd[47]_i_1_n_0\
    );
\TOFILTERd[48]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd_0\(47),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST_0,
      I4 => RXSTATES(3),
      I5 => RXSTATES(2),
      O => \TOFILTERd[48]_i_1_n_0\
    );
\TOFILTERd[49]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd_0\(48),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST_0,
      I4 => RXSTATES(3),
      I5 => RXSTATES(2),
      O => \TOFILTERd[49]_i_1_n_0\
    );
\TOFILTERd[4]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd_0\(3),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST_0,
      I4 => RXSTATES(3),
      I5 => RXSTATES(2),
      O => \TOFILTERd[4]_i_1_n_0\
    );
\TOFILTERd[50]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd_0\(49),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST_0,
      I4 => RXSTATES(3),
      I5 => RXSTATES(2),
      O => \TOFILTERd[50]_i_1_n_0\
    );
\TOFILTERd[51]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd_0\(50),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST_0,
      I4 => RXSTATES(3),
      I5 => RXSTATES(2),
      O => \TOFILTERd[51]_i_1_n_0\
    );
\TOFILTERd[52]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd_0\(51),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST_0,
      I4 => RXSTATES(3),
      I5 => RXSTATES(2),
      O => \TOFILTERd[52]_i_1_n_0\
    );
\TOFILTERd[53]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd_0\(52),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST_0,
      I4 => RXSTATES(3),
      I5 => RXSTATES(2),
      O => \TOFILTERd[53]_i_1_n_0\
    );
\TOFILTERd[54]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd_0\(53),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST_0,
      I4 => RXSTATES(3),
      I5 => RXSTATES(2),
      O => \TOFILTERd[54]_i_1_n_0\
    );
\TOFILTERd[55]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd_0\(54),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST_0,
      I4 => RXSTATES(3),
      I5 => RXSTATES(2),
      O => \TOFILTERd[55]_i_1_n_0\
    );
\TOFILTERd[56]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd_0\(55),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST_0,
      I4 => RXSTATES(3),
      I5 => RXSTATES(2),
      O => \TOFILTERd[56]_i_1_n_0\
    );
\TOFILTERd[57]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd_0\(56),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST_0,
      I4 => RXSTATES(3),
      I5 => RXSTATES(2),
      O => \TOFILTERd[57]_i_1_n_0\
    );
\TOFILTERd[58]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd_0\(57),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST_0,
      I4 => RXSTATES(3),
      I5 => RXSTATES(2),
      O => \TOFILTERd[58]_i_1_n_0\
    );
\TOFILTERd[59]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd_0\(58),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST_0,
      I4 => RXSTATES(3),
      I5 => RXSTATES(2),
      O => \TOFILTERd[59]_i_1_n_0\
    );
\TOFILTERd[5]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd_0\(4),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST_0,
      I4 => RXSTATES(3),
      I5 => RXSTATES(2),
      O => \TOFILTERd[5]_i_1_n_0\
    );
\TOFILTERd[60]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd_0\(59),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST_0,
      I4 => RXSTATES(3),
      I5 => RXSTATES(2),
      O => \TOFILTERd[60]_i_1_n_0\
    );
\TOFILTERd[61]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd_0\(60),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST_0,
      I4 => RXSTATES(3),
      I5 => RXSTATES(2),
      O => \TOFILTERd[61]_i_1_n_0\
    );
\TOFILTERd[62]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd_0\(61),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST_0,
      I4 => RXSTATES(3),
      I5 => RXSTATES(2),
      O => \TOFILTERd[62]_i_1_n_0\
    );
\TOFILTERd[63]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"01050000FFFFFFFF"
    )
        port map (
      I0 => RXSTATES(1),
      I1 => RXSTATES(0),
      I2 => RXSTATES(3),
      I3 => RXSTATES(2),
      I4 => \CRC_RG_reg[14]\,
      I5 => SRST_0,
      O => \TOFILTERd[63]_i_1_n_0\
    );
\TOFILTERd[63]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd_0\(62),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST_0,
      I4 => RXSTATES(3),
      I5 => RXSTATES(2),
      O => \TOFILTERd[63]_i_2_n_0\
    );
\TOFILTERd[6]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd_0\(5),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST_0,
      I4 => RXSTATES(3),
      I5 => RXSTATES(2),
      O => \TOFILTERd[6]_i_1_n_0\
    );
\TOFILTERd[7]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd_0\(6),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST_0,
      I4 => RXSTATES(3),
      I5 => RXSTATES(2),
      O => \TOFILTERd[7]_i_1_n_0\
    );
\TOFILTERd[8]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd_0\(7),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST_0,
      I4 => RXSTATES(3),
      I5 => RXSTATES(2),
      O => \TOFILTERd[8]_i_1_n_0\
    );
\TOFILTERd[9]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd_0\(8),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST_0,
      I4 => RXSTATES(3),
      I5 => RXSTATES(2),
      O => \TOFILTERd[9]_i_1_n_0\
    );
\TOFILTERd_reg[0]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[0]_i_1_n_0\,
      Q => \^tofilterd_0\(0)
    );
\TOFILTERd_reg[10]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[10]_i_1_n_0\,
      Q => \^tofilterd_0\(10)
    );
\TOFILTERd_reg[11]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[11]_i_1_n_0\,
      Q => \^tofilterd_0\(11)
    );
\TOFILTERd_reg[12]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[12]_i_1_n_0\,
      Q => \^tofilterd_0\(12)
    );
\TOFILTERd_reg[13]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[13]_i_1_n_0\,
      Q => \^tofilterd_0\(13)
    );
\TOFILTERd_reg[14]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[14]_i_1_n_0\,
      Q => \^tofilterd_0\(14)
    );
\TOFILTERd_reg[15]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[15]_i_1_n_0\,
      Q => \^tofilterd_0\(15)
    );
\TOFILTERd_reg[16]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[16]_i_1_n_0\,
      Q => \^tofilterd_0\(16)
    );
\TOFILTERd_reg[17]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[17]_i_1_n_0\,
      Q => \^tofilterd_0\(17)
    );
\TOFILTERd_reg[18]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[18]_i_1_n_0\,
      Q => \^tofilterd_0\(18)
    );
\TOFILTERd_reg[19]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[19]_i_1_n_0\,
      Q => \^tofilterd_0\(19)
    );
\TOFILTERd_reg[1]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[1]_i_1_n_0\,
      Q => \^tofilterd_0\(1)
    );
\TOFILTERd_reg[20]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[20]_i_1_n_0\,
      Q => \^tofilterd_0\(20)
    );
\TOFILTERd_reg[21]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[21]_i_1_n_0\,
      Q => \^tofilterd_0\(21)
    );
\TOFILTERd_reg[22]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[22]_i_1_n_0\,
      Q => \^tofilterd_0\(22)
    );
\TOFILTERd_reg[23]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[23]_i_1_n_0\,
      Q => \^tofilterd_0\(23)
    );
\TOFILTERd_reg[24]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[24]_i_1_n_0\,
      Q => \^tofilterd_0\(24)
    );
\TOFILTERd_reg[25]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[25]_i_1_n_0\,
      Q => \^tofilterd_0\(25)
    );
\TOFILTERd_reg[26]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[26]_i_1_n_0\,
      Q => \^tofilterd_0\(26)
    );
\TOFILTERd_reg[27]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[27]_i_1_n_0\,
      Q => \^tofilterd_0\(27)
    );
\TOFILTERd_reg[28]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[28]_i_1_n_0\,
      Q => \^tofilterd_0\(28)
    );
\TOFILTERd_reg[29]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[29]_i_1_n_0\,
      Q => \^tofilterd_0\(29)
    );
\TOFILTERd_reg[2]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[2]_i_1_n_0\,
      Q => \^tofilterd_0\(2)
    );
\TOFILTERd_reg[30]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[30]_i_1_n_0\,
      Q => \^tofilterd_0\(30)
    );
\TOFILTERd_reg[31]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[31]_i_1_n_0\,
      Q => \^tofilterd_0\(31)
    );
\TOFILTERd_reg[32]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[32]_i_1_n_0\,
      Q => \^tofilterd_0\(32)
    );
\TOFILTERd_reg[33]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[33]_i_1_n_0\,
      Q => \^tofilterd_0\(33)
    );
\TOFILTERd_reg[34]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[34]_i_1_n_0\,
      Q => \^tofilterd_0\(34)
    );
\TOFILTERd_reg[35]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[35]_i_1_n_0\,
      Q => \^tofilterd_0\(35)
    );
\TOFILTERd_reg[36]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[36]_i_1_n_0\,
      Q => \^tofilterd_0\(36)
    );
\TOFILTERd_reg[37]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[37]_i_1_n_0\,
      Q => \^tofilterd_0\(37)
    );
\TOFILTERd_reg[38]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[38]_i_1_n_0\,
      Q => \^tofilterd_0\(38)
    );
\TOFILTERd_reg[39]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[39]_i_1_n_0\,
      Q => \^tofilterd_0\(39)
    );
\TOFILTERd_reg[3]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[3]_i_1_n_0\,
      Q => \^tofilterd_0\(3)
    );
\TOFILTERd_reg[40]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[40]_i_1_n_0\,
      Q => \^tofilterd_0\(40)
    );
\TOFILTERd_reg[41]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[41]_i_1_n_0\,
      Q => \^tofilterd_0\(41)
    );
\TOFILTERd_reg[42]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[42]_i_1_n_0\,
      Q => \^tofilterd_0\(42)
    );
\TOFILTERd_reg[43]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[43]_i_1_n_0\,
      Q => \^tofilterd_0\(43)
    );
\TOFILTERd_reg[44]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[44]_i_1_n_0\,
      Q => \^tofilterd_0\(44)
    );
\TOFILTERd_reg[45]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[45]_i_1_n_0\,
      Q => \^tofilterd_0\(45)
    );
\TOFILTERd_reg[46]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[46]_i_1_n_0\,
      Q => \^tofilterd_0\(46)
    );
\TOFILTERd_reg[47]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[47]_i_1_n_0\,
      Q => \^tofilterd_0\(47)
    );
\TOFILTERd_reg[48]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[48]_i_1_n_0\,
      Q => \^tofilterd_0\(48)
    );
\TOFILTERd_reg[49]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[49]_i_1_n_0\,
      Q => \^tofilterd_0\(49)
    );
\TOFILTERd_reg[4]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[4]_i_1_n_0\,
      Q => \^tofilterd_0\(4)
    );
\TOFILTERd_reg[50]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[50]_i_1_n_0\,
      Q => \^tofilterd_0\(50)
    );
\TOFILTERd_reg[51]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[51]_i_1_n_0\,
      Q => \^tofilterd_0\(51)
    );
\TOFILTERd_reg[52]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[52]_i_1_n_0\,
      Q => \^tofilterd_0\(52)
    );
\TOFILTERd_reg[53]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[53]_i_1_n_0\,
      Q => \^tofilterd_0\(53)
    );
\TOFILTERd_reg[54]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[54]_i_1_n_0\,
      Q => \^tofilterd_0\(54)
    );
\TOFILTERd_reg[55]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[55]_i_1_n_0\,
      Q => \^tofilterd_0\(55)
    );
\TOFILTERd_reg[56]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[56]_i_1_n_0\,
      Q => \^tofilterd_0\(56)
    );
\TOFILTERd_reg[57]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[57]_i_1_n_0\,
      Q => \^tofilterd_0\(57)
    );
\TOFILTERd_reg[58]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[58]_i_1_n_0\,
      Q => \^tofilterd_0\(58)
    );
\TOFILTERd_reg[59]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[59]_i_1_n_0\,
      Q => \^tofilterd_0\(59)
    );
\TOFILTERd_reg[5]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[5]_i_1_n_0\,
      Q => \^tofilterd_0\(5)
    );
\TOFILTERd_reg[60]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[60]_i_1_n_0\,
      Q => \^tofilterd_0\(60)
    );
\TOFILTERd_reg[61]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[61]_i_1_n_0\,
      Q => \^tofilterd_0\(61)
    );
\TOFILTERd_reg[62]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[62]_i_1_n_0\,
      Q => \^tofilterd_0\(62)
    );
\TOFILTERd_reg[63]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[63]_i_2_n_0\,
      Q => \^tofilterd_0\(63)
    );
\TOFILTERd_reg[6]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[6]_i_1_n_0\,
      Q => \^tofilterd_0\(6)
    );
\TOFILTERd_reg[7]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[7]_i_1_n_0\,
      Q => \^tofilterd_0\(7)
    );
\TOFILTERd_reg[8]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[8]_i_1_n_0\,
      Q => \^tofilterd_0\(8)
    );
\TOFILTERd_reg[9]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[9]_i_1_n_0\,
      Q => \^tofilterd_0\(9)
    );
TXpin_i_5: unisim.vcomponents.LUT5
    generic map(
      INIT => X"BBBA888A"
    )
        port map (
      I0 => \^rxout_reg\,
      I1 => \RXSTATES_reg[0]_0\,
      I2 => TXpin_i_2,
      I3 => \^req_error_rx\,
      I4 => TXpin_i_2_0,
      O => req_Error_reg_0
    );
\bs[0]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFF57F55"
    )
        port map (
      I0 => \TOFILTERd_reg[0]_0\,
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => RXSTATES(3),
      I4 => RXSTATES(2),
      O => I56(0)
    );
\bs[1]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000F80FE00008002"
    )
        port map (
      I0 => \TOFILTERd_reg[0]_0\,
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => RXSTATES(3),
      I4 => RXSTATES(2),
      I5 => bs(0),
      O => I56(1)
    );
\bs[2]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"020A0208"
    )
        port map (
      I0 => bs(1),
      I1 => RXSTATES(2),
      I2 => RXSTATES(3),
      I3 => RXSTATES(1),
      I4 => RXSTATES(0),
      O => I56(2)
    );
\bs[3]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"020A0208"
    )
        port map (
      I0 => bs(2),
      I1 => RXSTATES(2),
      I2 => RXSTATES(3),
      I3 => RXSTATES(1),
      I4 => RXSTATES(0),
      O => I56(3)
    );
\bs[4]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"020A0208"
    )
        port map (
      I0 => bs(3),
      I1 => RXSTATES(2),
      I2 => RXSTATES(3),
      I3 => RXSTATES(1),
      I4 => RXSTATES(0),
      O => I56(4)
    );
\bs[5]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"020A0208"
    )
        port map (
      I0 => bs(4),
      I1 => RXSTATES(2),
      I2 => RXSTATES(3),
      I3 => RXSTATES(1),
      I4 => RXSTATES(0),
      O => I56(5)
    );
\bs_reg[0]\: unisim.vcomponents.FDPE
     port map (
      C => clk,
      CE => \bs_reg[0]_0\(0),
      D => I56(0),
      PRE => \^can_rst_0\,
      Q => bs(0)
    );
\bs_reg[1]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \bs_reg[0]_0\(0),
      CLR => \^can_rst_0\,
      D => I56(1),
      Q => bs(1)
    );
\bs_reg[2]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \bs_reg[0]_0\(0),
      CLR => \^can_rst_0\,
      D => I56(2),
      Q => bs(2)
    );
\bs_reg[3]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \bs_reg[0]_0\(0),
      CLR => \^can_rst_0\,
      D => I56(3),
      Q => bs(3)
    );
\bs_reg[4]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \bs_reg[0]_0\(0),
      CLR => \^can_rst_0\,
      D => I56(4),
      Q => bs(4)
    );
\bs_reg[5]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => \bs_reg[0]_0\(0),
      CLR => \^can_rst_0\,
      D => I56(5),
      Q => bs(5)
    );
done_i_14: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2001"
    )
        port map (
      I0 => RXSTATES(3),
      I1 => RXSTATES(2),
      I2 => RXSTATES(0),
      I3 => RXSTATES(1),
      O => \RXSTATES_reg[3]_0\
    );
\done_i_1__0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"CCC88888"
    )
        port map (
      I0 => \done_i_3__0_n_0\,
      I1 => SRST_0,
      I2 => RXSTATES(3),
      I3 => \^rxstates_reg[2]_0\,
      I4 => \^done_reg_0\,
      O => \done_i_1__0_n_0\
    );
\done_i_3__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000200000"
    )
        port map (
      I0 => \RXSTATES[2]_i_3_n_0\,
      I1 => RXSTATES(2),
      I2 => RXSTATES(3),
      I3 => RXSTATES(1),
      I4 => RXSTATES(0),
      I5 => imTX,
      O => \done_i_3__0_n_0\
    );
\done_i_4__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0001"
    )
        port map (
      I0 => RXSTATES(2),
      I1 => RXSTATES(3),
      I2 => RXSTATES(1),
      I3 => RXSTATES(0),
      O => \^rxstates_reg[2]_0\
    );
done_reg: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => '1',
      CLR => \^can_rst_0\,
      D => \done_i_1__0_n_0\,
      Q => \^done_reg_0\
    );
donefromrxr_i_1: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => SRST_0,
      I1 => \^done_reg_0\,
      O => donefromrxr
    );
req_Error_i_2: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0020020000200A00"
    )
        port map (
      I0 => \TOFILTERd_reg[0]_0\,
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => RXSTATES(3),
      I4 => RXSTATES(2),
      I5 => \RXSTATES[2]_i_3_n_0\,
      O => req_Error_i_2_n_0
    );
req_Error_i_4: unisim.vcomponents.LUT5
    generic map(
      INIT => X"55D5555F"
    )
        port map (
      I0 => SRST_0,
      I1 => RXSTATES(0),
      I2 => RXSTATES(3),
      I3 => RXSTATES(1),
      I4 => RXSTATES(2),
      O => req_Error_i_4_n_0
    );
req_Error_i_5: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000001"
    )
        port map (
      I0 => bs(1),
      I1 => bs(0),
      I2 => bs(3),
      I3 => bs(4),
      I4 => bs(2),
      O => req_Error_i_5_n_0
    );
req_Error_i_6: unisim.vcomponents.LUT5
    generic map(
      INIT => X"80000000"
    )
        port map (
      I0 => bs(1),
      I1 => bs(0),
      I2 => bs(3),
      I3 => bs(4),
      I4 => bs(2),
      O => req_Error_i_6_n_0
    );
req_Error_i_8: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0100"
    )
        port map (
      I0 => RXSTATES(1),
      I1 => RXSTATES(0),
      I2 => RXSTATES(2),
      I3 => RXSTATES(3),
      O => req_Error_i_8_n_0
    );
req_Error_reg: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => '1',
      CLR => \^can_rst_0\,
      D => rxcrc_n_0,
      Q => \^req_error_rx\
    );
rxcrc: entity work.design_1_FPGAPROJECT_0_0_CRC_0
     port map (
      CAN_RST => CAN_RST,
      CAN_RST_0 => \^can_rst_0\,
      \CRC_RG_reg[14]_0\ => \CRC_RG_reg[14]\,
      \CRC_RG_reg[3]_0\ => \TOFILTERd_reg[0]_0\,
      Q(3 downto 0) => RXSTATES(3 downto 0),
      SRST_0 => SRST_0,
      SRST_0_0 => rxcrc_n_0,
      \bs_reg[1]\ => \bs_reg[1]_0\,
      clk => clk,
      req_Error_reg => req_Error_i_2_n_0,
      req_Error_reg_0 => req_Error_i_4_n_0,
      req_Error_reg_1(0) => \bs_reg[0]_0\(0),
      req_Error_reg_2 => \^req_error_rx\,
      req_Error_reg_3 => req_Error_i_5_n_0,
      req_Error_reg_4(5 downto 0) => bs(5 downto 0),
      req_Error_reg_5 => req_Error_i_6_n_0,
      req_Error_reg_6 => req_Error_i_8_n_0
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1_FPGAPROJECT_0_0_RXMachine_6 is
  port (
    AckTakeOver : out STD_LOGIC;
    CAN_RST_0 : out STD_LOGIC;
    RTR_reg_0 : out STD_LOGIC;
    req_Error_RX : out STD_LOGIC;
    IDE_rec : out STD_LOGIC;
    done_reg_0 : out STD_LOGIC;
    req_Error_reg_0 : out STD_LOGIC;
    Q : out STD_LOGIC_VECTOR ( 0 to 0 );
    \D_Len_reg[3]_0\ : out STD_LOGIC_VECTOR ( 3 downto 0 );
    \RXSTATES_reg[2]_0\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    \RXSTATES_reg[0]_0\ : out STD_LOGIC;
    \RXSTATES_reg[0]_1\ : out STD_LOGIC;
    \RXSTATES_reg[1]_0\ : out STD_LOGIC;
    TOFILTERd : out STD_LOGIC_VECTOR ( 63 downto 0 );
    TOFILTERI : out STD_LOGIC_VECTOR ( 28 downto 0 );
    donefromrxr : out STD_LOGIC;
    RXOUT_reg : out STD_LOGIC;
    \bs_reg[1]_0\ : out STD_LOGIC;
    E : in STD_LOGIC_VECTOR ( 0 to 0 );
    Tq : in STD_LOGIC;
    CAN_RST : in STD_LOGIC;
    \REC_reg[0]\ : in STD_LOGIC;
    SRST : in STD_LOGIC;
    IDE_reg_0 : in STD_LOGIC;
    \RXSTATES_reg[0]_2\ : in STD_LOGIC;
    \RXSTATES_reg[0]_3\ : in STD_LOGIC;
    \CNT2_reg[3]\ : in STD_LOGIC;
    \CNT2_reg[3]_0\ : in STD_LOGIC;
    imTX : in STD_LOGIC;
    \RXSTATES_reg[1]_1\ : in STD_LOGIC;
    \RXSTATES_reg[3]_0\ : in STD_LOGIC;
    \CRC_RG_reg[14]\ : in STD_LOGIC;
    \Cnt[0]_i_2__0_0\ : in STD_LOGIC_VECTOR ( 2 downto 0 );
    \bs_reg[0]_0\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    Sampled_din : in STD_LOGIC;
    \TOFILTERI_reg[28]_0\ : in STD_LOGIC;
    \RXSTATES_reg[3]_1\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    D : in STD_LOGIC_VECTOR ( 0 to 0 );
    \Cnt_reg[0]_0\ : in STD_LOGIC_VECTOR ( 0 to 0 )
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of design_1_FPGAPROJECT_0_0_RXMachine_6 : entity is "RXMachine";
end design_1_FPGAPROJECT_0_0_RXMachine_6;

architecture STRUCTURE of design_1_FPGAPROJECT_0_0_RXMachine_6 is
  signal AckTakeOver_i_1_n_0 : STD_LOGIC;
  signal AckTakeOver_i_2_n_0 : STD_LOGIC;
  signal \^can_rst_0\ : STD_LOGIC;
  signal \Cnt[0]_i_1__0_n_0\ : STD_LOGIC;
  signal \Cnt[0]_i_2__0_n_0\ : STD_LOGIC;
  signal \Cnt[0]_i_3__0_n_0\ : STD_LOGIC;
  signal \Cnt[0]_i_4__0_n_0\ : STD_LOGIC;
  signal \Cnt[0]_i_5__0_n_0\ : STD_LOGIC;
  signal \Cnt[0]_i_6_n_0\ : STD_LOGIC;
  signal \Cnt[1]_i_1__0_n_0\ : STD_LOGIC;
  signal \Cnt[1]_i_2__0_n_0\ : STD_LOGIC;
  signal \Cnt[1]_i_3__0_n_0\ : STD_LOGIC;
  signal \Cnt[1]_i_4_n_0\ : STD_LOGIC;
  signal \Cnt[1]_i_5__0_n_0\ : STD_LOGIC;
  signal \Cnt[1]_i_6_n_0\ : STD_LOGIC;
  signal \Cnt[2]_i_1_n_0\ : STD_LOGIC;
  signal \Cnt[2]_i_2_n_0\ : STD_LOGIC;
  signal \Cnt[2]_i_3_n_0\ : STD_LOGIC;
  signal \Cnt[2]_i_4__0_n_0\ : STD_LOGIC;
  signal \Cnt[2]_i_5_n_0\ : STD_LOGIC;
  signal \Cnt[2]_i_6_n_0\ : STD_LOGIC;
  signal \Cnt[3]_i_1_n_0\ : STD_LOGIC;
  signal \Cnt[3]_i_2_n_0\ : STD_LOGIC;
  signal \Cnt[3]_i_3__0_n_0\ : STD_LOGIC;
  signal \Cnt[3]_i_4__0_n_0\ : STD_LOGIC;
  signal \Cnt[3]_i_5__1_n_0\ : STD_LOGIC;
  signal \Cnt[4]_i_1_n_0\ : STD_LOGIC;
  signal \Cnt[4]_i_2_n_0\ : STD_LOGIC;
  signal \Cnt[4]_i_3_n_0\ : STD_LOGIC;
  signal \Cnt[4]_i_4_n_0\ : STD_LOGIC;
  signal \Cnt[4]_i_5__0_n_0\ : STD_LOGIC;
  signal \Cnt[4]_i_6_n_0\ : STD_LOGIC;
  signal \Cnt[4]_i_7__0_n_0\ : STD_LOGIC;
  signal \Cnt[5]_i_2_n_0\ : STD_LOGIC;
  signal \Cnt[5]_i_3__0_n_0\ : STD_LOGIC;
  signal \Cnt[5]_i_4_n_0\ : STD_LOGIC;
  signal \Cnt[5]_i_5__0_n_0\ : STD_LOGIC;
  signal \Cnt[5]_i_6__0_n_0\ : STD_LOGIC;
  signal \Cnt[5]_i_7__0_n_0\ : STD_LOGIC;
  signal \Cnt[5]_i_8__0_n_0\ : STD_LOGIC;
  signal \Cnt[5]_i_9__0_n_0\ : STD_LOGIC;
  signal \Cnt_reg_n_0_[0]\ : STD_LOGIC;
  signal \Cnt_reg_n_0_[1]\ : STD_LOGIC;
  signal \Cnt_reg_n_0_[2]\ : STD_LOGIC;
  signal \Cnt_reg_n_0_[3]\ : STD_LOGIC;
  signal \Cnt_reg_n_0_[4]\ : STD_LOGIC;
  signal \Cnt_reg_n_0_[5]\ : STD_LOGIC;
  signal \D_Len[0]_i_1_n_0\ : STD_LOGIC;
  signal \D_Len[1]_i_1_n_0\ : STD_LOGIC;
  signal \D_Len[2]_i_1_n_0\ : STD_LOGIC;
  signal \D_Len[3]_i_1_n_0\ : STD_LOGIC;
  signal \D_Len[3]_i_2_n_0\ : STD_LOGIC;
  signal \D_Len[3]_i_3_n_0\ : STD_LOGIC;
  signal \^d_len_reg[3]_0\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal I56 : STD_LOGIC_VECTOR ( 5 downto 0 );
  signal I59 : STD_LOGIC;
  signal IDE1_out : STD_LOGIC;
  signal IDE_i_1_n_0 : STD_LOGIC;
  signal IDE_i_3_n_0 : STD_LOGIC;
  signal IDE_i_4_n_0 : STD_LOGIC;
  signal \^ide_rec\ : STD_LOGIC;
  signal \^q\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal RTR_i_1_n_0 : STD_LOGIC;
  signal RTR_i_4_n_0 : STD_LOGIC;
  signal \^rtr_reg_0\ : STD_LOGIC;
  signal RXSTATES : STD_LOGIC_VECTOR ( 2 downto 0 );
  signal \RXSTATES[0]_i_1_n_0\ : STD_LOGIC;
  signal \RXSTATES[0]_i_3_n_0\ : STD_LOGIC;
  signal \RXSTATES[0]_i_4_n_0\ : STD_LOGIC;
  signal \RXSTATES[0]_i_6_n_0\ : STD_LOGIC;
  signal \RXSTATES[0]_i_7_n_0\ : STD_LOGIC;
  signal \RXSTATES[0]_i_8_n_0\ : STD_LOGIC;
  signal \RXSTATES[2]_i_1_n_0\ : STD_LOGIC;
  signal \RXSTATES[2]_i_2_n_0\ : STD_LOGIC;
  signal \RXSTATES[2]_i_3_n_0\ : STD_LOGIC;
  signal \RXSTATES[2]_i_4_n_0\ : STD_LOGIC;
  signal \RXSTATES[3]_i_2_n_0\ : STD_LOGIC;
  signal \^rxstates_reg[1]_0\ : STD_LOGIC;
  signal \^tofilteri\ : STD_LOGIC_VECTOR ( 28 downto 0 );
  signal \TOFILTERI[10]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERI[11]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERI[12]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERI[13]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERI[14]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERI[15]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERI[16]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERI[17]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERI[18]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERI[19]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERI[1]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERI[20]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERI[21]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERI[22]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERI[23]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERI[24]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERI[25]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERI[26]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERI[27]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERI[28]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERI[28]_i_2_n_0\ : STD_LOGIC;
  signal \TOFILTERI[28]_i_3_n_0\ : STD_LOGIC;
  signal \TOFILTERI[28]_i_4_n_0\ : STD_LOGIC;
  signal \TOFILTERI[28]_i_5_n_0\ : STD_LOGIC;
  signal \TOFILTERI[28]_i_6_n_0\ : STD_LOGIC;
  signal \TOFILTERI[2]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERI[3]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERI[4]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERI[5]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERI[6]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERI[7]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERI[8]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERI[9]_i_1_n_0\ : STD_LOGIC;
  signal \^tofilterd\ : STD_LOGIC_VECTOR ( 63 downto 0 );
  signal \TOFILTERd[0]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[10]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[11]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[12]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[13]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[14]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[15]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[16]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[17]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[18]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[19]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[1]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[20]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[21]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[22]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[23]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[24]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[25]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[26]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[27]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[28]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[29]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[2]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[30]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[31]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[32]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[33]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[34]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[35]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[36]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[37]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[38]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[39]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[3]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[40]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[41]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[42]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[43]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[44]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[45]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[46]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[47]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[48]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[49]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[4]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[50]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[51]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[52]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[53]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[54]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[55]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[56]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[57]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[58]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[59]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[5]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[60]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[61]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[62]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[63]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[63]_i_2_n_0\ : STD_LOGIC;
  signal \TOFILTERd[6]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[7]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[8]_i_1_n_0\ : STD_LOGIC;
  signal \TOFILTERd[9]_i_1_n_0\ : STD_LOGIC;
  signal bs : STD_LOGIC_VECTOR ( 5 downto 0 );
  signal \done_i_1__0_n_0\ : STD_LOGIC;
  signal done_i_3_n_0 : STD_LOGIC;
  signal \^done_reg_0\ : STD_LOGIC;
  signal \^req_error_rx\ : STD_LOGIC;
  signal req_Error_i_2_n_0 : STD_LOGIC;
  signal req_Error_i_4_n_0 : STD_LOGIC;
  signal req_Error_i_5_n_0 : STD_LOGIC;
  signal req_Error_i_6_n_0 : STD_LOGIC;
  signal req_Error_i_8_n_0 : STD_LOGIC;
  signal rxcrc_n_1 : STD_LOGIC;
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of AckTakeOver_i_2 : label is "soft_lutpair82";
  attribute SOFT_HLUTNM of \Cnt[0]_i_4__0\ : label is "soft_lutpair86";
  attribute SOFT_HLUTNM of \Cnt[1]_i_2__0\ : label is "soft_lutpair84";
  attribute SOFT_HLUTNM of \Cnt[1]_i_5__0\ : label is "soft_lutpair72";
  attribute SOFT_HLUTNM of \Cnt[1]_i_6\ : label is "soft_lutpair83";
  attribute SOFT_HLUTNM of \Cnt[2]_i_3\ : label is "soft_lutpair85";
  attribute SOFT_HLUTNM of \Cnt[2]_i_4__0\ : label is "soft_lutpair84";
  attribute SOFT_HLUTNM of \Cnt[2]_i_5\ : label is "soft_lutpair74";
  attribute SOFT_HLUTNM of \Cnt[3]_i_5__1\ : label is "soft_lutpair77";
  attribute SOFT_HLUTNM of \Cnt[4]_i_2\ : label is "soft_lutpair78";
  attribute SOFT_HLUTNM of \Cnt[4]_i_3\ : label is "soft_lutpair72";
  attribute SOFT_HLUTNM of \Cnt[4]_i_5__0\ : label is "soft_lutpair83";
  attribute SOFT_HLUTNM of \Cnt[4]_i_6\ : label is "soft_lutpair74";
  attribute SOFT_HLUTNM of \Cnt[5]_i_3__0\ : label is "soft_lutpair86";
  attribute SOFT_HLUTNM of \Cnt[5]_i_4\ : label is "soft_lutpair85";
  attribute SOFT_HLUTNM of \Cnt[5]_i_6__0\ : label is "soft_lutpair73";
  attribute SOFT_HLUTNM of \Cnt[5]_i_9__0\ : label is "soft_lutpair87";
  attribute SOFT_HLUTNM of IDE_i_3 : label is "soft_lutpair75";
  attribute SOFT_HLUTNM of \RXSTATES[2]_i_4\ : label is "soft_lutpair87";
  attribute SOFT_HLUTNM of \State[0]_i_5\ : label is "soft_lutpair82";
  attribute SOFT_HLUTNM of \TOFILTERI[28]_i_5\ : label is "soft_lutpair79";
  attribute SOFT_HLUTNM of \bs[0]_i_1\ : label is "soft_lutpair71";
  attribute SOFT_HLUTNM of \bs[2]_i_1\ : label is "soft_lutpair76";
  attribute SOFT_HLUTNM of \bs[3]_i_1\ : label is "soft_lutpair77";
  attribute SOFT_HLUTNM of \bs[4]_i_1\ : label is "soft_lutpair78";
  attribute SOFT_HLUTNM of \bs[5]_i_1\ : label is "soft_lutpair79";
  attribute SOFT_HLUTNM of done_i_15 : label is "soft_lutpair71";
  attribute SOFT_HLUTNM of \done_i_1__0\ : label is "soft_lutpair81";
  attribute SOFT_HLUTNM of \done_i_4__0\ : label is "soft_lutpair76";
  attribute SOFT_HLUTNM of donefromrxr_i_1 : label is "soft_lutpair81";
  attribute SOFT_HLUTNM of req_Error_i_4 : label is "soft_lutpair75";
  attribute SOFT_HLUTNM of req_Error_i_5 : label is "soft_lutpair80";
  attribute SOFT_HLUTNM of req_Error_i_6 : label is "soft_lutpair80";
  attribute SOFT_HLUTNM of req_Error_i_8 : label is "soft_lutpair73";
begin
  CAN_RST_0 <= \^can_rst_0\;
  \D_Len_reg[3]_0\(3 downto 0) <= \^d_len_reg[3]_0\(3 downto 0);
  IDE_rec <= \^ide_rec\;
  Q(0) <= \^q\(0);
  RTR_reg_0 <= \^rtr_reg_0\;
  \RXSTATES_reg[1]_0\ <= \^rxstates_reg[1]_0\;
  TOFILTERI(28 downto 0) <= \^tofilteri\(28 downto 0);
  TOFILTERd(63 downto 0) <= \^tofilterd\(63 downto 0);
  done_reg_0 <= \^done_reg_0\;
  req_Error_RX <= \^req_error_rx\;
AckTakeOver_i_1: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFDFFF"
    )
        port map (
      I0 => RXSTATES(2),
      I1 => \^q\(0),
      I2 => AckTakeOver_i_2_n_0,
      I3 => SRST,
      I4 => imTX,
      I5 => \^req_error_rx\,
      O => AckTakeOver_i_1_n_0
    );
AckTakeOver_i_2: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => RXSTATES(0),
      I1 => RXSTATES(1),
      O => AckTakeOver_i_2_n_0
    );
AckTakeOver_reg: unisim.vcomponents.FDPE
     port map (
      C => Tq,
      CE => E(0),
      D => AckTakeOver_i_1_n_0,
      PRE => \^can_rst_0\,
      Q => AckTakeOver
    );
\CNT2[3]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFF00010000"
    )
        port map (
      I0 => RXSTATES(2),
      I1 => \^q\(0),
      I2 => RXSTATES(0),
      I3 => RXSTATES(1),
      I4 => \CNT2_reg[3]\,
      I5 => \CNT2_reg[3]_0\,
      O => \RXSTATES_reg[2]_0\(0)
    );
\Cnt[0]_i_1__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"888888888A8A888A"
    )
        port map (
      I0 => SRST,
      I1 => \Cnt[0]_i_2__0_n_0\,
      I2 => \Cnt[0]_i_3__0_n_0\,
      I3 => \Cnt[0]_i_4__0_n_0\,
      I4 => \Cnt[0]_i_5__0_n_0\,
      I5 => \^q\(0),
      O => \Cnt[0]_i_1__0_n_0\
    );
\Cnt[0]_i_2__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAABAAAAAAFAAAAA"
    )
        port map (
      I0 => \Cnt[0]_i_6_n_0\,
      I1 => \RXSTATES[2]_i_3_n_0\,
      I2 => RXSTATES(0),
      I3 => \Cnt_reg_n_0_[0]\,
      I4 => \Cnt[1]_i_6_n_0\,
      I5 => RXSTATES(1),
      O => \Cnt[0]_i_2__0_n_0\
    );
\Cnt[0]_i_3__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FF2E0000FFAA00FF"
    )
        port map (
      I0 => \Cnt_reg_n_0_[0]\,
      I1 => \RXSTATES[2]_i_3_n_0\,
      I2 => \RXSTATES[0]_i_7_n_0\,
      I3 => RXSTATES(2),
      I4 => RXSTATES(1),
      I5 => RXSTATES(0),
      O => \Cnt[0]_i_3__0_n_0\
    );
\Cnt[0]_i_4__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => RXSTATES(2),
      I1 => RXSTATES(1),
      O => \Cnt[0]_i_4__0_n_0\
    );
\Cnt[0]_i_5__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0F0F0F0F0F0F0F0E"
    )
        port map (
      I0 => \Cnt_reg_n_0_[5]\,
      I1 => \Cnt_reg_n_0_[4]\,
      I2 => \Cnt_reg_n_0_[0]\,
      I3 => \Cnt_reg_n_0_[1]\,
      I4 => \Cnt_reg_n_0_[2]\,
      I5 => \Cnt_reg_n_0_[3]\,
      O => \Cnt[0]_i_5__0_n_0\
    );
\Cnt[0]_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8008888888880008"
    )
        port map (
      I0 => \^q\(0),
      I1 => \Cnt[0]_i_4__0_n_0\,
      I2 => \Cnt[0]_i_2__0_0\(0),
      I3 => \Cnt[0]_i_2__0_0\(1),
      I4 => \Cnt[0]_i_2__0_0\(2),
      I5 => \Cnt[1]_i_5__0_n_0\,
      O => \Cnt[0]_i_6_n_0\
    );
\Cnt[1]_i_1__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000AA08AAAAAAAA"
    )
        port map (
      I0 => SRST,
      I1 => \Cnt[4]_i_3_n_0\,
      I2 => \Cnt[1]_i_2__0_n_0\,
      I3 => \Cnt[4]_i_2_n_0\,
      I4 => \Cnt[1]_i_3__0_n_0\,
      I5 => \Cnt[1]_i_4_n_0\,
      O => \Cnt[1]_i_1__0_n_0\
    );
\Cnt[1]_i_2__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"4FF4"
    )
        port map (
      I0 => RXSTATES(0),
      I1 => \RXSTATES[2]_i_3_n_0\,
      I2 => \Cnt_reg_n_0_[0]\,
      I3 => \Cnt_reg_n_0_[1]\,
      O => \Cnt[1]_i_2__0_n_0\
    );
\Cnt[1]_i_3__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BBBBAFFAAAAAAAAA"
    )
        port map (
      I0 => \^q\(0),
      I1 => \Cnt[1]_i_5__0_n_0\,
      I2 => \Cnt_reg_n_0_[1]\,
      I3 => \Cnt_reg_n_0_[0]\,
      I4 => \RXSTATES[2]_i_3_n_0\,
      I5 => \Cnt[0]_i_4__0_n_0\,
      O => \Cnt[1]_i_3__0_n_0\
    );
\Cnt[1]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFDFFDDFFD5555"
    )
        port map (
      I0 => \Cnt[1]_i_6_n_0\,
      I1 => \RXSTATES[2]_i_3_n_0\,
      I2 => \Cnt_reg_n_0_[0]\,
      I3 => \Cnt_reg_n_0_[1]\,
      I4 => RXSTATES(0),
      I5 => RXSTATES(1),
      O => \Cnt[1]_i_4_n_0\
    );
\Cnt[1]_i_5__0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8A"
    )
        port map (
      I0 => RXSTATES(2),
      I1 => RXSTATES(1),
      I2 => RXSTATES(0),
      O => \Cnt[1]_i_5__0_n_0\
    );
\Cnt[1]_i_6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \^q\(0),
      I1 => RXSTATES(2),
      O => \Cnt[1]_i_6_n_0\
    );
\Cnt[2]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"88888888AAAAA8AA"
    )
        port map (
      I0 => SRST,
      I1 => \Cnt[2]_i_2_n_0\,
      I2 => \Cnt[2]_i_3_n_0\,
      I3 => RXSTATES(1),
      I4 => \Cnt[2]_i_4__0_n_0\,
      I5 => \Cnt[2]_i_5_n_0\,
      O => \Cnt[2]_i_1_n_0\
    );
\Cnt[2]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"121A121A00120002"
    )
        port map (
      I0 => \^q\(0),
      I1 => RXSTATES(1),
      I2 => RXSTATES(2),
      I3 => RXSTATES(0),
      I4 => \RXSTATES[2]_i_3_n_0\,
      I5 => \Cnt[2]_i_6_n_0\,
      O => \Cnt[2]_i_2_n_0\
    );
\Cnt[2]_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"04"
    )
        port map (
      I0 => \RXSTATES[0]_i_8_n_0\,
      I1 => IDE_reg_0,
      I2 => RXSTATES(0),
      O => \Cnt[2]_i_3_n_0\
    );
\Cnt[2]_i_4__0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"A9"
    )
        port map (
      I0 => \Cnt_reg_n_0_[2]\,
      I1 => \Cnt_reg_n_0_[0]\,
      I2 => \Cnt_reg_n_0_[1]\,
      O => \Cnt[2]_i_4__0_n_0\
    );
\Cnt[2]_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFF1"
    )
        port map (
      I0 => RXSTATES(1),
      I1 => RXSTATES(0),
      I2 => \^q\(0),
      I3 => RXSTATES(2),
      O => \Cnt[2]_i_5_n_0\
    );
\Cnt[2]_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFF0000FFFF0000E"
    )
        port map (
      I0 => \Cnt_reg_n_0_[5]\,
      I1 => \Cnt_reg_n_0_[4]\,
      I2 => \Cnt_reg_n_0_[0]\,
      I3 => \Cnt_reg_n_0_[1]\,
      I4 => \Cnt_reg_n_0_[2]\,
      I5 => \Cnt_reg_n_0_[3]\,
      O => \Cnt[2]_i_6_n_0\
    );
\Cnt[3]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000088A800AA88AA"
    )
        port map (
      I0 => SRST,
      I1 => \Cnt[3]_i_2_n_0\,
      I2 => \Cnt[4]_i_3_n_0\,
      I3 => \Cnt[3]_i_3__0_n_0\,
      I4 => \Cnt[3]_i_4__0_n_0\,
      I5 => \Cnt[3]_i_5__1_n_0\,
      O => \Cnt[3]_i_1_n_0\
    );
\Cnt[3]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"7232323272327232"
    )
        port map (
      I0 => RXSTATES(2),
      I1 => RXSTATES(1),
      I2 => RXSTATES(0),
      I3 => \RXSTATES[2]_i_3_n_0\,
      I4 => IDE_reg_0,
      I5 => \RXSTATES[0]_i_7_n_0\,
      O => \Cnt[3]_i_2_n_0\
    );
\Cnt[3]_i_3__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000FFFFFFFF1"
    )
        port map (
      I0 => \Cnt_reg_n_0_[5]\,
      I1 => \Cnt_reg_n_0_[4]\,
      I2 => \Cnt_reg_n_0_[0]\,
      I3 => \Cnt_reg_n_0_[1]\,
      I4 => \Cnt_reg_n_0_[2]\,
      I5 => \Cnt_reg_n_0_[3]\,
      O => \Cnt[3]_i_3__0_n_0\
    );
\Cnt[3]_i_4__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AEAAAEAEAAAAAAAA"
    )
        port map (
      I0 => \^q\(0),
      I1 => RXSTATES(2),
      I2 => RXSTATES(1),
      I3 => RXSTATES(0),
      I4 => \RXSTATES[2]_i_3_n_0\,
      I5 => \Cnt[3]_i_3__0_n_0\,
      O => \Cnt[3]_i_4__0_n_0\
    );
\Cnt[3]_i_5__1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FF9F"
    )
        port map (
      I0 => RXSTATES(0),
      I1 => RXSTATES(1),
      I2 => \^q\(0),
      I3 => RXSTATES(2),
      O => \Cnt[3]_i_5__1_n_0\
    );
\Cnt[4]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000088A8AAAAAAAA"
    )
        port map (
      I0 => SRST,
      I1 => \Cnt[4]_i_2_n_0\,
      I2 => \Cnt[4]_i_3_n_0\,
      I3 => \Cnt[4]_i_4_n_0\,
      I4 => \Cnt[4]_i_5__0_n_0\,
      I5 => \Cnt[4]_i_6_n_0\,
      O => \Cnt[4]_i_1_n_0\
    );
\Cnt[4]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"32"
    )
        port map (
      I0 => RXSTATES(0),
      I1 => RXSTATES(1),
      I2 => RXSTATES(2),
      O => \Cnt[4]_i_2_n_0\
    );
\Cnt[4]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"44444044"
    )
        port map (
      I0 => RXSTATES(2),
      I1 => RXSTATES(1),
      I2 => RXSTATES(0),
      I3 => IDE_reg_0,
      I4 => \RXSTATES[0]_i_8_n_0\,
      O => \Cnt[4]_i_3_n_0\
    );
\Cnt[4]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAA2AAA2AAAAAAA"
    )
        port map (
      I0 => \Cnt[4]_i_7__0_n_0\,
      I1 => \RXSTATES[0]_i_7_n_0\,
      I2 => RXSTATES(0),
      I3 => \RXSTATES[2]_i_3_n_0\,
      I4 => \^d_len_reg[3]_0\(0),
      I5 => IDE_reg_0,
      O => \Cnt[4]_i_4_n_0\
    );
\Cnt[4]_i_5__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"AAEA"
    )
        port map (
      I0 => \^q\(0),
      I1 => \Cnt[4]_i_7__0_n_0\,
      I2 => RXSTATES(2),
      I3 => RXSTATES(1),
      O => \Cnt[4]_i_5__0_n_0\
    );
\Cnt[4]_i_6\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFFBBF"
    )
        port map (
      I0 => RXSTATES(2),
      I1 => \^q\(0),
      I2 => RXSTATES(1),
      I3 => RXSTATES(0),
      I4 => \Cnt[4]_i_7__0_n_0\,
      O => \Cnt[4]_i_6_n_0\
    );
\Cnt[4]_i_7__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000003FFFFFFFD"
    )
        port map (
      I0 => \Cnt_reg_n_0_[5]\,
      I1 => \Cnt_reg_n_0_[3]\,
      I2 => \Cnt_reg_n_0_[2]\,
      I3 => \Cnt_reg_n_0_[1]\,
      I4 => \Cnt_reg_n_0_[0]\,
      I5 => \Cnt_reg_n_0_[4]\,
      O => \Cnt[4]_i_7__0_n_0\
    );
\Cnt[5]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"20202022AAAAAAAA"
    )
        port map (
      I0 => SRST,
      I1 => \^q\(0),
      I2 => \Cnt[5]_i_3__0_n_0\,
      I3 => \Cnt[5]_i_4_n_0\,
      I4 => \Cnt[5]_i_5__0_n_0\,
      I5 => \Cnt[5]_i_6__0_n_0\,
      O => \Cnt[5]_i_2_n_0\
    );
\Cnt[5]_i_3__0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"40"
    )
        port map (
      I0 => RXSTATES(1),
      I1 => RXSTATES(2),
      I2 => \Cnt[5]_i_7__0_n_0\,
      O => \Cnt[5]_i_3__0_n_0\
    );
\Cnt[5]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => RXSTATES(0),
      I1 => \Cnt[5]_i_7__0_n_0\,
      O => \Cnt[5]_i_4_n_0\
    );
\Cnt[5]_i_5__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"04515555FFFFFFFF"
    )
        port map (
      I0 => \Cnt[5]_i_7__0_n_0\,
      I1 => IDE_reg_0,
      I2 => \^d_len_reg[3]_0\(0),
      I3 => \^d_len_reg[3]_0\(1),
      I4 => \Cnt[5]_i_8__0_n_0\,
      I5 => \Cnt[5]_i_9__0_n_0\,
      O => \Cnt[5]_i_5__0_n_0\
    );
\Cnt[5]_i_6__0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FBBFFFFF"
    )
        port map (
      I0 => RXSTATES(2),
      I1 => \^q\(0),
      I2 => RXSTATES(1),
      I3 => RXSTATES(0),
      I4 => \Cnt[5]_i_7__0_n_0\,
      O => \Cnt[5]_i_6__0_n_0\
    );
\Cnt[5]_i_7__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAAAAAAAAAAAA8"
    )
        port map (
      I0 => \Cnt_reg_n_0_[5]\,
      I1 => \Cnt_reg_n_0_[3]\,
      I2 => \Cnt_reg_n_0_[2]\,
      I3 => \Cnt_reg_n_0_[1]\,
      I4 => \Cnt_reg_n_0_[0]\,
      I5 => \Cnt_reg_n_0_[4]\,
      O => \Cnt[5]_i_7__0_n_0\
    );
\Cnt[5]_i_8__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000AAAAAAA8"
    )
        port map (
      I0 => \RXSTATES[2]_i_3_n_0\,
      I1 => \^d_len_reg[3]_0\(3),
      I2 => \^d_len_reg[3]_0\(1),
      I3 => \^d_len_reg[3]_0\(2),
      I4 => \^d_len_reg[3]_0\(0),
      I5 => \^rtr_reg_0\,
      O => \Cnt[5]_i_8__0_n_0\
    );
\Cnt[5]_i_9__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => RXSTATES(1),
      I1 => RXSTATES(2),
      O => \Cnt[5]_i_9__0_n_0\
    );
\Cnt_reg[0]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \Cnt_reg[0]_0\(0),
      CLR => \^can_rst_0\,
      D => \Cnt[0]_i_1__0_n_0\,
      Q => \Cnt_reg_n_0_[0]\
    );
\Cnt_reg[1]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \Cnt_reg[0]_0\(0),
      CLR => \^can_rst_0\,
      D => \Cnt[1]_i_1__0_n_0\,
      Q => \Cnt_reg_n_0_[1]\
    );
\Cnt_reg[2]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \Cnt_reg[0]_0\(0),
      CLR => \^can_rst_0\,
      D => \Cnt[2]_i_1_n_0\,
      Q => \Cnt_reg_n_0_[2]\
    );
\Cnt_reg[3]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \Cnt_reg[0]_0\(0),
      CLR => \^can_rst_0\,
      D => \Cnt[3]_i_1_n_0\,
      Q => \Cnt_reg_n_0_[3]\
    );
\Cnt_reg[4]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \Cnt_reg[0]_0\(0),
      CLR => \^can_rst_0\,
      D => \Cnt[4]_i_1_n_0\,
      Q => \Cnt_reg_n_0_[4]\
    );
\Cnt_reg[5]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \Cnt_reg[0]_0\(0),
      CLR => \^can_rst_0\,
      D => \Cnt[5]_i_2_n_0\,
      Q => \Cnt_reg_n_0_[5]\
    );
\D_Len[0]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000400000"
    )
        port map (
      I0 => IDE_reg_0,
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => \^q\(0),
      I4 => SRST,
      I5 => RXSTATES(2),
      O => \D_Len[0]_i_1_n_0\
    );
\D_Len[1]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000800000"
    )
        port map (
      I0 => \^d_len_reg[3]_0\(0),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => \^q\(0),
      I4 => SRST,
      I5 => RXSTATES(2),
      O => \D_Len[1]_i_1_n_0\
    );
\D_Len[2]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000800000"
    )
        port map (
      I0 => \^d_len_reg[3]_0\(1),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => \^q\(0),
      I4 => SRST,
      I5 => RXSTATES(2),
      O => \D_Len[2]_i_1_n_0\
    );
\D_Len[3]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"4F"
    )
        port map (
      I0 => \D_Len[3]_i_3_n_0\,
      I1 => \CRC_RG_reg[14]\,
      I2 => SRST,
      O => \D_Len[3]_i_1_n_0\
    );
\D_Len[3]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000800000"
    )
        port map (
      I0 => \^d_len_reg[3]_0\(2),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => \^q\(0),
      I4 => SRST,
      I5 => RXSTATES(2),
      O => \D_Len[3]_i_2_n_0\
    );
\D_Len[3]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFF4FFF0FFFFFFF0"
    )
        port map (
      I0 => \Cnt_reg_n_0_[1]\,
      I1 => \Cnt_reg_n_0_[2]\,
      I2 => RXSTATES(2),
      I3 => \^q\(0),
      I4 => RXSTATES(1),
      I5 => RXSTATES(0),
      O => \D_Len[3]_i_3_n_0\
    );
\D_Len_reg[0]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \D_Len[3]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \D_Len[0]_i_1_n_0\,
      Q => \^d_len_reg[3]_0\(0)
    );
\D_Len_reg[1]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \D_Len[3]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \D_Len[1]_i_1_n_0\,
      Q => \^d_len_reg[3]_0\(1)
    );
\D_Len_reg[2]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \D_Len[3]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \D_Len[2]_i_1_n_0\,
      Q => \^d_len_reg[3]_0\(2)
    );
\D_Len_reg[3]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \D_Len[3]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \D_Len[3]_i_2_n_0\,
      Q => \^d_len_reg[3]_0\(3)
    );
IDE_i_1: unisim.vcomponents.LUT5
    generic map(
      INIT => X"1F111011"
    )
        port map (
      I0 => IDE_reg_0,
      I1 => IDE_i_3_n_0,
      I2 => IDE_i_4_n_0,
      I3 => SRST,
      I4 => \^ide_rec\,
      O => IDE_i_1_n_0
    );
IDE_i_3: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFFFDF"
    )
        port map (
      I0 => SRST,
      I1 => RXSTATES(2),
      I2 => RXSTATES(1),
      I3 => RXSTATES(0),
      I4 => \^q\(0),
      O => IDE_i_3_n_0
    );
IDE_i_4: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000044400000044"
    )
        port map (
      I0 => \^q\(0),
      I1 => \CRC_RG_reg[14]\,
      I2 => RXSTATES(0),
      I3 => RXSTATES(1),
      I4 => RXSTATES(2),
      I5 => \TOFILTERI[28]_i_4_n_0\,
      O => IDE_i_4_n_0
    );
IDE_reg: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => '1',
      CLR => \^can_rst_0\,
      D => IDE_i_1_n_0,
      Q => \^ide_rec\
    );
\REC[0]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \^req_error_rx\,
      I1 => \REC_reg[0]\,
      O => req_Error_reg_0
    );
RTR_i_1: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFF400B0"
    )
        port map (
      I0 => \CRC_RG_reg[14]\,
      I1 => SRST,
      I2 => I59,
      I3 => RTR_i_4_n_0,
      I4 => \^rtr_reg_0\,
      O => RTR_i_1_n_0
    );
RTR_i_3: unisim.vcomponents.LUT6
    generic map(
      INIT => X"555755575557555F"
    )
        port map (
      I0 => SRST,
      I1 => RXSTATES(1),
      I2 => RXSTATES(2),
      I3 => \^q\(0),
      I4 => RXSTATES(0),
      I5 => IDE_reg_0,
      O => I59
    );
RTR_i_4: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAAAA8AAA0AAA0"
    )
        port map (
      I0 => SRST,
      I1 => \TOFILTERI[28]_i_6_n_0\,
      I2 => \^q\(0),
      I3 => RXSTATES(2),
      I4 => RXSTATES(0),
      I5 => RXSTATES(1),
      O => RTR_i_4_n_0
    );
RTR_reg: unisim.vcomponents.FDPE
     port map (
      C => Tq,
      CE => '1',
      D => RTR_i_1_n_0,
      PRE => \^can_rst_0\,
      Q => \^rtr_reg_0\
    );
\RXSTATES[0]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAAAAA80888080"
    )
        port map (
      I0 => SRST,
      I1 => \RXSTATES_reg[0]_2\,
      I2 => \RXSTATES[0]_i_3_n_0\,
      I3 => \RXSTATES[0]_i_4_n_0\,
      I4 => \RXSTATES[2]_i_4_n_0\,
      I5 => \RXSTATES_reg[0]_3\,
      O => \RXSTATES[0]_i_1_n_0\
    );
\RXSTATES[0]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFF00810000"
    )
        port map (
      I0 => RXSTATES(0),
      I1 => RXSTATES(1),
      I2 => \^q\(0),
      I3 => RXSTATES(2),
      I4 => IDE_reg_0,
      I5 => \RXSTATES[0]_i_6_n_0\,
      O => \RXSTATES[0]_i_3_n_0\
    );
\RXSTATES[0]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8888FFFF3033FFFF"
    )
        port map (
      I0 => \RXSTATES[0]_i_7_n_0\,
      I1 => \RXSTATES[2]_i_3_n_0\,
      I2 => \RXSTATES[0]_i_8_n_0\,
      I3 => IDE_reg_0,
      I4 => RXSTATES(1),
      I5 => RXSTATES(0),
      O => \RXSTATES[0]_i_4_n_0\
    );
\RXSTATES[0]_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"301E1B00001E1B00"
    )
        port map (
      I0 => \RXSTATES[2]_i_3_n_0\,
      I1 => RXSTATES(1),
      I2 => RXSTATES(0),
      I3 => \^q\(0),
      I4 => RXSTATES(2),
      I5 => \RXSTATES_reg[1]_1\,
      O => \RXSTATES[0]_i_6_n_0\
    );
\RXSTATES[0]_i_7\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"55555554"
    )
        port map (
      I0 => \^rtr_reg_0\,
      I1 => \^d_len_reg[3]_0\(0),
      I2 => \^d_len_reg[3]_0\(2),
      I3 => \^d_len_reg[3]_0\(1),
      I4 => \^d_len_reg[3]_0\(3),
      O => \RXSTATES[0]_i_7_n_0\
    );
\RXSTATES[0]_i_8\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFEFFFFF"
    )
        port map (
      I0 => \Cnt_reg_n_0_[1]\,
      I1 => \Cnt_reg_n_0_[0]\,
      I2 => \Cnt_reg_n_0_[2]\,
      I3 => \Cnt_reg_n_0_[5]\,
      I4 => \Cnt_reg_n_0_[4]\,
      I5 => \Cnt_reg_n_0_[3]\,
      O => \RXSTATES[0]_i_8_n_0\
    );
\RXSTATES[1]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F8C3C3C3F8CFCF03"
    )
        port map (
      I0 => \RXSTATES_reg[1]_1\,
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => RXSTATES(2),
      I4 => \^q\(0),
      I5 => \RXSTATES[2]_i_3_n_0\,
      O => \RXSTATES_reg[0]_0\
    );
\RXSTATES[2]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"A888888888888888"
    )
        port map (
      I0 => SRST,
      I1 => \RXSTATES[2]_i_2_n_0\,
      I2 => \RXSTATES[2]_i_3_n_0\,
      I3 => RXSTATES(0),
      I4 => RXSTATES(1),
      I5 => \RXSTATES[2]_i_4_n_0\,
      O => \RXSTATES[2]_i_1_n_0\
    );
\RXSTATES[2]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"55F5757555757575"
    )
        port map (
      I0 => \RXSTATES_reg[3]_0\,
      I1 => \^q\(0),
      I2 => RXSTATES(2),
      I3 => RXSTATES(1),
      I4 => RXSTATES(0),
      I5 => \RXSTATES_reg[1]_1\,
      O => \RXSTATES[2]_i_2_n_0\
    );
\RXSTATES[2]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000001"
    )
        port map (
      I0 => \Cnt_reg_n_0_[3]\,
      I1 => \Cnt_reg_n_0_[2]\,
      I2 => \Cnt_reg_n_0_[1]\,
      I3 => \Cnt_reg_n_0_[0]\,
      I4 => \Cnt_reg_n_0_[4]\,
      I5 => \Cnt_reg_n_0_[5]\,
      O => \RXSTATES[2]_i_3_n_0\
    );
\RXSTATES[2]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => RXSTATES(2),
      I1 => \^q\(0),
      O => \RXSTATES[2]_i_4_n_0\
    );
\RXSTATES[3]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0A802A00AAAAAAAA"
    )
        port map (
      I0 => SRST,
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => \^q\(0),
      I4 => RXSTATES(2),
      I5 => \RXSTATES_reg[3]_0\,
      O => \RXSTATES[3]_i_2_n_0\
    );
\RXSTATES_reg[0]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \RXSTATES_reg[3]_1\(0),
      CLR => \^can_rst_0\,
      D => \RXSTATES[0]_i_1_n_0\,
      Q => RXSTATES(0)
    );
\RXSTATES_reg[1]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \RXSTATES_reg[3]_1\(0),
      CLR => \^can_rst_0\,
      D => D(0),
      Q => RXSTATES(1)
    );
\RXSTATES_reg[2]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \RXSTATES_reg[3]_1\(0),
      CLR => \^can_rst_0\,
      D => \RXSTATES[2]_i_1_n_0\,
      Q => RXSTATES(2)
    );
\RXSTATES_reg[3]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \RXSTATES_reg[3]_1\(0),
      CLR => \^can_rst_0\,
      D => \RXSTATES[3]_i_2_n_0\,
      Q => \^q\(0)
    );
\State[0]_i_5\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000400"
    )
        port map (
      I0 => Sampled_din,
      I1 => RXSTATES(1),
      I2 => RXSTATES(0),
      I3 => \^q\(0),
      I4 => RXSTATES(2),
      O => RXOUT_reg
    );
\TOFILTERI[0]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000010000000000"
    )
        port map (
      I0 => IDE_reg_0,
      I1 => \^q\(0),
      I2 => RXSTATES(0),
      I3 => RXSTATES(1),
      I4 => RXSTATES(2),
      I5 => SRST,
      O => IDE1_out
    );
\TOFILTERI[10]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilteri\(9),
      I1 => \^q\(0),
      I2 => RXSTATES(0),
      I3 => RXSTATES(1),
      I4 => RXSTATES(2),
      I5 => SRST,
      O => \TOFILTERI[10]_i_1_n_0\
    );
\TOFILTERI[11]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilteri\(10),
      I1 => \^q\(0),
      I2 => RXSTATES(0),
      I3 => RXSTATES(1),
      I4 => RXSTATES(2),
      I5 => SRST,
      O => \TOFILTERI[11]_i_1_n_0\
    );
\TOFILTERI[12]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilteri\(11),
      I1 => \^q\(0),
      I2 => RXSTATES(0),
      I3 => RXSTATES(1),
      I4 => RXSTATES(2),
      I5 => SRST,
      O => \TOFILTERI[12]_i_1_n_0\
    );
\TOFILTERI[13]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilteri\(12),
      I1 => \^q\(0),
      I2 => RXSTATES(0),
      I3 => RXSTATES(1),
      I4 => RXSTATES(2),
      I5 => SRST,
      O => \TOFILTERI[13]_i_1_n_0\
    );
\TOFILTERI[14]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilteri\(13),
      I1 => \^q\(0),
      I2 => RXSTATES(0),
      I3 => RXSTATES(1),
      I4 => RXSTATES(2),
      I5 => SRST,
      O => \TOFILTERI[14]_i_1_n_0\
    );
\TOFILTERI[15]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilteri\(14),
      I1 => \^q\(0),
      I2 => RXSTATES(0),
      I3 => RXSTATES(1),
      I4 => RXSTATES(2),
      I5 => SRST,
      O => \TOFILTERI[15]_i_1_n_0\
    );
\TOFILTERI[16]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilteri\(15),
      I1 => \^q\(0),
      I2 => RXSTATES(0),
      I3 => RXSTATES(1),
      I4 => RXSTATES(2),
      I5 => SRST,
      O => \TOFILTERI[16]_i_1_n_0\
    );
\TOFILTERI[17]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilteri\(16),
      I1 => \^q\(0),
      I2 => RXSTATES(0),
      I3 => RXSTATES(1),
      I4 => RXSTATES(2),
      I5 => SRST,
      O => \TOFILTERI[17]_i_1_n_0\
    );
\TOFILTERI[18]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilteri\(17),
      I1 => \^q\(0),
      I2 => RXSTATES(0),
      I3 => RXSTATES(1),
      I4 => RXSTATES(2),
      I5 => SRST,
      O => \TOFILTERI[18]_i_1_n_0\
    );
\TOFILTERI[19]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilteri\(18),
      I1 => \^q\(0),
      I2 => RXSTATES(0),
      I3 => RXSTATES(1),
      I4 => RXSTATES(2),
      I5 => SRST,
      O => \TOFILTERI[19]_i_1_n_0\
    );
\TOFILTERI[1]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilteri\(0),
      I1 => \^q\(0),
      I2 => RXSTATES(0),
      I3 => RXSTATES(1),
      I4 => RXSTATES(2),
      I5 => SRST,
      O => \TOFILTERI[1]_i_1_n_0\
    );
\TOFILTERI[20]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilteri\(19),
      I1 => \^q\(0),
      I2 => RXSTATES(0),
      I3 => RXSTATES(1),
      I4 => RXSTATES(2),
      I5 => SRST,
      O => \TOFILTERI[20]_i_1_n_0\
    );
\TOFILTERI[21]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilteri\(20),
      I1 => \^q\(0),
      I2 => RXSTATES(0),
      I3 => RXSTATES(1),
      I4 => RXSTATES(2),
      I5 => SRST,
      O => \TOFILTERI[21]_i_1_n_0\
    );
\TOFILTERI[22]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilteri\(21),
      I1 => \^q\(0),
      I2 => RXSTATES(0),
      I3 => RXSTATES(1),
      I4 => RXSTATES(2),
      I5 => SRST,
      O => \TOFILTERI[22]_i_1_n_0\
    );
\TOFILTERI[23]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilteri\(22),
      I1 => \^q\(0),
      I2 => RXSTATES(0),
      I3 => RXSTATES(1),
      I4 => RXSTATES(2),
      I5 => SRST,
      O => \TOFILTERI[23]_i_1_n_0\
    );
\TOFILTERI[24]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilteri\(23),
      I1 => \^q\(0),
      I2 => RXSTATES(0),
      I3 => RXSTATES(1),
      I4 => RXSTATES(2),
      I5 => SRST,
      O => \TOFILTERI[24]_i_1_n_0\
    );
\TOFILTERI[25]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilteri\(24),
      I1 => \^q\(0),
      I2 => RXSTATES(0),
      I3 => RXSTATES(1),
      I4 => RXSTATES(2),
      I5 => SRST,
      O => \TOFILTERI[25]_i_1_n_0\
    );
\TOFILTERI[26]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilteri\(25),
      I1 => \^q\(0),
      I2 => RXSTATES(0),
      I3 => RXSTATES(1),
      I4 => RXSTATES(2),
      I5 => SRST,
      O => \TOFILTERI[26]_i_1_n_0\
    );
\TOFILTERI[27]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilteri\(26),
      I1 => \^q\(0),
      I2 => RXSTATES(0),
      I3 => RXSTATES(1),
      I4 => RXSTATES(2),
      I5 => SRST,
      O => \TOFILTERI[27]_i_1_n_0\
    );
\TOFILTERI[28]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BAAA0000FFFFFFFF"
    )
        port map (
      I0 => \TOFILTERI[28]_i_3_n_0\,
      I1 => \TOFILTERI[28]_i_4_n_0\,
      I2 => \TOFILTERI[28]_i_5_n_0\,
      I3 => \TOFILTERI[28]_i_6_n_0\,
      I4 => \TOFILTERI_reg[28]_0\,
      I5 => SRST,
      O => \TOFILTERI[28]_i_1_n_0\
    );
\TOFILTERI[28]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilteri\(27),
      I1 => \^q\(0),
      I2 => RXSTATES(0),
      I3 => RXSTATES(1),
      I4 => RXSTATES(2),
      I5 => SRST,
      O => \TOFILTERI[28]_i_2_n_0\
    );
\TOFILTERI[28]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => RXSTATES(2),
      I1 => RXSTATES(1),
      O => \TOFILTERI[28]_i_3_n_0\
    );
\TOFILTERI[28]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000004000000"
    )
        port map (
      I0 => \Cnt_reg_n_0_[5]\,
      I1 => \Cnt_reg_n_0_[4]\,
      I2 => \Cnt_reg_n_0_[3]\,
      I3 => \Cnt_reg_n_0_[1]\,
      I4 => \Cnt_reg_n_0_[0]\,
      I5 => \Cnt_reg_n_0_[2]\,
      O => \TOFILTERI[28]_i_4_n_0\
    );
\TOFILTERI[28]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"04"
    )
        port map (
      I0 => RXSTATES(2),
      I1 => RXSTATES(1),
      I2 => RXSTATES(0),
      O => \TOFILTERI[28]_i_5_n_0\
    );
\TOFILTERI[28]_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFBFFFE"
    )
        port map (
      I0 => \Cnt_reg_n_0_[5]\,
      I1 => \Cnt_reg_n_0_[4]\,
      I2 => \Cnt_reg_n_0_[0]\,
      I3 => \Cnt_reg_n_0_[1]\,
      I4 => \Cnt_reg_n_0_[2]\,
      I5 => \Cnt_reg_n_0_[3]\,
      O => \TOFILTERI[28]_i_6_n_0\
    );
\TOFILTERI[2]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilteri\(1),
      I1 => \^q\(0),
      I2 => RXSTATES(0),
      I3 => RXSTATES(1),
      I4 => RXSTATES(2),
      I5 => SRST,
      O => \TOFILTERI[2]_i_1_n_0\
    );
\TOFILTERI[3]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilteri\(2),
      I1 => \^q\(0),
      I2 => RXSTATES(0),
      I3 => RXSTATES(1),
      I4 => RXSTATES(2),
      I5 => SRST,
      O => \TOFILTERI[3]_i_1_n_0\
    );
\TOFILTERI[4]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilteri\(3),
      I1 => \^q\(0),
      I2 => RXSTATES(0),
      I3 => RXSTATES(1),
      I4 => RXSTATES(2),
      I5 => SRST,
      O => \TOFILTERI[4]_i_1_n_0\
    );
\TOFILTERI[5]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilteri\(4),
      I1 => \^q\(0),
      I2 => RXSTATES(0),
      I3 => RXSTATES(1),
      I4 => RXSTATES(2),
      I5 => SRST,
      O => \TOFILTERI[5]_i_1_n_0\
    );
\TOFILTERI[6]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilteri\(5),
      I1 => \^q\(0),
      I2 => RXSTATES(0),
      I3 => RXSTATES(1),
      I4 => RXSTATES(2),
      I5 => SRST,
      O => \TOFILTERI[6]_i_1_n_0\
    );
\TOFILTERI[7]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilteri\(6),
      I1 => \^q\(0),
      I2 => RXSTATES(0),
      I3 => RXSTATES(1),
      I4 => RXSTATES(2),
      I5 => SRST,
      O => \TOFILTERI[7]_i_1_n_0\
    );
\TOFILTERI[8]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilteri\(7),
      I1 => \^q\(0),
      I2 => RXSTATES(0),
      I3 => RXSTATES(1),
      I4 => RXSTATES(2),
      I5 => SRST,
      O => \TOFILTERI[8]_i_1_n_0\
    );
\TOFILTERI[9]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilteri\(8),
      I1 => \^q\(0),
      I2 => RXSTATES(0),
      I3 => RXSTATES(1),
      I4 => RXSTATES(2),
      I5 => SRST,
      O => \TOFILTERI[9]_i_1_n_0\
    );
\TOFILTERI_reg[0]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERI[28]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => IDE1_out,
      Q => \^tofilteri\(0)
    );
\TOFILTERI_reg[10]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERI[28]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERI[10]_i_1_n_0\,
      Q => \^tofilteri\(10)
    );
\TOFILTERI_reg[11]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERI[28]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERI[11]_i_1_n_0\,
      Q => \^tofilteri\(11)
    );
\TOFILTERI_reg[12]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERI[28]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERI[12]_i_1_n_0\,
      Q => \^tofilteri\(12)
    );
\TOFILTERI_reg[13]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERI[28]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERI[13]_i_1_n_0\,
      Q => \^tofilteri\(13)
    );
\TOFILTERI_reg[14]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERI[28]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERI[14]_i_1_n_0\,
      Q => \^tofilteri\(14)
    );
\TOFILTERI_reg[15]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERI[28]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERI[15]_i_1_n_0\,
      Q => \^tofilteri\(15)
    );
\TOFILTERI_reg[16]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERI[28]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERI[16]_i_1_n_0\,
      Q => \^tofilteri\(16)
    );
\TOFILTERI_reg[17]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERI[28]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERI[17]_i_1_n_0\,
      Q => \^tofilteri\(17)
    );
\TOFILTERI_reg[18]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERI[28]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERI[18]_i_1_n_0\,
      Q => \^tofilteri\(18)
    );
\TOFILTERI_reg[19]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERI[28]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERI[19]_i_1_n_0\,
      Q => \^tofilteri\(19)
    );
\TOFILTERI_reg[1]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERI[28]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERI[1]_i_1_n_0\,
      Q => \^tofilteri\(1)
    );
\TOFILTERI_reg[20]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERI[28]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERI[20]_i_1_n_0\,
      Q => \^tofilteri\(20)
    );
\TOFILTERI_reg[21]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERI[28]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERI[21]_i_1_n_0\,
      Q => \^tofilteri\(21)
    );
\TOFILTERI_reg[22]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERI[28]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERI[22]_i_1_n_0\,
      Q => \^tofilteri\(22)
    );
\TOFILTERI_reg[23]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERI[28]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERI[23]_i_1_n_0\,
      Q => \^tofilteri\(23)
    );
\TOFILTERI_reg[24]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERI[28]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERI[24]_i_1_n_0\,
      Q => \^tofilteri\(24)
    );
\TOFILTERI_reg[25]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERI[28]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERI[25]_i_1_n_0\,
      Q => \^tofilteri\(25)
    );
\TOFILTERI_reg[26]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERI[28]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERI[26]_i_1_n_0\,
      Q => \^tofilteri\(26)
    );
\TOFILTERI_reg[27]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERI[28]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERI[27]_i_1_n_0\,
      Q => \^tofilteri\(27)
    );
\TOFILTERI_reg[28]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERI[28]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERI[28]_i_2_n_0\,
      Q => \^tofilteri\(28)
    );
\TOFILTERI_reg[2]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERI[28]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERI[2]_i_1_n_0\,
      Q => \^tofilteri\(2)
    );
\TOFILTERI_reg[3]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERI[28]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERI[3]_i_1_n_0\,
      Q => \^tofilteri\(3)
    );
\TOFILTERI_reg[4]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERI[28]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERI[4]_i_1_n_0\,
      Q => \^tofilteri\(4)
    );
\TOFILTERI_reg[5]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERI[28]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERI[5]_i_1_n_0\,
      Q => \^tofilteri\(5)
    );
\TOFILTERI_reg[6]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERI[28]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERI[6]_i_1_n_0\,
      Q => \^tofilteri\(6)
    );
\TOFILTERI_reg[7]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERI[28]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERI[7]_i_1_n_0\,
      Q => \^tofilteri\(7)
    );
\TOFILTERI_reg[8]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERI[28]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERI[8]_i_1_n_0\,
      Q => \^tofilteri\(8)
    );
\TOFILTERI_reg[9]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERI[28]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERI[9]_i_1_n_0\,
      Q => \^tofilteri\(9)
    );
\TOFILTERd[0]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000010000000000"
    )
        port map (
      I0 => IDE_reg_0,
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST,
      I4 => \^q\(0),
      I5 => RXSTATES(2),
      O => \TOFILTERd[0]_i_1_n_0\
    );
\TOFILTERd[10]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd\(9),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST,
      I4 => \^q\(0),
      I5 => RXSTATES(2),
      O => \TOFILTERd[10]_i_1_n_0\
    );
\TOFILTERd[11]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd\(10),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST,
      I4 => \^q\(0),
      I5 => RXSTATES(2),
      O => \TOFILTERd[11]_i_1_n_0\
    );
\TOFILTERd[12]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd\(11),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST,
      I4 => \^q\(0),
      I5 => RXSTATES(2),
      O => \TOFILTERd[12]_i_1_n_0\
    );
\TOFILTERd[13]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd\(12),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST,
      I4 => \^q\(0),
      I5 => RXSTATES(2),
      O => \TOFILTERd[13]_i_1_n_0\
    );
\TOFILTERd[14]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd\(13),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST,
      I4 => \^q\(0),
      I5 => RXSTATES(2),
      O => \TOFILTERd[14]_i_1_n_0\
    );
\TOFILTERd[15]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd\(14),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST,
      I4 => \^q\(0),
      I5 => RXSTATES(2),
      O => \TOFILTERd[15]_i_1_n_0\
    );
\TOFILTERd[16]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd\(15),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST,
      I4 => \^q\(0),
      I5 => RXSTATES(2),
      O => \TOFILTERd[16]_i_1_n_0\
    );
\TOFILTERd[17]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd\(16),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST,
      I4 => \^q\(0),
      I5 => RXSTATES(2),
      O => \TOFILTERd[17]_i_1_n_0\
    );
\TOFILTERd[18]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd\(17),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST,
      I4 => \^q\(0),
      I5 => RXSTATES(2),
      O => \TOFILTERd[18]_i_1_n_0\
    );
\TOFILTERd[19]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd\(18),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST,
      I4 => \^q\(0),
      I5 => RXSTATES(2),
      O => \TOFILTERd[19]_i_1_n_0\
    );
\TOFILTERd[1]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd\(0),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST,
      I4 => \^q\(0),
      I5 => RXSTATES(2),
      O => \TOFILTERd[1]_i_1_n_0\
    );
\TOFILTERd[20]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd\(19),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST,
      I4 => \^q\(0),
      I5 => RXSTATES(2),
      O => \TOFILTERd[20]_i_1_n_0\
    );
\TOFILTERd[21]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd\(20),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST,
      I4 => \^q\(0),
      I5 => RXSTATES(2),
      O => \TOFILTERd[21]_i_1_n_0\
    );
\TOFILTERd[22]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd\(21),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST,
      I4 => \^q\(0),
      I5 => RXSTATES(2),
      O => \TOFILTERd[22]_i_1_n_0\
    );
\TOFILTERd[23]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd\(22),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST,
      I4 => \^q\(0),
      I5 => RXSTATES(2),
      O => \TOFILTERd[23]_i_1_n_0\
    );
\TOFILTERd[24]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd\(23),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST,
      I4 => \^q\(0),
      I5 => RXSTATES(2),
      O => \TOFILTERd[24]_i_1_n_0\
    );
\TOFILTERd[25]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd\(24),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST,
      I4 => \^q\(0),
      I5 => RXSTATES(2),
      O => \TOFILTERd[25]_i_1_n_0\
    );
\TOFILTERd[26]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd\(25),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST,
      I4 => \^q\(0),
      I5 => RXSTATES(2),
      O => \TOFILTERd[26]_i_1_n_0\
    );
\TOFILTERd[27]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd\(26),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST,
      I4 => \^q\(0),
      I5 => RXSTATES(2),
      O => \TOFILTERd[27]_i_1_n_0\
    );
\TOFILTERd[28]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd\(27),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST,
      I4 => \^q\(0),
      I5 => RXSTATES(2),
      O => \TOFILTERd[28]_i_1_n_0\
    );
\TOFILTERd[29]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd\(28),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST,
      I4 => \^q\(0),
      I5 => RXSTATES(2),
      O => \TOFILTERd[29]_i_1_n_0\
    );
\TOFILTERd[2]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd\(1),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST,
      I4 => \^q\(0),
      I5 => RXSTATES(2),
      O => \TOFILTERd[2]_i_1_n_0\
    );
\TOFILTERd[30]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd\(29),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST,
      I4 => \^q\(0),
      I5 => RXSTATES(2),
      O => \TOFILTERd[30]_i_1_n_0\
    );
\TOFILTERd[31]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd\(30),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST,
      I4 => \^q\(0),
      I5 => RXSTATES(2),
      O => \TOFILTERd[31]_i_1_n_0\
    );
\TOFILTERd[32]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd\(31),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST,
      I4 => \^q\(0),
      I5 => RXSTATES(2),
      O => \TOFILTERd[32]_i_1_n_0\
    );
\TOFILTERd[33]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd\(32),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST,
      I4 => \^q\(0),
      I5 => RXSTATES(2),
      O => \TOFILTERd[33]_i_1_n_0\
    );
\TOFILTERd[34]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd\(33),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST,
      I4 => \^q\(0),
      I5 => RXSTATES(2),
      O => \TOFILTERd[34]_i_1_n_0\
    );
\TOFILTERd[35]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd\(34),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST,
      I4 => \^q\(0),
      I5 => RXSTATES(2),
      O => \TOFILTERd[35]_i_1_n_0\
    );
\TOFILTERd[36]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd\(35),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST,
      I4 => \^q\(0),
      I5 => RXSTATES(2),
      O => \TOFILTERd[36]_i_1_n_0\
    );
\TOFILTERd[37]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd\(36),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST,
      I4 => \^q\(0),
      I5 => RXSTATES(2),
      O => \TOFILTERd[37]_i_1_n_0\
    );
\TOFILTERd[38]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd\(37),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST,
      I4 => \^q\(0),
      I5 => RXSTATES(2),
      O => \TOFILTERd[38]_i_1_n_0\
    );
\TOFILTERd[39]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd\(38),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST,
      I4 => \^q\(0),
      I5 => RXSTATES(2),
      O => \TOFILTERd[39]_i_1_n_0\
    );
\TOFILTERd[3]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd\(2),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST,
      I4 => \^q\(0),
      I5 => RXSTATES(2),
      O => \TOFILTERd[3]_i_1_n_0\
    );
\TOFILTERd[40]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd\(39),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST,
      I4 => \^q\(0),
      I5 => RXSTATES(2),
      O => \TOFILTERd[40]_i_1_n_0\
    );
\TOFILTERd[41]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd\(40),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST,
      I4 => \^q\(0),
      I5 => RXSTATES(2),
      O => \TOFILTERd[41]_i_1_n_0\
    );
\TOFILTERd[42]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd\(41),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST,
      I4 => \^q\(0),
      I5 => RXSTATES(2),
      O => \TOFILTERd[42]_i_1_n_0\
    );
\TOFILTERd[43]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd\(42),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST,
      I4 => \^q\(0),
      I5 => RXSTATES(2),
      O => \TOFILTERd[43]_i_1_n_0\
    );
\TOFILTERd[44]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd\(43),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST,
      I4 => \^q\(0),
      I5 => RXSTATES(2),
      O => \TOFILTERd[44]_i_1_n_0\
    );
\TOFILTERd[45]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd\(44),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST,
      I4 => \^q\(0),
      I5 => RXSTATES(2),
      O => \TOFILTERd[45]_i_1_n_0\
    );
\TOFILTERd[46]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd\(45),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST,
      I4 => \^q\(0),
      I5 => RXSTATES(2),
      O => \TOFILTERd[46]_i_1_n_0\
    );
\TOFILTERd[47]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd\(46),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST,
      I4 => \^q\(0),
      I5 => RXSTATES(2),
      O => \TOFILTERd[47]_i_1_n_0\
    );
\TOFILTERd[48]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd\(47),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST,
      I4 => \^q\(0),
      I5 => RXSTATES(2),
      O => \TOFILTERd[48]_i_1_n_0\
    );
\TOFILTERd[49]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd\(48),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST,
      I4 => \^q\(0),
      I5 => RXSTATES(2),
      O => \TOFILTERd[49]_i_1_n_0\
    );
\TOFILTERd[4]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd\(3),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST,
      I4 => \^q\(0),
      I5 => RXSTATES(2),
      O => \TOFILTERd[4]_i_1_n_0\
    );
\TOFILTERd[50]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd\(49),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST,
      I4 => \^q\(0),
      I5 => RXSTATES(2),
      O => \TOFILTERd[50]_i_1_n_0\
    );
\TOFILTERd[51]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd\(50),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST,
      I4 => \^q\(0),
      I5 => RXSTATES(2),
      O => \TOFILTERd[51]_i_1_n_0\
    );
\TOFILTERd[52]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd\(51),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST,
      I4 => \^q\(0),
      I5 => RXSTATES(2),
      O => \TOFILTERd[52]_i_1_n_0\
    );
\TOFILTERd[53]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd\(52),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST,
      I4 => \^q\(0),
      I5 => RXSTATES(2),
      O => \TOFILTERd[53]_i_1_n_0\
    );
\TOFILTERd[54]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd\(53),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST,
      I4 => \^q\(0),
      I5 => RXSTATES(2),
      O => \TOFILTERd[54]_i_1_n_0\
    );
\TOFILTERd[55]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd\(54),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST,
      I4 => \^q\(0),
      I5 => RXSTATES(2),
      O => \TOFILTERd[55]_i_1_n_0\
    );
\TOFILTERd[56]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd\(55),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST,
      I4 => \^q\(0),
      I5 => RXSTATES(2),
      O => \TOFILTERd[56]_i_1_n_0\
    );
\TOFILTERd[57]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd\(56),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST,
      I4 => \^q\(0),
      I5 => RXSTATES(2),
      O => \TOFILTERd[57]_i_1_n_0\
    );
\TOFILTERd[58]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd\(57),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST,
      I4 => \^q\(0),
      I5 => RXSTATES(2),
      O => \TOFILTERd[58]_i_1_n_0\
    );
\TOFILTERd[59]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd\(58),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST,
      I4 => \^q\(0),
      I5 => RXSTATES(2),
      O => \TOFILTERd[59]_i_1_n_0\
    );
\TOFILTERd[5]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd\(4),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST,
      I4 => \^q\(0),
      I5 => RXSTATES(2),
      O => \TOFILTERd[5]_i_1_n_0\
    );
\TOFILTERd[60]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd\(59),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST,
      I4 => \^q\(0),
      I5 => RXSTATES(2),
      O => \TOFILTERd[60]_i_1_n_0\
    );
\TOFILTERd[61]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd\(60),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST,
      I4 => \^q\(0),
      I5 => RXSTATES(2),
      O => \TOFILTERd[61]_i_1_n_0\
    );
\TOFILTERd[62]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd\(61),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST,
      I4 => \^q\(0),
      I5 => RXSTATES(2),
      O => \TOFILTERd[62]_i_1_n_0\
    );
\TOFILTERd[63]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00001300FFFFFFFF"
    )
        port map (
      I0 => RXSTATES(0),
      I1 => RXSTATES(1),
      I2 => RXSTATES(2),
      I3 => \CRC_RG_reg[14]\,
      I4 => \^q\(0),
      I5 => SRST,
      O => \TOFILTERd[63]_i_1_n_0\
    );
\TOFILTERd[63]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd\(62),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST,
      I4 => \^q\(0),
      I5 => RXSTATES(2),
      O => \TOFILTERd[63]_i_2_n_0\
    );
\TOFILTERd[6]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd\(5),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST,
      I4 => \^q\(0),
      I5 => RXSTATES(2),
      O => \TOFILTERd[6]_i_1_n_0\
    );
\TOFILTERd[7]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd\(6),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST,
      I4 => \^q\(0),
      I5 => RXSTATES(2),
      O => \TOFILTERd[7]_i_1_n_0\
    );
\TOFILTERd[8]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd\(7),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST,
      I4 => \^q\(0),
      I5 => RXSTATES(2),
      O => \TOFILTERd[8]_i_1_n_0\
    );
\TOFILTERd[9]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020000000000"
    )
        port map (
      I0 => \^tofilterd\(8),
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => SRST,
      I4 => \^q\(0),
      I5 => RXSTATES(2),
      O => \TOFILTERd[9]_i_1_n_0\
    );
\TOFILTERd_reg[0]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[0]_i_1_n_0\,
      Q => \^tofilterd\(0)
    );
\TOFILTERd_reg[10]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[10]_i_1_n_0\,
      Q => \^tofilterd\(10)
    );
\TOFILTERd_reg[11]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[11]_i_1_n_0\,
      Q => \^tofilterd\(11)
    );
\TOFILTERd_reg[12]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[12]_i_1_n_0\,
      Q => \^tofilterd\(12)
    );
\TOFILTERd_reg[13]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[13]_i_1_n_0\,
      Q => \^tofilterd\(13)
    );
\TOFILTERd_reg[14]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[14]_i_1_n_0\,
      Q => \^tofilterd\(14)
    );
\TOFILTERd_reg[15]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[15]_i_1_n_0\,
      Q => \^tofilterd\(15)
    );
\TOFILTERd_reg[16]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[16]_i_1_n_0\,
      Q => \^tofilterd\(16)
    );
\TOFILTERd_reg[17]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[17]_i_1_n_0\,
      Q => \^tofilterd\(17)
    );
\TOFILTERd_reg[18]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[18]_i_1_n_0\,
      Q => \^tofilterd\(18)
    );
\TOFILTERd_reg[19]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[19]_i_1_n_0\,
      Q => \^tofilterd\(19)
    );
\TOFILTERd_reg[1]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[1]_i_1_n_0\,
      Q => \^tofilterd\(1)
    );
\TOFILTERd_reg[20]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[20]_i_1_n_0\,
      Q => \^tofilterd\(20)
    );
\TOFILTERd_reg[21]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[21]_i_1_n_0\,
      Q => \^tofilterd\(21)
    );
\TOFILTERd_reg[22]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[22]_i_1_n_0\,
      Q => \^tofilterd\(22)
    );
\TOFILTERd_reg[23]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[23]_i_1_n_0\,
      Q => \^tofilterd\(23)
    );
\TOFILTERd_reg[24]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[24]_i_1_n_0\,
      Q => \^tofilterd\(24)
    );
\TOFILTERd_reg[25]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[25]_i_1_n_0\,
      Q => \^tofilterd\(25)
    );
\TOFILTERd_reg[26]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[26]_i_1_n_0\,
      Q => \^tofilterd\(26)
    );
\TOFILTERd_reg[27]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[27]_i_1_n_0\,
      Q => \^tofilterd\(27)
    );
\TOFILTERd_reg[28]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[28]_i_1_n_0\,
      Q => \^tofilterd\(28)
    );
\TOFILTERd_reg[29]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[29]_i_1_n_0\,
      Q => \^tofilterd\(29)
    );
\TOFILTERd_reg[2]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[2]_i_1_n_0\,
      Q => \^tofilterd\(2)
    );
\TOFILTERd_reg[30]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[30]_i_1_n_0\,
      Q => \^tofilterd\(30)
    );
\TOFILTERd_reg[31]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[31]_i_1_n_0\,
      Q => \^tofilterd\(31)
    );
\TOFILTERd_reg[32]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[32]_i_1_n_0\,
      Q => \^tofilterd\(32)
    );
\TOFILTERd_reg[33]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[33]_i_1_n_0\,
      Q => \^tofilterd\(33)
    );
\TOFILTERd_reg[34]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[34]_i_1_n_0\,
      Q => \^tofilterd\(34)
    );
\TOFILTERd_reg[35]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[35]_i_1_n_0\,
      Q => \^tofilterd\(35)
    );
\TOFILTERd_reg[36]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[36]_i_1_n_0\,
      Q => \^tofilterd\(36)
    );
\TOFILTERd_reg[37]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[37]_i_1_n_0\,
      Q => \^tofilterd\(37)
    );
\TOFILTERd_reg[38]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[38]_i_1_n_0\,
      Q => \^tofilterd\(38)
    );
\TOFILTERd_reg[39]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[39]_i_1_n_0\,
      Q => \^tofilterd\(39)
    );
\TOFILTERd_reg[3]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[3]_i_1_n_0\,
      Q => \^tofilterd\(3)
    );
\TOFILTERd_reg[40]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[40]_i_1_n_0\,
      Q => \^tofilterd\(40)
    );
\TOFILTERd_reg[41]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[41]_i_1_n_0\,
      Q => \^tofilterd\(41)
    );
\TOFILTERd_reg[42]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[42]_i_1_n_0\,
      Q => \^tofilterd\(42)
    );
\TOFILTERd_reg[43]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[43]_i_1_n_0\,
      Q => \^tofilterd\(43)
    );
\TOFILTERd_reg[44]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[44]_i_1_n_0\,
      Q => \^tofilterd\(44)
    );
\TOFILTERd_reg[45]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[45]_i_1_n_0\,
      Q => \^tofilterd\(45)
    );
\TOFILTERd_reg[46]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[46]_i_1_n_0\,
      Q => \^tofilterd\(46)
    );
\TOFILTERd_reg[47]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[47]_i_1_n_0\,
      Q => \^tofilterd\(47)
    );
\TOFILTERd_reg[48]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[48]_i_1_n_0\,
      Q => \^tofilterd\(48)
    );
\TOFILTERd_reg[49]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[49]_i_1_n_0\,
      Q => \^tofilterd\(49)
    );
\TOFILTERd_reg[4]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[4]_i_1_n_0\,
      Q => \^tofilterd\(4)
    );
\TOFILTERd_reg[50]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[50]_i_1_n_0\,
      Q => \^tofilterd\(50)
    );
\TOFILTERd_reg[51]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[51]_i_1_n_0\,
      Q => \^tofilterd\(51)
    );
\TOFILTERd_reg[52]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[52]_i_1_n_0\,
      Q => \^tofilterd\(52)
    );
\TOFILTERd_reg[53]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[53]_i_1_n_0\,
      Q => \^tofilterd\(53)
    );
\TOFILTERd_reg[54]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[54]_i_1_n_0\,
      Q => \^tofilterd\(54)
    );
\TOFILTERd_reg[55]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[55]_i_1_n_0\,
      Q => \^tofilterd\(55)
    );
\TOFILTERd_reg[56]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[56]_i_1_n_0\,
      Q => \^tofilterd\(56)
    );
\TOFILTERd_reg[57]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[57]_i_1_n_0\,
      Q => \^tofilterd\(57)
    );
\TOFILTERd_reg[58]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[58]_i_1_n_0\,
      Q => \^tofilterd\(58)
    );
\TOFILTERd_reg[59]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[59]_i_1_n_0\,
      Q => \^tofilterd\(59)
    );
\TOFILTERd_reg[5]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[5]_i_1_n_0\,
      Q => \^tofilterd\(5)
    );
\TOFILTERd_reg[60]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[60]_i_1_n_0\,
      Q => \^tofilterd\(60)
    );
\TOFILTERd_reg[61]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[61]_i_1_n_0\,
      Q => \^tofilterd\(61)
    );
\TOFILTERd_reg[62]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[62]_i_1_n_0\,
      Q => \^tofilterd\(62)
    );
\TOFILTERd_reg[63]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[63]_i_2_n_0\,
      Q => \^tofilterd\(63)
    );
\TOFILTERd_reg[6]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[6]_i_1_n_0\,
      Q => \^tofilterd\(6)
    );
\TOFILTERd_reg[7]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[7]_i_1_n_0\,
      Q => \^tofilterd\(7)
    );
\TOFILTERd_reg[8]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[8]_i_1_n_0\,
      Q => \^tofilterd\(8)
    );
\TOFILTERd_reg[9]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \TOFILTERd[63]_i_1_n_0\,
      CLR => \^can_rst_0\,
      D => \TOFILTERd[9]_i_1_n_0\,
      Q => \^tofilterd\(9)
    );
\bs[0]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFF57F55"
    )
        port map (
      I0 => IDE_reg_0,
      I1 => RXSTATES(0),
      I2 => RXSTATES(1),
      I3 => \^q\(0),
      I4 => RXSTATES(2),
      O => I56(0)
    );
\bs[1]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"08000FFE08000002"
    )
        port map (
      I0 => IDE_reg_0,
      I1 => RXSTATES(0),
      I2 => RXSTATES(2),
      I3 => RXSTATES(1),
      I4 => \^q\(0),
      I5 => bs(0),
      O => I56(1)
    );
\bs[2]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"02220220"
    )
        port map (
      I0 => bs(1),
      I1 => \^q\(0),
      I2 => RXSTATES(1),
      I3 => RXSTATES(2),
      I4 => RXSTATES(0),
      O => I56(2)
    );
\bs[3]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"02220220"
    )
        port map (
      I0 => bs(2),
      I1 => \^q\(0),
      I2 => RXSTATES(1),
      I3 => RXSTATES(2),
      I4 => RXSTATES(0),
      O => I56(3)
    );
\bs[4]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"02220220"
    )
        port map (
      I0 => bs(3),
      I1 => \^q\(0),
      I2 => RXSTATES(1),
      I3 => RXSTATES(2),
      I4 => RXSTATES(0),
      O => I56(4)
    );
\bs[5]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"02220220"
    )
        port map (
      I0 => bs(4),
      I1 => \^q\(0),
      I2 => RXSTATES(1),
      I3 => RXSTATES(2),
      I4 => RXSTATES(0),
      O => I56(5)
    );
\bs_reg[0]\: unisim.vcomponents.FDPE
     port map (
      C => Tq,
      CE => \bs_reg[0]_0\(0),
      D => I56(0),
      PRE => \^can_rst_0\,
      Q => bs(0)
    );
\bs_reg[1]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \bs_reg[0]_0\(0),
      CLR => \^can_rst_0\,
      D => I56(1),
      Q => bs(1)
    );
\bs_reg[2]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \bs_reg[0]_0\(0),
      CLR => \^can_rst_0\,
      D => I56(2),
      Q => bs(2)
    );
\bs_reg[3]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \bs_reg[0]_0\(0),
      CLR => \^can_rst_0\,
      D => I56(3),
      Q => bs(3)
    );
\bs_reg[4]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \bs_reg[0]_0\(0),
      CLR => \^can_rst_0\,
      D => I56(4),
      Q => bs(4)
    );
\bs_reg[5]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => \bs_reg[0]_0\(0),
      CLR => \^can_rst_0\,
      D => I56(5),
      Q => bs(5)
    );
done_i_15: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FF7E"
    )
        port map (
      I0 => RXSTATES(0),
      I1 => RXSTATES(1),
      I2 => \^q\(0),
      I3 => RXSTATES(2),
      O => \RXSTATES_reg[0]_1\
    );
\done_i_1__0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"CCC88888"
    )
        port map (
      I0 => done_i_3_n_0,
      I1 => SRST,
      I2 => \^q\(0),
      I3 => \^rxstates_reg[1]_0\,
      I4 => \^done_reg_0\,
      O => \done_i_1__0_n_0\
    );
done_i_3: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000200000"
    )
        port map (
      I0 => \RXSTATES[2]_i_3_n_0\,
      I1 => RXSTATES(2),
      I2 => \^q\(0),
      I3 => RXSTATES(1),
      I4 => RXSTATES(0),
      I5 => imTX,
      O => done_i_3_n_0
    );
\done_i_4__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0001"
    )
        port map (
      I0 => RXSTATES(1),
      I1 => RXSTATES(0),
      I2 => \^q\(0),
      I3 => RXSTATES(2),
      O => \^rxstates_reg[1]_0\
    );
done_reg: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => '1',
      CLR => \^can_rst_0\,
      D => \done_i_1__0_n_0\,
      Q => \^done_reg_0\
    );
donefromrxr_i_1: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => SRST,
      I1 => \^done_reg_0\,
      O => donefromrxr
    );
req_Error_i_2: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000080800202020"
    )
        port map (
      I0 => IDE_reg_0,
      I1 => RXSTATES(2),
      I2 => \^q\(0),
      I3 => \RXSTATES[2]_i_3_n_0\,
      I4 => RXSTATES(0),
      I5 => RXSTATES(1),
      O => req_Error_i_2_n_0
    );
req_Error_i_4: unisim.vcomponents.LUT5
    generic map(
      INIT => X"55D5555F"
    )
        port map (
      I0 => SRST,
      I1 => RXSTATES(0),
      I2 => \^q\(0),
      I3 => RXSTATES(1),
      I4 => RXSTATES(2),
      O => req_Error_i_4_n_0
    );
req_Error_i_5: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000001"
    )
        port map (
      I0 => bs(1),
      I1 => bs(0),
      I2 => bs(3),
      I3 => bs(4),
      I4 => bs(2),
      O => req_Error_i_5_n_0
    );
req_Error_i_6: unisim.vcomponents.LUT5
    generic map(
      INIT => X"80000000"
    )
        port map (
      I0 => bs(1),
      I1 => bs(0),
      I2 => bs(3),
      I3 => bs(4),
      I4 => bs(2),
      O => req_Error_i_6_n_0
    );
req_Error_i_8: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0100"
    )
        port map (
      I0 => RXSTATES(1),
      I1 => RXSTATES(0),
      I2 => RXSTATES(2),
      I3 => \^q\(0),
      O => req_Error_i_8_n_0
    );
req_Error_reg: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => '1',
      CLR => \^can_rst_0\,
      D => rxcrc_n_1,
      Q => \^req_error_rx\
    );
rxcrc: entity work.design_1_FPGAPROJECT_0_0_CRC_10
     port map (
      CAN_RST => CAN_RST,
      CAN_RST_0 => \^can_rst_0\,
      \CRC_RG_reg[14]_0\ => \CRC_RG_reg[14]\,
      \CRC_RG_reg[3]_0\ => IDE_reg_0,
      Q(3) => \^q\(0),
      Q(2 downto 0) => RXSTATES(2 downto 0),
      SRST => SRST,
      SRST_1 => rxcrc_n_1,
      Tq => Tq,
      \bs_reg[1]\ => \bs_reg[1]_0\,
      req_Error_reg => req_Error_i_5_n_0,
      req_Error_reg_0(5 downto 0) => bs(5 downto 0),
      req_Error_reg_1 => req_Error_i_6_n_0,
      req_Error_reg_2 => req_Error_i_8_n_0,
      req_Error_reg_3 => req_Error_i_2_n_0,
      req_Error_reg_4 => req_Error_i_4_n_0,
      req_Error_reg_5(0) => \bs_reg[0]_0\(0),
      req_Error_reg_6 => \^req_error_rx\
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1_FPGAPROJECT_0_0_TFF is
  port (
    q : out STD_LOGIC;
    RX : in STD_LOGIC;
    clk : in STD_LOGIC;
    q_reg : in STD_LOGIC
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of design_1_FPGAPROJECT_0_0_TFF : entity is "TFF";
end design_1_FPGAPROJECT_0_0_TFF;

architecture STRUCTURE of design_1_FPGAPROJECT_0_0_TFF is
  signal d1_n_0 : STD_LOGIC;
begin
d1: entity work.design_1_FPGAPROJECT_0_0_dff
     port map (
      RX => RX,
      clk => clk,
      q_reg_0 => d1_n_0,
      q_reg_1 => q_reg
    );
d2: entity work.design_1_FPGAPROJECT_0_0_dff_1
     port map (
      clk => clk,
      q => q,
      q_reg_0 => d1_n_0,
      q_reg_1 => q_reg
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1_FPGAPROJECT_0_0_TFF_2 is
  port (
    RXBUSs : out STD_LOGIC;
    RX : in STD_LOGIC;
    Tq : in STD_LOGIC;
    q_reg : in STD_LOGIC
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of design_1_FPGAPROJECT_0_0_TFF_2 : entity is "TFF";
end design_1_FPGAPROJECT_0_0_TFF_2;

architecture STRUCTURE of design_1_FPGAPROJECT_0_0_TFF_2 is
  signal d1_n_0 : STD_LOGIC;
begin
d1: entity work.design_1_FPGAPROJECT_0_0_dff_11
     port map (
      RX => RX,
      Tq => Tq,
      q_reg_0 => d1_n_0,
      q_reg_1 => q_reg
    );
d2: entity work.design_1_FPGAPROJECT_0_0_dff_12
     port map (
      RXBUSs => RXBUSs,
      Tq => Tq,
      q_reg_0 => d1_n_0,
      q_reg_1 => q_reg
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1_FPGAPROJECT_0_0_TXMachine is
  port (
    imTX : out STD_LOGIC;
    done_reg_0 : out STD_LOGIC;
    req_Error_reg : out STD_LOGIC;
    \TXSTATES_reg[1]_0\ : out STD_LOGIC;
    req_Error_reg_0 : out STD_LOGIC;
    req_Error_reg_1 : out STD_LOGIC;
    \TXSTATES_reg[0]_0\ : out STD_LOGIC;
    \TXSTATES_reg[1]_1\ : out STD_LOGIC;
    RXOUT_reg : out STD_LOGIC;
    \TXSTATES_reg[0]_1\ : out STD_LOGIC;
    \TXSTATES_reg[2]_0\ : out STD_LOGIC;
    donefromtxr : out STD_LOGIC;
    E : in STD_LOGIC_VECTOR ( 0 to 0 );
    clk : in STD_LOGIC;
    \CRC_RG_reg[0]\ : in STD_LOGIC;
    SRST_0 : in STD_LOGIC;
    IDE_TX_0 : in STD_LOGIC;
    \serial_reg[4]\ : in STD_LOGIC;
    \Cnt_reg[1]_0\ : in STD_LOGIC;
    req_Error_RX : in STD_LOGIC;
    \TEC[8]_i_17\ : in STD_LOGIC;
    \TEC[8]_i_17_0\ : in STD_LOGIC;
    Sampled_din : in STD_LOGIC;
    \TXSTATES_reg[0]_2\ : in STD_LOGIC;
    Q : in STD_LOGIC_VECTOR ( 1 downto 0 );
    \Cnt[0]_i_3\ : in STD_LOGIC;
    TRANSMITr : in STD_LOGIC;
    done_i_11 : in STD_LOGIC;
    RTR_TX_0 : in STD_LOGIC;
    D_Len_TX_0 : in STD_LOGIC_VECTOR ( 3 downto 0 );
    done_i_11_0 : in STD_LOGIC;
    ID_TX_0 : in STD_LOGIC_VECTOR ( 28 downto 0 );
    data_TX_0 : in STD_LOGIC_VECTOR ( 63 downto 0 );
    D : in STD_LOGIC_VECTOR ( 1 downto 0 )
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of design_1_FPGAPROJECT_0_0_TXMachine : entity is "TXMachine";
end design_1_FPGAPROJECT_0_0_TXMachine;

architecture STRUCTURE of design_1_FPGAPROJECT_0_0_TXMachine is
  signal \Cnt[1]_i_4_n_0\ : STD_LOGIC;
  signal \Cnt[2]_i_2_n_0\ : STD_LOGIC;
  signal \Cnt[2]_i_5__0_n_0\ : STD_LOGIC;
  signal \Cnt[3]_i_10_n_0\ : STD_LOGIC;
  signal \Cnt[3]_i_2__0_n_0\ : STD_LOGIC;
  signal \Cnt[3]_i_4_n_0\ : STD_LOGIC;
  signal \Cnt[3]_i_5_n_0\ : STD_LOGIC;
  signal \Cnt[4]_i_3__0_n_0\ : STD_LOGIC;
  signal \Cnt[4]_i_4_n_0\ : STD_LOGIC;
  signal \Cnt[5]_i_4_n_0\ : STD_LOGIC;
  signal \Cnt[5]_i_8_n_0\ : STD_LOGIC;
  signal \Cnt[5]_i_9_n_0\ : STD_LOGIC;
  signal \Cnt_reg_n_0_[0]\ : STD_LOGIC;
  signal \Cnt_reg_n_0_[1]\ : STD_LOGIC;
  signal \Cnt_reg_n_0_[2]\ : STD_LOGIC;
  signal \Cnt_reg_n_0_[3]\ : STD_LOGIC;
  signal \Cnt_reg_n_0_[4]\ : STD_LOGIC;
  signal \Cnt_reg_n_0_[5]\ : STD_LOGIC;
  signal \State[0]_i_10_n_0\ : STD_LOGIC;
  signal \State[0]_i_6_n_0\ : STD_LOGIC;
  signal TXSTATES : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \TXSTATES[2]_i_3_n_0\ : STD_LOGIC;
  signal \^txstates_reg[1]_0\ : STD_LOGIC;
  signal TransBS_n_0 : STD_LOGIC;
  signal TransBS_n_1 : STD_LOGIC;
  signal TransBS_n_11 : STD_LOGIC;
  signal TransBS_n_12 : STD_LOGIC;
  signal TransBS_n_13 : STD_LOGIC;
  signal TransBS_n_14 : STD_LOGIC;
  signal TransBS_n_15 : STD_LOGIC;
  signal TransBS_n_16 : STD_LOGIC;
  signal TransBS_n_20 : STD_LOGIC;
  signal TransBS_n_8 : STD_LOGIC;
  signal TransBS_n_9 : STD_LOGIC;
  signal done_i_15_n_0 : STD_LOGIC;
  signal done_i_16_n_0 : STD_LOGIC;
  signal done_i_17_n_0 : STD_LOGIC;
  signal done_i_18_n_0 : STD_LOGIC;
  signal done_i_19_n_0 : STD_LOGIC;
  signal done_i_20_n_0 : STD_LOGIC;
  signal \done_i_2__0_n_0\ : STD_LOGIC;
  signal done_i_6_n_0 : STD_LOGIC;
  signal done_i_9_n_0 : STD_LOGIC;
  signal \^done_reg_0\ : STD_LOGIC;
  signal \^imtx\ : STD_LOGIC;
  signal imTX0_out : STD_LOGIC;
  signal imTX_i_2_n_0 : STD_LOGIC;
  signal req_Errorr : STD_LOGIC;
  signal req_Errorr_reg_n_0 : STD_LOGIC;
  signal txcrc_n_0 : STD_LOGIC;
  signal txcrc_n_1 : STD_LOGIC;
  signal txcrc_n_2 : STD_LOGIC;
  signal txcrc_n_3 : STD_LOGIC;
  signal txcrc_n_4 : STD_LOGIC;
  signal txcrc_n_5 : STD_LOGIC;
  signal txcrc_n_6 : STD_LOGIC;
  signal txcrc_n_7 : STD_LOGIC;
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \Cnt[2]_i_5__0\ : label is "soft_lutpair214";
  attribute SOFT_HLUTNM of \Cnt[3]_i_10\ : label is "soft_lutpair216";
  attribute SOFT_HLUTNM of \Cnt[3]_i_2__0\ : label is "soft_lutpair213";
  attribute SOFT_HLUTNM of \Cnt[5]_i_9\ : label is "soft_lutpair212";
  attribute SOFT_HLUTNM of \State[0]_i_10\ : label is "soft_lutpair215";
  attribute SOFT_HLUTNM of \State[0]_i_6\ : label is "soft_lutpair217";
  attribute SOFT_HLUTNM of ack_error_i_5 : label is "soft_lutpair215";
  attribute SOFT_HLUTNM of done_i_15 : label is "soft_lutpair218";
  attribute SOFT_HLUTNM of done_i_16 : label is "soft_lutpair213";
  attribute SOFT_HLUTNM of done_i_18 : label is "soft_lutpair214";
  attribute SOFT_HLUTNM of done_i_19 : label is "soft_lutpair212";
  attribute SOFT_HLUTNM of done_i_20 : label is "soft_lutpair218";
  attribute SOFT_HLUTNM of \done_i_2__0\ : label is "soft_lutpair216";
  attribute SOFT_HLUTNM of imTX_i_2 : label is "soft_lutpair217";
begin
  \TXSTATES_reg[1]_0\ <= \^txstates_reg[1]_0\;
  done_reg_0 <= \^done_reg_0\;
  imTX <= \^imtx\;
\Cnt[1]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \Cnt_reg_n_0_[0]\,
      I1 => \Cnt_reg_n_0_[1]\,
      O => \Cnt[1]_i_4_n_0\
    );
\Cnt[2]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"4040404E4E4E4E40"
    )
        port map (
      I0 => TXSTATES(1),
      I1 => TXSTATES(0),
      I2 => txcrc_n_4,
      I3 => \Cnt_reg_n_0_[0]\,
      I4 => \Cnt_reg_n_0_[1]\,
      I5 => \Cnt_reg_n_0_[2]\,
      O => \Cnt[2]_i_2_n_0\
    );
\Cnt[2]_i_5__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"F8FF"
    )
        port map (
      I0 => TXSTATES(0),
      I1 => txcrc_n_4,
      I2 => TXSTATES(1),
      I3 => TXSTATES(2),
      O => \Cnt[2]_i_5__0_n_0\
    );
\Cnt[3]_i_10\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"003E"
    )
        port map (
      I0 => TXSTATES(0),
      I1 => TXSTATES(2),
      I2 => TXSTATES(1),
      I3 => TXSTATES(3),
      O => \Cnt[3]_i_10_n_0\
    );
\Cnt[3]_i_2__0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"55007500"
    )
        port map (
      I0 => TXSTATES(3),
      I1 => txcrc_n_4,
      I2 => txcrc_n_5,
      I3 => TXSTATES(0),
      I4 => TXSTATES(1),
      O => \Cnt[3]_i_2__0_n_0\
    );
\Cnt[3]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"1D110000DDDDDDDD"
    )
        port map (
      I0 => txcrc_n_5,
      I1 => txcrc_n_4,
      I2 => RTR_TX_0,
      I3 => D_Len_TX_0(0),
      I4 => TXSTATES(1),
      I5 => \Cnt[3]_i_2__0_n_0\,
      O => \Cnt[3]_i_4_n_0\
    );
\Cnt[3]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFF8FFFFFFFFF"
    )
        port map (
      I0 => TXSTATES(0),
      I1 => txcrc_n_4,
      I2 => txcrc_n_5,
      I3 => TXSTATES(3),
      I4 => TXSTATES(1),
      I5 => TXSTATES(2),
      O => \Cnt[3]_i_5_n_0\
    );
\Cnt[4]_i_3__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000003FFFFFFFD"
    )
        port map (
      I0 => \Cnt_reg_n_0_[5]\,
      I1 => \Cnt_reg_n_0_[3]\,
      I2 => \Cnt_reg_n_0_[2]\,
      I3 => \Cnt_reg_n_0_[0]\,
      I4 => \Cnt_reg_n_0_[1]\,
      I5 => \Cnt_reg_n_0_[4]\,
      O => \Cnt[4]_i_3__0_n_0\
    );
\Cnt[4]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2002200220022000"
    )
        port map (
      I0 => \Cnt[5]_i_9_n_0\,
      I1 => RTR_TX_0,
      I2 => D_Len_TX_0(1),
      I3 => D_Len_TX_0(0),
      I4 => D_Len_TX_0(3),
      I5 => D_Len_TX_0(2),
      O => \Cnt[4]_i_4_n_0\
    );
\Cnt[5]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAAAAAAAAAAAA8"
    )
        port map (
      I0 => \Cnt_reg_n_0_[5]\,
      I1 => \Cnt_reg_n_0_[3]\,
      I2 => \Cnt_reg_n_0_[2]\,
      I3 => \Cnt_reg_n_0_[0]\,
      I4 => \Cnt_reg_n_0_[1]\,
      I5 => \Cnt_reg_n_0_[4]\,
      O => \Cnt[5]_i_4_n_0\
    );
\Cnt[5]_i_8\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"4444440000000040"
    )
        port map (
      I0 => RTR_TX_0,
      I1 => \Cnt[5]_i_9_n_0\,
      I2 => D_Len_TX_0(3),
      I3 => D_Len_TX_0(1),
      I4 => D_Len_TX_0(0),
      I5 => D_Len_TX_0(2),
      O => \Cnt[5]_i_8_n_0\
    );
\Cnt[5]_i_9\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => txcrc_n_4,
      I1 => TXSTATES(0),
      O => \Cnt[5]_i_9_n_0\
    );
\Cnt_reg[0]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => TransBS_n_0,
      CLR => \CRC_RG_reg[0]\,
      D => TransBS_n_16,
      Q => \Cnt_reg_n_0_[0]\
    );
\Cnt_reg[1]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => TransBS_n_0,
      CLR => \CRC_RG_reg[0]\,
      D => TransBS_n_15,
      Q => \Cnt_reg_n_0_[1]\
    );
\Cnt_reg[2]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => TransBS_n_0,
      CLR => \CRC_RG_reg[0]\,
      D => TransBS_n_14,
      Q => \Cnt_reg_n_0_[2]\
    );
\Cnt_reg[3]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => TransBS_n_0,
      CLR => \CRC_RG_reg[0]\,
      D => TransBS_n_13,
      Q => \Cnt_reg_n_0_[3]\
    );
\Cnt_reg[4]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => TransBS_n_0,
      CLR => \CRC_RG_reg[0]\,
      D => TransBS_n_12,
      Q => \Cnt_reg_n_0_[4]\
    );
\Cnt_reg[5]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => TransBS_n_0,
      CLR => \CRC_RG_reg[0]\,
      D => TransBS_n_11,
      Q => \Cnt_reg_n_0_[5]\
    );
\State[0]_i_10\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"F7FB"
    )
        port map (
      I0 => TXSTATES(2),
      I1 => TXSTATES(1),
      I2 => TXSTATES(3),
      I3 => TXSTATES(0),
      O => \State[0]_i_10_n_0\
    );
\State[0]_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FC01"
    )
        port map (
      I0 => TXSTATES(0),
      I1 => TXSTATES(2),
      I2 => TXSTATES(1),
      I3 => TXSTATES(3),
      O => \State[0]_i_6_n_0\
    );
\TXSTATES[2]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0033300033BB0000"
    )
        port map (
      I0 => \Cnt_reg[1]_0\,
      I1 => TXSTATES(3),
      I2 => txcrc_n_4,
      I3 => TXSTATES(0),
      I4 => TXSTATES(2),
      I5 => TXSTATES(1),
      O => \TXSTATES[2]_i_3_n_0\
    );
\TXSTATES_reg[0]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => E(0),
      CLR => \CRC_RG_reg[0]\,
      D => TransBS_n_9,
      Q => TXSTATES(0)
    );
\TXSTATES_reg[1]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => E(0),
      CLR => \CRC_RG_reg[0]\,
      D => TransBS_n_8,
      Q => TXSTATES(1)
    );
\TXSTATES_reg[2]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => E(0),
      CLR => \CRC_RG_reg[0]\,
      D => D(0),
      Q => TXSTATES(2)
    );
\TXSTATES_reg[3]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => E(0),
      CLR => \CRC_RG_reg[0]\,
      D => D(1),
      Q => TXSTATES(3)
    );
TransBS: entity work.design_1_FPGAPROJECT_0_0_bitstuffer
     port map (
      \CRC_RG_reg[14]\ => txcrc_n_3,
      \CRC_RG_reg[14]_0\ => txcrc_n_2,
      \Cnt[0]_i_2_0\ => done_i_17_n_0,
      \Cnt[0]_i_2_1\ => \Cnt[5]_i_9_n_0\,
      \Cnt[0]_i_3_0\(1 downto 0) => Q(1 downto 0),
      \Cnt[0]_i_3_1\ => \Cnt[0]_i_3\,
      \Cnt_reg[0]\(0) => \Cnt_reg_n_0_[0]\,
      \Cnt_reg[1]\ => \Cnt_reg[1]_0\,
      \Cnt_reg[1]_0\ => \Cnt[1]_i_4_n_0\,
      \Cnt_reg[2]\ => \Cnt[2]_i_2_n_0\,
      \Cnt_reg[2]_0\ => \Cnt[2]_i_5__0_n_0\,
      \Cnt_reg[2]_1\ => txcrc_n_1,
      \Cnt_reg[3]\ => \Cnt[3]_i_2__0_n_0\,
      \Cnt_reg[3]_0\ => \Cnt[3]_i_4_n_0\,
      \Cnt_reg[3]_1\ => \Cnt[3]_i_5_n_0\,
      \Cnt_reg[4]\ => \Cnt[4]_i_3__0_n_0\,
      \Cnt_reg[4]_0\ => \Cnt[4]_i_4_n_0\,
      \Cnt_reg[4]_1\ => txcrc_n_7,
      \Cnt_reg[5]\ => \Cnt[5]_i_4_n_0\,
      \Cnt_reg[5]_0\ => \Cnt[5]_i_8_n_0\,
      D(1) => TransBS_n_8,
      D(0) => TransBS_n_9,
      \D_Len[0]_i_3\ => \Cnt[3]_i_10_n_0\,
      E(0) => TransBS_n_0,
      IDE_TX_0 => IDE_TX_0,
      Q(3 downto 0) => TXSTATES(3 downto 0),
      \REC[8]_i_12\ => \State[0]_i_6_n_0\,
      RXOUT_reg => RXOUT_reg,
      SRST_0 => SRST_0,
      SRST_0_0(5) => TransBS_n_11,
      SRST_0_0(4) => TransBS_n_12,
      SRST_0_0(3) => TransBS_n_13,
      SRST_0_0(2) => TransBS_n_14,
      SRST_0_0(1) => TransBS_n_15,
      SRST_0_0(0) => TransBS_n_16,
      Sampled_din => Sampled_din,
      \State[0]_i_2\ => \^txstates_reg[1]_0\,
      \State[0]_i_4_0\ => \State[0]_i_10_n_0\,
      \TEC[8]_i_17\ => \TEC[8]_i_17\,
      \TEC[8]_i_17_0\ => \TEC[8]_i_17_0\,
      \TXSTATES_reg[0]\ => \TXSTATES_reg[0]_0\,
      \TXSTATES_reg[0]_0\ => \TXSTATES_reg[0]_1\,
      \TXSTATES_reg[0]_1\ => \TXSTATES_reg[0]_2\,
      \TXSTATES_reg[1]\ => \TXSTATES_reg[1]_1\,
      \TXSTATES_reg[2]\ => \TXSTATES_reg[2]_0\,
      \TXSTATES_reg[2]_0\ => \TXSTATES[2]_i_3_n_0\,
      \TXSTATES_reg[3]\(0) => TransBS_n_20,
      clk => clk,
      done_i_4_0 => done_i_15_n_0,
      done_i_4_1 => done_i_16_n_0,
      done_i_4_2 => done_i_18_n_0,
      done_i_4_3 => done_i_19_n_0,
      done_i_4_4 => done_i_20_n_0,
      done_reg => TransBS_n_1,
      done_reg_0 => txcrc_n_6,
      done_reg_1 => txcrc_n_4,
      done_reg_2 => \done_i_2__0_n_0\,
      done_reg_3 => done_i_6_n_0,
      done_reg_4 => \^done_reg_0\,
      done_reg_5 => done_i_9_n_0,
      imTX => \^imtx\,
      imTX0_out => imTX0_out,
      imTX_reg => imTX_i_2_n_0,
      req_Error_RX => req_Error_RX,
      req_Error_reg => req_Error_reg,
      req_Error_reg_0 => req_Error_reg_0,
      req_Error_reg_1 => req_Error_reg_1,
      req_Errorr => req_Errorr,
      req_Errorr_reg => req_Errorr_reg_n_0,
      \serial_reg[0]_0\ => txcrc_n_0,
      \serial_reg[0]_1\ => \CRC_RG_reg[0]\,
      \serial_reg[4]_0\ => \serial_reg[4]\
    );
ack_error_i_5: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0800"
    )
        port map (
      I0 => TXSTATES(1),
      I1 => TXSTATES(2),
      I2 => TXSTATES(3),
      I3 => TXSTATES(0),
      O => \^txstates_reg[1]_0\
    );
done_i_15: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => TXSTATES(2),
      I1 => TXSTATES(1),
      O => done_i_15_n_0
    );
done_i_16: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => TXSTATES(0),
      I1 => txcrc_n_4,
      O => done_i_16_n_0
    );
done_i_17: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000FFFE0000"
    )
        port map (
      I0 => D_Len_TX_0(2),
      I1 => D_Len_TX_0(3),
      I2 => D_Len_TX_0(1),
      I3 => D_Len_TX_0(0),
      I4 => \Cnt[5]_i_9_n_0\,
      I5 => RTR_TX_0,
      O => done_i_17_n_0
    );
done_i_18: unisim.vcomponents.LUT4
    generic map(
      INIT => X"F5D7"
    )
        port map (
      I0 => TXSTATES(2),
      I1 => TXSTATES(1),
      I2 => TXSTATES(0),
      I3 => txcrc_n_4,
      O => done_i_18_n_0
    );
done_i_19: unisim.vcomponents.LUT5
    generic map(
      INIT => X"70707F0F"
    )
        port map (
      I0 => TRANSMITr,
      I1 => done_i_11,
      I2 => txcrc_n_4,
      I3 => done_i_11_0,
      I4 => TXSTATES(0),
      O => done_i_19_n_0
    );
done_i_20: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => TXSTATES(2),
      I1 => TXSTATES(3),
      O => done_i_20_n_0
    );
\done_i_2__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0010"
    )
        port map (
      I0 => TXSTATES(0),
      I1 => TXSTATES(3),
      I2 => TXSTATES(1),
      I3 => TXSTATES(2),
      O => \done_i_2__0_n_0\
    );
done_i_6: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CFFE0000FFFFFFFF"
    )
        port map (
      I0 => TXSTATES(0),
      I1 => TXSTATES(2),
      I2 => TXSTATES(3),
      I3 => TXSTATES(1),
      I4 => \serial_reg[4]\,
      I5 => SRST_0,
      O => done_i_6_n_0
    );
done_i_9: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000008"
    )
        port map (
      I0 => TRANSMITr,
      I1 => done_i_11,
      I2 => TXSTATES(1),
      I3 => TXSTATES(2),
      I4 => TXSTATES(0),
      I5 => TXSTATES(3),
      O => done_i_9_n_0
    );
done_reg: unisim.vcomponents.FDPE
     port map (
      C => clk,
      CE => '1',
      D => TransBS_n_1,
      PRE => \CRC_RG_reg[0]\,
      Q => \^done_reg_0\
    );
donefromtxr_i_1: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => SRST_0,
      I1 => \^done_reg_0\,
      O => donefromtxr
    );
imTX_i_2: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0001"
    )
        port map (
      I0 => TXSTATES(1),
      I1 => TXSTATES(2),
      I2 => TXSTATES(0),
      I3 => TXSTATES(3),
      O => imTX_i_2_n_0
    );
imTX_reg: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => E(0),
      CLR => \CRC_RG_reg[0]\,
      D => imTX0_out,
      Q => \^imtx\
    );
req_Errorr_reg: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => E(0),
      CLR => \CRC_RG_reg[0]\,
      D => req_Errorr,
      Q => req_Errorr_reg_n_0
    );
txcrc: entity work.design_1_FPGAPROJECT_0_0_CRC
     port map (
      \CRC_RG_reg[0]_0\ => \CRC_RG_reg[0]\,
      \CRC_RG_reg[14]_0\ => \serial_reg[4]\,
      \Cnt_reg[0]\ => txcrc_n_1,
      \Cnt_reg[2]\ => txcrc_n_4,
      \Cnt_reg[3]\ => txcrc_n_5,
      D_Len_TX_0(3 downto 0) => D_Len_TX_0(3 downto 0),
      E(0) => TransBS_n_20,
      IDE_TX_0 => IDE_TX_0,
      ID_TX_0(28 downto 0) => ID_TX_0(28 downto 0),
      Q(3 downto 0) => TXSTATES(3 downto 0),
      RTR_TX_0 => RTR_TX_0,
      SRST_0 => SRST_0,
      SRST_0_0 => txcrc_n_3,
      \TXSTATES_reg[0]\ => txcrc_n_6,
      \TXSTATES_reg[2]\ => txcrc_n_7,
      \TXSTATES_reg[3]\ => txcrc_n_0,
      \TXSTATES_reg[3]_0\ => txcrc_n_2,
      clk => clk,
      data_TX_0(63 downto 0) => data_TX_0(63 downto 0),
      \serial[0]_i_12_0\(5) => \Cnt_reg_n_0_[5]\,
      \serial[0]_i_12_0\(4) => \Cnt_reg_n_0_[4]\,
      \serial[0]_i_12_0\(3) => \Cnt_reg_n_0_[3]\,
      \serial[0]_i_12_0\(2) => \Cnt_reg_n_0_[2]\,
      \serial[0]_i_12_0\(1) => \Cnt_reg_n_0_[1]\,
      \serial[0]_i_12_0\(0) => \Cnt_reg_n_0_[0]\
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1_FPGAPROJECT_0_0_TXMachine_7 is
  port (
    imTX : out STD_LOGIC;
    done_reg_0 : out STD_LOGIC;
    \TEC_reg[8]\ : out STD_LOGIC;
    req_Error_reg : out STD_LOGIC;
    \TXSTATES_reg[1]_0\ : out STD_LOGIC;
    req_Error_reg_0 : out STD_LOGIC;
    req_Error_reg_1 : out STD_LOGIC;
    \TXSTATES_reg[3]_0\ : out STD_LOGIC;
    \TXSTATES_reg[1]_1\ : out STD_LOGIC;
    RXOUT_reg : out STD_LOGIC;
    \TXSTATES_reg[3]_1\ : out STD_LOGIC;
    \TXSTATES_reg[3]_2\ : out STD_LOGIC;
    \TXSTATES_reg[2]_0\ : out STD_LOGIC;
    \TXSTATES_reg[1]_2\ : out STD_LOGIC;
    donefromtxr : out STD_LOGIC;
    imTX_reg_0 : out STD_LOGIC;
    TRANSMIT_1 : out STD_LOGIC;
    req_Error_reg_2 : out STD_LOGIC;
    imTX_reg_1 : out STD_LOGIC;
    E : in STD_LOGIC_VECTOR ( 0 to 0 );
    Tq : in STD_LOGIC;
    \CRC_RG_reg[0]\ : in STD_LOGIC;
    TEC : in STD_LOGIC_VECTOR ( 1 downto 0 );
    req_Error_RX : in STD_LOGIC;
    \Cnt_reg[1]_0\ : in STD_LOGIC;
    \REC[0]_i_5\ : in STD_LOGIC;
    \REC[0]_i_5_0\ : in STD_LOGIC;
    Sampled_din : in STD_LOGIC;
    SRST : in STD_LOGIC;
    IDE_TX : in STD_LOGIC;
    \Cnt[0]_i_2\ : in STD_LOGIC;
    \Cnt_reg[5]_0\ : in STD_LOGIC;
    TRANSMITr : in STD_LOGIC;
    done_i_12 : in STD_LOGIC;
    done_i_12_0 : in STD_LOGIC;
    RTR_TX : in STD_LOGIC;
    D_Len_TX : in STD_LOGIC_VECTOR ( 3 downto 0 );
    data_TX : in STD_LOGIC_VECTOR ( 63 downto 0 );
    ID_TX : in STD_LOGIC_VECTOR ( 28 downto 0 );
    \TEC[8]_i_5\ : in STD_LOGIC;
    TRANSMIT : in STD_LOGIC;
    TRANSMIT_reg : in STD_LOGIC;
    done_TXr : in STD_LOGIC;
    \REC_reg[8]\ : in STD_LOGIC;
    D : in STD_LOGIC_VECTOR ( 3 downto 0 )
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of design_1_FPGAPROJECT_0_0_TXMachine_7 : entity is "TXMachine";
end design_1_FPGAPROJECT_0_0_TXMachine_7;

architecture STRUCTURE of design_1_FPGAPROJECT_0_0_TXMachine_7 is
  signal \CRC_RG[14]_i_12_n_0\ : STD_LOGIC;
  signal \CRC_RG[14]_i_9_n_0\ : STD_LOGIC;
  signal \Cnt[0]_i_3_n_0\ : STD_LOGIC;
  signal \Cnt[0]_i_5_n_0\ : STD_LOGIC;
  signal \Cnt[1]_i_4__0_n_0\ : STD_LOGIC;
  signal \Cnt[1]_i_5_n_0\ : STD_LOGIC;
  signal \Cnt[1]_i_6__0_n_0\ : STD_LOGIC;
  signal \Cnt[1]_i_8_n_0\ : STD_LOGIC;
  signal \Cnt[2]_i_2__0_n_0\ : STD_LOGIC;
  signal \Cnt[3]_i_2__1_n_0\ : STD_LOGIC;
  signal \Cnt[3]_i_4_n_0\ : STD_LOGIC;
  signal \Cnt[4]_i_3__0_n_0\ : STD_LOGIC;
  signal \Cnt[4]_i_5_n_0\ : STD_LOGIC;
  signal \Cnt[5]_i_10_n_0\ : STD_LOGIC;
  signal \Cnt[5]_i_5_n_0\ : STD_LOGIC;
  signal \Cnt[5]_i_9_n_0\ : STD_LOGIC;
  signal \Cnt_reg_n_0_[0]\ : STD_LOGIC;
  signal \Cnt_reg_n_0_[1]\ : STD_LOGIC;
  signal \Cnt_reg_n_0_[2]\ : STD_LOGIC;
  signal \Cnt_reg_n_0_[3]\ : STD_LOGIC;
  signal \Cnt_reg_n_0_[4]\ : STD_LOGIC;
  signal \Cnt_reg_n_0_[5]\ : STD_LOGIC;
  signal \State[0]_i_11_n_0\ : STD_LOGIC;
  signal \State[0]_i_7_n_0\ : STD_LOGIC;
  signal TXSTATES : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \TXSTATES[1]_i_4_n_0\ : STD_LOGIC;
  signal \TXSTATES[2]_i_3_n_0\ : STD_LOGIC;
  signal \^txstates_reg[1]_0\ : STD_LOGIC;
  signal TX_INST_0_i_4_n_0 : STD_LOGIC;
  signal TX_INST_0_i_5_n_0 : STD_LOGIC;
  signal TransBS_n_13 : STD_LOGIC;
  signal TransBS_n_14 : STD_LOGIC;
  signal TransBS_n_15 : STD_LOGIC;
  signal TransBS_n_16 : STD_LOGIC;
  signal TransBS_n_17 : STD_LOGIC;
  signal TransBS_n_18 : STD_LOGIC;
  signal TransBS_n_19 : STD_LOGIC;
  signal TransBS_n_20 : STD_LOGIC;
  signal TransBS_n_21 : STD_LOGIC;
  signal TransBS_n_22 : STD_LOGIC;
  signal TransBS_n_23 : STD_LOGIC;
  signal TransBS_n_24 : STD_LOGIC;
  signal TransBS_n_25 : STD_LOGIC;
  signal TransBS_n_26 : STD_LOGIC;
  signal TransBS_n_27 : STD_LOGIC;
  signal TransBS_n_28 : STD_LOGIC;
  signal TransBS_n_29 : STD_LOGIC;
  signal TransBS_n_30 : STD_LOGIC;
  signal TransBS_n_31 : STD_LOGIC;
  signal done_i_10_n_0 : STD_LOGIC;
  signal done_i_13_n_0 : STD_LOGIC;
  signal done_i_16_n_0 : STD_LOGIC;
  signal done_i_17_n_0 : STD_LOGIC;
  signal done_i_18_n_0 : STD_LOGIC;
  signal done_i_19_n_0 : STD_LOGIC;
  signal \done_i_2__0_n_0\ : STD_LOGIC;
  signal done_i_6_n_0 : STD_LOGIC;
  signal done_i_9_n_0 : STD_LOGIC;
  signal \^done_reg_0\ : STD_LOGIC;
  signal \^imtx\ : STD_LOGIC;
  signal imTX0_out : STD_LOGIC;
  signal imTX_i_2_n_0 : STD_LOGIC;
  signal \^imtx_reg_1\ : STD_LOGIC;
  signal req_Errorr : STD_LOGIC;
  signal req_Errorr_reg_n_0 : STD_LOGIC;
  signal \serial[0]_i_13_n_0\ : STD_LOGIC;
  signal \serial[0]_i_34_n_0\ : STD_LOGIC;
  signal txcrc_n_0 : STD_LOGIC;
  signal txcrc_n_1 : STD_LOGIC;
  signal txcrc_n_2 : STD_LOGIC;
  signal txcrc_n_3 : STD_LOGIC;
  signal txcrc_n_4 : STD_LOGIC;
  signal txcrc_n_5 : STD_LOGIC;
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \Cnt[1]_i_5\ : label is "soft_lutpair109";
  attribute SOFT_HLUTNM of \Cnt[1]_i_6__0\ : label is "soft_lutpair105";
  attribute SOFT_HLUTNM of \Cnt[3]_i_4\ : label is "soft_lutpair110";
  attribute SOFT_HLUTNM of \Cnt[5]_i_10\ : label is "soft_lutpair104";
  attribute SOFT_HLUTNM of \REC[8]_i_12\ : label is "soft_lutpair112";
  attribute SOFT_HLUTNM of \State[0]_i_11\ : label is "soft_lutpair107";
  attribute SOFT_HLUTNM of \State[0]_i_7\ : label is "soft_lutpair105";
  attribute SOFT_HLUTNM of \TEC[8]_i_14\ : label is "soft_lutpair112";
  attribute SOFT_HLUTNM of \TXSTATES[1]_i_4\ : label is "soft_lutpair109";
  attribute SOFT_HLUTNM of TX_INST_0_i_4 : label is "soft_lutpair106";
  attribute SOFT_HLUTNM of ack_error_i_4 : label is "soft_lutpair108";
  attribute SOFT_HLUTNM of done_i_13 : label is "soft_lutpair111";
  attribute SOFT_HLUTNM of done_i_16 : label is "soft_lutpair111";
  attribute SOFT_HLUTNM of done_i_17 : label is "soft_lutpair110";
  attribute SOFT_HLUTNM of done_i_18 : label is "soft_lutpair108";
  attribute SOFT_HLUTNM of done_i_19 : label is "soft_lutpair104";
  attribute SOFT_HLUTNM of \done_i_2__0\ : label is "soft_lutpair107";
  attribute SOFT_HLUTNM of done_i_9 : label is "soft_lutpair106";
begin
  \TXSTATES_reg[1]_0\ <= \^txstates_reg[1]_0\;
  done_reg_0 <= \^done_reg_0\;
  imTX <= \^imtx\;
  imTX_reg_1 <= \^imtx_reg_1\;
\CRC_RG[14]_i_12\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"44444444444FF444"
    )
        port map (
      I0 => TransBS_n_20,
      I1 => RTR_TX,
      I2 => \Cnt_reg_n_0_[0]\,
      I3 => \Cnt_reg_n_0_[1]\,
      I4 => \Cnt_reg_n_0_[2]\,
      I5 => \serial[0]_i_34_n_0\,
      O => \CRC_RG[14]_i_12_n_0\
    );
\CRC_RG[14]_i_9\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFF001500BF"
    )
        port map (
      I0 => TransBS_n_25,
      I1 => TransBS_n_20,
      I2 => TransBS_n_24,
      I3 => \CRC_RG[14]_i_12_n_0\,
      I4 => TransBS_n_23,
      I5 => \serial[0]_i_13_n_0\,
      O => \CRC_RG[14]_i_9_n_0\
    );
\Cnt[0]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000FFFFFFFE"
    )
        port map (
      I0 => \Cnt_reg_n_0_[4]\,
      I1 => \Cnt_reg_n_0_[5]\,
      I2 => \Cnt_reg_n_0_[3]\,
      I3 => \Cnt_reg_n_0_[1]\,
      I4 => \Cnt_reg_n_0_[2]\,
      I5 => \Cnt_reg_n_0_[0]\,
      O => \Cnt[0]_i_3_n_0\
    );
\Cnt[0]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000FFFE0000"
    )
        port map (
      I0 => D_Len_TX(2),
      I1 => D_Len_TX(3),
      I2 => D_Len_TX(1),
      I3 => D_Len_TX(0),
      I4 => \Cnt[5]_i_10_n_0\,
      I5 => RTR_TX,
      O => \Cnt[0]_i_5_n_0\
    );
\Cnt[1]_i_4__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \Cnt_reg_n_0_[0]\,
      I1 => \Cnt_reg_n_0_[1]\,
      O => \Cnt[1]_i_4__0_n_0\
    );
\Cnt[1]_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FF5D"
    )
        port map (
      I0 => TXSTATES(2),
      I1 => TXSTATES(0),
      I2 => TransBS_n_20,
      I3 => TXSTATES(1),
      O => \Cnt[1]_i_5_n_0\
    );
\Cnt[1]_i_6__0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"0001FFFF"
    )
        port map (
      I0 => TXSTATES(2),
      I1 => TXSTATES(1),
      I2 => TXSTATES(3),
      I3 => TXSTATES(0),
      I4 => SRST,
      O => \Cnt[1]_i_6__0_n_0\
    );
\Cnt[1]_i_8\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => TXSTATES(0),
      I1 => TXSTATES(1),
      O => \Cnt[1]_i_8_n_0\
    );
\Cnt[2]_i_2__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"1E001E001EFF0000"
    )
        port map (
      I0 => \Cnt_reg_n_0_[0]\,
      I1 => \Cnt_reg_n_0_[1]\,
      I2 => \Cnt_reg_n_0_[2]\,
      I3 => TransBS_n_20,
      I4 => TXSTATES(0),
      I5 => TXSTATES(1),
      O => \Cnt[2]_i_2__0_n_0\
    );
\Cnt[3]_i_2__1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F0F0F0F0F0F0F00E"
    )
        port map (
      I0 => \Cnt_reg_n_0_[4]\,
      I1 => \Cnt_reg_n_0_[5]\,
      I2 => \Cnt_reg_n_0_[3]\,
      I3 => \Cnt_reg_n_0_[0]\,
      I4 => \Cnt_reg_n_0_[1]\,
      I5 => \Cnt_reg_n_0_[2]\,
      O => \Cnt[3]_i_2__1_n_0\
    );
\Cnt[3]_i_4\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"BBFB"
    )
        port map (
      I0 => TransBS_n_20,
      I1 => TXSTATES(0),
      I2 => D_Len_TX(0),
      I3 => RTR_TX,
      O => \Cnt[3]_i_4_n_0\
    );
\Cnt[4]_i_3__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"555555555555555B"
    )
        port map (
      I0 => \Cnt_reg_n_0_[4]\,
      I1 => \Cnt_reg_n_0_[5]\,
      I2 => \Cnt_reg_n_0_[3]\,
      I3 => \Cnt_reg_n_0_[0]\,
      I4 => \Cnt_reg_n_0_[1]\,
      I5 => \Cnt_reg_n_0_[2]\,
      O => \Cnt[4]_i_3__0_n_0\
    );
\Cnt[4]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"DFFDDFFDDFFDDFFF"
    )
        port map (
      I0 => \Cnt[5]_i_10_n_0\,
      I1 => RTR_TX,
      I2 => D_Len_TX(1),
      I3 => D_Len_TX(0),
      I4 => D_Len_TX(3),
      I5 => D_Len_TX(2),
      O => \Cnt[4]_i_5_n_0\
    );
\Cnt[5]_i_10\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => TXSTATES(0),
      I1 => TransBS_n_20,
      O => \Cnt[5]_i_10_n_0\
    );
\Cnt[5]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5555555555555557"
    )
        port map (
      I0 => \Cnt_reg_n_0_[5]\,
      I1 => \Cnt_reg_n_0_[3]\,
      I2 => \Cnt_reg_n_0_[0]\,
      I3 => \Cnt_reg_n_0_[1]\,
      I4 => \Cnt_reg_n_0_[2]\,
      I5 => \Cnt_reg_n_0_[4]\,
      O => \Cnt[5]_i_5_n_0\
    );
\Cnt[5]_i_9\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"4444440000000040"
    )
        port map (
      I0 => RTR_TX,
      I1 => \Cnt[5]_i_10_n_0\,
      I2 => D_Len_TX(3),
      I3 => D_Len_TX(1),
      I4 => D_Len_TX(0),
      I5 => D_Len_TX(2),
      O => \Cnt[5]_i_9_n_0\
    );
\Cnt_reg[0]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => TransBS_n_31,
      CLR => \CRC_RG_reg[0]\,
      D => TransBS_n_19,
      Q => \Cnt_reg_n_0_[0]\
    );
\Cnt_reg[1]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => TransBS_n_31,
      CLR => \CRC_RG_reg[0]\,
      D => TransBS_n_18,
      Q => \Cnt_reg_n_0_[1]\
    );
\Cnt_reg[2]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => TransBS_n_31,
      CLR => \CRC_RG_reg[0]\,
      D => TransBS_n_17,
      Q => \Cnt_reg_n_0_[2]\
    );
\Cnt_reg[3]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => TransBS_n_31,
      CLR => \CRC_RG_reg[0]\,
      D => TransBS_n_16,
      Q => \Cnt_reg_n_0_[3]\
    );
\Cnt_reg[4]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => TransBS_n_31,
      CLR => \CRC_RG_reg[0]\,
      D => TransBS_n_15,
      Q => \Cnt_reg_n_0_[4]\
    );
\Cnt_reg[5]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => TransBS_n_31,
      CLR => \CRC_RG_reg[0]\,
      D => TransBS_n_14,
      Q => \Cnt_reg_n_0_[5]\
    );
\REC[8]_i_12\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \^imtx\,
      I1 => \TEC[8]_i_5\,
      O => \^imtx_reg_1\
    );
\REC[8]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"45"
    )
        port map (
      I0 => \^imtx_reg_1\,
      I1 => \REC_reg[8]\,
      I2 => req_Error_RX,
      O => req_Error_reg_2
    );
\State[0]_i_11\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"F7FB"
    )
        port map (
      I0 => TXSTATES(2),
      I1 => TXSTATES(1),
      I2 => TXSTATES(3),
      I3 => TXSTATES(0),
      O => \State[0]_i_11_n_0\
    );
\State[0]_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"E0E1"
    )
        port map (
      I0 => TXSTATES(2),
      I1 => TXSTATES(1),
      I2 => TXSTATES(3),
      I3 => TXSTATES(0),
      O => \State[0]_i_7_n_0\
    );
\TEC[8]_i_14\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \^imtx\,
      I1 => \TEC[8]_i_5\,
      O => imTX_reg_0
    );
TRANSMITr_i_1: unisim.vcomponents.LUT5
    generic map(
      INIT => X"F8FF8888"
    )
        port map (
      I0 => TRANSMIT,
      I1 => TRANSMIT_reg,
      I2 => done_TXr,
      I3 => \^done_reg_0\,
      I4 => TRANSMITr,
      O => TRANSMIT_1
    );
\TXSTATES[1]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"45"
    )
        port map (
      I0 => TXSTATES(1),
      I1 => TransBS_n_20,
      I2 => TXSTATES(0),
      O => \TXSTATES[1]_i_4_n_0\
    );
\TXSTATES[2]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000C00001CCC1CCC"
    )
        port map (
      I0 => TransBS_n_20,
      I1 => TXSTATES(2),
      I2 => TXSTATES(0),
      I3 => TXSTATES(1),
      I4 => \Cnt_reg[1]_0\,
      I5 => TXSTATES(3),
      O => \TXSTATES[2]_i_3_n_0\
    );
\TXSTATES_reg[0]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => E(0),
      CLR => \CRC_RG_reg[0]\,
      D => D(0),
      Q => TXSTATES(0)
    );
\TXSTATES_reg[1]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => E(0),
      CLR => \CRC_RG_reg[0]\,
      D => D(1),
      Q => TXSTATES(1)
    );
\TXSTATES_reg[2]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => E(0),
      CLR => \CRC_RG_reg[0]\,
      D => D(2),
      Q => TXSTATES(2)
    );
\TXSTATES_reg[3]\: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => E(0),
      CLR => \CRC_RG_reg[0]\,
      D => D(3),
      Q => TXSTATES(3)
    );
TX_INST_0_i_4: unisim.vcomponents.LUT4
    generic map(
      INIT => X"003E"
    )
        port map (
      I0 => TXSTATES(0),
      I1 => TXSTATES(2),
      I2 => TXSTATES(1),
      I3 => TXSTATES(3),
      O => TX_INST_0_i_4_n_0
    );
TX_INST_0_i_5: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFBFFAFAFABAF"
    )
        port map (
      I0 => TXSTATES(2),
      I1 => \CRC_RG[14]_i_9_n_0\,
      I2 => TXSTATES(0),
      I3 => TXSTATES(1),
      I4 => TransBS_n_22,
      I5 => TransBS_n_21,
      O => TX_INST_0_i_5_n_0
    );
TransBS: entity work.design_1_FPGAPROJECT_0_0_bitstuffer_8
     port map (
      \CRC_RG_reg[14]\ => txcrc_n_0,
      \CRC_RG_reg[14]_0\ => txcrc_n_1,
      \CRC_RG_reg[14]_1\ => txcrc_n_5,
      \Cnt[0]_i_2_0\ => \Cnt[0]_i_2\,
      \Cnt_reg[0]\ => \Cnt[0]_i_5_n_0\,
      \Cnt_reg[0]_0\ => \Cnt[0]_i_3_n_0\,
      \Cnt_reg[1]\ => \Cnt_reg[1]_0\,
      \Cnt_reg[1]_0\ => \Cnt[1]_i_4__0_n_0\,
      \Cnt_reg[1]_1\ => \Cnt[1]_i_5_n_0\,
      \Cnt_reg[1]_2\ => \Cnt[1]_i_6__0_n_0\,
      \Cnt_reg[1]_3\ => \Cnt[1]_i_8_n_0\,
      \Cnt_reg[2]\ => TransBS_n_20,
      \Cnt_reg[2]_0\ => \Cnt[2]_i_2__0_n_0\,
      \Cnt_reg[2]_1\ => \TXSTATES[1]_i_4_n_0\,
      \Cnt_reg[3]\ => TransBS_n_22,
      \Cnt_reg[3]_0\ => \Cnt[3]_i_2__1_n_0\,
      \Cnt_reg[3]_1\ => \Cnt[3]_i_4_n_0\,
      \Cnt_reg[4]\ => TransBS_n_25,
      \Cnt_reg[4]_0\ => TransBS_n_29,
      \Cnt_reg[4]_1\ => \Cnt[4]_i_3__0_n_0\,
      \Cnt_reg[4]_2\ => txcrc_n_4,
      \Cnt_reg[4]_3\ => \Cnt[4]_i_5_n_0\,
      \Cnt_reg[5]\ => \Cnt[5]_i_5_n_0\,
      \Cnt_reg[5]_0\ => \Cnt[5]_i_9_n_0\,
      \Cnt_reg[5]_1\ => \Cnt_reg[5]_0\,
      D(5) => TransBS_n_14,
      D(4) => TransBS_n_15,
      D(3) => TransBS_n_16,
      D(2) => TransBS_n_17,
      D(1) => TransBS_n_18,
      D(0) => TransBS_n_19,
      D_Len_TX(3 downto 0) => D_Len_TX(3 downto 0),
      \D_Len_TX_1[3]\ => TransBS_n_26,
      E(0) => TransBS_n_13,
      IDE_TX => IDE_TX,
      ID_TX(28 downto 0) => ID_TX(28 downto 0),
      \ID_TX_1[10]\ => TransBS_n_27,
      \ID_TX_1[28]\ => TransBS_n_24,
      \ID_TX_1[28]_0\ => TransBS_n_28,
      \ID_TX_1[8]\ => TransBS_n_23,
      Q(3 downto 0) => TXSTATES(3 downto 0),
      \REC[0]_i_5\ => \REC[0]_i_5\,
      \REC[0]_i_5_0\ => \REC[0]_i_5_0\,
      \REC[0]_i_6_0\ => \State[0]_i_11_n_0\,
      RTR_TX => RTR_TX,
      RXOUT_reg => RXOUT_reg,
      SRST => SRST,
      SRST_1(0) => TransBS_n_31,
      Sampled_din => Sampled_din,
      \State[0]_i_2\ => \^txstates_reg[1]_0\,
      \State[0]_i_4_0\ => txcrc_n_2,
      \State[2]_i_3\ => \State[0]_i_7_n_0\,
      TEC(1 downto 0) => TEC(1 downto 0),
      \TEC_reg[8]\ => \TEC_reg[8]\,
      \TXSTATES_reg[1]\ => \TXSTATES_reg[1]_1\,
      \TXSTATES_reg[1]_0\ => \TXSTATES_reg[1]_2\,
      \TXSTATES_reg[1]_1\ => TransBS_n_21,
      \TXSTATES_reg[2]\ => \TXSTATES_reg[2]_0\,
      \TXSTATES_reg[3]\ => \TXSTATES_reg[3]_0\,
      \TXSTATES_reg[3]_0\ => \TXSTATES_reg[3]_1\,
      \TXSTATES_reg[3]_1\ => \TXSTATES_reg[3]_2\,
      TX_INST_0_i_2 => TX_INST_0_i_4_n_0,
      TX_INST_0_i_2_0 => TX_INST_0_i_5_n_0,
      Tq => Tq,
      done_i_4_0 => done_i_16_n_0,
      done_i_4_1 => done_i_17_n_0,
      done_i_4_2 => done_i_18_n_0,
      done_i_4_3 => done_i_19_n_0,
      done_reg => TransBS_n_30,
      done_reg_0 => \done_i_2__0_n_0\,
      done_reg_1 => done_i_10_n_0,
      done_reg_2 => done_i_9_n_0,
      done_reg_3 => done_i_13_n_0,
      done_reg_4 => done_i_6_n_0,
      done_reg_5 => \^done_reg_0\,
      imTX0_out => imTX0_out,
      imTX_reg => imTX_i_2_n_0,
      imTX_reg_0 => \TXSTATES[2]_i_3_n_0\,
      req_Error_RX => req_Error_RX,
      req_Error_reg => req_Error_reg,
      req_Error_reg_0 => req_Error_reg_0,
      req_Error_reg_1 => req_Error_reg_1,
      req_Errorr => req_Errorr,
      req_Errorr_reg => req_Errorr_reg_n_0,
      \serial[0]_i_12_0\(5) => \Cnt_reg_n_0_[5]\,
      \serial[0]_i_12_0\(4) => \Cnt_reg_n_0_[4]\,
      \serial[0]_i_12_0\(3) => \Cnt_reg_n_0_[3]\,
      \serial[0]_i_12_0\(2) => \Cnt_reg_n_0_[2]\,
      \serial[0]_i_12_0\(1) => \Cnt_reg_n_0_[1]\,
      \serial[0]_i_12_0\(0) => \Cnt_reg_n_0_[0]\,
      \serial[0]_i_2_0\ => \serial[0]_i_13_n_0\,
      \serial_reg[0]_0\ => txcrc_n_3,
      \serial_reg[0]_1\ => \CRC_RG_reg[0]\
    );
ack_error_i_4: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0080"
    )
        port map (
      I0 => TXSTATES(1),
      I1 => TXSTATES(2),
      I2 => TXSTATES(0),
      I3 => TXSTATES(3),
      O => \^txstates_reg[1]_0\
    );
done_i_10: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000002"
    )
        port map (
      I0 => TRANSMITr,
      I1 => TXSTATES(0),
      I2 => TXSTATES(3),
      I3 => TXSTATES(1),
      I4 => TXSTATES(2),
      I5 => done_i_12,
      O => done_i_10_n_0
    );
done_i_13: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => TXSTATES(2),
      I1 => TXSTATES(3),
      O => done_i_13_n_0
    );
done_i_16: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => TXSTATES(2),
      I1 => TXSTATES(1),
      O => done_i_16_n_0
    );
done_i_17: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => TransBS_n_20,
      I1 => TXSTATES(0),
      O => done_i_17_n_0
    );
done_i_18: unisim.vcomponents.LUT4
    generic map(
      INIT => X"D7F5"
    )
        port map (
      I0 => TXSTATES(2),
      I1 => TXSTATES(1),
      I2 => TXSTATES(0),
      I3 => TransBS_n_20,
      O => done_i_18_n_0
    );
done_i_19: unisim.vcomponents.LUT5
    generic map(
      INIT => X"0D0DFDF0"
    )
        port map (
      I0 => TRANSMITr,
      I1 => done_i_12,
      I2 => TransBS_n_20,
      I3 => done_i_12_0,
      I4 => TXSTATES(0),
      O => done_i_19_n_0
    );
\done_i_2__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0010"
    )
        port map (
      I0 => TXSTATES(0),
      I1 => TXSTATES(3),
      I2 => TXSTATES(1),
      I3 => TXSTATES(2),
      O => \done_i_2__0_n_0\
    );
done_i_6: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CFFE0000FFFFFFFF"
    )
        port map (
      I0 => TXSTATES(0),
      I1 => TXSTATES(2),
      I2 => TXSTATES(3),
      I3 => TXSTATES(1),
      I4 => \Cnt_reg[5]_0\,
      I5 => SRST,
      O => done_i_6_n_0
    );
done_i_9: unisim.vcomponents.LUT5
    generic map(
      INIT => X"0100FFFF"
    )
        port map (
      I0 => \Cnt_reg[1]_0\,
      I1 => TXSTATES(1),
      I2 => TXSTATES(0),
      I3 => TXSTATES(2),
      I4 => TXSTATES(3),
      O => done_i_9_n_0
    );
done_reg: unisim.vcomponents.FDPE
     port map (
      C => Tq,
      CE => '1',
      D => TransBS_n_30,
      PRE => \CRC_RG_reg[0]\,
      Q => \^done_reg_0\
    );
donefromtxr_i_1: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => SRST,
      I1 => \^done_reg_0\,
      O => donefromtxr
    );
imTX_i_2: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8888888888888880"
    )
        port map (
      I0 => \^imtx\,
      I1 => SRST,
      I2 => TXSTATES(0),
      I3 => TXSTATES(3),
      I4 => TXSTATES(1),
      I5 => TXSTATES(2),
      O => imTX_i_2_n_0
    );
imTX_reg: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => E(0),
      CLR => \CRC_RG_reg[0]\,
      D => imTX0_out,
      Q => \^imtx\
    );
req_Errorr_reg: unisim.vcomponents.FDCE
     port map (
      C => Tq,
      CE => E(0),
      CLR => \CRC_RG_reg[0]\,
      D => req_Errorr,
      Q => req_Errorr_reg_n_0
    );
\serial[0]_i_13\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"55555555555555D5"
    )
        port map (
      I0 => TransBS_n_29,
      I1 => \Cnt_reg_n_0_[0]\,
      I2 => \Cnt_reg_n_0_[1]\,
      I3 => \serial[0]_i_34_n_0\,
      I4 => IDE_TX,
      I5 => \Cnt_reg_n_0_[2]\,
      O => \serial[0]_i_13_n_0\
    );
\serial[0]_i_34\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"FB"
    )
        port map (
      I0 => \Cnt_reg_n_0_[3]\,
      I1 => \Cnt_reg_n_0_[4]\,
      I2 => \Cnt_reg_n_0_[5]\,
      O => \serial[0]_i_34_n_0\
    );
txcrc: entity work.design_1_FPGAPROJECT_0_0_CRC_9
     port map (
      \CRC_RG[14]_i_8_0\ => TransBS_n_29,
      \CRC_RG[14]_i_8_1\ => TransBS_n_28,
      \CRC_RG[14]_i_8_2\ => TransBS_n_27,
      \CRC_RG[14]_i_8_3\ => TransBS_n_26,
      \CRC_RG_reg[0]_0\ => \CRC_RG_reg[0]\,
      \CRC_RG_reg[14]_0\ => \Cnt_reg[5]_0\,
      \Cnt[5]_i_7\ => \CRC_RG[14]_i_9_n_0\,
      \Cnt_reg[5]\ => txcrc_n_3,
      E(0) => TransBS_n_13,
      Q(3 downto 0) => TXSTATES(3 downto 0),
      SRST => SRST,
      SRST_1 => txcrc_n_0,
      \TXSTATES_reg[0]\ => txcrc_n_4,
      \TXSTATES_reg[2]\ => txcrc_n_5,
      \TXSTATES_reg[3]\ => txcrc_n_1,
      \TXSTATES_reg[3]_0\ => txcrc_n_2,
      Tq => Tq,
      data_TX(63 downto 0) => data_TX(63 downto 0),
      \serial[0]_i_2\(5) => \Cnt_reg_n_0_[5]\,
      \serial[0]_i_2\(4) => \Cnt_reg_n_0_[4]\,
      \serial[0]_i_2\(3) => \Cnt_reg_n_0_[3]\,
      \serial[0]_i_2\(2) => \Cnt_reg_n_0_[2]\,
      \serial[0]_i_2\(1) => \Cnt_reg_n_0_[1]\,
      \serial[0]_i_2\(0) => \Cnt_reg_n_0_[0]\
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1_FPGAPROJECT_0_0_CANCORE is
  port (
    CAN_CLK : in STD_LOGIC;
    CAN_RST : in STD_LOGIC;
    RX : in STD_LOGIC;
    TX : out STD_LOGIC;
    done_RX : out STD_LOGIC;
    done_TX : out STD_LOGIC;
    SRST : in STD_LOGIC;
    SJW : in STD_LOGIC_VECTOR ( 2 downto 0 );
    TPROP : in STD_LOGIC_VECTOR ( 3 downto 0 );
    TSEG1 : in STD_LOGIC_VECTOR ( 3 downto 0 );
    TSEG2 : in STD_LOGIC_VECTOR ( 3 downto 0 );
    BRP : in STD_LOGIC_VECTOR ( 4 downto 0 );
    Mode : in STD_LOGIC_VECTOR ( 2 downto 0 );
    TRANSMIT : in STD_LOGIC;
    IDE_TX : in STD_LOGIC;
    RTR_TX : in STD_LOGIC;
    D_Len_TX : in STD_LOGIC_VECTOR ( 3 downto 0 );
    ID_TX : in STD_LOGIC_VECTOR ( 28 downto 0 );
    data_TX : in STD_LOGIC_VECTOR ( 63 downto 0 );
    IDE_rec : out STD_LOGIC;
    RTR_rec : out STD_LOGIC;
    D_Len_rec : out STD_LOGIC_VECTOR ( 3 downto 0 );
    TOFILTERd : out STD_LOGIC_VECTOR ( 63 downto 0 );
    TOFILTERI : out STD_LOGIC_VECTOR ( 28 downto 0 );
    TEC : out STD_LOGIC_VECTOR ( 8 downto 0 );
    REC : out STD_LOGIC_VECTOR ( 8 downto 0 )
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of design_1_FPGAPROJECT_0_0_CANCORE : entity is "CANCORE";
end design_1_FPGAPROJECT_0_0_CANCORE;

architecture STRUCTURE of design_1_FPGAPROJECT_0_0_CANCORE is
  signal AckTakeOver : STD_LOGIC;
  signal RXBUS : STD_LOGIC;
  signal RXBUSs : STD_LOGIC;
  signal RXSTATES : STD_LOGIC_VECTOR ( 3 to 3 );
  signal Sampled_din : STD_LOGIC;
  signal State : STD_LOGIC_VECTOR ( 2 downto 0 );
  signal \^tec\ : STD_LOGIC_VECTOR ( 8 downto 0 );
  signal TRANSMIT_reg : STD_LOGIC;
  signal TRANSMITr : STD_LOGIC;
  signal Tq : STD_LOGIC;
  signal \^done_rx\ : STD_LOGIC;
  signal \^done_tx\ : STD_LOGIC;
  signal done_TXr : STD_LOGIC;
  signal donefromrxr : STD_LOGIC;
  signal donefromtxr : STD_LOGIC;
  signal err1_n_12 : STD_LOGIC;
  signal err1_n_13 : STD_LOGIC;
  signal err1_n_23 : STD_LOGIC;
  signal err1_n_24 : STD_LOGIC;
  signal err1_n_25 : STD_LOGIC;
  signal err1_n_26 : STD_LOGIC;
  signal err1_n_27 : STD_LOGIC;
  signal err1_n_28 : STD_LOGIC;
  signal err1_n_30 : STD_LOGIC;
  signal err1_n_32 : STD_LOGIC;
  signal err1_n_33 : STD_LOGIC;
  signal err1_n_34 : STD_LOGIC;
  signal err1_n_35 : STD_LOGIC;
  signal err1_n_36 : STD_LOGIC;
  signal err1_n_37 : STD_LOGIC;
  signal err1_n_38 : STD_LOGIC;
  signal imTX : STD_LOGIC;
  signal rengine1_n_1 : STD_LOGIC;
  signal rengine1_n_10 : STD_LOGIC;
  signal rengine1_n_11 : STD_LOGIC;
  signal rengine1_n_2 : STD_LOGIC;
  signal rengine1_n_3 : STD_LOGIC;
  signal rengine1_n_4 : STD_LOGIC;
  signal rengine1_n_5 : STD_LOGIC;
  signal rengine1_n_6 : STD_LOGIC;
  signal rengine1_n_7 : STD_LOGIC;
  signal rengine1_n_8 : STD_LOGIC;
  signal rengine1_n_9 : STD_LOGIC;
  signal req_Error_RX : STD_LOGIC;
  signal rx1_n_1 : STD_LOGIC;
  signal rx1_n_110 : STD_LOGIC;
  signal rx1_n_111 : STD_LOGIC;
  signal rx1_n_12 : STD_LOGIC;
  signal rx1_n_13 : STD_LOGIC;
  signal rx1_n_14 : STD_LOGIC;
  signal rx1_n_15 : STD_LOGIC;
  signal rx1_n_6 : STD_LOGIC;
  signal tx1_n_10 : STD_LOGIC;
  signal tx1_n_11 : STD_LOGIC;
  signal tx1_n_12 : STD_LOGIC;
  signal tx1_n_13 : STD_LOGIC;
  signal tx1_n_15 : STD_LOGIC;
  signal tx1_n_16 : STD_LOGIC;
  signal tx1_n_17 : STD_LOGIC;
  signal tx1_n_18 : STD_LOGIC;
  signal tx1_n_2 : STD_LOGIC;
  signal tx1_n_3 : STD_LOGIC;
  signal tx1_n_4 : STD_LOGIC;
  signal tx1_n_5 : STD_LOGIC;
  signal tx1_n_6 : STD_LOGIC;
  signal tx1_n_7 : STD_LOGIC;
  signal tx1_n_8 : STD_LOGIC;
  signal tx1_n_9 : STD_LOGIC;
begin
  TEC(8 downto 0) <= \^tec\(8 downto 0);
  done_RX <= \^done_rx\;
  done_TX <= \^done_tx\;
TFF_RXB: entity work.design_1_FPGAPROJECT_0_0_TFF_2
     port map (
      RX => RX,
      RXBUSs => RXBUSs,
      Tq => Tq,
      q_reg => rx1_n_1
    );
TRANSMIT_reg_reg: unisim.vcomponents.FDCE
     port map (
      C => CAN_CLK,
      CE => '1',
      CLR => rx1_n_1,
      D => TRANSMIT,
      Q => TRANSMIT_reg
    );
TRANSMITr_reg: unisim.vcomponents.FDCE
     port map (
      C => CAN_CLK,
      CE => '1',
      CLR => rx1_n_1,
      D => tx1_n_16,
      Q => TRANSMITr
    );
done_TXr_reg: unisim.vcomponents.FDCE
     port map (
      C => CAN_CLK,
      CE => '1',
      CLR => rx1_n_1,
      D => \^done_tx\,
      Q => done_TXr
    );
err1: entity work.design_1_FPGAPROJECT_0_0_ErrorHandler_3
     port map (
      AckTakeOver => AckTakeOver,
      D(3) => err1_n_24,
      D(2) => err1_n_25,
      D(1) => err1_n_26,
      D(0) => err1_n_27,
      E(0) => rengine1_n_10,
      IDE_i_2_0 => tx1_n_7,
      Mode(2 downto 0) => Mode(2 downto 0),
      \Mode_1[1]\ => err1_n_32,
      Q(8 downto 0) => \^tec\(8 downto 0),
      \REC[0]_i_3_0\ => tx1_n_2,
      \REC[0]_i_3_1\ => tx1_n_5,
      \REC_reg[0]_0\ => rx1_n_6,
      \REC_reg[6]_0\ => \^done_rx\,
      \REC_reg[8]_0\(8 downto 0) => REC(8 downto 0),
      \REC_reg[8]_1\ => err1_n_34,
      \REC_reg[8]_2\ => tx1_n_17,
      \REC_reg[8]_3\ => tx1_n_18,
      \RECin_reg[7]_0\ => tx1_n_8,
      RXBUS => RXBUS,
      RXBUSs => RXBUSs,
      \RXSTATES_reg[1]\ => rx1_n_13,
      SRST => SRST,
      SRST_1(0) => err1_n_33,
      Sampled_din => Sampled_din,
      \State_reg[0]_0\ => err1_n_23,
      \State_reg[0]_1\ => err1_n_28,
      \State_reg[0]_2\ => err1_n_38,
      \State_reg[0]_3\ => rengine1_n_11,
      \State_reg[0]_4\ => rx1_n_110,
      \State_reg[0]_5\ => tx1_n_3,
      \State_reg[2]_0\(2 downto 0) => State(2 downto 0),
      \State_reg[2]_1\ => err1_n_13,
      \State_reg[2]_2\ => err1_n_35,
      \State_reg[2]_3\ => err1_n_37,
      \State_reg[2]_i_2_0\ => tx1_n_6,
      \TEC_reg[0]_0\ => tx1_n_15,
      \TEC_reg[0]_1\ => \^done_tx\,
      \TEC_reg[8]_0\ => err1_n_12,
      TX => TX,
      \TXSTATES_reg[0]\ => tx1_n_11,
      \TXSTATES_reg[1]\ => tx1_n_13,
      \TXSTATES_reg[2]\ => tx1_n_12,
      \TXSTATES_reg[3]\ => tx1_n_10,
      Tq => Tq,
      ack_error_reg_0 => rx1_n_1,
      ack_error_reg_1 => rengine1_n_4,
      ack_error_reg_2 => tx1_n_4,
      ack_error_reg_3 => tx1_n_9,
      donefromrxr => donefromrxr,
      donefromtxr => donefromtxr,
      imTX => imTX,
      lastvalue_reg_0 => rengine1_n_8,
      q_reg => err1_n_30,
      req_Error_RX => req_Error_RX,
      req_Error_reg => err1_n_36
    );
p1: entity work.design_1_FPGAPROJECT_0_0_Prescaler_4
     port map (
      BRP(4 downto 0) => BRP(4 downto 0),
      CAN_CLK => CAN_CLK,
      Tq => Tq,
      \count_reg[0]_0\ => rx1_n_1
    );
rengine1: entity work.design_1_FPGAPROJECT_0_0_Rengine_5
     port map (
      \CNT1_reg[3]_0\ => rengine1_n_3,
      \CNT1_reg[3]_1\ => rengine1_n_6,
      \CNT1_reg[4]_0\ => rx1_n_15,
      \CNT1_reg[4]_1\ => err1_n_32,
      \CNT1_reg[4]_2\ => err1_n_30,
      \CNT2_reg[3]_0\ => rengine1_n_4,
      \CNT2_reg[3]_1\(0) => rx1_n_12,
      E(0) => rengine1_n_1,
      Q(0) => RXSTATES(3),
      RXBUS => RXBUS,
      RXBUS_d_reg_0 => rengine1_n_2,
      RXOUT_reg_0 => rengine1_n_8,
      RXOUT_reg_1 => rx1_n_1,
      \RXSTATES_reg[3]\ => rengine1_n_5,
      \RXSTATES_reg[3]_0\ => rx1_n_111,
      \RXSTATES_reg[3]_1\ => err1_n_35,
      SJW(2 downto 0) => SJW(2 downto 0),
      SRST => SRST,
      SRST_1(0) => rengine1_n_7,
      SRST_1_0(0) => rengine1_n_9,
      SRST_1_1(0) => rengine1_n_10,
      SRST_1_2(0) => rengine1_n_11,
      Sampled_din => Sampled_din,
      TPROP(3 downto 0) => TPROP(3 downto 0),
      TSEG1(3 downto 0) => TSEG1(3 downto 0),
      TSEG2(3 downto 0) => TSEG2(3 downto 0),
      Tq => Tq
    );
rx1: entity work.design_1_FPGAPROJECT_0_0_RXMachine_6
     port map (
      AckTakeOver => AckTakeOver,
      CAN_RST => CAN_RST,
      CAN_RST_0 => rx1_n_1,
      \CNT2_reg[3]\ => rengine1_n_2,
      \CNT2_reg[3]_0\ => rengine1_n_3,
      \CRC_RG_reg[14]\ => rengine1_n_6,
      \Cnt[0]_i_2__0_0\(2 downto 0) => State(2 downto 0),
      \Cnt_reg[0]_0\(0) => rengine1_n_9,
      D(0) => err1_n_33,
      \D_Len_reg[3]_0\(3 downto 0) => D_Len_rec(3 downto 0),
      E(0) => rengine1_n_11,
      IDE_rec => IDE_rec,
      IDE_reg_0 => err1_n_30,
      Q(0) => RXSTATES(3),
      \REC_reg[0]\ => err1_n_28,
      RTR_reg_0 => RTR_rec,
      RXOUT_reg => rx1_n_110,
      \RXSTATES_reg[0]_0\ => rx1_n_13,
      \RXSTATES_reg[0]_1\ => rx1_n_14,
      \RXSTATES_reg[0]_2\ => err1_n_38,
      \RXSTATES_reg[0]_3\ => err1_n_36,
      \RXSTATES_reg[1]_0\ => rx1_n_15,
      \RXSTATES_reg[1]_1\ => err1_n_13,
      \RXSTATES_reg[2]_0\(0) => rx1_n_12,
      \RXSTATES_reg[3]_0\ => err1_n_35,
      \RXSTATES_reg[3]_1\(0) => rengine1_n_7,
      SRST => SRST,
      Sampled_din => Sampled_din,
      TOFILTERI(28 downto 0) => TOFILTERI(28 downto 0),
      \TOFILTERI_reg[28]_0\ => rengine1_n_5,
      TOFILTERd(63 downto 0) => TOFILTERd(63 downto 0),
      Tq => Tq,
      \bs_reg[0]_0\(0) => rengine1_n_1,
      \bs_reg[1]_0\ => rx1_n_111,
      done_reg_0 => \^done_rx\,
      donefromrxr => donefromrxr,
      imTX => imTX,
      req_Error_RX => req_Error_RX,
      req_Error_reg_0 => rx1_n_6
    );
tx1: entity work.design_1_FPGAPROJECT_0_0_TXMachine_7
     port map (
      \CRC_RG_reg[0]\ => rx1_n_1,
      \Cnt[0]_i_2\ => err1_n_34,
      \Cnt_reg[1]_0\ => err1_n_13,
      \Cnt_reg[5]_0\ => rengine1_n_4,
      D(3) => err1_n_24,
      D(2) => err1_n_25,
      D(1) => err1_n_26,
      D(0) => err1_n_27,
      D_Len_TX(3 downto 0) => D_Len_TX(3 downto 0),
      E(0) => rengine1_n_11,
      IDE_TX => IDE_TX,
      ID_TX(28 downto 0) => ID_TX(28 downto 0),
      \REC[0]_i_5\ => rx1_n_110,
      \REC[0]_i_5_0\ => err1_n_23,
      \REC_reg[8]\ => err1_n_28,
      RTR_TX => RTR_TX,
      RXOUT_reg => tx1_n_9,
      SRST => SRST,
      Sampled_din => Sampled_din,
      TEC(1 downto 0) => \^tec\(8 downto 7),
      \TEC[8]_i_5\ => err1_n_37,
      \TEC_reg[8]\ => tx1_n_2,
      TRANSMIT => TRANSMIT,
      TRANSMIT_1 => tx1_n_16,
      TRANSMIT_reg => TRANSMIT_reg,
      TRANSMITr => TRANSMITr,
      \TXSTATES_reg[1]_0\ => tx1_n_4,
      \TXSTATES_reg[1]_1\ => tx1_n_8,
      \TXSTATES_reg[1]_2\ => tx1_n_13,
      \TXSTATES_reg[2]_0\ => tx1_n_12,
      \TXSTATES_reg[3]_0\ => tx1_n_7,
      \TXSTATES_reg[3]_1\ => tx1_n_10,
      \TXSTATES_reg[3]_2\ => tx1_n_11,
      Tq => Tq,
      data_TX(63 downto 0) => data_TX(63 downto 0),
      done_TXr => done_TXr,
      done_i_12 => rx1_n_14,
      done_i_12_0 => err1_n_12,
      done_reg_0 => \^done_tx\,
      donefromtxr => donefromtxr,
      imTX => imTX,
      imTX_reg_0 => tx1_n_15,
      imTX_reg_1 => tx1_n_18,
      req_Error_RX => req_Error_RX,
      req_Error_reg => tx1_n_3,
      req_Error_reg_0 => tx1_n_5,
      req_Error_reg_1 => tx1_n_6,
      req_Error_reg_2 => tx1_n_17
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity \design_1_FPGAPROJECT_0_0_CANCORE__2\ is
  port (
    done_TX : out STD_LOGIC;
    RTR_rec_0 : out STD_LOGIC;
    IDE_rec_0 : out STD_LOGIC;
    done_reg : out STD_LOGIC;
    Q : out STD_LOGIC_VECTOR ( 8 downto 0 );
    \REC_reg[8]\ : out STD_LOGIC_VECTOR ( 8 downto 0 );
    D_Len_rec_0 : out STD_LOGIC_VECTOR ( 3 downto 0 );
    TOFILTERd_0 : out STD_LOGIC_VECTOR ( 63 downto 0 );
    TOFILTERI_0 : out STD_LOGIC_VECTOR ( 28 downto 0 );
    RX : out STD_LOGIC;
    SRST_0 : in STD_LOGIC;
    IDE_TX_0 : in STD_LOGIC;
    TRANSMIT_0 : in STD_LOGIC;
    CAN_CLK : in STD_LOGIC;
    Mode_0 : in STD_LOGIC_VECTOR ( 2 downto 0 );
    TX : in STD_LOGIC;
    RTR_TX_0 : in STD_LOGIC;
    D_Len_TX_0 : in STD_LOGIC_VECTOR ( 3 downto 0 );
    ID_TX_0 : in STD_LOGIC_VECTOR ( 28 downto 0 );
    data_TX_0 : in STD_LOGIC_VECTOR ( 63 downto 0 );
    CAN_RST : in STD_LOGIC;
    BRP_0 : in STD_LOGIC_VECTOR ( 4 downto 0 )
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of \design_1_FPGAPROJECT_0_0_CANCORE__2\ : entity is "CANCORE";
end \design_1_FPGAPROJECT_0_0_CANCORE__2\;

architecture STRUCTURE of \design_1_FPGAPROJECT_0_0_CANCORE__2\ is
  signal AckTakeOver : STD_LOGIC;
  signal \^q\ : STD_LOGIC_VECTOR ( 8 downto 0 );
  signal \^rx\ : STD_LOGIC;
  signal RXBUS : STD_LOGIC;
  signal RXBUS_d : STD_LOGIC;
  signal RXBUSs : STD_LOGIC;
  signal Sampled_din : STD_LOGIC;
  signal State : STD_LOGIC_VECTOR ( 0 to 0 );
  signal TRANSMIT_reg : STD_LOGIC;
  signal TRANSMITr : STD_LOGIC;
  signal TRANSMITr_i_1_n_0 : STD_LOGIC;
  signal Tq : STD_LOGIC;
  signal Tq_i_1_n_0 : STD_LOGIC;
  signal count_reg : STD_LOGIC_VECTOR ( 4 downto 3 );
  signal \^done_tx\ : STD_LOGIC;
  signal done_TXr : STD_LOGIC;
  signal \^done_reg\ : STD_LOGIC;
  signal donefromrxr : STD_LOGIC;
  signal donefromtxr : STD_LOGIC;
  signal err1_n_20 : STD_LOGIC;
  signal err1_n_21 : STD_LOGIC;
  signal err1_n_22 : STD_LOGIC;
  signal err1_n_23 : STD_LOGIC;
  signal err1_n_24 : STD_LOGIC;
  signal err1_n_25 : STD_LOGIC;
  signal err1_n_26 : STD_LOGIC;
  signal err1_n_29 : STD_LOGIC;
  signal err1_n_30 : STD_LOGIC;
  signal err1_n_31 : STD_LOGIC;
  signal err1_n_32 : STD_LOGIC;
  signal err1_n_33 : STD_LOGIC;
  signal err1_n_34 : STD_LOGIC;
  signal imTX : STD_LOGIC;
  signal lastvalue : STD_LOGIC;
  signal p1_n_3 : STD_LOGIC;
  signal rengine1_n_10 : STD_LOGIC;
  signal rengine1_n_11 : STD_LOGIC;
  signal rengine1_n_12 : STD_LOGIC;
  signal rengine1_n_13 : STD_LOGIC;
  signal rengine1_n_2 : STD_LOGIC;
  signal rengine1_n_3 : STD_LOGIC;
  signal rengine1_n_4 : STD_LOGIC;
  signal rengine1_n_5 : STD_LOGIC;
  signal rengine1_n_6 : STD_LOGIC;
  signal rengine1_n_7 : STD_LOGIC;
  signal rengine1_n_8 : STD_LOGIC;
  signal rengine1_n_9 : STD_LOGIC;
  signal req_Error_RX : STD_LOGIC;
  signal rx1_n_1 : STD_LOGIC;
  signal rx1_n_13 : STD_LOGIC;
  signal rx1_n_14 : STD_LOGIC;
  signal rx1_n_15 : STD_LOGIC;
  signal rx1_n_6 : STD_LOGIC;
  signal rx1_n_7 : STD_LOGIC;
  signal rx1_n_8 : STD_LOGIC;
  signal rx1_n_80 : STD_LOGIC;
  signal tx1_n_10 : STD_LOGIC;
  signal tx1_n_2 : STD_LOGIC;
  signal tx1_n_3 : STD_LOGIC;
  signal tx1_n_4 : STD_LOGIC;
  signal tx1_n_5 : STD_LOGIC;
  signal tx1_n_6 : STD_LOGIC;
  signal tx1_n_7 : STD_LOGIC;
  signal tx1_n_8 : STD_LOGIC;
  signal tx1_n_9 : STD_LOGIC;
begin
  Q(8 downto 0) <= \^q\(8 downto 0);
  RX <= \^rx\;
  done_TX <= \^done_tx\;
  done_reg <= \^done_reg\;
TFF_RXB: entity work.design_1_FPGAPROJECT_0_0_TFF
     port map (
      RX => \^rx\,
      clk => Tq,
      q => RXBUSs,
      q_reg => rx1_n_1
    );
TRANSMIT_reg_reg: unisim.vcomponents.FDCE
     port map (
      C => CAN_CLK,
      CE => '1',
      CLR => rx1_n_1,
      D => TRANSMIT_0,
      Q => TRANSMIT_reg
    );
TRANSMITr_i_1: unisim.vcomponents.LUT5
    generic map(
      INIT => X"F8FF8888"
    )
        port map (
      I0 => TRANSMIT_0,
      I1 => TRANSMIT_reg,
      I2 => done_TXr,
      I3 => \^done_tx\,
      I4 => TRANSMITr,
      O => TRANSMITr_i_1_n_0
    );
TRANSMITr_reg: unisim.vcomponents.FDCE
     port map (
      C => CAN_CLK,
      CE => '1',
      CLR => rx1_n_1,
      D => TRANSMITr_i_1_n_0,
      Q => TRANSMITr
    );
Tq_i_1: unisim.vcomponents.LUT6
    generic map(
      INIT => X"6FFFFF6F90000090"
    )
        port map (
      I0 => count_reg(4),
      I1 => BRP_0(4),
      I2 => p1_n_3,
      I3 => BRP_0(3),
      I4 => count_reg(3),
      I5 => Tq,
      O => Tq_i_1_n_0
    );
done_TXr_reg: unisim.vcomponents.FDCE
     port map (
      C => CAN_CLK,
      CE => '1',
      CLR => rx1_n_1,
      D => \^done_tx\,
      Q => done_TXr
    );
err1: entity work.design_1_FPGAPROJECT_0_0_ErrorHandler
     port map (
      AckTakeOver => AckTakeOver,
      \Cnt_reg[0]_0\(0) => rengine1_n_5,
      \Cnt_reg[3]_0\ => rengine1_n_8,
      D(1) => err1_n_22,
      D(0) => err1_n_23,
      \D_Len[0]_i_2_0\ => tx1_n_6,
      E(0) => rengine1_n_7,
      Mode_0(2 downto 0) => Mode_0(2 downto 0),
      Mode_0_1_sp_1 => err1_n_25,
      Q(8 downto 0) => \^q\(8 downto 0),
      \REC[0]_i_2_0\ => rengine1_n_13,
      \REC[8]_i_7_0\ => tx1_n_5,
      \REC_reg[0]_0\ => \^done_reg\,
      \REC_reg[7]_0\ => err1_n_32,
      \REC_reg[8]_0\(8 downto 0) => \REC_reg[8]\(8 downto 0),
      \REC_reg[8]_1\ => err1_n_33,
      RX => \^rx\,
      RXBUS => RXBUS,
      RXBUS_d => RXBUS_d,
      RXOUT_reg => err1_n_24,
      \RXSTATES_reg[1]\ => rx1_n_14,
      SRST_0 => SRST_0,
      SRST_0_0(0) => err1_n_29,
      Sampled_din => Sampled_din,
      \State_reg[0]_0\(0) => State(0),
      \State_reg[0]_1\ => err1_n_20,
      \State_reg[0]_2\ => err1_n_31,
      \State_reg[0]_3\ => err1_n_34,
      \State_reg[0]_4\ => tx1_n_2,
      \State_reg[0]_5\ => rx1_n_6,
      \State_reg[2]_0\ => err1_n_21,
      \State_reg[2]_1\ => err1_n_30,
      \TEC[8]_i_11_0\ => tx1_n_4,
      \TEC_reg[0]_0\ => tx1_n_7,
      \TEC_reg[0]_1\ => \^done_tx\,
      TX => TX,
      \TXSTATES_reg[2]\ => tx1_n_10,
      \TXSTATES_reg[3]\ => tx1_n_9,
      TXpin_reg_0 => rx1_n_8,
      ack_error_reg_0 => rx1_n_1,
      ack_error_reg_1 => rengine1_n_6,
      ack_error_reg_2 => tx1_n_3,
      ack_error_reg_3 => tx1_n_8,
      clk => Tq,
      donefromrxr => donefromrxr,
      donefromtxr => donefromtxr,
      imTX => imTX,
      lastvalue => lastvalue,
      lastvalue_reg_0 => rengine1_n_12,
      \^q\ => RXBUSs,
      q_reg => err1_n_26,
      req_Error_RX => req_Error_RX
    );
p1: entity work.design_1_FPGAPROJECT_0_0_Prescaler
     port map (
      BRP_0(4 downto 0) => BRP_0(4 downto 0),
      CAN_CLK => CAN_CLK,
      Tq_reg_0 => Tq_i_1_n_0,
      clk => Tq,
      \count_reg[0]_0\ => p1_n_3,
      \count_reg[0]_1\ => rx1_n_1,
      \count_reg[4]_0\(1 downto 0) => count_reg(4 downto 3)
    );
rengine1: entity work.design_1_FPGAPROJECT_0_0_Rengine
     port map (
      \CNT1_reg[0]_0\ => err1_n_24,
      \CNT1_reg[3]_0\ => rengine1_n_10,
      \CNT1_reg[3]_1\ => err1_n_26,
      \CNT1_reg[4]_0\ => rengine1_n_2,
      \CNT1_reg[4]_1\ => rengine1_n_4,
      \CNT2_reg[0]_0\ => rengine1_n_6,
      \CNT2_reg[0]_1\ => err1_n_25,
      \CNT2_reg[1]_0\ => rx1_n_7,
      \CNT2_reg[3]_0\(0) => rx1_n_13,
      E(0) => rengine1_n_3,
      \REC[0]_i_3\(0) => State(0),
      RXBUS => RXBUS,
      RXBUS_d => RXBUS_d,
      RXBUS_d_reg_0 => rengine1_n_9,
      RXOUT_reg_0 => rengine1_n_8,
      RXOUT_reg_1 => rengine1_n_12,
      RXOUT_reg_2 => rengine1_n_13,
      RXOUT_reg_3 => rx1_n_1,
      \RXSTATES_reg[3]\ => rx1_n_80,
      \RXSTATES_reg[3]_0\ => err1_n_30,
      SRST_0 => SRST_0,
      SRST_0_0(0) => rengine1_n_5,
      SRST_0_1(0) => rengine1_n_7,
      SRST_0_2(0) => rengine1_n_11,
      Sampled_din => Sampled_din,
      clk => Tq,
      lastvalue => lastvalue
    );
rx1: entity work.design_1_FPGAPROJECT_0_0_RXMachine
     port map (
      AckTakeOver => AckTakeOver,
      CAN_RST => CAN_RST,
      CAN_RST_0 => rx1_n_1,
      \CNT2_reg[3]\ => rengine1_n_10,
      \CNT2_reg[3]_0\ => rengine1_n_9,
      \CRC_RG_reg[14]\ => rengine1_n_4,
      \Cnt_reg[0]_0\(0) => rengine1_n_3,
      D(0) => err1_n_29,
      E(0) => rengine1_n_7,
      IDE_rec_0 => IDE_rec_0,
      Q(3 downto 0) => D_Len_rec_0(3 downto 0),
      RTR_rec_0 => RTR_rec_0,
      RXOUT_reg => rx1_n_6,
      \RXSTATES_reg[0]_0\ => err1_n_21,
      \RXSTATES_reg[0]_1\ => err1_n_34,
      \RXSTATES_reg[1]_0\ => rx1_n_14,
      \RXSTATES_reg[2]_0\ => rx1_n_7,
      \RXSTATES_reg[2]_1\(0) => rx1_n_13,
      \RXSTATES_reg[3]_0\ => rx1_n_15,
      \RXSTATES_reg[3]_1\ => err1_n_30,
      \RXSTATES_reg[3]_2\(0) => rengine1_n_11,
      SRST_0 => SRST_0,
      Sampled_din => Sampled_din,
      TOFILTERI_0(28 downto 0) => TOFILTERI_0(28 downto 0),
      TOFILTERd_0(63 downto 0) => TOFILTERd_0(63 downto 0),
      \TOFILTERd_reg[0]_0\ => err1_n_26,
      TXpin_i_2 => tx1_n_7,
      TXpin_i_2_0 => err1_n_32,
      \bs_reg[0]_0\(0) => rengine1_n_2,
      \bs_reg[1]_0\ => rx1_n_80,
      clk => Tq,
      done_reg_0 => \^done_reg\,
      donefromrxr => donefromrxr,
      imTX => imTX,
      req_Error_RX => req_Error_RX,
      req_Error_reg_0 => rx1_n_8
    );
tx1: entity work.design_1_FPGAPROJECT_0_0_TXMachine
     port map (
      \CRC_RG_reg[0]\ => rx1_n_1,
      \Cnt[0]_i_3\ => err1_n_33,
      \Cnt_reg[1]_0\ => err1_n_21,
      D(1) => err1_n_22,
      D(0) => err1_n_23,
      D_Len_TX_0(3 downto 0) => D_Len_TX_0(3 downto 0),
      E(0) => rengine1_n_7,
      IDE_TX_0 => IDE_TX_0,
      ID_TX_0(28 downto 0) => ID_TX_0(28 downto 0),
      Q(1 downto 0) => \^q\(8 downto 7),
      RTR_TX_0 => RTR_TX_0,
      RXOUT_reg => tx1_n_8,
      SRST_0 => SRST_0,
      Sampled_din => Sampled_din,
      \TEC[8]_i_17\ => rx1_n_6,
      \TEC[8]_i_17_0\ => err1_n_31,
      TRANSMITr => TRANSMITr,
      \TXSTATES_reg[0]_0\ => tx1_n_6,
      \TXSTATES_reg[0]_1\ => tx1_n_9,
      \TXSTATES_reg[0]_2\ => err1_n_20,
      \TXSTATES_reg[1]_0\ => tx1_n_3,
      \TXSTATES_reg[1]_1\ => tx1_n_7,
      \TXSTATES_reg[2]_0\ => tx1_n_10,
      clk => Tq,
      data_TX_0(63 downto 0) => data_TX_0(63 downto 0),
      done_i_11 => rx1_n_15,
      done_i_11_0 => err1_n_32,
      done_reg_0 => \^done_tx\,
      donefromtxr => donefromtxr,
      imTX => imTX,
      req_Error_RX => req_Error_RX,
      req_Error_reg => tx1_n_2,
      req_Error_reg_0 => tx1_n_4,
      req_Error_reg_1 => tx1_n_5,
      \serial_reg[4]\ => rengine1_n_6
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1_FPGAPROJECT_0_0_FPGAPROJECT is
  port (
    Q : out STD_LOGIC_VECTOR ( 8 downto 0 );
    \REC_reg[8]\ : out STD_LOGIC_VECTOR ( 8 downto 0 );
    done_reg : out STD_LOGIC;
    RTR_rec_0 : out STD_LOGIC;
    D_Len_rec_0 : out STD_LOGIC_VECTOR ( 3 downto 0 );
    TOFILTERd_0 : out STD_LOGIC_VECTOR ( 63 downto 0 );
    TOFILTERI_0 : out STD_LOGIC_VECTOR ( 28 downto 0 );
    done_reg_0 : out STD_LOGIC;
    done_RX_1 : out STD_LOGIC;
    done_TX_1 : out STD_LOGIC;
    IDE_rec_1 : out STD_LOGIC;
    RTR_rec_1 : out STD_LOGIC;
    D_Len_rec_1 : out STD_LOGIC_VECTOR ( 3 downto 0 );
    TOFILTERd_1 : out STD_LOGIC_VECTOR ( 63 downto 0 );
    TOFILTERI_1 : out STD_LOGIC_VECTOR ( 28 downto 0 );
    TEC_1 : out STD_LOGIC_VECTOR ( 8 downto 0 );
    REC_1 : out STD_LOGIC_VECTOR ( 8 downto 0 );
    IDE_rec_0 : out STD_LOGIC;
    SRST_0 : in STD_LOGIC;
    IDE_TX_0 : in STD_LOGIC;
    CAN_CLK : in STD_LOGIC;
    CAN_RST : in STD_LOGIC;
    BRP_0 : in STD_LOGIC_VECTOR ( 4 downto 0 );
    TRANSMIT_0 : in STD_LOGIC;
    SRST_1 : in STD_LOGIC;
    BRP_1 : in STD_LOGIC_VECTOR ( 4 downto 0 );
    Mode_1 : in STD_LOGIC_VECTOR ( 2 downto 0 );
    TRANSMIT_1 : in STD_LOGIC;
    IDE_TX_1 : in STD_LOGIC;
    RTR_TX_1 : in STD_LOGIC;
    D_Len_TX_1 : in STD_LOGIC_VECTOR ( 3 downto 0 );
    ID_TX_1 : in STD_LOGIC_VECTOR ( 28 downto 0 );
    data_TX_1 : in STD_LOGIC_VECTOR ( 63 downto 0 );
    Mode_0 : in STD_LOGIC_VECTOR ( 2 downto 0 );
    RTR_TX_0 : in STD_LOGIC;
    D_Len_TX_0 : in STD_LOGIC_VECTOR ( 3 downto 0 );
    ID_TX_0 : in STD_LOGIC_VECTOR ( 28 downto 0 );
    data_TX_0 : in STD_LOGIC_VECTOR ( 63 downto 0 )
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of design_1_FPGAPROJECT_0_0_FPGAPROJECT : entity is "FPGAPROJECT";
end design_1_FPGAPROJECT_0_0_FPGAPROJECT;

architecture STRUCTURE of design_1_FPGAPROJECT_0_0_FPGAPROJECT is
  signal \BUS\ : STD_LOGIC;
  signal TX_1 : STD_LOGIC;
  attribute KEEP_HIERARCHY : string;
  attribute KEEP_HIERARCHY of CANCORE_1 : label is "YES";
begin
CANCORE_0: entity work.\design_1_FPGAPROJECT_0_0_CANCORE__2\
     port map (
      BRP_0(4 downto 0) => BRP_0(4 downto 0),
      CAN_CLK => CAN_CLK,
      CAN_RST => CAN_RST,
      D_Len_TX_0(3 downto 0) => D_Len_TX_0(3 downto 0),
      D_Len_rec_0(3 downto 0) => D_Len_rec_0(3 downto 0),
      IDE_TX_0 => IDE_TX_0,
      IDE_rec_0 => IDE_rec_0,
      ID_TX_0(28 downto 0) => ID_TX_0(28 downto 0),
      Mode_0(2 downto 0) => Mode_0(2 downto 0),
      Q(8 downto 0) => Q(8 downto 0),
      \REC_reg[8]\(8 downto 0) => \REC_reg[8]\(8 downto 0),
      RTR_TX_0 => RTR_TX_0,
      RTR_rec_0 => RTR_rec_0,
      RX => \BUS\,
      SRST_0 => SRST_0,
      TOFILTERI_0(28 downto 0) => TOFILTERI_0(28 downto 0),
      TOFILTERd_0(63 downto 0) => TOFILTERd_0(63 downto 0),
      TRANSMIT_0 => TRANSMIT_0,
      TX => TX_1,
      data_TX_0(63 downto 0) => data_TX_0(63 downto 0),
      done_TX => done_reg_0,
      done_reg => done_reg
    );
CANCORE_1: entity work.design_1_FPGAPROJECT_0_0_CANCORE
     port map (
      BRP(4 downto 0) => BRP_1(4 downto 0),
      CAN_CLK => CAN_CLK,
      CAN_RST => CAN_RST,
      D_Len_TX(3 downto 0) => D_Len_TX_1(3 downto 0),
      D_Len_rec(3 downto 0) => D_Len_rec_1(3 downto 0),
      IDE_TX => IDE_TX_1,
      IDE_rec => IDE_rec_1,
      ID_TX(28 downto 0) => ID_TX_1(28 downto 0),
      Mode(2 downto 0) => Mode_1(2 downto 0),
      REC(8 downto 0) => REC_1(8 downto 0),
      RTR_TX => RTR_TX_1,
      RTR_rec => RTR_rec_1,
      RX => \BUS\,
      SJW(2 downto 0) => B"010",
      SRST => SRST_1,
      TEC(8 downto 0) => TEC_1(8 downto 0),
      TOFILTERI(28 downto 0) => TOFILTERI_1(28 downto 0),
      TOFILTERd(63 downto 0) => TOFILTERd_1(63 downto 0),
      TPROP(3 downto 0) => B"0100",
      TRANSMIT => TRANSMIT_1,
      TSEG1(3 downto 0) => B"0100",
      TSEG2(3 downto 0) => B"0100",
      TX => TX_1,
      data_TX(63 downto 0) => data_TX_1(63 downto 0),
      done_RX => done_RX_1,
      done_TX => done_TX_1
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1_FPGAPROJECT_0_0 is
  port (
    CAN_CLK : in STD_LOGIC;
    CAN_RST : in STD_LOGIC;
    SRST_0 : in STD_LOGIC;
    BRP_0 : in STD_LOGIC_VECTOR ( 4 downto 0 );
    Mode_0 : in STD_LOGIC_VECTOR ( 2 downto 0 );
    TRANSMIT_0 : in STD_LOGIC;
    IDE_TX_0 : in STD_LOGIC;
    RTR_TX_0 : in STD_LOGIC;
    D_Len_TX_0 : in STD_LOGIC_VECTOR ( 3 downto 0 );
    ID_TX_0 : in STD_LOGIC_VECTOR ( 28 downto 0 );
    data_TX_0 : in STD_LOGIC_VECTOR ( 63 downto 0 );
    done_RX_0 : out STD_LOGIC;
    done_TX_0 : out STD_LOGIC;
    IDE_rec_0 : out STD_LOGIC;
    RTR_rec_0 : out STD_LOGIC;
    D_Len_rec_0 : out STD_LOGIC_VECTOR ( 3 downto 0 );
    TOFILTERd_0 : out STD_LOGIC_VECTOR ( 63 downto 0 );
    TOFILTERI_0 : out STD_LOGIC_VECTOR ( 28 downto 0 );
    TEC_0 : out STD_LOGIC_VECTOR ( 8 downto 0 );
    REC_0 : out STD_LOGIC_VECTOR ( 8 downto 0 );
    SRST_1 : in STD_LOGIC;
    BRP_1 : in STD_LOGIC_VECTOR ( 4 downto 0 );
    Mode_1 : in STD_LOGIC_VECTOR ( 2 downto 0 );
    TRANSMIT_1 : in STD_LOGIC;
    IDE_TX_1 : in STD_LOGIC;
    RTR_TX_1 : in STD_LOGIC;
    D_Len_TX_1 : in STD_LOGIC_VECTOR ( 3 downto 0 );
    ID_TX_1 : in STD_LOGIC_VECTOR ( 28 downto 0 );
    data_TX_1 : in STD_LOGIC_VECTOR ( 63 downto 0 );
    done_RX_1 : out STD_LOGIC;
    done_TX_1 : out STD_LOGIC;
    IDE_rec_1 : out STD_LOGIC;
    RTR_rec_1 : out STD_LOGIC;
    D_Len_rec_1 : out STD_LOGIC_VECTOR ( 3 downto 0 );
    TOFILTERd_1 : out STD_LOGIC_VECTOR ( 63 downto 0 );
    TOFILTERI_1 : out STD_LOGIC_VECTOR ( 28 downto 0 );
    TEC_1 : out STD_LOGIC_VECTOR ( 8 downto 0 );
    REC_1 : out STD_LOGIC_VECTOR ( 8 downto 0 )
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of design_1_FPGAPROJECT_0_0 : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of design_1_FPGAPROJECT_0_0 : entity is "design_1_FPGAPROJECT_0_0,FPGAPROJECT,{}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of design_1_FPGAPROJECT_0_0 : entity is "yes";
  attribute IP_DEFINITION_SOURCE : string;
  attribute IP_DEFINITION_SOURCE of design_1_FPGAPROJECT_0_0 : entity is "module_ref";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of design_1_FPGAPROJECT_0_0 : entity is "FPGAPROJECT,Vivado 2025.2";
end design_1_FPGAPROJECT_0_0;

architecture STRUCTURE of design_1_FPGAPROJECT_0_0 is
  attribute X_INTERFACE_INFO : string;
  attribute X_INTERFACE_INFO of CAN_CLK : signal is "xilinx.com:signal:clock:1.0 CAN_CLK CLK";
  attribute X_INTERFACE_MODE : string;
  attribute X_INTERFACE_MODE of CAN_CLK : signal is "slave";
  attribute X_INTERFACE_PARAMETER : string;
  attribute X_INTERFACE_PARAMETER of CAN_CLK : signal is "XIL_INTERFACENAME CAN_CLK, ASSOCIATED_RESET CAN_RST, FREQ_HZ 10000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN /clk_wiz_0_clk_out1, INSERT_VIP 0";
  attribute X_INTERFACE_INFO of CAN_RST : signal is "xilinx.com:signal:reset:1.0 CAN_RST RST";
  attribute X_INTERFACE_MODE of CAN_RST : signal is "slave";
  attribute X_INTERFACE_PARAMETER of CAN_RST : signal is "XIL_INTERFACENAME CAN_RST, POLARITY ACTIVE_LOW, INSERT_VIP 0";
begin
inst: entity work.design_1_FPGAPROJECT_0_0_FPGAPROJECT
     port map (
      BRP_0(4 downto 0) => BRP_0(4 downto 0),
      BRP_1(4 downto 0) => BRP_1(4 downto 0),
      CAN_CLK => CAN_CLK,
      CAN_RST => CAN_RST,
      D_Len_TX_0(3 downto 0) => D_Len_TX_0(3 downto 0),
      D_Len_TX_1(3 downto 0) => D_Len_TX_1(3 downto 0),
      D_Len_rec_0(3 downto 0) => D_Len_rec_0(3 downto 0),
      D_Len_rec_1(3 downto 0) => D_Len_rec_1(3 downto 0),
      IDE_TX_0 => IDE_TX_0,
      IDE_TX_1 => IDE_TX_1,
      IDE_rec_0 => IDE_rec_0,
      IDE_rec_1 => IDE_rec_1,
      ID_TX_0(28 downto 0) => ID_TX_0(28 downto 0),
      ID_TX_1(28 downto 0) => ID_TX_1(28 downto 0),
      Mode_0(2 downto 0) => Mode_0(2 downto 0),
      Mode_1(2 downto 0) => Mode_1(2 downto 0),
      Q(8 downto 0) => TEC_0(8 downto 0),
      REC_1(8 downto 0) => REC_1(8 downto 0),
      \REC_reg[8]\(8 downto 0) => REC_0(8 downto 0),
      RTR_TX_0 => RTR_TX_0,
      RTR_TX_1 => RTR_TX_1,
      RTR_rec_0 => RTR_rec_0,
      RTR_rec_1 => RTR_rec_1,
      SRST_0 => SRST_0,
      SRST_1 => SRST_1,
      TEC_1(8 downto 0) => TEC_1(8 downto 0),
      TOFILTERI_0(28 downto 0) => TOFILTERI_0(28 downto 0),
      TOFILTERI_1(28 downto 0) => TOFILTERI_1(28 downto 0),
      TOFILTERd_0(63 downto 0) => TOFILTERd_0(63 downto 0),
      TOFILTERd_1(63 downto 0) => TOFILTERd_1(63 downto 0),
      TRANSMIT_0 => TRANSMIT_0,
      TRANSMIT_1 => TRANSMIT_1,
      data_TX_0(63 downto 0) => data_TX_0(63 downto 0),
      data_TX_1(63 downto 0) => data_TX_1(63 downto 0),
      done_RX_1 => done_RX_1,
      done_TX_1 => done_TX_1,
      done_reg => done_RX_0,
      done_reg_0 => done_TX_0
    );
end STRUCTURE;
