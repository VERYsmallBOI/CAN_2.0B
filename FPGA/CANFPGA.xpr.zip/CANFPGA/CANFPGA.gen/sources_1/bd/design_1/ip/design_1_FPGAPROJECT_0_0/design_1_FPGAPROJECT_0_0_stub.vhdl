-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2025.2 (win64) Build 6299465 Fri Nov 14 19:35:11 GMT 2025
-- Date        : Tue Sep 15 17:17:25 2026
-- Host        : CLANKER running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode synth_stub
--               c:/Users/Tamil/Documents/Mirafra/CAN_FPGA/CANFPGA/CANFPGA.gen/sources_1/bd/design_1/ip/design_1_FPGAPROJECT_0_0/design_1_FPGAPROJECT_0_0_stub.vhdl
-- Design      : design_1_FPGAPROJECT_0_0
-- Purpose     : Stub declaration of top-level module interface
-- Device      : xc7z007sclg400-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity design_1_FPGAPROJECT_0_0 is
  Port ( 
    CAN_CLK : in STD_LOGIC;
    CAN_RST : in STD_LOGIC;
    SRST_0 : in STD_LOGIC;
    BRP_0 : in STD_LOGIC_VECTOR ( 4 downto 0 );
    Mode_0 : in STD_LOGIC_VECTOR ( 2 downto 0 );
    TRANSMIT_0 : in STD_LOGIC;
    IDE_TX_0 : in STD_LOGIC;
    RTR_TX_0 : in STD_LOGIC;
    D_Len_TX_0 : in STD_LOGIC_VECTOR ( 3 downto 0 );
    ID_TX_0 : in STD_LOGIC_VECTOR ( 28 downto 0 );
    data_TX_0 : in STD_LOGIC_VECTOR ( 63 downto 0 );
    done_RX_0 : out STD_LOGIC;
    done_TX_0 : out STD_LOGIC;
    IDE_rec_0 : out STD_LOGIC;
    RTR_rec_0 : out STD_LOGIC;
    D_Len_rec_0 : out STD_LOGIC_VECTOR ( 3 downto 0 );
    TOFILTERd_0 : out STD_LOGIC_VECTOR ( 63 downto 0 );
    TOFILTERI_0 : out STD_LOGIC_VECTOR ( 28 downto 0 );
    TEC_0 : out STD_LOGIC_VECTOR ( 8 downto 0 );
    REC_0 : out STD_LOGIC_VECTOR ( 8 downto 0 );
    SRST_1 : in STD_LOGIC;
    BRP_1 : in STD_LOGIC_VECTOR ( 4 downto 0 );
    Mode_1 : in STD_LOGIC_VECTOR ( 2 downto 0 );
    TRANSMIT_1 : in STD_LOGIC;
    IDE_TX_1 : in STD_LOGIC;
    RTR_TX_1 : in STD_LOGIC;
    D_Len_TX_1 : in STD_LOGIC_VECTOR ( 3 downto 0 );
    ID_TX_1 : in STD_LOGIC_VECTOR ( 28 downto 0 );
    data_TX_1 : in STD_LOGIC_VECTOR ( 63 downto 0 );
    done_RX_1 : out STD_LOGIC;
    done_TX_1 : out STD_LOGIC;
    IDE_rec_1 : out STD_LOGIC;
    RTR_rec_1 : out STD_LOGIC;
    D_Len_rec_1 : out STD_LOGIC_VECTOR ( 3 downto 0 );
    TOFILTERd_1 : out STD_LOGIC_VECTOR ( 63 downto 0 );
    TOFILTERI_1 : out STD_LOGIC_VECTOR ( 28 downto 0 );
    TEC_1 : out STD_LOGIC_VECTOR ( 8 downto 0 );
    REC_1 : out STD_LOGIC_VECTOR ( 8 downto 0 )
  );

  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of design_1_FPGAPROJECT_0_0 : entity is "design_1_FPGAPROJECT_0_0,FPGAPROJECT,{}";
  attribute CORE_GENERATION_INFO : string;
  attribute CORE_GENERATION_INFO of design_1_FPGAPROJECT_0_0 : entity is "design_1_FPGAPROJECT_0_0,FPGAPROJECT,{x_ipProduct=Vivado 2025.2,x_ipVendor=xilinx.com,x_ipLibrary=module_ref,x_ipName=FPGAPROJECT,x_ipVersion=1.0,x_ipCoreRevision=1,x_ipLanguage=VERILOG,x_ipSimLanguage=MIXED}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of design_1_FPGAPROJECT_0_0 : entity is "yes";
  attribute IP_DEFINITION_SOURCE : string;
  attribute IP_DEFINITION_SOURCE of design_1_FPGAPROJECT_0_0 : entity is "module_ref";
end design_1_FPGAPROJECT_0_0;

architecture stub of design_1_FPGAPROJECT_0_0 is
  attribute syn_black_box : boolean;
  attribute black_box_pad_pin : string;
  attribute syn_black_box of stub : architecture is true;
  attribute black_box_pad_pin of stub : architecture is "CAN_CLK,CAN_RST,SRST_0,BRP_0[4:0],Mode_0[2:0],TRANSMIT_0,IDE_TX_0,RTR_TX_0,D_Len_TX_0[3:0],ID_TX_0[28:0],data_TX_0[63:0],done_RX_0,done_TX_0,IDE_rec_0,RTR_rec_0,D_Len_rec_0[3:0],TOFILTERd_0[63:0],TOFILTERI_0[28:0],TEC_0[8:0],REC_0[8:0],SRST_1,BRP_1[4:0],Mode_1[2:0],TRANSMIT_1,IDE_TX_1,RTR_TX_1,D_Len_TX_1[3:0],ID_TX_1[28:0],data_TX_1[63:0],done_RX_1,done_TX_1,IDE_rec_1,RTR_rec_1,D_Len_rec_1[3:0],TOFILTERd_1[63:0],TOFILTERI_1[28:0],TEC_1[8:0],REC_1[8:0]";
  attribute X_INTERFACE_INFO : string;
  attribute X_INTERFACE_INFO of CAN_CLK : signal is "xilinx.com:signal:clock:1.0 CAN_CLK CLK";
  attribute X_INTERFACE_MODE : string;
  attribute X_INTERFACE_MODE of CAN_CLK : signal is "slave";
  attribute X_INTERFACE_PARAMETER : string;
  attribute X_INTERFACE_PARAMETER of CAN_CLK : signal is "XIL_INTERFACENAME CAN_CLK, ASSOCIATED_RESET CAN_RST, FREQ_HZ 10000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN /clk_wiz_0_clk_out1, INSERT_VIP 0";
  attribute X_INTERFACE_INFO of CAN_RST : signal is "xilinx.com:signal:reset:1.0 CAN_RST RST";
  attribute X_INTERFACE_MODE of CAN_RST : signal is "slave";
  attribute X_INTERFACE_PARAMETER of CAN_RST : signal is "XIL_INTERFACENAME CAN_RST, POLARITY ACTIVE_LOW, INSERT_VIP 0";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of stub : architecture is "FPGAPROJECT,Vivado 2025.2";
begin
end;
