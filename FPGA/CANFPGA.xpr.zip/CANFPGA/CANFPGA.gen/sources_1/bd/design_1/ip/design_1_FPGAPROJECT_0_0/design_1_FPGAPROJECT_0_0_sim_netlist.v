// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2025.2 (win64) Build 6299465 Fri Nov 14 19:35:11 GMT 2025
// Date        : Tue Sep 15 17:17:25 2026
// Host        : CLANKER running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim
//               c:/Users/Tamil/Documents/Mirafra/CAN_FPGA/CANFPGA/CANFPGA.gen/sources_1/bd/design_1/ip/design_1_FPGAPROJECT_0_0/design_1_FPGAPROJECT_0_0_sim_netlist.v
// Design      : design_1_FPGAPROJECT_0_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7z007sclg400-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "design_1_FPGAPROJECT_0_0,FPGAPROJECT,{}" *) (* DowngradeIPIdentifiedWarnings = "yes" *) (* IP_DEFINITION_SOURCE = "module_ref" *) 
(* X_CORE_INFO = "FPGAPROJECT,Vivado 2025.2" *) 
(* NotValidForBitStream *)
module design_1_FPGAPROJECT_0_0
   (CAN_CLK,
    CAN_RST,
    SRST_0,
    BRP_0,
    Mode_0,
    TRANSMIT_0,
    IDE_TX_0,
    RTR_TX_0,
    D_Len_TX_0,
    ID_TX_0,
    data_TX_0,
    done_RX_0,
    done_TX_0,
    IDE_rec_0,
    RTR_rec_0,
    D_Len_rec_0,
    TOFILTERd_0,
    TOFILTERI_0,
    TEC_0,
    REC_0,
    SRST_1,
    BRP_1,
    Mode_1,
    TRANSMIT_1,
    IDE_TX_1,
    RTR_TX_1,
    D_Len_TX_1,
    ID_TX_1,
    data_TX_1,
    done_RX_1,
    done_TX_1,
    IDE_rec_1,
    RTR_rec_1,
    D_Len_rec_1,
    TOFILTERd_1,
    TOFILTERI_1,
    TEC_1,
    REC_1);
  (* X_INTERFACE_INFO = "xilinx.com:signal:clock:1.0 CAN_CLK CLK" *) (* X_INTERFACE_MODE = "slave" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME CAN_CLK, ASSOCIATED_RESET CAN_RST, FREQ_HZ 10000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN /clk_wiz_0_clk_out1, INSERT_VIP 0" *) input CAN_CLK;
  (* X_INTERFACE_INFO = "xilinx.com:signal:reset:1.0 CAN_RST RST" *) (* X_INTERFACE_MODE = "slave" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME CAN_RST, POLARITY ACTIVE_LOW, INSERT_VIP 0" *) input CAN_RST;
  input SRST_0;
  input [4:0]BRP_0;
  input [2:0]Mode_0;
  input TRANSMIT_0;
  input IDE_TX_0;
  input RTR_TX_0;
  input [3:0]D_Len_TX_0;
  input [28:0]ID_TX_0;
  input [63:0]data_TX_0;
  output done_RX_0;
  output done_TX_0;
  output IDE_rec_0;
  output RTR_rec_0;
  output [3:0]D_Len_rec_0;
  output [63:0]TOFILTERd_0;
  output [28:0]TOFILTERI_0;
  output [8:0]TEC_0;
  output [8:0]REC_0;
  input SRST_1;
  input [4:0]BRP_1;
  input [2:0]Mode_1;
  input TRANSMIT_1;
  input IDE_TX_1;
  input RTR_TX_1;
  input [3:0]D_Len_TX_1;
  input [28:0]ID_TX_1;
  input [63:0]data_TX_1;
  output done_RX_1;
  output done_TX_1;
  output IDE_rec_1;
  output RTR_rec_1;
  output [3:0]D_Len_rec_1;
  output [63:0]TOFILTERd_1;
  output [28:0]TOFILTERI_1;
  output [8:0]TEC_1;
  output [8:0]REC_1;

  wire [4:0]BRP_0;
  wire [4:0]BRP_1;
  wire CAN_CLK;
  wire CAN_RST;
  wire [3:0]D_Len_TX_0;
  wire [3:0]D_Len_TX_1;
  wire [3:0]D_Len_rec_0;
  wire [3:0]D_Len_rec_1;
  wire IDE_TX_0;
  wire IDE_TX_1;
  wire IDE_rec_0;
  wire IDE_rec_1;
  wire [28:0]ID_TX_0;
  wire [28:0]ID_TX_1;
  wire [2:0]Mode_0;
  wire [2:0]Mode_1;
  wire [8:0]REC_0;
  wire [8:0]REC_1;
  wire RTR_TX_0;
  wire RTR_TX_1;
  wire RTR_rec_0;
  wire RTR_rec_1;
  wire SRST_0;
  wire SRST_1;
  wire [8:0]TEC_0;
  wire [8:0]TEC_1;
  wire [28:0]TOFILTERI_0;
  wire [28:0]TOFILTERI_1;
  wire [63:0]TOFILTERd_0;
  wire [63:0]TOFILTERd_1;
  wire TRANSMIT_0;
  wire TRANSMIT_1;
  wire [63:0]data_TX_0;
  wire [63:0]data_TX_1;
  wire done_RX_0;
  wire done_RX_1;
  wire done_TX_0;
  wire done_TX_1;

  design_1_FPGAPROJECT_0_0_FPGAPROJECT inst
       (.BRP_0(BRP_0),
        .BRP_1(BRP_1),
        .CAN_CLK(CAN_CLK),
        .CAN_RST(CAN_RST),
        .D_Len_TX_0(D_Len_TX_0),
        .D_Len_TX_1(D_Len_TX_1),
        .D_Len_rec_0(D_Len_rec_0),
        .D_Len_rec_1(D_Len_rec_1),
        .IDE_TX_0(IDE_TX_0),
        .IDE_TX_1(IDE_TX_1),
        .IDE_rec_0(IDE_rec_0),
        .IDE_rec_1(IDE_rec_1),
        .ID_TX_0(ID_TX_0),
        .ID_TX_1(ID_TX_1),
        .Mode_0(Mode_0),
        .Mode_1(Mode_1),
        .Q(TEC_0),
        .REC_1(REC_1),
        .\REC_reg[8] (REC_0),
        .RTR_TX_0(RTR_TX_0),
        .RTR_TX_1(RTR_TX_1),
        .RTR_rec_0(RTR_rec_0),
        .RTR_rec_1(RTR_rec_1),
        .SRST_0(SRST_0),
        .SRST_1(SRST_1),
        .TEC_1(TEC_1),
        .TOFILTERI_0(TOFILTERI_0),
        .TOFILTERI_1(TOFILTERI_1),
        .TOFILTERd_0(TOFILTERd_0),
        .TOFILTERd_1(TOFILTERd_1),
        .TRANSMIT_0(TRANSMIT_0),
        .TRANSMIT_1(TRANSMIT_1),
        .data_TX_0(data_TX_0),
        .data_TX_1(data_TX_1),
        .done_RX_1(done_RX_1),
        .done_TX_1(done_TX_1),
        .done_reg(done_RX_0),
        .done_reg_0(done_TX_0));
endmodule

(* ORIG_REF_NAME = "CANCORE" *) 
module design_1_FPGAPROJECT_0_0_CANCORE
   (CAN_CLK,
    CAN_RST,
    RX,
    TX,
    done_RX,
    done_TX,
    SRST,
    SJW,
    TPROP,
    TSEG1,
    TSEG2,
    BRP,
    Mode,
    TRANSMIT,
    IDE_TX,
    RTR_TX,
    D_Len_TX,
    ID_TX,
    data_TX,
    IDE_rec,
    RTR_rec,
    D_Len_rec,
    TOFILTERd,
    TOFILTERI,
    TEC,
    REC);
  input CAN_CLK;
  input CAN_RST;
  input RX;
  output TX;
  output done_RX;
  output done_TX;
  input SRST;
  input [2:0]SJW;
  input [3:0]TPROP;
  input [3:0]TSEG1;
  input [3:0]TSEG2;
  input [4:0]BRP;
  input [2:0]Mode;
  input TRANSMIT;
  input IDE_TX;
  input RTR_TX;
  input [3:0]D_Len_TX;
  input [28:0]ID_TX;
  input [63:0]data_TX;
  output IDE_rec;
  output RTR_rec;
  output [3:0]D_Len_rec;
  output [63:0]TOFILTERd;
  output [28:0]TOFILTERI;
  output [8:0]TEC;
  output [8:0]REC;

  wire AckTakeOver;
  wire [4:0]BRP;
  wire CAN_CLK;
  wire CAN_RST;
  wire [3:0]D_Len_TX;
  wire [3:0]D_Len_rec;
  wire IDE_TX;
  wire IDE_rec;
  wire [28:0]ID_TX;
  wire [2:0]Mode;
  wire [8:0]REC;
  wire RTR_TX;
  wire RTR_rec;
  wire RX;
  wire RXBUS;
  wire RXBUSs;
  wire [3:3]RXSTATES;
  wire [2:0]SJW;
  wire SRST;
  wire Sampled_din;
  wire [2:0]State;
  wire [8:0]TEC;
  wire [28:0]TOFILTERI;
  wire [63:0]TOFILTERd;
  wire [3:0]TPROP;
  wire TRANSMIT;
  wire TRANSMIT_reg;
  wire TRANSMITr;
  wire [3:0]TSEG1;
  wire [3:0]TSEG2;
  wire TX;
  wire Tq;
  wire [63:0]data_TX;
  wire done_RX;
  wire done_TX;
  wire done_TXr;
  wire donefromrxr;
  wire donefromtxr;
  wire err1_n_12;
  wire err1_n_13;
  wire err1_n_23;
  wire err1_n_24;
  wire err1_n_25;
  wire err1_n_26;
  wire err1_n_27;
  wire err1_n_28;
  wire err1_n_30;
  wire err1_n_32;
  wire err1_n_33;
  wire err1_n_34;
  wire err1_n_35;
  wire err1_n_36;
  wire err1_n_37;
  wire err1_n_38;
  wire imTX;
  wire rengine1_n_1;
  wire rengine1_n_10;
  wire rengine1_n_11;
  wire rengine1_n_2;
  wire rengine1_n_3;
  wire rengine1_n_4;
  wire rengine1_n_5;
  wire rengine1_n_6;
  wire rengine1_n_7;
  wire rengine1_n_8;
  wire rengine1_n_9;
  wire req_Error_RX;
  wire rx1_n_1;
  wire rx1_n_110;
  wire rx1_n_111;
  wire rx1_n_12;
  wire rx1_n_13;
  wire rx1_n_14;
  wire rx1_n_15;
  wire rx1_n_6;
  wire tx1_n_10;
  wire tx1_n_11;
  wire tx1_n_12;
  wire tx1_n_13;
  wire tx1_n_15;
  wire tx1_n_16;
  wire tx1_n_17;
  wire tx1_n_18;
  wire tx1_n_2;
  wire tx1_n_3;
  wire tx1_n_4;
  wire tx1_n_5;
  wire tx1_n_6;
  wire tx1_n_7;
  wire tx1_n_8;
  wire tx1_n_9;

  design_1_FPGAPROJECT_0_0_TFF_2 TFF_RXB
       (.RX(RX),
        .RXBUSs(RXBUSs),
        .Tq(Tq),
        .q_reg(rx1_n_1));
  FDCE TRANSMIT_reg_reg
       (.C(CAN_CLK),
        .CE(1'b1),
        .CLR(rx1_n_1),
        .D(TRANSMIT),
        .Q(TRANSMIT_reg));
  FDCE TRANSMITr_reg
       (.C(CAN_CLK),
        .CE(1'b1),
        .CLR(rx1_n_1),
        .D(tx1_n_16),
        .Q(TRANSMITr));
  FDCE done_TXr_reg
       (.C(CAN_CLK),
        .CE(1'b1),
        .CLR(rx1_n_1),
        .D(done_TX),
        .Q(done_TXr));
  design_1_FPGAPROJECT_0_0_ErrorHandler_3 err1
       (.AckTakeOver(AckTakeOver),
        .D({err1_n_24,err1_n_25,err1_n_26,err1_n_27}),
        .E(rengine1_n_10),
        .IDE_i_2_0(tx1_n_7),
        .Mode(Mode),
        .\Mode_1[1] (err1_n_32),
        .Q(TEC),
        .\REC[0]_i_3_0 (tx1_n_2),
        .\REC[0]_i_3_1 (tx1_n_5),
        .\REC_reg[0]_0 (rx1_n_6),
        .\REC_reg[6]_0 (done_RX),
        .\REC_reg[8]_0 (REC),
        .\REC_reg[8]_1 (err1_n_34),
        .\REC_reg[8]_2 (tx1_n_17),
        .\REC_reg[8]_3 (tx1_n_18),
        .\RECin_reg[7]_0 (tx1_n_8),
        .RXBUS(RXBUS),
        .RXBUSs(RXBUSs),
        .\RXSTATES_reg[1] (rx1_n_13),
        .SRST(SRST),
        .SRST_1(err1_n_33),
        .Sampled_din(Sampled_din),
        .\State_reg[0]_0 (err1_n_23),
        .\State_reg[0]_1 (err1_n_28),
        .\State_reg[0]_2 (err1_n_38),
        .\State_reg[0]_3 (rengine1_n_11),
        .\State_reg[0]_4 (rx1_n_110),
        .\State_reg[0]_5 (tx1_n_3),
        .\State_reg[2]_0 (State),
        .\State_reg[2]_1 (err1_n_13),
        .\State_reg[2]_2 (err1_n_35),
        .\State_reg[2]_3 (err1_n_37),
        .\State_reg[2]_i_2_0 (tx1_n_6),
        .\TEC_reg[0]_0 (tx1_n_15),
        .\TEC_reg[0]_1 (done_TX),
        .\TEC_reg[8]_0 (err1_n_12),
        .TX(TX),
        .\TXSTATES_reg[0] (tx1_n_11),
        .\TXSTATES_reg[1] (tx1_n_13),
        .\TXSTATES_reg[2] (tx1_n_12),
        .\TXSTATES_reg[3] (tx1_n_10),
        .Tq(Tq),
        .ack_error_reg_0(rx1_n_1),
        .ack_error_reg_1(rengine1_n_4),
        .ack_error_reg_2(tx1_n_4),
        .ack_error_reg_3(tx1_n_9),
        .donefromrxr(donefromrxr),
        .donefromtxr(donefromtxr),
        .imTX(imTX),
        .lastvalue_reg_0(rengine1_n_8),
        .q_reg(err1_n_30),
        .req_Error_RX(req_Error_RX),
        .req_Error_reg(err1_n_36));
  design_1_FPGAPROJECT_0_0_Prescaler_4 p1
       (.BRP(BRP),
        .CAN_CLK(CAN_CLK),
        .Tq(Tq),
        .\count_reg[0]_0 (rx1_n_1));
  design_1_FPGAPROJECT_0_0_Rengine_5 rengine1
       (.\CNT1_reg[3]_0 (rengine1_n_3),
        .\CNT1_reg[3]_1 (rengine1_n_6),
        .\CNT1_reg[4]_0 (rx1_n_15),
        .\CNT1_reg[4]_1 (err1_n_32),
        .\CNT1_reg[4]_2 (err1_n_30),
        .\CNT2_reg[3]_0 (rengine1_n_4),
        .\CNT2_reg[3]_1 (rx1_n_12),
        .E(rengine1_n_1),
        .Q(RXSTATES),
        .RXBUS(RXBUS),
        .RXBUS_d_reg_0(rengine1_n_2),
        .RXOUT_reg_0(rengine1_n_8),
        .RXOUT_reg_1(rx1_n_1),
        .\RXSTATES_reg[3] (rengine1_n_5),
        .\RXSTATES_reg[3]_0 (rx1_n_111),
        .\RXSTATES_reg[3]_1 (err1_n_35),
        .SJW(SJW),
        .SRST(SRST),
        .SRST_1(rengine1_n_7),
        .SRST_1_0(rengine1_n_9),
        .SRST_1_1(rengine1_n_10),
        .SRST_1_2(rengine1_n_11),
        .Sampled_din(Sampled_din),
        .TPROP(TPROP),
        .TSEG1(TSEG1),
        .TSEG2(TSEG2),
        .Tq(Tq));
  design_1_FPGAPROJECT_0_0_RXMachine_6 rx1
       (.AckTakeOver(AckTakeOver),
        .CAN_RST(CAN_RST),
        .CAN_RST_0(rx1_n_1),
        .\CNT2_reg[3] (rengine1_n_2),
        .\CNT2_reg[3]_0 (rengine1_n_3),
        .\CRC_RG_reg[14] (rengine1_n_6),
        .\Cnt[0]_i_2__0_0 (State),
        .\Cnt_reg[0]_0 (rengine1_n_9),
        .D(err1_n_33),
        .\D_Len_reg[3]_0 (D_Len_rec),
        .E(rengine1_n_11),
        .IDE_rec(IDE_rec),
        .IDE_reg_0(err1_n_30),
        .Q(RXSTATES),
        .\REC_reg[0] (err1_n_28),
        .RTR_reg_0(RTR_rec),
        .RXOUT_reg(rx1_n_110),
        .\RXSTATES_reg[0]_0 (rx1_n_13),
        .\RXSTATES_reg[0]_1 (rx1_n_14),
        .\RXSTATES_reg[0]_2 (err1_n_38),
        .\RXSTATES_reg[0]_3 (err1_n_36),
        .\RXSTATES_reg[1]_0 (rx1_n_15),
        .\RXSTATES_reg[1]_1 (err1_n_13),
        .\RXSTATES_reg[2]_0 (rx1_n_12),
        .\RXSTATES_reg[3]_0 (err1_n_35),
        .\RXSTATES_reg[3]_1 (rengine1_n_7),
        .SRST(SRST),
        .Sampled_din(Sampled_din),
        .TOFILTERI(TOFILTERI),
        .\TOFILTERI_reg[28]_0 (rengine1_n_5),
        .TOFILTERd(TOFILTERd),
        .Tq(Tq),
        .\bs_reg[0]_0 (rengine1_n_1),
        .\bs_reg[1]_0 (rx1_n_111),
        .done_reg_0(done_RX),
        .donefromrxr(donefromrxr),
        .imTX(imTX),
        .req_Error_RX(req_Error_RX),
        .req_Error_reg_0(rx1_n_6));
  design_1_FPGAPROJECT_0_0_TXMachine_7 tx1
       (.\CRC_RG_reg[0] (rx1_n_1),
        .\Cnt[0]_i_2 (err1_n_34),
        .\Cnt_reg[1]_0 (err1_n_13),
        .\Cnt_reg[5]_0 (rengine1_n_4),
        .D({err1_n_24,err1_n_25,err1_n_26,err1_n_27}),
        .D_Len_TX(D_Len_TX),
        .E(rengine1_n_11),
        .IDE_TX(IDE_TX),
        .ID_TX(ID_TX),
        .\REC[0]_i_5 (rx1_n_110),
        .\REC[0]_i_5_0 (err1_n_23),
        .\REC_reg[8] (err1_n_28),
        .RTR_TX(RTR_TX),
        .RXOUT_reg(tx1_n_9),
        .SRST(SRST),
        .Sampled_din(Sampled_din),
        .TEC(TEC[8:7]),
        .\TEC[8]_i_5 (err1_n_37),
        .\TEC_reg[8] (tx1_n_2),
        .TRANSMIT(TRANSMIT),
        .TRANSMIT_1(tx1_n_16),
        .TRANSMIT_reg(TRANSMIT_reg),
        .TRANSMITr(TRANSMITr),
        .\TXSTATES_reg[1]_0 (tx1_n_4),
        .\TXSTATES_reg[1]_1 (tx1_n_8),
        .\TXSTATES_reg[1]_2 (tx1_n_13),
        .\TXSTATES_reg[2]_0 (tx1_n_12),
        .\TXSTATES_reg[3]_0 (tx1_n_7),
        .\TXSTATES_reg[3]_1 (tx1_n_10),
        .\TXSTATES_reg[3]_2 (tx1_n_11),
        .Tq(Tq),
        .data_TX(data_TX),
        .done_TXr(done_TXr),
        .done_i_12(rx1_n_14),
        .done_i_12_0(err1_n_12),
        .done_reg_0(done_TX),
        .donefromtxr(donefromtxr),
        .imTX(imTX),
        .imTX_reg_0(tx1_n_15),
        .imTX_reg_1(tx1_n_18),
        .req_Error_RX(req_Error_RX),
        .req_Error_reg(tx1_n_3),
        .req_Error_reg_0(tx1_n_5),
        .req_Error_reg_1(tx1_n_6),
        .req_Error_reg_2(tx1_n_17));
endmodule

(* ORIG_REF_NAME = "CANCORE" *) 
module design_1_FPGAPROJECT_0_0_CANCORE__2
   (done_TX,
    RTR_rec_0,
    IDE_rec_0,
    done_reg,
    Q,
    \REC_reg[8] ,
    D_Len_rec_0,
    TOFILTERd_0,
    TOFILTERI_0,
    RX,
    SRST_0,
    IDE_TX_0,
    TRANSMIT_0,
    CAN_CLK,
    Mode_0,
    TX,
    RTR_TX_0,
    D_Len_TX_0,
    ID_TX_0,
    data_TX_0,
    CAN_RST,
    BRP_0);
  output done_TX;
  output RTR_rec_0;
  output IDE_rec_0;
  output done_reg;
  output [8:0]Q;
  output [8:0]\REC_reg[8] ;
  output [3:0]D_Len_rec_0;
  output [63:0]TOFILTERd_0;
  output [28:0]TOFILTERI_0;
  output RX;
  input SRST_0;
  input IDE_TX_0;
  input TRANSMIT_0;
  input CAN_CLK;
  input [2:0]Mode_0;
  input TX;
  input RTR_TX_0;
  input [3:0]D_Len_TX_0;
  input [28:0]ID_TX_0;
  input [63:0]data_TX_0;
  input CAN_RST;
  input [4:0]BRP_0;

  wire AckTakeOver;
  wire [4:0]BRP_0;
  wire CAN_CLK;
  wire CAN_RST;
  wire [3:0]D_Len_TX_0;
  wire [3:0]D_Len_rec_0;
  wire IDE_TX_0;
  wire IDE_rec_0;
  wire [28:0]ID_TX_0;
  wire [2:0]Mode_0;
  wire [8:0]Q;
  wire [8:0]\REC_reg[8] ;
  wire RTR_TX_0;
  wire RTR_rec_0;
  wire RX;
  wire RXBUS;
  wire RXBUS_d;
  wire RXBUSs;
  wire SRST_0;
  wire Sampled_din;
  wire [0:0]State;
  wire [28:0]TOFILTERI_0;
  wire [63:0]TOFILTERd_0;
  wire TRANSMIT_0;
  wire TRANSMIT_reg;
  wire TRANSMITr;
  wire TRANSMITr_i_1_n_0;
  wire TX;
  wire Tq;
  wire Tq_i_1_n_0;
  wire [4:3]count_reg;
  wire [63:0]data_TX_0;
  wire done_TX;
  wire done_TXr;
  wire done_reg;
  wire donefromrxr;
  wire donefromtxr;
  wire err1_n_20;
  wire err1_n_21;
  wire err1_n_22;
  wire err1_n_23;
  wire err1_n_24;
  wire err1_n_25;
  wire err1_n_26;
  wire err1_n_29;
  wire err1_n_30;
  wire err1_n_31;
  wire err1_n_32;
  wire err1_n_33;
  wire err1_n_34;
  wire imTX;
  wire lastvalue;
  wire p1_n_3;
  wire rengine1_n_10;
  wire rengine1_n_11;
  wire rengine1_n_12;
  wire rengine1_n_13;
  wire rengine1_n_2;
  wire rengine1_n_3;
  wire rengine1_n_4;
  wire rengine1_n_5;
  wire rengine1_n_6;
  wire rengine1_n_7;
  wire rengine1_n_8;
  wire rengine1_n_9;
  wire req_Error_RX;
  wire rx1_n_1;
  wire rx1_n_13;
  wire rx1_n_14;
  wire rx1_n_15;
  wire rx1_n_6;
  wire rx1_n_7;
  wire rx1_n_8;
  wire rx1_n_80;
  wire tx1_n_10;
  wire tx1_n_2;
  wire tx1_n_3;
  wire tx1_n_4;
  wire tx1_n_5;
  wire tx1_n_6;
  wire tx1_n_7;
  wire tx1_n_8;
  wire tx1_n_9;

  design_1_FPGAPROJECT_0_0_TFF TFF_RXB
       (.RX(RX),
        .clk(Tq),
        .q(RXBUSs),
        .q_reg(rx1_n_1));
  FDCE TRANSMIT_reg_reg
       (.C(CAN_CLK),
        .CE(1'b1),
        .CLR(rx1_n_1),
        .D(TRANSMIT_0),
        .Q(TRANSMIT_reg));
  LUT5 #(
    .INIT(32'hF8FF8888)) 
    TRANSMITr_i_1
       (.I0(TRANSMIT_0),
        .I1(TRANSMIT_reg),
        .I2(done_TXr),
        .I3(done_TX),
        .I4(TRANSMITr),
        .O(TRANSMITr_i_1_n_0));
  FDCE TRANSMITr_reg
       (.C(CAN_CLK),
        .CE(1'b1),
        .CLR(rx1_n_1),
        .D(TRANSMITr_i_1_n_0),
        .Q(TRANSMITr));
  LUT6 #(
    .INIT(64'h6FFFFF6F90000090)) 
    Tq_i_1
       (.I0(count_reg[4]),
        .I1(BRP_0[4]),
        .I2(p1_n_3),
        .I3(BRP_0[3]),
        .I4(count_reg[3]),
        .I5(Tq),
        .O(Tq_i_1_n_0));
  FDCE done_TXr_reg
       (.C(CAN_CLK),
        .CE(1'b1),
        .CLR(rx1_n_1),
        .D(done_TX),
        .Q(done_TXr));
  design_1_FPGAPROJECT_0_0_ErrorHandler err1
       (.AckTakeOver(AckTakeOver),
        .\Cnt_reg[0]_0 (rengine1_n_5),
        .\Cnt_reg[3]_0 (rengine1_n_8),
        .D({err1_n_22,err1_n_23}),
        .\D_Len[0]_i_2_0 (tx1_n_6),
        .E(rengine1_n_7),
        .Mode_0(Mode_0),
        .Mode_0_1_sp_1(err1_n_25),
        .Q(Q),
        .\REC[0]_i_2_0 (rengine1_n_13),
        .\REC[8]_i_7_0 (tx1_n_5),
        .\REC_reg[0]_0 (done_reg),
        .\REC_reg[7]_0 (err1_n_32),
        .\REC_reg[8]_0 (\REC_reg[8] ),
        .\REC_reg[8]_1 (err1_n_33),
        .RX(RX),
        .RXBUS(RXBUS),
        .RXBUS_d(RXBUS_d),
        .RXOUT_reg(err1_n_24),
        .\RXSTATES_reg[1] (rx1_n_14),
        .SRST_0(SRST_0),
        .SRST_0_0(err1_n_29),
        .Sampled_din(Sampled_din),
        .\State_reg[0]_0 (State),
        .\State_reg[0]_1 (err1_n_20),
        .\State_reg[0]_2 (err1_n_31),
        .\State_reg[0]_3 (err1_n_34),
        .\State_reg[0]_4 (tx1_n_2),
        .\State_reg[0]_5 (rx1_n_6),
        .\State_reg[2]_0 (err1_n_21),
        .\State_reg[2]_1 (err1_n_30),
        .\TEC[8]_i_11_0 (tx1_n_4),
        .\TEC_reg[0]_0 (tx1_n_7),
        .\TEC_reg[0]_1 (done_TX),
        .TX(TX),
        .\TXSTATES_reg[2] (tx1_n_10),
        .\TXSTATES_reg[3] (tx1_n_9),
        .TXpin_reg_0(rx1_n_8),
        .ack_error_reg_0(rx1_n_1),
        .ack_error_reg_1(rengine1_n_6),
        .ack_error_reg_2(tx1_n_3),
        .ack_error_reg_3(tx1_n_8),
        .clk(Tq),
        .donefromrxr(donefromrxr),
        .donefromtxr(donefromtxr),
        .imTX(imTX),
        .lastvalue(lastvalue),
        .lastvalue_reg_0(rengine1_n_12),
        .q(RXBUSs),
        .q_reg(err1_n_26),
        .req_Error_RX(req_Error_RX));
  design_1_FPGAPROJECT_0_0_Prescaler p1
       (.BRP_0(BRP_0),
        .CAN_CLK(CAN_CLK),
        .Tq_reg_0(Tq_i_1_n_0),
        .clk(Tq),
        .\count_reg[0]_0 (p1_n_3),
        .\count_reg[0]_1 (rx1_n_1),
        .\count_reg[4]_0 (count_reg));
  design_1_FPGAPROJECT_0_0_Rengine rengine1
       (.\CNT1_reg[0]_0 (err1_n_24),
        .\CNT1_reg[3]_0 (rengine1_n_10),
        .\CNT1_reg[3]_1 (err1_n_26),
        .\CNT1_reg[4]_0 (rengine1_n_2),
        .\CNT1_reg[4]_1 (rengine1_n_4),
        .\CNT2_reg[0]_0 (rengine1_n_6),
        .\CNT2_reg[0]_1 (err1_n_25),
        .\CNT2_reg[1]_0 (rx1_n_7),
        .\CNT2_reg[3]_0 (rx1_n_13),
        .E(rengine1_n_3),
        .\REC[0]_i_3 (State),
        .RXBUS(RXBUS),
        .RXBUS_d(RXBUS_d),
        .RXBUS_d_reg_0(rengine1_n_9),
        .RXOUT_reg_0(rengine1_n_8),
        .RXOUT_reg_1(rengine1_n_12),
        .RXOUT_reg_2(rengine1_n_13),
        .RXOUT_reg_3(rx1_n_1),
        .\RXSTATES_reg[3] (rx1_n_80),
        .\RXSTATES_reg[3]_0 (err1_n_30),
        .SRST_0(SRST_0),
        .SRST_0_0(rengine1_n_5),
        .SRST_0_1(rengine1_n_7),
        .SRST_0_2(rengine1_n_11),
        .Sampled_din(Sampled_din),
        .clk(Tq),
        .lastvalue(lastvalue));
  design_1_FPGAPROJECT_0_0_RXMachine rx1
       (.AckTakeOver(AckTakeOver),
        .CAN_RST(CAN_RST),
        .CAN_RST_0(rx1_n_1),
        .\CNT2_reg[3] (rengine1_n_10),
        .\CNT2_reg[3]_0 (rengine1_n_9),
        .\CRC_RG_reg[14] (rengine1_n_4),
        .\Cnt_reg[0]_0 (rengine1_n_3),
        .D(err1_n_29),
        .E(rengine1_n_7),
        .IDE_rec_0(IDE_rec_0),
        .Q(D_Len_rec_0),
        .RTR_rec_0(RTR_rec_0),
        .RXOUT_reg(rx1_n_6),
        .\RXSTATES_reg[0]_0 (err1_n_21),
        .\RXSTATES_reg[0]_1 (err1_n_34),
        .\RXSTATES_reg[1]_0 (rx1_n_14),
        .\RXSTATES_reg[2]_0 (rx1_n_7),
        .\RXSTATES_reg[2]_1 (rx1_n_13),
        .\RXSTATES_reg[3]_0 (rx1_n_15),
        .\RXSTATES_reg[3]_1 (err1_n_30),
        .\RXSTATES_reg[3]_2 (rengine1_n_11),
        .SRST_0(SRST_0),
        .Sampled_din(Sampled_din),
        .TOFILTERI_0(TOFILTERI_0),
        .TOFILTERd_0(TOFILTERd_0),
        .\TOFILTERd_reg[0]_0 (err1_n_26),
        .TXpin_i_2(tx1_n_7),
        .TXpin_i_2_0(err1_n_32),
        .\bs_reg[0]_0 (rengine1_n_2),
        .\bs_reg[1]_0 (rx1_n_80),
        .clk(Tq),
        .done_reg_0(done_reg),
        .donefromrxr(donefromrxr),
        .imTX(imTX),
        .req_Error_RX(req_Error_RX),
        .req_Error_reg_0(rx1_n_8));
  design_1_FPGAPROJECT_0_0_TXMachine tx1
       (.\CRC_RG_reg[0] (rx1_n_1),
        .\Cnt[0]_i_3 (err1_n_33),
        .\Cnt_reg[1]_0 (err1_n_21),
        .D({err1_n_22,err1_n_23}),
        .D_Len_TX_0(D_Len_TX_0),
        .E(rengine1_n_7),
        .IDE_TX_0(IDE_TX_0),
        .ID_TX_0(ID_TX_0),
        .Q(Q[8:7]),
        .RTR_TX_0(RTR_TX_0),
        .RXOUT_reg(tx1_n_8),
        .SRST_0(SRST_0),
        .Sampled_din(Sampled_din),
        .\TEC[8]_i_17 (rx1_n_6),
        .\TEC[8]_i_17_0 (err1_n_31),
        .TRANSMITr(TRANSMITr),
        .\TXSTATES_reg[0]_0 (tx1_n_6),
        .\TXSTATES_reg[0]_1 (tx1_n_9),
        .\TXSTATES_reg[0]_2 (err1_n_20),
        .\TXSTATES_reg[1]_0 (tx1_n_3),
        .\TXSTATES_reg[1]_1 (tx1_n_7),
        .\TXSTATES_reg[2]_0 (tx1_n_10),
        .clk(Tq),
        .data_TX_0(data_TX_0),
        .done_i_11(rx1_n_15),
        .done_i_11_0(err1_n_32),
        .done_reg_0(done_TX),
        .donefromtxr(donefromtxr),
        .imTX(imTX),
        .req_Error_RX(req_Error_RX),
        .req_Error_reg(tx1_n_2),
        .req_Error_reg_0(tx1_n_4),
        .req_Error_reg_1(tx1_n_5),
        .\serial_reg[4] (rengine1_n_6));
endmodule

(* ORIG_REF_NAME = "CRC" *) 
module design_1_FPGAPROJECT_0_0_CRC
   (\TXSTATES_reg[3] ,
    \Cnt_reg[0] ,
    \TXSTATES_reg[3]_0 ,
    SRST_0_0,
    \Cnt_reg[2] ,
    \Cnt_reg[3] ,
    \TXSTATES_reg[0] ,
    \TXSTATES_reg[2] ,
    Q,
    \serial[0]_i_12_0 ,
    \CRC_RG_reg[14]_0 ,
    SRST_0,
    IDE_TX_0,
    RTR_TX_0,
    ID_TX_0,
    D_Len_TX_0,
    data_TX_0,
    E,
    clk,
    \CRC_RG_reg[0]_0 );
  output \TXSTATES_reg[3] ;
  output \Cnt_reg[0] ;
  output \TXSTATES_reg[3]_0 ;
  output SRST_0_0;
  output \Cnt_reg[2] ;
  output \Cnt_reg[3] ;
  output \TXSTATES_reg[0] ;
  output \TXSTATES_reg[2] ;
  input [3:0]Q;
  input [5:0]\serial[0]_i_12_0 ;
  input \CRC_RG_reg[14]_0 ;
  input SRST_0;
  input IDE_TX_0;
  input RTR_TX_0;
  input [28:0]ID_TX_0;
  input [3:0]D_Len_TX_0;
  input [63:0]data_TX_0;
  input [0:0]E;
  input clk;
  input \CRC_RG_reg[0]_0 ;

  wire \CRC_RG[14]_i_7_n_0 ;
  wire \CRC_RG_reg[0]_0 ;
  wire \CRC_RG_reg[14]_0 ;
  wire \CRC_RG_reg_n_0_[0] ;
  wire \CRC_RG_reg_n_0_[10] ;
  wire \CRC_RG_reg_n_0_[11] ;
  wire \CRC_RG_reg_n_0_[12] ;
  wire \CRC_RG_reg_n_0_[13] ;
  wire \CRC_RG_reg_n_0_[1] ;
  wire \CRC_RG_reg_n_0_[2] ;
  wire \CRC_RG_reg_n_0_[3] ;
  wire \CRC_RG_reg_n_0_[4] ;
  wire \CRC_RG_reg_n_0_[5] ;
  wire \CRC_RG_reg_n_0_[6] ;
  wire \CRC_RG_reg_n_0_[7] ;
  wire \CRC_RG_reg_n_0_[8] ;
  wire \CRC_RG_reg_n_0_[9] ;
  wire \Cnt_reg[0] ;
  wire \Cnt_reg[2] ;
  wire \Cnt_reg[3] ;
  wire [3:0]D_Len_TX_0;
  wire [0:0]E;
  wire IDE_TX_0;
  wire [28:0]ID_TX_0;
  wire [3:0]Q;
  wire RTR_TX_0;
  wire SRST_0;
  wire SRST_0_0;
  wire \TXSTATES_reg[0] ;
  wire \TXSTATES_reg[2] ;
  wire \TXSTATES_reg[3] ;
  wire \TXSTATES_reg[3]_0 ;
  wire clk;
  wire [63:0]data_TX_0;
  wire [14:14]out_CRC;
  wire [14:0]p_1_in__0;
  wire \serial[0]_i_10_n_0 ;
  wire \serial[0]_i_11_n_0 ;
  wire [5:0]\serial[0]_i_12_0 ;
  wire \serial[0]_i_12_n_0 ;
  wire \serial[0]_i_13_n_0 ;
  wire \serial[0]_i_14_n_0 ;
  wire \serial[0]_i_15_n_0 ;
  wire \serial[0]_i_16_n_0 ;
  wire \serial[0]_i_17_n_0 ;
  wire \serial[0]_i_18_n_0 ;
  wire \serial[0]_i_19_n_0 ;
  wire \serial[0]_i_20_n_0 ;
  wire \serial[0]_i_21_n_0 ;
  wire \serial[0]_i_22_n_0 ;
  wire \serial[0]_i_23_n_0 ;
  wire \serial[0]_i_24_n_0 ;
  wire \serial[0]_i_25_n_0 ;
  wire \serial[0]_i_26_n_0 ;
  wire \serial[0]_i_27_n_0 ;
  wire \serial[0]_i_28_n_0 ;
  wire \serial[0]_i_29_n_0 ;
  wire \serial[0]_i_30_n_0 ;
  wire \serial[0]_i_31_n_0 ;
  wire \serial[0]_i_32_n_0 ;
  wire \serial[0]_i_33_n_0 ;
  wire \serial[0]_i_34_n_0 ;
  wire \serial[0]_i_35_n_0 ;
  wire \serial[0]_i_36_n_0 ;
  wire \serial[0]_i_37_n_0 ;
  wire \serial[0]_i_38_n_0 ;
  wire \serial[0]_i_39_n_0 ;
  wire \serial[0]_i_4_n_0 ;
  wire \serial[0]_i_50_n_0 ;
  wire \serial[0]_i_51_n_0 ;
  wire \serial[0]_i_52_n_0 ;
  wire \serial[0]_i_53_n_0 ;
  wire \serial[0]_i_54_n_0 ;
  wire \serial[0]_i_55_n_0 ;
  wire \serial[0]_i_56_n_0 ;
  wire \serial[0]_i_57_n_0 ;
  wire \serial[0]_i_58_n_0 ;
  wire \serial[0]_i_59_n_0 ;
  wire \serial[0]_i_5_n_0 ;
  wire \serial[0]_i_60_n_0 ;
  wire \serial[0]_i_61_n_0 ;
  wire \serial[0]_i_62_n_0 ;
  wire \serial[0]_i_63_n_0 ;
  wire \serial[0]_i_64_n_0 ;
  wire \serial[0]_i_65_n_0 ;
  wire \serial[0]_i_66_n_0 ;
  wire \serial[0]_i_67_n_0 ;
  wire \serial[0]_i_68_n_0 ;
  wire \serial[0]_i_69_n_0 ;
  wire \serial[0]_i_6_n_0 ;
  wire \serial[0]_i_7_n_0 ;
  wire \serial[0]_i_8_n_0 ;
  wire \serial[0]_i_9_n_0 ;
  wire \serial_reg[0]_i_40_n_0 ;
  wire \serial_reg[0]_i_41_n_0 ;
  wire \serial_reg[0]_i_42_n_0 ;
  wire \serial_reg[0]_i_43_n_0 ;
  wire \serial_reg[0]_i_44_n_0 ;
  wire \serial_reg[0]_i_45_n_0 ;
  wire \serial_reg[0]_i_46_n_0 ;
  wire \serial_reg[0]_i_47_n_0 ;
  wire \serial_reg[0]_i_48_n_0 ;
  wire \serial_reg[0]_i_49_n_0 ;

  LUT6 #(
    .INIT(64'h00000000FF9E0000)) 
    \CRC_RG[0]_i_1 
       (.I0(Q[1]),
        .I1(Q[0]),
        .I2(Q[3]),
        .I3(Q[2]),
        .I4(SRST_0),
        .I5(\CRC_RG[14]_i_7_n_0 ),
        .O(p_1_in__0[0]));
  (* SOFT_HLUTNM = "soft_lutpair210" *) 
  LUT3 #(
    .INIT(8'h82)) 
    \CRC_RG[10]_i_1 
       (.I0(SRST_0_0),
        .I1(\CRC_RG[14]_i_7_n_0 ),
        .I2(\CRC_RG_reg_n_0_[9] ),
        .O(p_1_in__0[10]));
  LUT6 #(
    .INIT(64'hAAAA82A800000000)) 
    \CRC_RG[11]_i_1 
       (.I0(\CRC_RG_reg_n_0_[10] ),
        .I1(Q[1]),
        .I2(Q[0]),
        .I3(Q[3]),
        .I4(Q[2]),
        .I5(SRST_0),
        .O(p_1_in__0[11]));
  LUT6 #(
    .INIT(64'hAAAA82A800000000)) 
    \CRC_RG[12]_i_1 
       (.I0(\CRC_RG_reg_n_0_[11] ),
        .I1(Q[1]),
        .I2(Q[0]),
        .I3(Q[3]),
        .I4(Q[2]),
        .I5(SRST_0),
        .O(p_1_in__0[12]));
  LUT6 #(
    .INIT(64'hAAAA82A800000000)) 
    \CRC_RG[13]_i_1 
       (.I0(\CRC_RG_reg_n_0_[12] ),
        .I1(Q[1]),
        .I2(Q[0]),
        .I3(Q[3]),
        .I4(Q[2]),
        .I5(SRST_0),
        .O(p_1_in__0[13]));
  (* SOFT_HLUTNM = "soft_lutpair210" *) 
  LUT3 #(
    .INIT(8'h82)) 
    \CRC_RG[14]_i_2 
       (.I0(SRST_0_0),
        .I1(\CRC_RG[14]_i_7_n_0 ),
        .I2(\CRC_RG_reg_n_0_[13] ),
        .O(p_1_in__0[14]));
  (* SOFT_HLUTNM = "soft_lutpair204" *) 
  LUT5 #(
    .INIT(32'hAA8A8AA8)) 
    \CRC_RG[14]_i_3 
       (.I0(SRST_0),
        .I1(Q[2]),
        .I2(Q[3]),
        .I3(Q[0]),
        .I4(Q[1]),
        .O(SRST_0_0));
  (* SOFT_HLUTNM = "soft_lutpair203" *) 
  LUT5 #(
    .INIT(32'h15140000)) 
    \CRC_RG[14]_i_4 
       (.I0(Q[3]),
        .I1(Q[1]),
        .I2(Q[2]),
        .I3(Q[0]),
        .I4(\CRC_RG_reg[14]_0 ),
        .O(\TXSTATES_reg[3]_0 ));
  (* SOFT_HLUTNM = "soft_lutpair203" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \CRC_RG[14]_i_6 
       (.I0(Q[2]),
        .I1(Q[1]),
        .O(\TXSTATES_reg[2] ));
  LUT2 #(
    .INIT(4'h6)) 
    \CRC_RG[14]_i_7 
       (.I0(out_CRC),
        .I1(\TXSTATES_reg[3] ),
        .O(\CRC_RG[14]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'hAAAA82A800000000)) 
    \CRC_RG[1]_i_1 
       (.I0(\CRC_RG_reg_n_0_[0] ),
        .I1(Q[1]),
        .I2(Q[0]),
        .I3(Q[3]),
        .I4(Q[2]),
        .I5(SRST_0),
        .O(p_1_in__0[1]));
  LUT6 #(
    .INIT(64'hAAAA82A800000000)) 
    \CRC_RG[2]_i_1 
       (.I0(\CRC_RG_reg_n_0_[1] ),
        .I1(Q[1]),
        .I2(Q[0]),
        .I3(Q[3]),
        .I4(Q[2]),
        .I5(SRST_0),
        .O(p_1_in__0[2]));
  (* SOFT_HLUTNM = "soft_lutpair208" *) 
  LUT3 #(
    .INIT(8'h82)) 
    \CRC_RG[3]_i_1 
       (.I0(SRST_0_0),
        .I1(\CRC_RG[14]_i_7_n_0 ),
        .I2(\CRC_RG_reg_n_0_[2] ),
        .O(p_1_in__0[3]));
  (* SOFT_HLUTNM = "soft_lutpair208" *) 
  LUT3 #(
    .INIT(8'h82)) 
    \CRC_RG[4]_i_1 
       (.I0(SRST_0_0),
        .I1(\CRC_RG[14]_i_7_n_0 ),
        .I2(\CRC_RG_reg_n_0_[3] ),
        .O(p_1_in__0[4]));
  LUT6 #(
    .INIT(64'hAAAA82A800000000)) 
    \CRC_RG[5]_i_1 
       (.I0(\CRC_RG_reg_n_0_[4] ),
        .I1(Q[1]),
        .I2(Q[0]),
        .I3(Q[3]),
        .I4(Q[2]),
        .I5(SRST_0),
        .O(p_1_in__0[5]));
  LUT6 #(
    .INIT(64'hAAAA82A800000000)) 
    \CRC_RG[6]_i_1 
       (.I0(\CRC_RG_reg_n_0_[5] ),
        .I1(Q[1]),
        .I2(Q[0]),
        .I3(Q[3]),
        .I4(Q[2]),
        .I5(SRST_0),
        .O(p_1_in__0[6]));
  (* SOFT_HLUTNM = "soft_lutpair209" *) 
  LUT3 #(
    .INIT(8'h82)) 
    \CRC_RG[7]_i_1 
       (.I0(SRST_0_0),
        .I1(\CRC_RG[14]_i_7_n_0 ),
        .I2(\CRC_RG_reg_n_0_[6] ),
        .O(p_1_in__0[7]));
  (* SOFT_HLUTNM = "soft_lutpair209" *) 
  LUT3 #(
    .INIT(8'h82)) 
    \CRC_RG[8]_i_1 
       (.I0(SRST_0_0),
        .I1(\CRC_RG[14]_i_7_n_0 ),
        .I2(\CRC_RG_reg_n_0_[7] ),
        .O(p_1_in__0[8]));
  LUT6 #(
    .INIT(64'hAAAA82A800000000)) 
    \CRC_RG[9]_i_1 
       (.I0(\CRC_RG_reg_n_0_[8] ),
        .I1(Q[1]),
        .I2(Q[0]),
        .I3(Q[3]),
        .I4(Q[2]),
        .I5(SRST_0),
        .O(p_1_in__0[9]));
  FDCE \CRC_RG_reg[0] 
       (.C(clk),
        .CE(E),
        .CLR(\CRC_RG_reg[0]_0 ),
        .D(p_1_in__0[0]),
        .Q(\CRC_RG_reg_n_0_[0] ));
  FDCE \CRC_RG_reg[10] 
       (.C(clk),
        .CE(E),
        .CLR(\CRC_RG_reg[0]_0 ),
        .D(p_1_in__0[10]),
        .Q(\CRC_RG_reg_n_0_[10] ));
  FDCE \CRC_RG_reg[11] 
       (.C(clk),
        .CE(E),
        .CLR(\CRC_RG_reg[0]_0 ),
        .D(p_1_in__0[11]),
        .Q(\CRC_RG_reg_n_0_[11] ));
  FDCE \CRC_RG_reg[12] 
       (.C(clk),
        .CE(E),
        .CLR(\CRC_RG_reg[0]_0 ),
        .D(p_1_in__0[12]),
        .Q(\CRC_RG_reg_n_0_[12] ));
  FDCE \CRC_RG_reg[13] 
       (.C(clk),
        .CE(E),
        .CLR(\CRC_RG_reg[0]_0 ),
        .D(p_1_in__0[13]),
        .Q(\CRC_RG_reg_n_0_[13] ));
  FDCE \CRC_RG_reg[14] 
       (.C(clk),
        .CE(E),
        .CLR(\CRC_RG_reg[0]_0 ),
        .D(p_1_in__0[14]),
        .Q(out_CRC));
  FDCE \CRC_RG_reg[1] 
       (.C(clk),
        .CE(E),
        .CLR(\CRC_RG_reg[0]_0 ),
        .D(p_1_in__0[1]),
        .Q(\CRC_RG_reg_n_0_[1] ));
  FDCE \CRC_RG_reg[2] 
       (.C(clk),
        .CE(E),
        .CLR(\CRC_RG_reg[0]_0 ),
        .D(p_1_in__0[2]),
        .Q(\CRC_RG_reg_n_0_[2] ));
  FDCE \CRC_RG_reg[3] 
       (.C(clk),
        .CE(E),
        .CLR(\CRC_RG_reg[0]_0 ),
        .D(p_1_in__0[3]),
        .Q(\CRC_RG_reg_n_0_[3] ));
  FDCE \CRC_RG_reg[4] 
       (.C(clk),
        .CE(E),
        .CLR(\CRC_RG_reg[0]_0 ),
        .D(p_1_in__0[4]),
        .Q(\CRC_RG_reg_n_0_[4] ));
  FDCE \CRC_RG_reg[5] 
       (.C(clk),
        .CE(E),
        .CLR(\CRC_RG_reg[0]_0 ),
        .D(p_1_in__0[5]),
        .Q(\CRC_RG_reg_n_0_[5] ));
  FDCE \CRC_RG_reg[6] 
       (.C(clk),
        .CE(E),
        .CLR(\CRC_RG_reg[0]_0 ),
        .D(p_1_in__0[6]),
        .Q(\CRC_RG_reg_n_0_[6] ));
  FDCE \CRC_RG_reg[7] 
       (.C(clk),
        .CE(E),
        .CLR(\CRC_RG_reg[0]_0 ),
        .D(p_1_in__0[7]),
        .Q(\CRC_RG_reg_n_0_[7] ));
  FDCE \CRC_RG_reg[8] 
       (.C(clk),
        .CE(E),
        .CLR(\CRC_RG_reg[0]_0 ),
        .D(p_1_in__0[8]),
        .Q(\CRC_RG_reg_n_0_[8] ));
  FDCE \CRC_RG_reg[9] 
       (.C(clk),
        .CE(E),
        .CLR(\CRC_RG_reg[0]_0 ),
        .D(p_1_in__0[9]),
        .Q(\CRC_RG_reg_n_0_[9] ));
  (* SOFT_HLUTNM = "soft_lutpair207" *) 
  LUT3 #(
    .INIT(8'hE1)) 
    \Cnt[2]_i_6__0 
       (.I0(\serial[0]_i_12_0 [0]),
        .I1(\serial[0]_i_12_0 [1]),
        .I2(\serial[0]_i_12_0 [2]),
        .O(\Cnt_reg[0] ));
  (* SOFT_HLUTNM = "soft_lutpair206" *) 
  LUT4 #(
    .INIT(16'hAAA9)) 
    \Cnt[3]_i_6 
       (.I0(\serial[0]_i_12_0 [3]),
        .I1(\serial[0]_i_12_0 [2]),
        .I2(\serial[0]_i_12_0 [0]),
        .I3(\serial[0]_i_12_0 [1]),
        .O(\Cnt_reg[3] ));
  (* SOFT_HLUTNM = "soft_lutpair204" *) 
  LUT2 #(
    .INIT(4'h2)) 
    done_i_12
       (.I0(Q[0]),
        .I1(Q[1]),
        .O(\TXSTATES_reg[0] ));
  LUT6 #(
    .INIT(64'h0000000000000001)) 
    done_i_13
       (.I0(\serial[0]_i_12_0 [2]),
        .I1(\serial[0]_i_12_0 [0]),
        .I2(\serial[0]_i_12_0 [1]),
        .I3(\serial[0]_i_12_0 [4]),
        .I4(\serial[0]_i_12_0 [3]),
        .I5(\serial[0]_i_12_0 [5]),
        .O(\Cnt_reg[2] ));
  LUT6 #(
    .INIT(64'h8888888F8F888888)) 
    \serial[0]_i_10 
       (.I0(\Cnt_reg[2] ),
        .I1(RTR_TX_0),
        .I2(\serial[0]_i_26_n_0 ),
        .I3(\serial[0]_i_12_0 [0]),
        .I4(\serial[0]_i_12_0 [1]),
        .I5(\serial[0]_i_12_0 [2]),
        .O(\serial[0]_i_10_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \serial[0]_i_11 
       (.I0(\serial[0]_i_27_n_0 ),
        .I1(\serial[0]_i_28_n_0 ),
        .I2(\Cnt_reg[3] ),
        .I3(\serial[0]_i_29_n_0 ),
        .I4(\Cnt_reg[0] ),
        .I5(\serial[0]_i_30_n_0 ),
        .O(\serial[0]_i_11_n_0 ));
  LUT6 #(
    .INIT(64'h55555555555555D5)) 
    \serial[0]_i_12 
       (.I0(\serial[0]_i_13_n_0 ),
        .I1(\serial[0]_i_12_0 [1]),
        .I2(\serial[0]_i_12_0 [0]),
        .I3(IDE_TX_0),
        .I4(\serial[0]_i_12_0 [2]),
        .I5(\serial[0]_i_26_n_0 ),
        .O(\serial[0]_i_12_n_0 ));
  LUT6 #(
    .INIT(64'h000000570000FFFF)) 
    \serial[0]_i_13 
       (.I0(\serial[0]_i_12_0 [2]),
        .I1(\serial[0]_i_12_0 [1]),
        .I2(\serial[0]_i_12_0 [0]),
        .I3(\serial[0]_i_12_0 [3]),
        .I4(\serial[0]_i_12_0 [5]),
        .I5(\serial[0]_i_12_0 [4]),
        .O(\serial[0]_i_13_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \serial[0]_i_14 
       (.I0(\serial[0]_i_31_n_0 ),
        .I1(\serial[0]_i_32_n_0 ),
        .I2(\serial[0]_i_33_n_0 ),
        .I3(\serial[0]_i_34_n_0 ),
        .I4(\serial[0]_i_35_n_0 ),
        .I5(ID_TX_0[28]),
        .O(\serial[0]_i_14_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair205" *) 
  LUT5 #(
    .INIT(32'hAAAAA999)) 
    \serial[0]_i_15 
       (.I0(\serial[0]_i_12_0 [4]),
        .I1(\serial[0]_i_12_0 [2]),
        .I2(\serial[0]_i_12_0 [1]),
        .I3(\serial[0]_i_12_0 [0]),
        .I4(\serial[0]_i_12_0 [3]),
        .O(\serial[0]_i_15_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \serial[0]_i_16 
       (.I0(\serial[0]_i_36_n_0 ),
        .I1(\serial[0]_i_37_n_0 ),
        .I2(\serial[0]_i_33_n_0 ),
        .I3(\serial[0]_i_38_n_0 ),
        .I4(\serial[0]_i_35_n_0 ),
        .I5(\serial[0]_i_39_n_0 ),
        .O(\serial[0]_i_16_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair211" *) 
  LUT3 #(
    .INIT(8'h01)) 
    \serial[0]_i_17 
       (.I0(\serial[0]_i_12_0 [5]),
        .I1(\serial[0]_i_12_0 [3]),
        .I2(\serial[0]_i_12_0 [4]),
        .O(\serial[0]_i_17_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \serial[0]_i_18 
       (.I0(D_Len_TX_0[3]),
        .I1(D_Len_TX_0[2]),
        .I2(\serial[0]_i_12_0 [1]),
        .I3(D_Len_TX_0[1]),
        .I4(\serial[0]_i_12_0 [0]),
        .I5(D_Len_TX_0[0]),
        .O(\serial[0]_i_18_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \serial[0]_i_19 
       (.I0(\serial_reg[0]_i_40_n_0 ),
        .I1(\serial_reg[0]_i_41_n_0 ),
        .I2(\serial[0]_i_12_0 [4]),
        .I3(\serial_reg[0]_i_42_n_0 ),
        .I4(\serial[0]_i_12_0 [3]),
        .I5(\serial_reg[0]_i_43_n_0 ),
        .O(\serial[0]_i_19_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \serial[0]_i_20 
       (.I0(\serial_reg[0]_i_44_n_0 ),
        .I1(\serial_reg[0]_i_45_n_0 ),
        .I2(\serial[0]_i_12_0 [4]),
        .I3(\serial_reg[0]_i_46_n_0 ),
        .I4(\serial[0]_i_12_0 [3]),
        .I5(\serial_reg[0]_i_47_n_0 ),
        .O(\serial[0]_i_20_n_0 ));
  LUT6 #(
    .INIT(64'hFFFF8A80FFFFFFFF)) 
    \serial[0]_i_21 
       (.I0(Q[0]),
        .I1(\serial_reg[0]_i_48_n_0 ),
        .I2(\serial[0]_i_12_0 [3]),
        .I3(\serial_reg[0]_i_49_n_0 ),
        .I4(Q[1]),
        .I5(Q[2]),
        .O(\serial[0]_i_21_n_0 ));
  LUT6 #(
    .INIT(64'hFCAF0CAFFCA00CA0)) 
    \serial[0]_i_22 
       (.I0(ID_TX_0[24]),
        .I1(ID_TX_0[25]),
        .I2(\serial[0]_i_12_0 [0]),
        .I3(\serial[0]_i_12_0 [1]),
        .I4(ID_TX_0[26]),
        .I5(ID_TX_0[27]),
        .O(\serial[0]_i_22_n_0 ));
  LUT6 #(
    .INIT(64'hFCAF0CAFFCA00CA0)) 
    \serial[0]_i_23 
       (.I0(ID_TX_0[16]),
        .I1(ID_TX_0[17]),
        .I2(\serial[0]_i_12_0 [0]),
        .I3(\serial[0]_i_12_0 [1]),
        .I4(ID_TX_0[18]),
        .I5(ID_TX_0[19]),
        .O(\serial[0]_i_23_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair207" *) 
  LUT3 #(
    .INIT(8'h56)) 
    \serial[0]_i_24 
       (.I0(\serial[0]_i_12_0 [2]),
        .I1(\serial[0]_i_12_0 [1]),
        .I2(\serial[0]_i_12_0 [0]),
        .O(\serial[0]_i_24_n_0 ));
  LUT6 #(
    .INIT(64'hFCAF0CAFFCA00CA0)) 
    \serial[0]_i_25 
       (.I0(ID_TX_0[20]),
        .I1(ID_TX_0[21]),
        .I2(\serial[0]_i_12_0 [0]),
        .I3(\serial[0]_i_12_0 [1]),
        .I4(ID_TX_0[22]),
        .I5(ID_TX_0[23]),
        .O(\serial[0]_i_25_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair211" *) 
  LUT3 #(
    .INIT(8'hFB)) 
    \serial[0]_i_26 
       (.I0(\serial[0]_i_12_0 [3]),
        .I1(\serial[0]_i_12_0 [4]),
        .I2(\serial[0]_i_12_0 [5]),
        .O(\serial[0]_i_26_n_0 ));
  LUT6 #(
    .INIT(64'hFCAF0CAFFCA00CA0)) 
    \serial[0]_i_27 
       (.I0(ID_TX_0[12]),
        .I1(ID_TX_0[13]),
        .I2(\serial[0]_i_12_0 [0]),
        .I3(\serial[0]_i_12_0 [1]),
        .I4(ID_TX_0[14]),
        .I5(ID_TX_0[15]),
        .O(\serial[0]_i_27_n_0 ));
  LUT6 #(
    .INIT(64'hFCAF0CAFFCA00CA0)) 
    \serial[0]_i_28 
       (.I0(ID_TX_0[8]),
        .I1(ID_TX_0[9]),
        .I2(\serial[0]_i_12_0 [0]),
        .I3(\serial[0]_i_12_0 [1]),
        .I4(ID_TX_0[10]),
        .I5(ID_TX_0[11]),
        .O(\serial[0]_i_28_n_0 ));
  LUT6 #(
    .INIT(64'hFCAF0CAFFCA00CA0)) 
    \serial[0]_i_29 
       (.I0(ID_TX_0[4]),
        .I1(ID_TX_0[5]),
        .I2(\serial[0]_i_12_0 [0]),
        .I3(\serial[0]_i_12_0 [1]),
        .I4(ID_TX_0[6]),
        .I5(ID_TX_0[7]),
        .O(\serial[0]_i_29_n_0 ));
  LUT6 #(
    .INIT(64'h0010111155555555)) 
    \serial[0]_i_3 
       (.I0(Q[3]),
        .I1(Q[2]),
        .I2(\serial[0]_i_4_n_0 ),
        .I3(\serial[0]_i_5_n_0 ),
        .I4(\serial[0]_i_6_n_0 ),
        .I5(\serial[0]_i_7_n_0 ),
        .O(\TXSTATES_reg[3] ));
  LUT6 #(
    .INIT(64'hFCAF0CAFFCA00CA0)) 
    \serial[0]_i_30 
       (.I0(ID_TX_0[0]),
        .I1(ID_TX_0[1]),
        .I2(\serial[0]_i_12_0 [0]),
        .I3(\serial[0]_i_12_0 [1]),
        .I4(ID_TX_0[2]),
        .I5(ID_TX_0[3]),
        .O(\serial[0]_i_30_n_0 ));
  LUT6 #(
    .INIT(64'hFCAF0CAFFCA00CA0)) 
    \serial[0]_i_31 
       (.I0(ID_TX_0[18]),
        .I1(ID_TX_0[19]),
        .I2(\serial[0]_i_12_0 [0]),
        .I3(\serial[0]_i_12_0 [1]),
        .I4(ID_TX_0[16]),
        .I5(ID_TX_0[17]),
        .O(\serial[0]_i_31_n_0 ));
  LUT6 #(
    .INIT(64'hFCAF0CAFFCA00CA0)) 
    \serial[0]_i_32 
       (.I0(ID_TX_0[22]),
        .I1(ID_TX_0[23]),
        .I2(\serial[0]_i_12_0 [0]),
        .I3(\serial[0]_i_12_0 [1]),
        .I4(ID_TX_0[20]),
        .I5(ID_TX_0[21]),
        .O(\serial[0]_i_32_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair206" *) 
  LUT4 #(
    .INIT(16'h556A)) 
    \serial[0]_i_33 
       (.I0(\serial[0]_i_12_0 [3]),
        .I1(\serial[0]_i_12_0 [0]),
        .I2(\serial[0]_i_12_0 [1]),
        .I3(\serial[0]_i_12_0 [2]),
        .O(\serial[0]_i_33_n_0 ));
  LUT6 #(
    .INIT(64'hFCAF0CAFFCA00CA0)) 
    \serial[0]_i_34 
       (.I0(ID_TX_0[26]),
        .I1(ID_TX_0[27]),
        .I2(\serial[0]_i_12_0 [0]),
        .I3(\serial[0]_i_12_0 [1]),
        .I4(ID_TX_0[24]),
        .I5(ID_TX_0[25]),
        .O(\serial[0]_i_34_n_0 ));
  LUT3 #(
    .INIT(8'h6A)) 
    \serial[0]_i_35 
       (.I0(\serial[0]_i_12_0 [2]),
        .I1(\serial[0]_i_12_0 [1]),
        .I2(\serial[0]_i_12_0 [0]),
        .O(\serial[0]_i_35_n_0 ));
  LUT6 #(
    .INIT(64'hFCAF0CAFFCA00CA0)) 
    \serial[0]_i_36 
       (.I0(ID_TX_0[2]),
        .I1(ID_TX_0[3]),
        .I2(\serial[0]_i_12_0 [0]),
        .I3(\serial[0]_i_12_0 [1]),
        .I4(ID_TX_0[0]),
        .I5(ID_TX_0[1]),
        .O(\serial[0]_i_36_n_0 ));
  LUT6 #(
    .INIT(64'hFCAF0CAFFCA00CA0)) 
    \serial[0]_i_37 
       (.I0(ID_TX_0[6]),
        .I1(ID_TX_0[7]),
        .I2(\serial[0]_i_12_0 [0]),
        .I3(\serial[0]_i_12_0 [1]),
        .I4(ID_TX_0[4]),
        .I5(ID_TX_0[5]),
        .O(\serial[0]_i_37_n_0 ));
  LUT6 #(
    .INIT(64'hFCAF0CAFFCA00CA0)) 
    \serial[0]_i_38 
       (.I0(ID_TX_0[10]),
        .I1(ID_TX_0[11]),
        .I2(\serial[0]_i_12_0 [0]),
        .I3(\serial[0]_i_12_0 [1]),
        .I4(ID_TX_0[8]),
        .I5(ID_TX_0[9]),
        .O(\serial[0]_i_38_n_0 ));
  LUT6 #(
    .INIT(64'hFCAF0CAFFCA00CA0)) 
    \serial[0]_i_39 
       (.I0(ID_TX_0[14]),
        .I1(ID_TX_0[15]),
        .I2(\serial[0]_i_12_0 [0]),
        .I3(\serial[0]_i_12_0 [1]),
        .I4(ID_TX_0[12]),
        .I5(ID_TX_0[13]),
        .O(\serial[0]_i_39_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF002300EF)) 
    \serial[0]_i_4 
       (.I0(\Cnt_reg[2] ),
        .I1(\serial[0]_i_8_n_0 ),
        .I2(\serial[0]_i_9_n_0 ),
        .I3(\serial[0]_i_10_n_0 ),
        .I4(\serial[0]_i_11_n_0 ),
        .I5(\serial[0]_i_12_n_0 ),
        .O(\serial[0]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hDFDDDFDFDFDDDDDD)) 
    \serial[0]_i_5 
       (.I0(Q[1]),
        .I1(Q[0]),
        .I2(\serial[0]_i_13_n_0 ),
        .I3(\serial[0]_i_14_n_0 ),
        .I4(\serial[0]_i_15_n_0 ),
        .I5(\serial[0]_i_16_n_0 ),
        .O(\serial[0]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \serial[0]_i_50 
       (.I0(data_TX_0[59]),
        .I1(data_TX_0[58]),
        .I2(\serial[0]_i_12_0 [1]),
        .I3(data_TX_0[57]),
        .I4(\serial[0]_i_12_0 [0]),
        .I5(data_TX_0[56]),
        .O(\serial[0]_i_50_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \serial[0]_i_51 
       (.I0(data_TX_0[63]),
        .I1(data_TX_0[62]),
        .I2(\serial[0]_i_12_0 [1]),
        .I3(data_TX_0[61]),
        .I4(\serial[0]_i_12_0 [0]),
        .I5(data_TX_0[60]),
        .O(\serial[0]_i_51_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \serial[0]_i_52 
       (.I0(data_TX_0[51]),
        .I1(data_TX_0[50]),
        .I2(\serial[0]_i_12_0 [1]),
        .I3(data_TX_0[49]),
        .I4(\serial[0]_i_12_0 [0]),
        .I5(data_TX_0[48]),
        .O(\serial[0]_i_52_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \serial[0]_i_53 
       (.I0(data_TX_0[55]),
        .I1(data_TX_0[54]),
        .I2(\serial[0]_i_12_0 [1]),
        .I3(data_TX_0[53]),
        .I4(\serial[0]_i_12_0 [0]),
        .I5(data_TX_0[52]),
        .O(\serial[0]_i_53_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \serial[0]_i_54 
       (.I0(data_TX_0[43]),
        .I1(data_TX_0[42]),
        .I2(\serial[0]_i_12_0 [1]),
        .I3(data_TX_0[41]),
        .I4(\serial[0]_i_12_0 [0]),
        .I5(data_TX_0[40]),
        .O(\serial[0]_i_54_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \serial[0]_i_55 
       (.I0(data_TX_0[47]),
        .I1(data_TX_0[46]),
        .I2(\serial[0]_i_12_0 [1]),
        .I3(data_TX_0[45]),
        .I4(\serial[0]_i_12_0 [0]),
        .I5(data_TX_0[44]),
        .O(\serial[0]_i_55_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \serial[0]_i_56 
       (.I0(data_TX_0[35]),
        .I1(data_TX_0[34]),
        .I2(\serial[0]_i_12_0 [1]),
        .I3(data_TX_0[33]),
        .I4(\serial[0]_i_12_0 [0]),
        .I5(data_TX_0[32]),
        .O(\serial[0]_i_56_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \serial[0]_i_57 
       (.I0(data_TX_0[39]),
        .I1(data_TX_0[38]),
        .I2(\serial[0]_i_12_0 [1]),
        .I3(data_TX_0[37]),
        .I4(\serial[0]_i_12_0 [0]),
        .I5(data_TX_0[36]),
        .O(\serial[0]_i_57_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \serial[0]_i_58 
       (.I0(data_TX_0[27]),
        .I1(data_TX_0[26]),
        .I2(\serial[0]_i_12_0 [1]),
        .I3(data_TX_0[25]),
        .I4(\serial[0]_i_12_0 [0]),
        .I5(data_TX_0[24]),
        .O(\serial[0]_i_58_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \serial[0]_i_59 
       (.I0(data_TX_0[31]),
        .I1(data_TX_0[30]),
        .I2(\serial[0]_i_12_0 [1]),
        .I3(data_TX_0[29]),
        .I4(\serial[0]_i_12_0 [0]),
        .I5(data_TX_0[28]),
        .O(\serial[0]_i_59_n_0 ));
  LUT6 #(
    .INIT(64'hBF000000FFFFFFFF)) 
    \serial[0]_i_6 
       (.I0(\serial[0]_i_12_0 [1]),
        .I1(\serial[0]_i_12_0 [2]),
        .I2(\serial[0]_i_17_n_0 ),
        .I3(Q[1]),
        .I4(\serial[0]_i_18_n_0 ),
        .I5(Q[0]),
        .O(\serial[0]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \serial[0]_i_60 
       (.I0(data_TX_0[19]),
        .I1(data_TX_0[18]),
        .I2(\serial[0]_i_12_0 [1]),
        .I3(data_TX_0[17]),
        .I4(\serial[0]_i_12_0 [0]),
        .I5(data_TX_0[16]),
        .O(\serial[0]_i_60_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \serial[0]_i_61 
       (.I0(data_TX_0[23]),
        .I1(data_TX_0[22]),
        .I2(\serial[0]_i_12_0 [1]),
        .I3(data_TX_0[21]),
        .I4(\serial[0]_i_12_0 [0]),
        .I5(data_TX_0[20]),
        .O(\serial[0]_i_61_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \serial[0]_i_62 
       (.I0(data_TX_0[11]),
        .I1(data_TX_0[10]),
        .I2(\serial[0]_i_12_0 [1]),
        .I3(data_TX_0[9]),
        .I4(\serial[0]_i_12_0 [0]),
        .I5(data_TX_0[8]),
        .O(\serial[0]_i_62_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \serial[0]_i_63 
       (.I0(data_TX_0[15]),
        .I1(data_TX_0[14]),
        .I2(\serial[0]_i_12_0 [1]),
        .I3(data_TX_0[13]),
        .I4(\serial[0]_i_12_0 [0]),
        .I5(data_TX_0[12]),
        .O(\serial[0]_i_63_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \serial[0]_i_64 
       (.I0(data_TX_0[3]),
        .I1(data_TX_0[2]),
        .I2(\serial[0]_i_12_0 [1]),
        .I3(data_TX_0[1]),
        .I4(\serial[0]_i_12_0 [0]),
        .I5(data_TX_0[0]),
        .O(\serial[0]_i_64_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \serial[0]_i_65 
       (.I0(data_TX_0[7]),
        .I1(data_TX_0[6]),
        .I2(\serial[0]_i_12_0 [1]),
        .I3(data_TX_0[5]),
        .I4(\serial[0]_i_12_0 [0]),
        .I5(data_TX_0[4]),
        .O(\serial[0]_i_65_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \serial[0]_i_66 
       (.I0(\CRC_RG_reg_n_0_[11] ),
        .I1(\CRC_RG_reg_n_0_[10] ),
        .I2(\serial[0]_i_12_0 [1]),
        .I3(\CRC_RG_reg_n_0_[9] ),
        .I4(\serial[0]_i_12_0 [0]),
        .I5(\CRC_RG_reg_n_0_[8] ),
        .O(\serial[0]_i_66_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \serial[0]_i_67 
       (.I0(out_CRC),
        .I1(\serial[0]_i_12_0 [1]),
        .I2(\CRC_RG_reg_n_0_[13] ),
        .I3(\serial[0]_i_12_0 [0]),
        .I4(\CRC_RG_reg_n_0_[12] ),
        .O(\serial[0]_i_67_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \serial[0]_i_68 
       (.I0(\CRC_RG_reg_n_0_[3] ),
        .I1(\CRC_RG_reg_n_0_[2] ),
        .I2(\serial[0]_i_12_0 [1]),
        .I3(\CRC_RG_reg_n_0_[1] ),
        .I4(\serial[0]_i_12_0 [0]),
        .I5(\CRC_RG_reg_n_0_[0] ),
        .O(\serial[0]_i_68_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \serial[0]_i_69 
       (.I0(\CRC_RG_reg_n_0_[7] ),
        .I1(\CRC_RG_reg_n_0_[6] ),
        .I2(\serial[0]_i_12_0 [1]),
        .I3(\CRC_RG_reg_n_0_[5] ),
        .I4(\serial[0]_i_12_0 [0]),
        .I5(\CRC_RG_reg_n_0_[4] ),
        .O(\serial[0]_i_69_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF0000B800)) 
    \serial[0]_i_7 
       (.I0(\serial[0]_i_19_n_0 ),
        .I1(\serial[0]_i_12_0 [5]),
        .I2(\serial[0]_i_20_n_0 ),
        .I3(Q[2]),
        .I4(\TXSTATES_reg[0] ),
        .I5(\serial[0]_i_21_n_0 ),
        .O(\serial[0]_i_7_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair205" *) 
  LUT5 #(
    .INIT(32'h55555556)) 
    \serial[0]_i_8 
       (.I0(\serial[0]_i_12_0 [4]),
        .I1(\serial[0]_i_12_0 [1]),
        .I2(\serial[0]_i_12_0 [0]),
        .I3(\serial[0]_i_12_0 [2]),
        .I4(\serial[0]_i_12_0 [3]),
        .O(\serial[0]_i_8_n_0 ));
  LUT6 #(
    .INIT(64'hCFC0AFAFCFC0A0A0)) 
    \serial[0]_i_9 
       (.I0(ID_TX_0[28]),
        .I1(\serial[0]_i_22_n_0 ),
        .I2(\Cnt_reg[3] ),
        .I3(\serial[0]_i_23_n_0 ),
        .I4(\serial[0]_i_24_n_0 ),
        .I5(\serial[0]_i_25_n_0 ),
        .O(\serial[0]_i_9_n_0 ));
  MUXF7 \serial_reg[0]_i_40 
       (.I0(\serial[0]_i_50_n_0 ),
        .I1(\serial[0]_i_51_n_0 ),
        .O(\serial_reg[0]_i_40_n_0 ),
        .S(\serial[0]_i_12_0 [2]));
  MUXF7 \serial_reg[0]_i_41 
       (.I0(\serial[0]_i_52_n_0 ),
        .I1(\serial[0]_i_53_n_0 ),
        .O(\serial_reg[0]_i_41_n_0 ),
        .S(\serial[0]_i_12_0 [2]));
  MUXF7 \serial_reg[0]_i_42 
       (.I0(\serial[0]_i_54_n_0 ),
        .I1(\serial[0]_i_55_n_0 ),
        .O(\serial_reg[0]_i_42_n_0 ),
        .S(\serial[0]_i_12_0 [2]));
  MUXF7 \serial_reg[0]_i_43 
       (.I0(\serial[0]_i_56_n_0 ),
        .I1(\serial[0]_i_57_n_0 ),
        .O(\serial_reg[0]_i_43_n_0 ),
        .S(\serial[0]_i_12_0 [2]));
  MUXF7 \serial_reg[0]_i_44 
       (.I0(\serial[0]_i_58_n_0 ),
        .I1(\serial[0]_i_59_n_0 ),
        .O(\serial_reg[0]_i_44_n_0 ),
        .S(\serial[0]_i_12_0 [2]));
  MUXF7 \serial_reg[0]_i_45 
       (.I0(\serial[0]_i_60_n_0 ),
        .I1(\serial[0]_i_61_n_0 ),
        .O(\serial_reg[0]_i_45_n_0 ),
        .S(\serial[0]_i_12_0 [2]));
  MUXF7 \serial_reg[0]_i_46 
       (.I0(\serial[0]_i_62_n_0 ),
        .I1(\serial[0]_i_63_n_0 ),
        .O(\serial_reg[0]_i_46_n_0 ),
        .S(\serial[0]_i_12_0 [2]));
  MUXF7 \serial_reg[0]_i_47 
       (.I0(\serial[0]_i_64_n_0 ),
        .I1(\serial[0]_i_65_n_0 ),
        .O(\serial_reg[0]_i_47_n_0 ),
        .S(\serial[0]_i_12_0 [2]));
  MUXF7 \serial_reg[0]_i_48 
       (.I0(\serial[0]_i_66_n_0 ),
        .I1(\serial[0]_i_67_n_0 ),
        .O(\serial_reg[0]_i_48_n_0 ),
        .S(\serial[0]_i_12_0 [2]));
  MUXF7 \serial_reg[0]_i_49 
       (.I0(\serial[0]_i_68_n_0 ),
        .I1(\serial[0]_i_69_n_0 ),
        .O(\serial_reg[0]_i_49_n_0 ),
        .S(\serial[0]_i_12_0 [2]));
endmodule

(* ORIG_REF_NAME = "CRC" *) 
module design_1_FPGAPROJECT_0_0_CRC_0
   (SRST_0_0,
    \bs_reg[1] ,
    CAN_RST_0,
    Q,
    SRST_0,
    \CRC_RG_reg[3]_0 ,
    \CRC_RG_reg[14]_0 ,
    req_Error_reg,
    req_Error_reg_0,
    req_Error_reg_1,
    req_Error_reg_2,
    req_Error_reg_3,
    req_Error_reg_4,
    req_Error_reg_5,
    req_Error_reg_6,
    CAN_RST,
    clk);
  output SRST_0_0;
  output \bs_reg[1] ;
  output CAN_RST_0;
  input [3:0]Q;
  input SRST_0;
  input \CRC_RG_reg[3]_0 ;
  input \CRC_RG_reg[14]_0 ;
  input req_Error_reg;
  input req_Error_reg_0;
  input [0:0]req_Error_reg_1;
  input req_Error_reg_2;
  input req_Error_reg_3;
  input [5:0]req_Error_reg_4;
  input req_Error_reg_5;
  input req_Error_reg_6;
  input CAN_RST;
  input clk;

  wire CAN_RST;
  wire CAN_RST_0;
  wire \CRC_RG[0]_i_1__0_n_0 ;
  wire \CRC_RG[10]_i_1__0_n_0 ;
  wire \CRC_RG[14]_i_1__0_n_0 ;
  wire \CRC_RG[14]_i_2__0_n_0 ;
  wire \CRC_RG[14]_i_3__0_n_0 ;
  wire \CRC_RG[14]_i_4__0_n_0 ;
  wire \CRC_RG[3]_i_1__0_n_0 ;
  wire \CRC_RG[4]_i_1__0_n_0 ;
  wire \CRC_RG[7]_i_1__0_n_0 ;
  wire \CRC_RG[8]_i_1__0_n_0 ;
  wire \CRC_RG_reg[14]_0 ;
  wire \CRC_RG_reg[3]_0 ;
  wire [3:0]Q;
  wire \RXSTATES[3]_i_5_n_0 ;
  wire SRST_0;
  wire SRST_0_0;
  wire \bs_reg[1] ;
  wire clk;
  wire [14:0]out_CRC;
  wire [13:1]p_1_in__0;
  wire req_Error_i_10_n_0;
  wire req_Error_i_11_n_0;
  wire req_Error_i_3_n_0;
  wire req_Error_i_7_n_0;
  wire req_Error_i_9_n_0;
  wire req_Error_reg;
  wire req_Error_reg_0;
  wire [0:0]req_Error_reg_1;
  wire req_Error_reg_2;
  wire req_Error_reg_3;
  wire [5:0]req_Error_reg_4;
  wire req_Error_reg_5;
  wire req_Error_reg_6;

  LUT6 #(
    .INIT(64'hAAAA22A800000000)) 
    \CRC_RG[0]_i_1__0 
       (.I0(\CRC_RG[14]_i_3__0_n_0 ),
        .I1(Q[0]),
        .I2(Q[1]),
        .I3(Q[3]),
        .I4(Q[2]),
        .I5(SRST_0),
        .O(\CRC_RG[0]_i_1__0_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair172" *) 
  LUT3 #(
    .INIT(8'h60)) 
    \CRC_RG[10]_i_1__0 
       (.I0(\CRC_RG[14]_i_3__0_n_0 ),
        .I1(out_CRC[9]),
        .I2(\CRC_RG[14]_i_4__0_n_0 ),
        .O(\CRC_RG[10]_i_1__0_n_0 ));
  LUT6 #(
    .INIT(64'hAAAA22A800000000)) 
    \CRC_RG[11]_i_1__0 
       (.I0(out_CRC[10]),
        .I1(Q[0]),
        .I2(Q[1]),
        .I3(Q[3]),
        .I4(Q[2]),
        .I5(SRST_0),
        .O(p_1_in__0[11]));
  LUT6 #(
    .INIT(64'hAAAA22A800000000)) 
    \CRC_RG[12]_i_1__0 
       (.I0(out_CRC[11]),
        .I1(Q[0]),
        .I2(Q[1]),
        .I3(Q[3]),
        .I4(Q[2]),
        .I5(SRST_0),
        .O(p_1_in__0[12]));
  LUT6 #(
    .INIT(64'hAAAA22A800000000)) 
    \CRC_RG[13]_i_1__0 
       (.I0(out_CRC[12]),
        .I1(Q[0]),
        .I2(Q[1]),
        .I3(Q[3]),
        .I4(Q[2]),
        .I5(SRST_0),
        .O(p_1_in__0[13]));
  LUT6 #(
    .INIT(64'h000ACCABFFFFFFFF)) 
    \CRC_RG[14]_i_1__0 
       (.I0(\CRC_RG_reg[14]_0 ),
        .I1(Q[0]),
        .I2(Q[1]),
        .I3(Q[3]),
        .I4(Q[2]),
        .I5(SRST_0),
        .O(\CRC_RG[14]_i_1__0_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair172" *) 
  LUT3 #(
    .INIT(8'h60)) 
    \CRC_RG[14]_i_2__0 
       (.I0(\CRC_RG[14]_i_3__0_n_0 ),
        .I1(out_CRC[13]),
        .I2(\CRC_RG[14]_i_4__0_n_0 ),
        .O(\CRC_RG[14]_i_2__0_n_0 ));
  LUT2 #(
    .INIT(4'h9)) 
    \CRC_RG[14]_i_3__0 
       (.I0(out_CRC[14]),
        .I1(\CRC_RG_reg[3]_0 ),
        .O(\CRC_RG[14]_i_3__0_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair171" *) 
  LUT5 #(
    .INIT(32'h8A8AAAA8)) 
    \CRC_RG[14]_i_4__0 
       (.I0(SRST_0),
        .I1(Q[2]),
        .I2(Q[3]),
        .I3(Q[1]),
        .I4(Q[0]),
        .O(\CRC_RG[14]_i_4__0_n_0 ));
  LUT6 #(
    .INIT(64'hAAAA22A800000000)) 
    \CRC_RG[1]_i_1__0 
       (.I0(out_CRC[0]),
        .I1(Q[0]),
        .I2(Q[1]),
        .I3(Q[3]),
        .I4(Q[2]),
        .I5(SRST_0),
        .O(p_1_in__0[1]));
  LUT6 #(
    .INIT(64'hAAAA22A800000000)) 
    \CRC_RG[2]_i_1__0 
       (.I0(out_CRC[1]),
        .I1(Q[0]),
        .I2(Q[1]),
        .I3(Q[3]),
        .I4(Q[2]),
        .I5(SRST_0),
        .O(p_1_in__0[2]));
  (* SOFT_HLUTNM = "soft_lutpair174" *) 
  LUT3 #(
    .INIT(8'h60)) 
    \CRC_RG[3]_i_1__0 
       (.I0(\CRC_RG[14]_i_3__0_n_0 ),
        .I1(out_CRC[2]),
        .I2(\CRC_RG[14]_i_4__0_n_0 ),
        .O(\CRC_RG[3]_i_1__0_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair174" *) 
  LUT3 #(
    .INIT(8'h60)) 
    \CRC_RG[4]_i_1__0 
       (.I0(\CRC_RG[14]_i_3__0_n_0 ),
        .I1(out_CRC[3]),
        .I2(\CRC_RG[14]_i_4__0_n_0 ),
        .O(\CRC_RG[4]_i_1__0_n_0 ));
  LUT6 #(
    .INIT(64'hAAAA22A800000000)) 
    \CRC_RG[5]_i_1__0 
       (.I0(out_CRC[4]),
        .I1(Q[0]),
        .I2(Q[1]),
        .I3(Q[3]),
        .I4(Q[2]),
        .I5(SRST_0),
        .O(p_1_in__0[5]));
  LUT6 #(
    .INIT(64'hAAAA22A800000000)) 
    \CRC_RG[6]_i_1__0 
       (.I0(out_CRC[5]),
        .I1(Q[0]),
        .I2(Q[1]),
        .I3(Q[3]),
        .I4(Q[2]),
        .I5(SRST_0),
        .O(p_1_in__0[6]));
  (* SOFT_HLUTNM = "soft_lutpair173" *) 
  LUT3 #(
    .INIT(8'h60)) 
    \CRC_RG[7]_i_1__0 
       (.I0(\CRC_RG[14]_i_3__0_n_0 ),
        .I1(out_CRC[6]),
        .I2(\CRC_RG[14]_i_4__0_n_0 ),
        .O(\CRC_RG[7]_i_1__0_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair173" *) 
  LUT3 #(
    .INIT(8'h60)) 
    \CRC_RG[8]_i_1__0 
       (.I0(\CRC_RG[14]_i_3__0_n_0 ),
        .I1(out_CRC[7]),
        .I2(\CRC_RG[14]_i_4__0_n_0 ),
        .O(\CRC_RG[8]_i_1__0_n_0 ));
  LUT6 #(
    .INIT(64'hAAAA22A800000000)) 
    \CRC_RG[9]_i_1__0 
       (.I0(out_CRC[8]),
        .I1(Q[0]),
        .I2(Q[1]),
        .I3(Q[3]),
        .I4(Q[2]),
        .I5(SRST_0),
        .O(p_1_in__0[9]));
  FDCE \CRC_RG_reg[0] 
       (.C(clk),
        .CE(\CRC_RG[14]_i_1__0_n_0 ),
        .CLR(CAN_RST_0),
        .D(\CRC_RG[0]_i_1__0_n_0 ),
        .Q(out_CRC[0]));
  FDCE \CRC_RG_reg[10] 
       (.C(clk),
        .CE(\CRC_RG[14]_i_1__0_n_0 ),
        .CLR(CAN_RST_0),
        .D(\CRC_RG[10]_i_1__0_n_0 ),
        .Q(out_CRC[10]));
  FDCE \CRC_RG_reg[11] 
       (.C(clk),
        .CE(\CRC_RG[14]_i_1__0_n_0 ),
        .CLR(CAN_RST_0),
        .D(p_1_in__0[11]),
        .Q(out_CRC[11]));
  FDCE \CRC_RG_reg[12] 
       (.C(clk),
        .CE(\CRC_RG[14]_i_1__0_n_0 ),
        .CLR(CAN_RST_0),
        .D(p_1_in__0[12]),
        .Q(out_CRC[12]));
  FDCE \CRC_RG_reg[13] 
       (.C(clk),
        .CE(\CRC_RG[14]_i_1__0_n_0 ),
        .CLR(CAN_RST_0),
        .D(p_1_in__0[13]),
        .Q(out_CRC[13]));
  FDCE \CRC_RG_reg[14] 
       (.C(clk),
        .CE(\CRC_RG[14]_i_1__0_n_0 ),
        .CLR(CAN_RST_0),
        .D(\CRC_RG[14]_i_2__0_n_0 ),
        .Q(out_CRC[14]));
  FDCE \CRC_RG_reg[1] 
       (.C(clk),
        .CE(\CRC_RG[14]_i_1__0_n_0 ),
        .CLR(CAN_RST_0),
        .D(p_1_in__0[1]),
        .Q(out_CRC[1]));
  FDCE \CRC_RG_reg[2] 
       (.C(clk),
        .CE(\CRC_RG[14]_i_1__0_n_0 ),
        .CLR(CAN_RST_0),
        .D(p_1_in__0[2]),
        .Q(out_CRC[2]));
  FDCE \CRC_RG_reg[3] 
       (.C(clk),
        .CE(\CRC_RG[14]_i_1__0_n_0 ),
        .CLR(CAN_RST_0),
        .D(\CRC_RG[3]_i_1__0_n_0 ),
        .Q(out_CRC[3]));
  FDCE \CRC_RG_reg[4] 
       (.C(clk),
        .CE(\CRC_RG[14]_i_1__0_n_0 ),
        .CLR(CAN_RST_0),
        .D(\CRC_RG[4]_i_1__0_n_0 ),
        .Q(out_CRC[4]));
  FDCE \CRC_RG_reg[5] 
       (.C(clk),
        .CE(\CRC_RG[14]_i_1__0_n_0 ),
        .CLR(CAN_RST_0),
        .D(p_1_in__0[5]),
        .Q(out_CRC[5]));
  FDCE \CRC_RG_reg[6] 
       (.C(clk),
        .CE(\CRC_RG[14]_i_1__0_n_0 ),
        .CLR(CAN_RST_0),
        .D(p_1_in__0[6]),
        .Q(out_CRC[6]));
  FDCE \CRC_RG_reg[7] 
       (.C(clk),
        .CE(\CRC_RG[14]_i_1__0_n_0 ),
        .CLR(CAN_RST_0),
        .D(\CRC_RG[7]_i_1__0_n_0 ),
        .Q(out_CRC[7]));
  FDCE \CRC_RG_reg[8] 
       (.C(clk),
        .CE(\CRC_RG[14]_i_1__0_n_0 ),
        .CLR(CAN_RST_0),
        .D(\CRC_RG[8]_i_1__0_n_0 ),
        .Q(out_CRC[8]));
  FDCE \CRC_RG_reg[9] 
       (.C(clk),
        .CE(\CRC_RG[14]_i_1__0_n_0 ),
        .CLR(CAN_RST_0),
        .D(p_1_in__0[9]),
        .Q(out_CRC[9]));
  LUT6 #(
    .INIT(64'h4000000000000001)) 
    \RXSTATES[3]_i_4 
       (.I0(\RXSTATES[3]_i_5_n_0 ),
        .I1(req_Error_reg_4[1]),
        .I2(req_Error_reg_4[0]),
        .I3(req_Error_reg_4[3]),
        .I4(req_Error_reg_4[4]),
        .I5(req_Error_reg_4[2]),
        .O(\bs_reg[1] ));
  (* SOFT_HLUTNM = "soft_lutpair171" *) 
  LUT4 #(
    .INIT(16'hFCF1)) 
    \RXSTATES[3]_i_5 
       (.I0(Q[0]),
        .I1(Q[1]),
        .I2(Q[3]),
        .I3(Q[2]),
        .O(\RXSTATES[3]_i_5_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    done_i_2
       (.I0(CAN_RST),
        .O(CAN_RST_0));
  LUT6 #(
    .INIT(64'h0FFF0F0F0E000E0E)) 
    req_Error_i_1
       (.I0(req_Error_reg),
        .I1(req_Error_i_3_n_0),
        .I2(req_Error_reg_0),
        .I3(req_Error_reg_1),
        .I4(SRST_0),
        .I5(req_Error_reg_2),
        .O(SRST_0_0));
  LUT4 #(
    .INIT(16'h0001)) 
    req_Error_i_10
       (.I0(out_CRC[11]),
        .I1(out_CRC[0]),
        .I2(out_CRC[5]),
        .I3(out_CRC[2]),
        .O(req_Error_i_10_n_0));
  LUT4 #(
    .INIT(16'hFFFE)) 
    req_Error_i_11
       (.I0(out_CRC[10]),
        .I1(out_CRC[6]),
        .I2(out_CRC[13]),
        .I3(out_CRC[1]),
        .O(req_Error_i_11_n_0));
  LUT6 #(
    .INIT(64'h5404FFFF54045404)) 
    req_Error_i_3
       (.I0(\RXSTATES[3]_i_5_n_0 ),
        .I1(req_Error_reg_3),
        .I2(req_Error_reg_4[5]),
        .I3(req_Error_reg_5),
        .I4(req_Error_i_7_n_0),
        .I5(req_Error_reg_6),
        .O(req_Error_i_3_n_0));
  LUT6 #(
    .INIT(64'h0000000000000004)) 
    req_Error_i_7
       (.I0(req_Error_i_9_n_0),
        .I1(req_Error_i_10_n_0),
        .I2(req_Error_i_11_n_0),
        .I3(out_CRC[14]),
        .I4(out_CRC[7]),
        .I5(out_CRC[4]),
        .O(req_Error_i_7_n_0));
  LUT4 #(
    .INIT(16'hFFFE)) 
    req_Error_i_9
       (.I0(out_CRC[12]),
        .I1(out_CRC[8]),
        .I2(out_CRC[9]),
        .I3(out_CRC[3]),
        .O(req_Error_i_9_n_0));
endmodule

(* ORIG_REF_NAME = "CRC" *) 
module design_1_FPGAPROJECT_0_0_CRC_10
   (CAN_RST_0,
    SRST_1,
    \bs_reg[1] ,
    CAN_RST,
    Q,
    SRST,
    req_Error_reg,
    req_Error_reg_0,
    req_Error_reg_1,
    req_Error_reg_2,
    req_Error_reg_3,
    req_Error_reg_4,
    req_Error_reg_5,
    req_Error_reg_6,
    \CRC_RG_reg[3]_0 ,
    \CRC_RG_reg[14]_0 ,
    Tq);
  output CAN_RST_0;
  output SRST_1;
  output \bs_reg[1] ;
  input CAN_RST;
  input [3:0]Q;
  input SRST;
  input req_Error_reg;
  input [5:0]req_Error_reg_0;
  input req_Error_reg_1;
  input req_Error_reg_2;
  input req_Error_reg_3;
  input req_Error_reg_4;
  input [0:0]req_Error_reg_5;
  input req_Error_reg_6;
  input \CRC_RG_reg[3]_0 ;
  input \CRC_RG_reg[14]_0 ;
  input Tq;

  wire CAN_RST;
  wire CAN_RST_0;
  wire \CRC_RG[0]_i_1__0_n_0 ;
  wire \CRC_RG[10]_i_1__0_n_0 ;
  wire \CRC_RG[14]_i_1__0_n_0 ;
  wire \CRC_RG[14]_i_2__0_n_0 ;
  wire \CRC_RG[14]_i_3__0_n_0 ;
  wire \CRC_RG[14]_i_4__0_n_0 ;
  wire \CRC_RG[3]_i_1__0_n_0 ;
  wire \CRC_RG[4]_i_1__0_n_0 ;
  wire \CRC_RG[7]_i_1__0_n_0 ;
  wire \CRC_RG[8]_i_1__0_n_0 ;
  wire \CRC_RG_reg[14]_0 ;
  wire \CRC_RG_reg[3]_0 ;
  wire [3:0]Q;
  wire \RXSTATES[3]_i_5_n_0 ;
  wire SRST;
  wire SRST_1;
  wire Tq;
  wire \bs_reg[1] ;
  wire [14:0]out_CRC;
  wire [13:1]p_1_in__0;
  wire req_Error_i_10_n_0;
  wire req_Error_i_11_n_0;
  wire req_Error_i_3_n_0;
  wire req_Error_i_7_n_0;
  wire req_Error_i_9_n_0;
  wire req_Error_reg;
  wire [5:0]req_Error_reg_0;
  wire req_Error_reg_1;
  wire req_Error_reg_2;
  wire req_Error_reg_3;
  wire req_Error_reg_4;
  wire [0:0]req_Error_reg_5;
  wire req_Error_reg_6;

  LUT6 #(
    .INIT(64'hAAAA22A800000000)) 
    \CRC_RG[0]_i_1__0 
       (.I0(\CRC_RG[14]_i_3__0_n_0 ),
        .I1(Q[0]),
        .I2(Q[1]),
        .I3(Q[3]),
        .I4(Q[2]),
        .I5(SRST),
        .O(\CRC_RG[0]_i_1__0_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair68" *) 
  LUT3 #(
    .INIT(8'h60)) 
    \CRC_RG[10]_i_1__0 
       (.I0(\CRC_RG[14]_i_3__0_n_0 ),
        .I1(out_CRC[9]),
        .I2(\CRC_RG[14]_i_4__0_n_0 ),
        .O(\CRC_RG[10]_i_1__0_n_0 ));
  LUT6 #(
    .INIT(64'hAAAA22A800000000)) 
    \CRC_RG[11]_i_1__0 
       (.I0(out_CRC[10]),
        .I1(Q[0]),
        .I2(Q[1]),
        .I3(Q[3]),
        .I4(Q[2]),
        .I5(SRST),
        .O(p_1_in__0[11]));
  LUT6 #(
    .INIT(64'hAAAA22A800000000)) 
    \CRC_RG[12]_i_1__0 
       (.I0(out_CRC[11]),
        .I1(Q[0]),
        .I2(Q[1]),
        .I3(Q[3]),
        .I4(Q[2]),
        .I5(SRST),
        .O(p_1_in__0[12]));
  LUT6 #(
    .INIT(64'hAAAA22A800000000)) 
    \CRC_RG[13]_i_1__0 
       (.I0(out_CRC[12]),
        .I1(Q[0]),
        .I2(Q[1]),
        .I3(Q[3]),
        .I4(Q[2]),
        .I5(SRST),
        .O(p_1_in__0[13]));
  LUT6 #(
    .INIT(64'h000ACCABFFFFFFFF)) 
    \CRC_RG[14]_i_1__0 
       (.I0(\CRC_RG_reg[14]_0 ),
        .I1(Q[0]),
        .I2(Q[1]),
        .I3(Q[3]),
        .I4(Q[2]),
        .I5(SRST),
        .O(\CRC_RG[14]_i_1__0_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair68" *) 
  LUT3 #(
    .INIT(8'h60)) 
    \CRC_RG[14]_i_2__0 
       (.I0(\CRC_RG[14]_i_3__0_n_0 ),
        .I1(out_CRC[13]),
        .I2(\CRC_RG[14]_i_4__0_n_0 ),
        .O(\CRC_RG[14]_i_2__0_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair67" *) 
  LUT2 #(
    .INIT(4'h9)) 
    \CRC_RG[14]_i_3__0 
       (.I0(out_CRC[14]),
        .I1(\CRC_RG_reg[3]_0 ),
        .O(\CRC_RG[14]_i_3__0_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair66" *) 
  LUT5 #(
    .INIT(32'h8A8AAAA8)) 
    \CRC_RG[14]_i_4__0 
       (.I0(SRST),
        .I1(Q[2]),
        .I2(Q[3]),
        .I3(Q[1]),
        .I4(Q[0]),
        .O(\CRC_RG[14]_i_4__0_n_0 ));
  LUT6 #(
    .INIT(64'hAAAA22A800000000)) 
    \CRC_RG[1]_i_1__0 
       (.I0(out_CRC[0]),
        .I1(Q[0]),
        .I2(Q[1]),
        .I3(Q[3]),
        .I4(Q[2]),
        .I5(SRST),
        .O(p_1_in__0[1]));
  LUT6 #(
    .INIT(64'hAAAA22A800000000)) 
    \CRC_RG[2]_i_1__0 
       (.I0(out_CRC[1]),
        .I1(Q[0]),
        .I2(Q[1]),
        .I3(Q[3]),
        .I4(Q[2]),
        .I5(SRST),
        .O(p_1_in__0[2]));
  (* SOFT_HLUTNM = "soft_lutpair70" *) 
  LUT3 #(
    .INIT(8'h60)) 
    \CRC_RG[3]_i_1__0 
       (.I0(\CRC_RG[14]_i_3__0_n_0 ),
        .I1(out_CRC[2]),
        .I2(\CRC_RG[14]_i_4__0_n_0 ),
        .O(\CRC_RG[3]_i_1__0_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair70" *) 
  LUT3 #(
    .INIT(8'h60)) 
    \CRC_RG[4]_i_1__0 
       (.I0(\CRC_RG[14]_i_3__0_n_0 ),
        .I1(out_CRC[3]),
        .I2(\CRC_RG[14]_i_4__0_n_0 ),
        .O(\CRC_RG[4]_i_1__0_n_0 ));
  LUT6 #(
    .INIT(64'hAAAA22A800000000)) 
    \CRC_RG[5]_i_1__0 
       (.I0(out_CRC[4]),
        .I1(Q[0]),
        .I2(Q[1]),
        .I3(Q[3]),
        .I4(Q[2]),
        .I5(SRST),
        .O(p_1_in__0[5]));
  LUT6 #(
    .INIT(64'hAAAA22A800000000)) 
    \CRC_RG[6]_i_1__0 
       (.I0(out_CRC[5]),
        .I1(Q[0]),
        .I2(Q[1]),
        .I3(Q[3]),
        .I4(Q[2]),
        .I5(SRST),
        .O(p_1_in__0[6]));
  (* SOFT_HLUTNM = "soft_lutpair69" *) 
  LUT3 #(
    .INIT(8'h60)) 
    \CRC_RG[7]_i_1__0 
       (.I0(\CRC_RG[14]_i_3__0_n_0 ),
        .I1(out_CRC[6]),
        .I2(\CRC_RG[14]_i_4__0_n_0 ),
        .O(\CRC_RG[7]_i_1__0_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair69" *) 
  LUT3 #(
    .INIT(8'h60)) 
    \CRC_RG[8]_i_1__0 
       (.I0(\CRC_RG[14]_i_3__0_n_0 ),
        .I1(out_CRC[7]),
        .I2(\CRC_RG[14]_i_4__0_n_0 ),
        .O(\CRC_RG[8]_i_1__0_n_0 ));
  LUT6 #(
    .INIT(64'hAAAA22A800000000)) 
    \CRC_RG[9]_i_1__0 
       (.I0(out_CRC[8]),
        .I1(Q[0]),
        .I2(Q[1]),
        .I3(Q[3]),
        .I4(Q[2]),
        .I5(SRST),
        .O(p_1_in__0[9]));
  FDCE \CRC_RG_reg[0] 
       (.C(Tq),
        .CE(\CRC_RG[14]_i_1__0_n_0 ),
        .CLR(CAN_RST_0),
        .D(\CRC_RG[0]_i_1__0_n_0 ),
        .Q(out_CRC[0]));
  FDCE \CRC_RG_reg[10] 
       (.C(Tq),
        .CE(\CRC_RG[14]_i_1__0_n_0 ),
        .CLR(CAN_RST_0),
        .D(\CRC_RG[10]_i_1__0_n_0 ),
        .Q(out_CRC[10]));
  FDCE \CRC_RG_reg[11] 
       (.C(Tq),
        .CE(\CRC_RG[14]_i_1__0_n_0 ),
        .CLR(CAN_RST_0),
        .D(p_1_in__0[11]),
        .Q(out_CRC[11]));
  FDCE \CRC_RG_reg[12] 
       (.C(Tq),
        .CE(\CRC_RG[14]_i_1__0_n_0 ),
        .CLR(CAN_RST_0),
        .D(p_1_in__0[12]),
        .Q(out_CRC[12]));
  FDCE \CRC_RG_reg[13] 
       (.C(Tq),
        .CE(\CRC_RG[14]_i_1__0_n_0 ),
        .CLR(CAN_RST_0),
        .D(p_1_in__0[13]),
        .Q(out_CRC[13]));
  FDCE \CRC_RG_reg[14] 
       (.C(Tq),
        .CE(\CRC_RG[14]_i_1__0_n_0 ),
        .CLR(CAN_RST_0),
        .D(\CRC_RG[14]_i_2__0_n_0 ),
        .Q(out_CRC[14]));
  FDCE \CRC_RG_reg[1] 
       (.C(Tq),
        .CE(\CRC_RG[14]_i_1__0_n_0 ),
        .CLR(CAN_RST_0),
        .D(p_1_in__0[1]),
        .Q(out_CRC[1]));
  FDCE \CRC_RG_reg[2] 
       (.C(Tq),
        .CE(\CRC_RG[14]_i_1__0_n_0 ),
        .CLR(CAN_RST_0),
        .D(p_1_in__0[2]),
        .Q(out_CRC[2]));
  FDCE \CRC_RG_reg[3] 
       (.C(Tq),
        .CE(\CRC_RG[14]_i_1__0_n_0 ),
        .CLR(CAN_RST_0),
        .D(\CRC_RG[3]_i_1__0_n_0 ),
        .Q(out_CRC[3]));
  FDCE \CRC_RG_reg[4] 
       (.C(Tq),
        .CE(\CRC_RG[14]_i_1__0_n_0 ),
        .CLR(CAN_RST_0),
        .D(\CRC_RG[4]_i_1__0_n_0 ),
        .Q(out_CRC[4]));
  FDCE \CRC_RG_reg[5] 
       (.C(Tq),
        .CE(\CRC_RG[14]_i_1__0_n_0 ),
        .CLR(CAN_RST_0),
        .D(p_1_in__0[5]),
        .Q(out_CRC[5]));
  FDCE \CRC_RG_reg[6] 
       (.C(Tq),
        .CE(\CRC_RG[14]_i_1__0_n_0 ),
        .CLR(CAN_RST_0),
        .D(p_1_in__0[6]),
        .Q(out_CRC[6]));
  FDCE \CRC_RG_reg[7] 
       (.C(Tq),
        .CE(\CRC_RG[14]_i_1__0_n_0 ),
        .CLR(CAN_RST_0),
        .D(\CRC_RG[7]_i_1__0_n_0 ),
        .Q(out_CRC[7]));
  FDCE \CRC_RG_reg[8] 
       (.C(Tq),
        .CE(\CRC_RG[14]_i_1__0_n_0 ),
        .CLR(CAN_RST_0),
        .D(\CRC_RG[8]_i_1__0_n_0 ),
        .Q(out_CRC[8]));
  FDCE \CRC_RG_reg[9] 
       (.C(Tq),
        .CE(\CRC_RG[14]_i_1__0_n_0 ),
        .CLR(CAN_RST_0),
        .D(p_1_in__0[9]),
        .Q(out_CRC[9]));
  LUT6 #(
    .INIT(64'h8000000000000002)) 
    \RXSTATES[3]_i_4 
       (.I0(\RXSTATES[3]_i_5_n_0 ),
        .I1(req_Error_reg_0[1]),
        .I2(req_Error_reg_0[0]),
        .I3(req_Error_reg_0[3]),
        .I4(req_Error_reg_0[4]),
        .I5(req_Error_reg_0[2]),
        .O(\bs_reg[1] ));
  (* SOFT_HLUTNM = "soft_lutpair66" *) 
  LUT4 #(
    .INIT(16'h003E)) 
    \RXSTATES[3]_i_5 
       (.I0(Q[0]),
        .I1(Q[2]),
        .I2(Q[1]),
        .I3(Q[3]),
        .O(\RXSTATES[3]_i_5_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    done_i_2
       (.I0(CAN_RST),
        .O(CAN_RST_0));
  LUT6 #(
    .INIT(64'h0FFF0F0F0E000E0E)) 
    req_Error_i_1
       (.I0(req_Error_reg_3),
        .I1(req_Error_i_3_n_0),
        .I2(req_Error_reg_4),
        .I3(req_Error_reg_5),
        .I4(SRST),
        .I5(req_Error_reg_6),
        .O(SRST_1));
  LUT4 #(
    .INIT(16'h0001)) 
    req_Error_i_10
       (.I0(out_CRC[11]),
        .I1(out_CRC[5]),
        .I2(out_CRC[4]),
        .I3(out_CRC[1]),
        .O(req_Error_i_10_n_0));
  (* SOFT_HLUTNM = "soft_lutpair67" *) 
  LUT4 #(
    .INIT(16'hFFFE)) 
    req_Error_i_11
       (.I0(out_CRC[3]),
        .I1(out_CRC[2]),
        .I2(out_CRC[7]),
        .I3(out_CRC[14]),
        .O(req_Error_i_11_n_0));
  LUT6 #(
    .INIT(64'hE020FFFFE020E020)) 
    req_Error_i_3
       (.I0(req_Error_reg),
        .I1(req_Error_reg_0[5]),
        .I2(\RXSTATES[3]_i_5_n_0 ),
        .I3(req_Error_reg_1),
        .I4(req_Error_i_7_n_0),
        .I5(req_Error_reg_2),
        .O(req_Error_i_3_n_0));
  LUT6 #(
    .INIT(64'h0000000000000004)) 
    req_Error_i_7
       (.I0(req_Error_i_9_n_0),
        .I1(req_Error_i_10_n_0),
        .I2(req_Error_i_11_n_0),
        .I3(out_CRC[13]),
        .I4(out_CRC[6]),
        .I5(out_CRC[0]),
        .O(req_Error_i_7_n_0));
  LUT4 #(
    .INIT(16'hFFFE)) 
    req_Error_i_9
       (.I0(out_CRC[10]),
        .I1(out_CRC[8]),
        .I2(out_CRC[12]),
        .I3(out_CRC[9]),
        .O(req_Error_i_9_n_0));
endmodule

(* ORIG_REF_NAME = "CRC" *) 
module design_1_FPGAPROJECT_0_0_CRC_9
   (SRST_1,
    \TXSTATES_reg[3] ,
    \TXSTATES_reg[3]_0 ,
    \Cnt_reg[5] ,
    \TXSTATES_reg[0] ,
    \TXSTATES_reg[2] ,
    Q,
    SRST,
    \CRC_RG_reg[14]_0 ,
    \Cnt[5]_i_7 ,
    \CRC_RG[14]_i_8_0 ,
    \CRC_RG[14]_i_8_1 ,
    \CRC_RG[14]_i_8_2 ,
    \serial[0]_i_2 ,
    data_TX,
    \CRC_RG[14]_i_8_3 ,
    E,
    Tq,
    \CRC_RG_reg[0]_0 );
  output SRST_1;
  output \TXSTATES_reg[3] ;
  output \TXSTATES_reg[3]_0 ;
  output \Cnt_reg[5] ;
  output \TXSTATES_reg[0] ;
  output \TXSTATES_reg[2] ;
  input [3:0]Q;
  input SRST;
  input \CRC_RG_reg[14]_0 ;
  input \Cnt[5]_i_7 ;
  input \CRC_RG[14]_i_8_0 ;
  input \CRC_RG[14]_i_8_1 ;
  input \CRC_RG[14]_i_8_2 ;
  input [5:0]\serial[0]_i_2 ;
  input [63:0]data_TX;
  input \CRC_RG[14]_i_8_3 ;
  input [0:0]E;
  input Tq;
  input \CRC_RG_reg[0]_0 ;

  wire \CRC_RG[14]_i_10_n_0 ;
  wire \CRC_RG[14]_i_11_n_0 ;
  wire \CRC_RG[14]_i_13_n_0 ;
  wire \CRC_RG[14]_i_14_n_0 ;
  wire \CRC_RG[14]_i_7_n_0 ;
  wire \CRC_RG[14]_i_8_0 ;
  wire \CRC_RG[14]_i_8_1 ;
  wire \CRC_RG[14]_i_8_2 ;
  wire \CRC_RG[14]_i_8_3 ;
  wire \CRC_RG_reg[0]_0 ;
  wire \CRC_RG_reg[14]_0 ;
  wire \CRC_RG_reg_n_0_[0] ;
  wire \CRC_RG_reg_n_0_[10] ;
  wire \CRC_RG_reg_n_0_[11] ;
  wire \CRC_RG_reg_n_0_[12] ;
  wire \CRC_RG_reg_n_0_[13] ;
  wire \CRC_RG_reg_n_0_[1] ;
  wire \CRC_RG_reg_n_0_[2] ;
  wire \CRC_RG_reg_n_0_[3] ;
  wire \CRC_RG_reg_n_0_[4] ;
  wire \CRC_RG_reg_n_0_[5] ;
  wire \CRC_RG_reg_n_0_[6] ;
  wire \CRC_RG_reg_n_0_[7] ;
  wire \CRC_RG_reg_n_0_[8] ;
  wire \CRC_RG_reg_n_0_[9] ;
  wire \Cnt[5]_i_7 ;
  wire \Cnt_reg[5] ;
  wire [0:0]E;
  wire [3:0]Q;
  wire SRST;
  wire SRST_1;
  wire \TXSTATES_reg[0] ;
  wire \TXSTATES_reg[2] ;
  wire \TXSTATES_reg[3] ;
  wire \TXSTATES_reg[3]_0 ;
  wire Tq;
  wire [63:0]data_TX;
  wire [14:14]out_CRC;
  wire [14:0]p_1_in__0;
  wire [5:0]\serial[0]_i_2 ;
  wire \serial[0]_i_35_n_0 ;
  wire \serial[0]_i_36_n_0 ;
  wire \serial[0]_i_37_n_0 ;
  wire \serial[0]_i_38_n_0 ;
  wire \serial[0]_i_39_n_0 ;
  wire \serial[0]_i_40_n_0 ;
  wire \serial[0]_i_41_n_0 ;
  wire \serial[0]_i_42_n_0 ;
  wire \serial[0]_i_43_n_0 ;
  wire \serial[0]_i_44_n_0 ;
  wire \serial[0]_i_45_n_0 ;
  wire \serial[0]_i_46_n_0 ;
  wire \serial[0]_i_47_n_0 ;
  wire \serial[0]_i_48_n_0 ;
  wire \serial[0]_i_49_n_0 ;
  wire \serial[0]_i_50_n_0 ;
  wire \serial[0]_i_51_n_0 ;
  wire \serial[0]_i_52_n_0 ;
  wire \serial[0]_i_53_n_0 ;
  wire \serial[0]_i_54_n_0 ;
  wire \serial[0]_i_7_n_0 ;
  wire \serial[0]_i_8_n_0 ;
  wire \serial[0]_i_9_n_0 ;
  wire \serial_reg[0]_i_14_n_0 ;
  wire \serial_reg[0]_i_15_n_0 ;
  wire \serial_reg[0]_i_16_n_0 ;
  wire \serial_reg[0]_i_17_n_0 ;
  wire \serial_reg[0]_i_18_n_0 ;
  wire \serial_reg[0]_i_19_n_0 ;
  wire \serial_reg[0]_i_20_n_0 ;
  wire \serial_reg[0]_i_21_n_0 ;
  wire \serial_reg[0]_i_22_n_0 ;
  wire \serial_reg[0]_i_23_n_0 ;

  LUT6 #(
    .INIT(64'h00000000FF9E0000)) 
    \CRC_RG[0]_i_1 
       (.I0(Q[1]),
        .I1(Q[0]),
        .I2(Q[3]),
        .I3(Q[2]),
        .I4(SRST),
        .I5(\CRC_RG[14]_i_7_n_0 ),
        .O(p_1_in__0[0]));
  (* SOFT_HLUTNM = "soft_lutpair103" *) 
  LUT3 #(
    .INIT(8'h82)) 
    \CRC_RG[10]_i_1 
       (.I0(SRST_1),
        .I1(\CRC_RG[14]_i_7_n_0 ),
        .I2(\CRC_RG_reg_n_0_[9] ),
        .O(p_1_in__0[10]));
  LUT6 #(
    .INIT(64'hAAAA82A800000000)) 
    \CRC_RG[11]_i_1 
       (.I0(\CRC_RG_reg_n_0_[10] ),
        .I1(Q[1]),
        .I2(Q[0]),
        .I3(Q[3]),
        .I4(Q[2]),
        .I5(SRST),
        .O(p_1_in__0[11]));
  LUT6 #(
    .INIT(64'hAAAA82A800000000)) 
    \CRC_RG[12]_i_1 
       (.I0(\CRC_RG_reg_n_0_[11] ),
        .I1(Q[1]),
        .I2(Q[0]),
        .I3(Q[3]),
        .I4(Q[2]),
        .I5(SRST),
        .O(p_1_in__0[12]));
  LUT6 #(
    .INIT(64'hAAAA82A800000000)) 
    \CRC_RG[13]_i_1 
       (.I0(\CRC_RG_reg_n_0_[12] ),
        .I1(Q[1]),
        .I2(Q[0]),
        .I3(Q[3]),
        .I4(Q[2]),
        .I5(SRST),
        .O(p_1_in__0[13]));
  LUT6 #(
    .INIT(64'hFFFFFFFF4540FFFF)) 
    \CRC_RG[14]_i_10 
       (.I0(\CRC_RG[14]_i_8_0 ),
        .I1(\CRC_RG[14]_i_8_1 ),
        .I2(\CRC_RG[14]_i_13_n_0 ),
        .I3(\CRC_RG[14]_i_8_2 ),
        .I4(Q[1]),
        .I5(Q[0]),
        .O(\CRC_RG[14]_i_10_n_0 ));
  LUT3 #(
    .INIT(8'h4F)) 
    \CRC_RG[14]_i_11 
       (.I0(\CRC_RG[14]_i_14_n_0 ),
        .I1(\CRC_RG[14]_i_8_3 ),
        .I2(Q[0]),
        .O(\CRC_RG[14]_i_11_n_0 ));
  LUT5 #(
    .INIT(32'hAAAAA999)) 
    \CRC_RG[14]_i_13 
       (.I0(\serial[0]_i_2 [4]),
        .I1(\serial[0]_i_2 [2]),
        .I2(\serial[0]_i_2 [1]),
        .I3(\serial[0]_i_2 [0]),
        .I4(\serial[0]_i_2 [3]),
        .O(\CRC_RG[14]_i_13_n_0 ));
  LUT6 #(
    .INIT(64'h00000004FFFFFFFF)) 
    \CRC_RG[14]_i_14 
       (.I0(\serial[0]_i_2 [1]),
        .I1(\serial[0]_i_2 [2]),
        .I2(\serial[0]_i_2 [3]),
        .I3(\serial[0]_i_2 [4]),
        .I4(\serial[0]_i_2 [5]),
        .I5(Q[1]),
        .O(\CRC_RG[14]_i_14_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair103" *) 
  LUT3 #(
    .INIT(8'h82)) 
    \CRC_RG[14]_i_2 
       (.I0(SRST_1),
        .I1(\CRC_RG[14]_i_7_n_0 ),
        .I2(\CRC_RG_reg_n_0_[13] ),
        .O(p_1_in__0[14]));
  (* SOFT_HLUTNM = "soft_lutpair99" *) 
  LUT5 #(
    .INIT(32'hAA8A8AA8)) 
    \CRC_RG[14]_i_3 
       (.I0(SRST),
        .I1(Q[2]),
        .I2(Q[3]),
        .I3(Q[0]),
        .I4(Q[1]),
        .O(SRST_1));
  (* SOFT_HLUTNM = "soft_lutpair100" *) 
  LUT5 #(
    .INIT(32'h15140000)) 
    \CRC_RG[14]_i_4 
       (.I0(Q[3]),
        .I1(Q[1]),
        .I2(Q[2]),
        .I3(Q[0]),
        .I4(\CRC_RG_reg[14]_0 ),
        .O(\TXSTATES_reg[3] ));
  (* SOFT_HLUTNM = "soft_lutpair99" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \CRC_RG[14]_i_6 
       (.I0(Q[2]),
        .I1(Q[1]),
        .O(\TXSTATES_reg[2] ));
  LUT2 #(
    .INIT(4'h9)) 
    \CRC_RG[14]_i_7 
       (.I0(out_CRC),
        .I1(\TXSTATES_reg[3]_0 ),
        .O(\CRC_RG[14]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'hBBBBBABBBABABABA)) 
    \CRC_RG[14]_i_8 
       (.I0(Q[3]),
        .I1(\Cnt_reg[5] ),
        .I2(Q[2]),
        .I3(\Cnt[5]_i_7 ),
        .I4(\CRC_RG[14]_i_10_n_0 ),
        .I5(\CRC_RG[14]_i_11_n_0 ),
        .O(\TXSTATES_reg[3]_0 ));
  LUT6 #(
    .INIT(64'hAAAA82A800000000)) 
    \CRC_RG[1]_i_1 
       (.I0(\CRC_RG_reg_n_0_[0] ),
        .I1(Q[1]),
        .I2(Q[0]),
        .I3(Q[3]),
        .I4(Q[2]),
        .I5(SRST),
        .O(p_1_in__0[1]));
  LUT6 #(
    .INIT(64'hAAAA82A800000000)) 
    \CRC_RG[2]_i_1 
       (.I0(\CRC_RG_reg_n_0_[1] ),
        .I1(Q[1]),
        .I2(Q[0]),
        .I3(Q[3]),
        .I4(Q[2]),
        .I5(SRST),
        .O(p_1_in__0[2]));
  (* SOFT_HLUTNM = "soft_lutpair101" *) 
  LUT3 #(
    .INIT(8'h82)) 
    \CRC_RG[3]_i_1 
       (.I0(SRST_1),
        .I1(\CRC_RG[14]_i_7_n_0 ),
        .I2(\CRC_RG_reg_n_0_[2] ),
        .O(p_1_in__0[3]));
  (* SOFT_HLUTNM = "soft_lutpair101" *) 
  LUT3 #(
    .INIT(8'h82)) 
    \CRC_RG[4]_i_1 
       (.I0(SRST_1),
        .I1(\CRC_RG[14]_i_7_n_0 ),
        .I2(\CRC_RG_reg_n_0_[3] ),
        .O(p_1_in__0[4]));
  LUT6 #(
    .INIT(64'hAAAA82A800000000)) 
    \CRC_RG[5]_i_1 
       (.I0(\CRC_RG_reg_n_0_[4] ),
        .I1(Q[1]),
        .I2(Q[0]),
        .I3(Q[3]),
        .I4(Q[2]),
        .I5(SRST),
        .O(p_1_in__0[5]));
  LUT6 #(
    .INIT(64'hAAAA82A800000000)) 
    \CRC_RG[6]_i_1 
       (.I0(\CRC_RG_reg_n_0_[5] ),
        .I1(Q[1]),
        .I2(Q[0]),
        .I3(Q[3]),
        .I4(Q[2]),
        .I5(SRST),
        .O(p_1_in__0[6]));
  (* SOFT_HLUTNM = "soft_lutpair102" *) 
  LUT3 #(
    .INIT(8'h82)) 
    \CRC_RG[7]_i_1 
       (.I0(SRST_1),
        .I1(\CRC_RG[14]_i_7_n_0 ),
        .I2(\CRC_RG_reg_n_0_[6] ),
        .O(p_1_in__0[7]));
  (* SOFT_HLUTNM = "soft_lutpair102" *) 
  LUT3 #(
    .INIT(8'h82)) 
    \CRC_RG[8]_i_1 
       (.I0(SRST_1),
        .I1(\CRC_RG[14]_i_7_n_0 ),
        .I2(\CRC_RG_reg_n_0_[7] ),
        .O(p_1_in__0[8]));
  LUT6 #(
    .INIT(64'hAAAA82A800000000)) 
    \CRC_RG[9]_i_1 
       (.I0(\CRC_RG_reg_n_0_[8] ),
        .I1(Q[1]),
        .I2(Q[0]),
        .I3(Q[3]),
        .I4(Q[2]),
        .I5(SRST),
        .O(p_1_in__0[9]));
  FDCE \CRC_RG_reg[0] 
       (.C(Tq),
        .CE(E),
        .CLR(\CRC_RG_reg[0]_0 ),
        .D(p_1_in__0[0]),
        .Q(\CRC_RG_reg_n_0_[0] ));
  FDCE \CRC_RG_reg[10] 
       (.C(Tq),
        .CE(E),
        .CLR(\CRC_RG_reg[0]_0 ),
        .D(p_1_in__0[10]),
        .Q(\CRC_RG_reg_n_0_[10] ));
  FDCE \CRC_RG_reg[11] 
       (.C(Tq),
        .CE(E),
        .CLR(\CRC_RG_reg[0]_0 ),
        .D(p_1_in__0[11]),
        .Q(\CRC_RG_reg_n_0_[11] ));
  FDCE \CRC_RG_reg[12] 
       (.C(Tq),
        .CE(E),
        .CLR(\CRC_RG_reg[0]_0 ),
        .D(p_1_in__0[12]),
        .Q(\CRC_RG_reg_n_0_[12] ));
  FDCE \CRC_RG_reg[13] 
       (.C(Tq),
        .CE(E),
        .CLR(\CRC_RG_reg[0]_0 ),
        .D(p_1_in__0[13]),
        .Q(\CRC_RG_reg_n_0_[13] ));
  FDCE \CRC_RG_reg[14] 
       (.C(Tq),
        .CE(E),
        .CLR(\CRC_RG_reg[0]_0 ),
        .D(p_1_in__0[14]),
        .Q(out_CRC));
  FDCE \CRC_RG_reg[1] 
       (.C(Tq),
        .CE(E),
        .CLR(\CRC_RG_reg[0]_0 ),
        .D(p_1_in__0[1]),
        .Q(\CRC_RG_reg_n_0_[1] ));
  FDCE \CRC_RG_reg[2] 
       (.C(Tq),
        .CE(E),
        .CLR(\CRC_RG_reg[0]_0 ),
        .D(p_1_in__0[2]),
        .Q(\CRC_RG_reg_n_0_[2] ));
  FDCE \CRC_RG_reg[3] 
       (.C(Tq),
        .CE(E),
        .CLR(\CRC_RG_reg[0]_0 ),
        .D(p_1_in__0[3]),
        .Q(\CRC_RG_reg_n_0_[3] ));
  FDCE \CRC_RG_reg[4] 
       (.C(Tq),
        .CE(E),
        .CLR(\CRC_RG_reg[0]_0 ),
        .D(p_1_in__0[4]),
        .Q(\CRC_RG_reg_n_0_[4] ));
  FDCE \CRC_RG_reg[5] 
       (.C(Tq),
        .CE(E),
        .CLR(\CRC_RG_reg[0]_0 ),
        .D(p_1_in__0[5]),
        .Q(\CRC_RG_reg_n_0_[5] ));
  FDCE \CRC_RG_reg[6] 
       (.C(Tq),
        .CE(E),
        .CLR(\CRC_RG_reg[0]_0 ),
        .D(p_1_in__0[6]),
        .Q(\CRC_RG_reg_n_0_[6] ));
  FDCE \CRC_RG_reg[7] 
       (.C(Tq),
        .CE(E),
        .CLR(\CRC_RG_reg[0]_0 ),
        .D(p_1_in__0[7]),
        .Q(\CRC_RG_reg_n_0_[7] ));
  FDCE \CRC_RG_reg[8] 
       (.C(Tq),
        .CE(E),
        .CLR(\CRC_RG_reg[0]_0 ),
        .D(p_1_in__0[8]),
        .Q(\CRC_RG_reg_n_0_[8] ));
  FDCE \CRC_RG_reg[9] 
       (.C(Tq),
        .CE(E),
        .CLR(\CRC_RG_reg[0]_0 ),
        .D(p_1_in__0[9]),
        .Q(\CRC_RG_reg_n_0_[9] ));
  (* SOFT_HLUTNM = "soft_lutpair100" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \Cnt[4]_i_7 
       (.I0(Q[0]),
        .I1(Q[1]),
        .O(\TXSTATES_reg[0] ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \serial[0]_i_35 
       (.I0(data_TX[59]),
        .I1(data_TX[58]),
        .I2(\serial[0]_i_2 [1]),
        .I3(data_TX[57]),
        .I4(\serial[0]_i_2 [0]),
        .I5(data_TX[56]),
        .O(\serial[0]_i_35_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \serial[0]_i_36 
       (.I0(data_TX[63]),
        .I1(data_TX[62]),
        .I2(\serial[0]_i_2 [1]),
        .I3(data_TX[61]),
        .I4(\serial[0]_i_2 [0]),
        .I5(data_TX[60]),
        .O(\serial[0]_i_36_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \serial[0]_i_37 
       (.I0(data_TX[51]),
        .I1(data_TX[50]),
        .I2(\serial[0]_i_2 [1]),
        .I3(data_TX[49]),
        .I4(\serial[0]_i_2 [0]),
        .I5(data_TX[48]),
        .O(\serial[0]_i_37_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \serial[0]_i_38 
       (.I0(data_TX[55]),
        .I1(data_TX[54]),
        .I2(\serial[0]_i_2 [1]),
        .I3(data_TX[53]),
        .I4(\serial[0]_i_2 [0]),
        .I5(data_TX[52]),
        .O(\serial[0]_i_38_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \serial[0]_i_39 
       (.I0(data_TX[43]),
        .I1(data_TX[42]),
        .I2(\serial[0]_i_2 [1]),
        .I3(data_TX[41]),
        .I4(\serial[0]_i_2 [0]),
        .I5(data_TX[40]),
        .O(\serial[0]_i_39_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \serial[0]_i_40 
       (.I0(data_TX[47]),
        .I1(data_TX[46]),
        .I2(\serial[0]_i_2 [1]),
        .I3(data_TX[45]),
        .I4(\serial[0]_i_2 [0]),
        .I5(data_TX[44]),
        .O(\serial[0]_i_40_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \serial[0]_i_41 
       (.I0(data_TX[35]),
        .I1(data_TX[34]),
        .I2(\serial[0]_i_2 [1]),
        .I3(data_TX[33]),
        .I4(\serial[0]_i_2 [0]),
        .I5(data_TX[32]),
        .O(\serial[0]_i_41_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \serial[0]_i_42 
       (.I0(data_TX[39]),
        .I1(data_TX[38]),
        .I2(\serial[0]_i_2 [1]),
        .I3(data_TX[37]),
        .I4(\serial[0]_i_2 [0]),
        .I5(data_TX[36]),
        .O(\serial[0]_i_42_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \serial[0]_i_43 
       (.I0(data_TX[27]),
        .I1(data_TX[26]),
        .I2(\serial[0]_i_2 [1]),
        .I3(data_TX[25]),
        .I4(\serial[0]_i_2 [0]),
        .I5(data_TX[24]),
        .O(\serial[0]_i_43_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \serial[0]_i_44 
       (.I0(data_TX[31]),
        .I1(data_TX[30]),
        .I2(\serial[0]_i_2 [1]),
        .I3(data_TX[29]),
        .I4(\serial[0]_i_2 [0]),
        .I5(data_TX[28]),
        .O(\serial[0]_i_44_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \serial[0]_i_45 
       (.I0(data_TX[19]),
        .I1(data_TX[18]),
        .I2(\serial[0]_i_2 [1]),
        .I3(data_TX[17]),
        .I4(\serial[0]_i_2 [0]),
        .I5(data_TX[16]),
        .O(\serial[0]_i_45_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \serial[0]_i_46 
       (.I0(data_TX[23]),
        .I1(data_TX[22]),
        .I2(\serial[0]_i_2 [1]),
        .I3(data_TX[21]),
        .I4(\serial[0]_i_2 [0]),
        .I5(data_TX[20]),
        .O(\serial[0]_i_46_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \serial[0]_i_47 
       (.I0(data_TX[11]),
        .I1(data_TX[10]),
        .I2(\serial[0]_i_2 [1]),
        .I3(data_TX[9]),
        .I4(\serial[0]_i_2 [0]),
        .I5(data_TX[8]),
        .O(\serial[0]_i_47_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \serial[0]_i_48 
       (.I0(data_TX[15]),
        .I1(data_TX[14]),
        .I2(\serial[0]_i_2 [1]),
        .I3(data_TX[13]),
        .I4(\serial[0]_i_2 [0]),
        .I5(data_TX[12]),
        .O(\serial[0]_i_48_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \serial[0]_i_49 
       (.I0(data_TX[3]),
        .I1(data_TX[2]),
        .I2(\serial[0]_i_2 [1]),
        .I3(data_TX[1]),
        .I4(\serial[0]_i_2 [0]),
        .I5(data_TX[0]),
        .O(\serial[0]_i_49_n_0 ));
  LUT6 #(
    .INIT(64'h00000000FFFF47FF)) 
    \serial[0]_i_5 
       (.I0(\serial[0]_i_7_n_0 ),
        .I1(\serial[0]_i_2 [5]),
        .I2(\serial[0]_i_8_n_0 ),
        .I3(Q[2]),
        .I4(\TXSTATES_reg[0] ),
        .I5(\serial[0]_i_9_n_0 ),
        .O(\Cnt_reg[5] ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \serial[0]_i_50 
       (.I0(data_TX[7]),
        .I1(data_TX[6]),
        .I2(\serial[0]_i_2 [1]),
        .I3(data_TX[5]),
        .I4(\serial[0]_i_2 [0]),
        .I5(data_TX[4]),
        .O(\serial[0]_i_50_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \serial[0]_i_51 
       (.I0(\CRC_RG_reg_n_0_[11] ),
        .I1(\CRC_RG_reg_n_0_[10] ),
        .I2(\serial[0]_i_2 [1]),
        .I3(\CRC_RG_reg_n_0_[9] ),
        .I4(\serial[0]_i_2 [0]),
        .I5(\CRC_RG_reg_n_0_[8] ),
        .O(\serial[0]_i_51_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \serial[0]_i_52 
       (.I0(out_CRC),
        .I1(\serial[0]_i_2 [1]),
        .I2(\CRC_RG_reg_n_0_[13] ),
        .I3(\serial[0]_i_2 [0]),
        .I4(\CRC_RG_reg_n_0_[12] ),
        .O(\serial[0]_i_52_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \serial[0]_i_53 
       (.I0(\CRC_RG_reg_n_0_[3] ),
        .I1(\CRC_RG_reg_n_0_[2] ),
        .I2(\serial[0]_i_2 [1]),
        .I3(\CRC_RG_reg_n_0_[1] ),
        .I4(\serial[0]_i_2 [0]),
        .I5(\CRC_RG_reg_n_0_[0] ),
        .O(\serial[0]_i_53_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \serial[0]_i_54 
       (.I0(\CRC_RG_reg_n_0_[7] ),
        .I1(\CRC_RG_reg_n_0_[6] ),
        .I2(\serial[0]_i_2 [1]),
        .I3(\CRC_RG_reg_n_0_[5] ),
        .I4(\serial[0]_i_2 [0]),
        .I5(\CRC_RG_reg_n_0_[4] ),
        .O(\serial[0]_i_54_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \serial[0]_i_7 
       (.I0(\serial_reg[0]_i_14_n_0 ),
        .I1(\serial_reg[0]_i_15_n_0 ),
        .I2(\serial[0]_i_2 [4]),
        .I3(\serial_reg[0]_i_16_n_0 ),
        .I4(\serial[0]_i_2 [3]),
        .I5(\serial_reg[0]_i_17_n_0 ),
        .O(\serial[0]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \serial[0]_i_8 
       (.I0(\serial_reg[0]_i_18_n_0 ),
        .I1(\serial_reg[0]_i_19_n_0 ),
        .I2(\serial[0]_i_2 [4]),
        .I3(\serial_reg[0]_i_20_n_0 ),
        .I4(\serial[0]_i_2 [3]),
        .I5(\serial_reg[0]_i_21_n_0 ),
        .O(\serial[0]_i_8_n_0 ));
  LUT6 #(
    .INIT(64'hFFFF8A80FFFFFFFF)) 
    \serial[0]_i_9 
       (.I0(Q[0]),
        .I1(\serial_reg[0]_i_22_n_0 ),
        .I2(\serial[0]_i_2 [3]),
        .I3(\serial_reg[0]_i_23_n_0 ),
        .I4(Q[1]),
        .I5(Q[2]),
        .O(\serial[0]_i_9_n_0 ));
  MUXF7 \serial_reg[0]_i_14 
       (.I0(\serial[0]_i_35_n_0 ),
        .I1(\serial[0]_i_36_n_0 ),
        .O(\serial_reg[0]_i_14_n_0 ),
        .S(\serial[0]_i_2 [2]));
  MUXF7 \serial_reg[0]_i_15 
       (.I0(\serial[0]_i_37_n_0 ),
        .I1(\serial[0]_i_38_n_0 ),
        .O(\serial_reg[0]_i_15_n_0 ),
        .S(\serial[0]_i_2 [2]));
  MUXF7 \serial_reg[0]_i_16 
       (.I0(\serial[0]_i_39_n_0 ),
        .I1(\serial[0]_i_40_n_0 ),
        .O(\serial_reg[0]_i_16_n_0 ),
        .S(\serial[0]_i_2 [2]));
  MUXF7 \serial_reg[0]_i_17 
       (.I0(\serial[0]_i_41_n_0 ),
        .I1(\serial[0]_i_42_n_0 ),
        .O(\serial_reg[0]_i_17_n_0 ),
        .S(\serial[0]_i_2 [2]));
  MUXF7 \serial_reg[0]_i_18 
       (.I0(\serial[0]_i_43_n_0 ),
        .I1(\serial[0]_i_44_n_0 ),
        .O(\serial_reg[0]_i_18_n_0 ),
        .S(\serial[0]_i_2 [2]));
  MUXF7 \serial_reg[0]_i_19 
       (.I0(\serial[0]_i_45_n_0 ),
        .I1(\serial[0]_i_46_n_0 ),
        .O(\serial_reg[0]_i_19_n_0 ),
        .S(\serial[0]_i_2 [2]));
  MUXF7 \serial_reg[0]_i_20 
       (.I0(\serial[0]_i_47_n_0 ),
        .I1(\serial[0]_i_48_n_0 ),
        .O(\serial_reg[0]_i_20_n_0 ),
        .S(\serial[0]_i_2 [2]));
  MUXF7 \serial_reg[0]_i_21 
       (.I0(\serial[0]_i_49_n_0 ),
        .I1(\serial[0]_i_50_n_0 ),
        .O(\serial_reg[0]_i_21_n_0 ),
        .S(\serial[0]_i_2 [2]));
  MUXF7 \serial_reg[0]_i_22 
       (.I0(\serial[0]_i_51_n_0 ),
        .I1(\serial[0]_i_52_n_0 ),
        .O(\serial_reg[0]_i_22_n_0 ),
        .S(\serial[0]_i_2 [2]));
  MUXF7 \serial_reg[0]_i_23 
       (.I0(\serial[0]_i_53_n_0 ),
        .I1(\serial[0]_i_54_n_0 ),
        .O(\serial_reg[0]_i_23_n_0 ),
        .S(\serial[0]_i_2 [2]));
endmodule

(* ORIG_REF_NAME = "ErrorHandler" *) 
module design_1_FPGAPROJECT_0_0_ErrorHandler
   (lastvalue,
    Q,
    \State_reg[0]_0 ,
    \REC_reg[8]_0 ,
    \State_reg[0]_1 ,
    \State_reg[2]_0 ,
    D,
    RXOUT_reg,
    Mode_0_1_sp_1,
    q_reg,
    RXBUS,
    RX,
    SRST_0_0,
    \State_reg[2]_1 ,
    \State_reg[0]_2 ,
    \REC_reg[7]_0 ,
    \REC_reg[8]_1 ,
    \State_reg[0]_3 ,
    E,
    lastvalue_reg_0,
    clk,
    ack_error_reg_0,
    donefromtxr,
    donefromrxr,
    imTX,
    req_Error_RX,
    \D_Len[0]_i_2_0 ,
    AckTakeOver,
    Sampled_din,
    SRST_0,
    \REC_reg[0]_0 ,
    ack_error_reg_1,
    \TEC_reg[0]_0 ,
    TXpin_reg_0,
    \Cnt_reg[0]_0 ,
    \TEC[8]_i_11_0 ,
    \State_reg[0]_4 ,
    \State_reg[0]_5 ,
    \TXSTATES_reg[2] ,
    \TXSTATES_reg[3] ,
    ack_error_reg_2,
    ack_error_reg_3,
    RXBUS_d,
    q,
    Mode_0,
    TX,
    \RXSTATES_reg[1] ,
    \Cnt_reg[3]_0 ,
    \REC[0]_i_2_0 ,
    \TEC_reg[0]_1 ,
    \REC[8]_i_7_0 );
  output lastvalue;
  output [8:0]Q;
  output [0:0]\State_reg[0]_0 ;
  output [8:0]\REC_reg[8]_0 ;
  output \State_reg[0]_1 ;
  output \State_reg[2]_0 ;
  output [1:0]D;
  output RXOUT_reg;
  output Mode_0_1_sp_1;
  output q_reg;
  output RXBUS;
  output RX;
  output [0:0]SRST_0_0;
  output \State_reg[2]_1 ;
  output \State_reg[0]_2 ;
  output \REC_reg[7]_0 ;
  output \REC_reg[8]_1 ;
  output \State_reg[0]_3 ;
  input [0:0]E;
  input lastvalue_reg_0;
  input clk;
  input ack_error_reg_0;
  input donefromtxr;
  input donefromrxr;
  input imTX;
  input req_Error_RX;
  input \D_Len[0]_i_2_0 ;
  input AckTakeOver;
  input Sampled_din;
  input SRST_0;
  input \REC_reg[0]_0 ;
  input ack_error_reg_1;
  input \TEC_reg[0]_0 ;
  input TXpin_reg_0;
  input [0:0]\Cnt_reg[0]_0 ;
  input \TEC[8]_i_11_0 ;
  input \State_reg[0]_4 ;
  input \State_reg[0]_5 ;
  input \TXSTATES_reg[2] ;
  input \TXSTATES_reg[3] ;
  input ack_error_reg_2;
  input ack_error_reg_3;
  input RXBUS_d;
  input q;
  input [2:0]Mode_0;
  input TX;
  input \RXSTATES_reg[1] ;
  input \Cnt_reg[3]_0 ;
  input \REC[0]_i_2_0 ;
  input \TEC_reg[0]_1 ;
  input \REC[8]_i_7_0 ;

  wire AckTakeOver;
  wire \Cnt[0]_i_2__1_n_0 ;
  wire \Cnt[0]_i_3__1_n_0 ;
  wire \Cnt[0]_i_4__1_n_0 ;
  wire \Cnt[0]_i_5__0_n_0 ;
  wire \Cnt[0]_i_6_n_0 ;
  wire \Cnt[1]_i_2__1_n_0 ;
  wire \Cnt[2]_i_2__1_n_0 ;
  wire \Cnt[2]_i_3__1_n_0 ;
  wire \Cnt[2]_i_4__1_n_0 ;
  wire \Cnt[2]_i_5__1_n_0 ;
  wire \Cnt[2]_i_6__1_n_0 ;
  wire \Cnt[3]_i_10__0_n_0 ;
  wire \Cnt[3]_i_11_n_0 ;
  wire \Cnt[3]_i_3__0_n_0 ;
  wire \Cnt[3]_i_4__1_n_0 ;
  wire \Cnt[3]_i_5__0_n_0 ;
  wire \Cnt[3]_i_6__0_n_0 ;
  wire \Cnt[3]_i_7__0_n_0 ;
  wire \Cnt[3]_i_9__0_n_0 ;
  wire [0:0]\Cnt_reg[0]_0 ;
  wire \Cnt_reg[3]_0 ;
  wire \Cnt_reg_n_0_[0] ;
  wire \Cnt_reg_n_0_[1] ;
  wire \Cnt_reg_n_0_[2] ;
  wire \Cnt_reg_n_0_[3] ;
  wire [3:0]Cntr;
  wire [1:0]D;
  wire \D_Len[0]_i_2_0 ;
  wire \D_Len[0]_i_3_n_0 ;
  wire [0:0]E;
  wire [2:0]Mode_0;
  wire Mode_0_1_sn_1;
  wire [8:0]Q;
  wire \REC[0]_i_1_n_0 ;
  wire \REC[0]_i_2_0 ;
  wire \REC[0]_i_2_n_0 ;
  wire \REC[0]_i_3_n_0 ;
  wire \REC[0]_i_4_n_0 ;
  wire \REC[1]_i_1_n_0 ;
  wire \REC[1]_i_2_n_0 ;
  wire \REC[1]_i_3_n_0 ;
  wire \REC[1]_i_4_n_0 ;
  wire \REC[1]_i_5_n_0 ;
  wire \REC[1]_i_6_n_0 ;
  wire \REC[2]_i_1_n_0 ;
  wire \REC[2]_i_2_n_0 ;
  wire \REC[2]_i_3_n_0 ;
  wire \REC[2]_i_4_n_0 ;
  wire \REC[2]_i_5_n_0 ;
  wire \REC[2]_i_6_n_0 ;
  wire \REC[2]_i_7_n_0 ;
  wire \REC[3]_i_1_n_0 ;
  wire \REC[3]_i_2_n_0 ;
  wire \REC[3]_i_3_n_0 ;
  wire \REC[3]_i_4_n_0 ;
  wire \REC[3]_i_5_n_0 ;
  wire \REC[3]_i_6_n_0 ;
  wire \REC[4]_i_1_n_0 ;
  wire \REC[4]_i_2_n_0 ;
  wire \REC[4]_i_3_n_0 ;
  wire \REC[4]_i_4_n_0 ;
  wire \REC[4]_i_5_n_0 ;
  wire \REC[4]_i_6_n_0 ;
  wire \REC[4]_i_7_n_0 ;
  wire \REC[4]_i_8_n_0 ;
  wire \REC[5]_i_1_n_0 ;
  wire \REC[5]_i_2_n_0 ;
  wire \REC[5]_i_3_n_0 ;
  wire \REC[5]_i_4_n_0 ;
  wire \REC[5]_i_5_n_0 ;
  wire \REC[5]_i_7_n_0 ;
  wire \REC[5]_i_8_n_0 ;
  wire \REC[5]_i_9_n_0 ;
  wire \REC[6]_i_1_n_0 ;
  wire \REC[6]_i_2_n_0 ;
  wire \REC[6]_i_3_n_0 ;
  wire \REC[6]_i_4_n_0 ;
  wire \REC[6]_i_5_n_0 ;
  wire \REC[6]_i_6_n_0 ;
  wire \REC[6]_i_7_n_0 ;
  wire \REC[6]_i_8_n_0 ;
  wire \REC[6]_i_9_n_0 ;
  wire \REC[7]_i_1_n_0 ;
  wire \REC[7]_i_2_n_0 ;
  wire \REC[7]_i_3_n_0 ;
  wire \REC[7]_i_4_n_0 ;
  wire \REC[7]_i_5_n_0 ;
  wire \REC[7]_i_6_n_0 ;
  wire \REC[7]_i_7_n_0 ;
  wire \REC[8]_i_10_n_0 ;
  wire \REC[8]_i_11_n_0 ;
  wire \REC[8]_i_12_n_0 ;
  wire \REC[8]_i_13_n_0 ;
  wire \REC[8]_i_14_n_0 ;
  wire \REC[8]_i_15_n_0 ;
  wire \REC[8]_i_17_n_0 ;
  wire \REC[8]_i_1_n_0 ;
  wire \REC[8]_i_2_n_0 ;
  wire \REC[8]_i_3_n_0 ;
  wire \REC[8]_i_4_n_0 ;
  wire \REC[8]_i_5_n_0 ;
  wire \REC[8]_i_6_n_0 ;
  wire \REC[8]_i_7_0 ;
  wire \REC[8]_i_7_n_0 ;
  wire \REC[8]_i_8_n_0 ;
  wire \REC[8]_i_9_n_0 ;
  wire \REC_reg[0]_0 ;
  wire \REC_reg[7]_0 ;
  wire [8:0]\REC_reg[8]_0 ;
  wire \REC_reg[8]_1 ;
  wire [0:0]RECin;
  wire \RECin_reg_n_0_[7] ;
  wire \RECin_reg_n_0_[8] ;
  wire RX;
  wire RXBUS;
  wire RXBUS_d;
  wire RXOUT_reg;
  wire \RXSTATES_reg[1] ;
  wire [0:0]Reck;
  wire \Reck[4]_i_2_n_0 ;
  wire \Reck[5]_i_2_n_0 ;
  wire \Reck[6]_i_3_n_0 ;
  wire \Reck[6]_i_4_n_0 ;
  wire \Reck_reg_n_0_[0] ;
  wire \Reck_reg_n_0_[1] ;
  wire \Reck_reg_n_0_[2] ;
  wire \Reck_reg_n_0_[3] ;
  wire \Reck_reg_n_0_[4] ;
  wire \Reck_reg_n_0_[5] ;
  wire \Reck_reg_n_0_[6] ;
  wire [6:0]Reckr;
  wire SRST_0;
  wire [0:0]SRST_0_0;
  wire Sampled_din;
  wire [2:1]State;
  wire \State[0]_i_1_n_0 ;
  wire \State[0]_i_2_n_0 ;
  wire \State[0]_i_3_n_0 ;
  wire \State[0]_i_5_n_0 ;
  wire \State[0]_i_8_n_0 ;
  wire \State[0]_i_9_n_0 ;
  wire \State[1]_i_1_n_0 ;
  wire \State[1]_i_2_n_0 ;
  wire \State[1]_i_3_n_0 ;
  wire \State[1]_i_4_n_0 ;
  wire \State[1]_i_5_n_0 ;
  wire \State[2]_i_1_n_0 ;
  wire \State[2]_i_2_n_0 ;
  wire \State[2]_i_3_n_0 ;
  wire \State[2]_i_4_n_0 ;
  wire \State[2]_i_5_n_0 ;
  wire \State[2]_i_6_n_0 ;
  wire \State[2]_i_7_n_0 ;
  wire \State[2]_i_8_n_0 ;
  wire [0:0]\State_reg[0]_0 ;
  wire \State_reg[0]_1 ;
  wire \State_reg[0]_2 ;
  wire \State_reg[0]_3 ;
  wire \State_reg[0]_4 ;
  wire \State_reg[0]_5 ;
  wire \State_reg[2]_0 ;
  wire \State_reg[2]_1 ;
  wire \TEC[0]_i_1_n_0 ;
  wire \TEC[0]_i_2_n_0 ;
  wire \TEC[0]_i_3_n_0 ;
  wire \TEC[1]_i_1_n_0 ;
  wire \TEC[1]_i_2_n_0 ;
  wire \TEC[1]_i_3_n_0 ;
  wire \TEC[1]_i_4_n_0 ;
  wire \TEC[1]_i_5_n_0 ;
  wire \TEC[2]_i_1_n_0 ;
  wire \TEC[2]_i_2_n_0 ;
  wire \TEC[2]_i_3_n_0 ;
  wire \TEC[2]_i_4_n_0 ;
  wire \TEC[2]_i_5_n_0 ;
  wire \TEC[3]_i_1_n_0 ;
  wire \TEC[3]_i_2_n_0 ;
  wire \TEC[3]_i_3_n_0 ;
  wire \TEC[3]_i_4_n_0 ;
  wire \TEC[3]_i_5_n_0 ;
  wire \TEC[4]_i_1_n_0 ;
  wire \TEC[4]_i_2_n_0 ;
  wire \TEC[4]_i_3_n_0 ;
  wire \TEC[4]_i_4_n_0 ;
  wire \TEC[4]_i_5_n_0 ;
  wire \TEC[4]_i_6_n_0 ;
  wire \TEC[5]_i_1_n_0 ;
  wire \TEC[5]_i_2_n_0 ;
  wire \TEC[5]_i_3_n_0 ;
  wire \TEC[5]_i_4_n_0 ;
  wire \TEC[5]_i_5_n_0 ;
  wire \TEC[5]_i_6_n_0 ;
  wire \TEC[6]_i_1_n_0 ;
  wire \TEC[6]_i_2_n_0 ;
  wire \TEC[6]_i_3_n_0 ;
  wire \TEC[6]_i_4_n_0 ;
  wire \TEC[6]_i_5_n_0 ;
  wire \TEC[6]_i_6_n_0 ;
  wire \TEC[6]_i_7_n_0 ;
  wire \TEC[7]_i_1_n_0 ;
  wire \TEC[7]_i_2_n_0 ;
  wire \TEC[7]_i_3_n_0 ;
  wire \TEC[7]_i_4_n_0 ;
  wire \TEC[7]_i_5_n_0 ;
  wire \TEC[7]_i_6_n_0 ;
  wire \TEC[8]_i_10_n_0 ;
  wire \TEC[8]_i_11_0 ;
  wire \TEC[8]_i_11_n_0 ;
  wire \TEC[8]_i_12_n_0 ;
  wire \TEC[8]_i_13_n_0 ;
  wire \TEC[8]_i_14_n_0 ;
  wire \TEC[8]_i_15_n_0 ;
  wire \TEC[8]_i_16_n_0 ;
  wire \TEC[8]_i_17_n_0 ;
  wire \TEC[8]_i_18_n_0 ;
  wire \TEC[8]_i_19_n_0 ;
  wire \TEC[8]_i_1_n_0 ;
  wire \TEC[8]_i_20_n_0 ;
  wire \TEC[8]_i_21_n_0 ;
  wire \TEC[8]_i_2_n_0 ;
  wire \TEC[8]_i_4_n_0 ;
  wire \TEC[8]_i_5_n_0 ;
  wire \TEC[8]_i_6_n_0 ;
  wire \TEC[8]_i_7_n_0 ;
  wire \TEC[8]_i_8_n_0 ;
  wire \TEC[8]_i_9_n_0 ;
  wire \TEC_reg[0]_0 ;
  wire \TEC_reg[0]_1 ;
  wire \TECin[8]_i_2_n_0 ;
  wire \TECin[8]_i_3_n_0 ;
  wire \TECin_reg_n_0_[7] ;
  wire \TECin_reg_n_0_[8] ;
  wire TX;
  wire \TXSTATES_reg[2] ;
  wire \TXSTATES_reg[3] ;
  wire TX_from_Err;
  wire TXpin_i_1_n_0;
  wire TXpin_i_2_n_0;
  wire TXpin_i_3_n_0;
  wire TXpin_i_4_n_0;
  wire TXpin_reg_0;
  wire ack_error;
  wire ack_error_i_1_n_0;
  wire ack_error_i_3_n_0;
  wire ack_error_i_4_n_0;
  wire ack_error_reg_0;
  wire ack_error_reg_1;
  wire ack_error_reg_2;
  wire ack_error_reg_3;
  wire ack_error_reg_n_0;
  wire clk;
  wire donefromrxr;
  wire donefromrxr_reg_n_0;
  wire donefromtxr;
  wire donefromtxr_reg_n_0;
  wire imTX;
  wire lastvalue;
  wire lastvalue_reg_0;
  wire nozero_i_1_n_0;
  wire nozero_reg_n_0;
  wire q;
  wire q_reg;
  wire req_Error_RX;

  assign Mode_0_1_sp_1 = Mode_0_1_sn_1;
  (* SOFT_HLUTNM = "soft_lutpair139" *) 
  LUT2 #(
    .INIT(4'h2)) 
    CANCORE_1_i_1
       (.I0(TX),
        .I1(Mode_0_1_sn_1),
        .O(RX));
  (* SOFT_HLUTNM = "soft_lutpair122" *) 
  LUT4 #(
    .INIT(16'h00A2)) 
    CANCORE_1_i_2
       (.I0(\D_Len[0]_i_3_n_0 ),
        .I1(Mode_0[1]),
        .I2(Mode_0[2]),
        .I3(Mode_0[0]),
        .O(Mode_0_1_sn_1));
  (* SOFT_HLUTNM = "soft_lutpair139" *) 
  LUT4 #(
    .INIT(16'h4000)) 
    \CNT1[4]_i_3 
       (.I0(Mode_0_1_sn_1),
        .I1(Sampled_din),
        .I2(RXBUS_d),
        .I3(q_reg),
        .O(RXOUT_reg));
  LUT6 #(
    .INIT(64'hBB33BB30BB33BB33)) 
    \Cnt[0]_i_1__1 
       (.I0(\Cnt[0]_i_2__1_n_0 ),
        .I1(\Cnt_reg_n_0_[0] ),
        .I2(\Cnt[0]_i_3__1_n_0 ),
        .I3(\Cnt[0]_i_4__1_n_0 ),
        .I4(\Cnt[0]_i_5__0_n_0 ),
        .I5(\Cnt[0]_i_6_n_0 ),
        .O(Cntr[0]));
  LUT6 #(
    .INIT(64'h0000FFFEFFFE0000)) 
    \Cnt[0]_i_2__1 
       (.I0(\TECin_reg_n_0_[7] ),
        .I1(\RECin_reg_n_0_[8] ),
        .I2(\TECin_reg_n_0_[8] ),
        .I3(\RECin_reg_n_0_[7] ),
        .I4(lastvalue),
        .I5(Sampled_din),
        .O(\Cnt[0]_i_2__1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair115" *) 
  LUT5 #(
    .INIT(32'h00040804)) 
    \Cnt[0]_i_3__1 
       (.I0(\State_reg[0]_0 ),
        .I1(State[1]),
        .I2(State[2]),
        .I3(Sampled_din),
        .I4(\State[2]_i_8_n_0 ),
        .O(\Cnt[0]_i_3__1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair128" *) 
  LUT4 #(
    .INIT(16'h0010)) 
    \Cnt[0]_i_4__1 
       (.I0(State[2]),
        .I1(State[1]),
        .I2(\State_reg[0]_0 ),
        .I3(\Cnt[3]_i_7__0_n_0 ),
        .O(\Cnt[0]_i_4__1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair127" *) 
  LUT5 #(
    .INIT(32'h00000002)) 
    \Cnt[0]_i_5__0 
       (.I0(ack_error_i_3_n_0),
        .I1(\TECin_reg_n_0_[7] ),
        .I2(\RECin_reg_n_0_[8] ),
        .I3(\TECin_reg_n_0_[8] ),
        .I4(\RECin_reg_n_0_[7] ),
        .O(\Cnt[0]_i_5__0_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair130" *) 
  LUT5 #(
    .INIT(32'hFD7FFD5F)) 
    \Cnt[0]_i_6 
       (.I0(State[2]),
        .I1(State[1]),
        .I2(Sampled_din),
        .I3(\State_reg[0]_0 ),
        .I4(\Reck[6]_i_3_n_0 ),
        .O(\Cnt[0]_i_6_n_0 ));
  LUT5 #(
    .INIT(32'h60666666)) 
    \Cnt[1]_i_1__1 
       (.I0(\Cnt_reg_n_0_[0] ),
        .I1(\Cnt_reg_n_0_[1] ),
        .I2(\Cnt[1]_i_2__1_n_0 ),
        .I3(\Cnt[3]_i_3__0_n_0 ),
        .I4(\Cnt[2]_i_4__1_n_0 ),
        .O(Cntr[1]));
  (* SOFT_HLUTNM = "soft_lutpair130" *) 
  LUT4 #(
    .INIT(16'h0080)) 
    \Cnt[1]_i_2__1 
       (.I0(State[1]),
        .I1(State[2]),
        .I2(Sampled_din),
        .I3(\State_reg[0]_0 ),
        .O(\Cnt[1]_i_2__1_n_0 ));
  LUT6 #(
    .INIT(64'h7878780078787878)) 
    \Cnt[2]_i_1__1 
       (.I0(\Cnt_reg_n_0_[1] ),
        .I1(\Cnt_reg_n_0_[0] ),
        .I2(\Cnt_reg_n_0_[2] ),
        .I3(\Cnt[2]_i_2__1_n_0 ),
        .I4(\Cnt[2]_i_3__1_n_0 ),
        .I5(\Cnt[2]_i_4__1_n_0 ),
        .O(Cntr[2]));
  (* SOFT_HLUTNM = "soft_lutpair131" *) 
  LUT5 #(
    .INIT(32'h00040000)) 
    \Cnt[2]_i_2__1 
       (.I0(\Cnt[3]_i_7__0_n_0 ),
        .I1(\State_reg[0]_0 ),
        .I2(Sampled_din),
        .I3(State[1]),
        .I4(State[2]),
        .O(\Cnt[2]_i_2__1_n_0 ));
  LUT3 #(
    .INIT(8'h08)) 
    \Cnt[2]_i_3__1 
       (.I0(State[2]),
        .I1(Sampled_din),
        .I2(\State_reg[0]_0 ),
        .O(\Cnt[2]_i_3__1_n_0 ));
  LUT6 #(
    .INIT(64'hF1F1F100F100F100)) 
    \Cnt[2]_i_4__1 
       (.I0(\State_reg[0]_0 ),
        .I1(\Cnt[2]_i_5__1_n_0 ),
        .I2(\Cnt[2]_i_6__1_n_0 ),
        .I3(\Cnt[3]_i_4__1_n_0 ),
        .I4(\Cnt[3]_i_10__0_n_0 ),
        .I5(\Cnt[3]_i_7__0_n_0 ),
        .O(\Cnt[2]_i_4__1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair114" *) 
  LUT5 #(
    .INIT(32'h55551555)) 
    \Cnt[2]_i_5__1 
       (.I0(Sampled_din),
        .I1(\Cnt_reg_n_0_[1] ),
        .I2(\Cnt_reg_n_0_[0] ),
        .I3(\Cnt_reg_n_0_[2] ),
        .I4(\Cnt_reg_n_0_[3] ),
        .O(\Cnt[2]_i_5__1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair115" *) 
  LUT5 #(
    .INIT(32'hF8FFFAFF)) 
    \Cnt[2]_i_6__1 
       (.I0(\State_reg[0]_0 ),
        .I1(\State[2]_i_8_n_0 ),
        .I2(State[2]),
        .I3(State[1]),
        .I4(Sampled_din),
        .O(\Cnt[2]_i_6__1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair127" *) 
  LUT4 #(
    .INIT(16'h0001)) 
    \Cnt[3]_i_10__0 
       (.I0(\RECin_reg_n_0_[7] ),
        .I1(\TECin_reg_n_0_[8] ),
        .I2(\RECin_reg_n_0_[8] ),
        .I3(\TECin_reg_n_0_[7] ),
        .O(\Cnt[3]_i_10__0_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair148" *) 
  LUT4 #(
    .INIT(16'h2AAA)) 
    \Cnt[3]_i_11 
       (.I0(\Cnt_reg_n_0_[3] ),
        .I1(\Cnt_reg_n_0_[2] ),
        .I2(\Cnt_reg_n_0_[0] ),
        .I3(\Cnt_reg_n_0_[1] ),
        .O(\Cnt[3]_i_11_n_0 ));
  LUT5 #(
    .INIT(32'hFFFF0770)) 
    \Cnt[3]_i_2__1 
       (.I0(\Cnt[3]_i_3__0_n_0 ),
        .I1(\Cnt[3]_i_4__1_n_0 ),
        .I2(\Cnt_reg_n_0_[3] ),
        .I3(\Cnt[3]_i_5__0_n_0 ),
        .I4(\Cnt[3]_i_6__0_n_0 ),
        .O(Cntr[3]));
  LUT6 #(
    .INIT(64'hFFFFFBFFFFF3FBFF)) 
    \Cnt[3]_i_3__0 
       (.I0(\Reck[6]_i_3_n_0 ),
        .I1(State[2]),
        .I2(State[1]),
        .I3(Sampled_din),
        .I4(\State_reg[0]_0 ),
        .I5(\Cnt[3]_i_7__0_n_0 ),
        .O(\Cnt[3]_i_3__0_n_0 ));
  LUT6 #(
    .INIT(64'h0000D55DFFFFFFFF)) 
    \Cnt[3]_i_4__1 
       (.I0(\Cnt_reg[3]_0 ),
        .I1(\Cnt[3]_i_9__0_n_0 ),
        .I2(\Cnt_reg_n_0_[0] ),
        .I3(\Cnt_reg_n_0_[2] ),
        .I4(\Cnt[3]_i_10__0_n_0 ),
        .I5(ack_error_i_3_n_0),
        .O(\Cnt[3]_i_4__1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair154" *) 
  LUT3 #(
    .INIT(8'h80)) 
    \Cnt[3]_i_5__0 
       (.I0(\Cnt_reg_n_0_[1] ),
        .I1(\Cnt_reg_n_0_[0] ),
        .I2(\Cnt_reg_n_0_[2] ),
        .O(\Cnt[3]_i_5__0_n_0 ));
  LUT6 #(
    .INIT(64'h00E00000A00A0000)) 
    \Cnt[3]_i_6__0 
       (.I0(\Cnt[3]_i_11_n_0 ),
        .I1(\State[2]_i_6_n_0 ),
        .I2(Sampled_din),
        .I3(State[2]),
        .I4(State[1]),
        .I5(\State_reg[0]_0 ),
        .O(\Cnt[3]_i_6__0_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair148" *) 
  LUT4 #(
    .INIT(16'h0008)) 
    \Cnt[3]_i_7__0 
       (.I0(\Cnt_reg_n_0_[0] ),
        .I1(\Cnt_reg_n_0_[2] ),
        .I2(\Cnt_reg_n_0_[3] ),
        .I3(\Cnt_reg_n_0_[1] ),
        .O(\Cnt[3]_i_7__0_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair154" *) 
  LUT2 #(
    .INIT(4'h1)) 
    \Cnt[3]_i_9__0 
       (.I0(\Cnt_reg_n_0_[1] ),
        .I1(\Cnt_reg_n_0_[3] ),
        .O(\Cnt[3]_i_9__0_n_0 ));
  FDCE \Cnt_reg[0] 
       (.C(clk),
        .CE(\Cnt_reg[0]_0 ),
        .CLR(ack_error_reg_0),
        .D(Cntr[0]),
        .Q(\Cnt_reg_n_0_[0] ));
  FDCE \Cnt_reg[1] 
       (.C(clk),
        .CE(\Cnt_reg[0]_0 ),
        .CLR(ack_error_reg_0),
        .D(Cntr[1]),
        .Q(\Cnt_reg_n_0_[1] ));
  FDCE \Cnt_reg[2] 
       (.C(clk),
        .CE(\Cnt_reg[0]_0 ),
        .CLR(ack_error_reg_0),
        .D(Cntr[2]),
        .Q(\Cnt_reg_n_0_[2] ));
  FDCE \Cnt_reg[3] 
       (.C(clk),
        .CE(\Cnt_reg[0]_0 ),
        .CLR(ack_error_reg_0),
        .D(Cntr[3]),
        .Q(\Cnt_reg_n_0_[3] ));
  (* SOFT_HLUTNM = "soft_lutpair122" *) 
  LUT5 #(
    .INIT(32'h00003A33)) 
    \D_Len[0]_i_2 
       (.I0(\D_Len[0]_i_3_n_0 ),
        .I1(q),
        .I2(Mode_0[1]),
        .I3(Mode_0[2]),
        .I4(Mode_0[0]),
        .O(q_reg));
  (* SOFT_HLUTNM = "soft_lutpair135" *) 
  LUT4 #(
    .INIT(16'h4555)) 
    \D_Len[0]_i_3 
       (.I0(Q[8]),
        .I1(\D_Len[0]_i_2_0 ),
        .I2(TX_from_Err),
        .I3(AckTakeOver),
        .O(\D_Len[0]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h0077035533773377)) 
    \REC[0]_i_1 
       (.I0(\REC[1]_i_2_n_0 ),
        .I1(\REC[0]_i_2_n_0 ),
        .I2(\REC_reg[8]_0 [8]),
        .I3(\REC_reg[8]_0 [0]),
        .I4(\REC[8]_i_9_n_0 ),
        .I5(\REC[8]_i_5_n_0 ),
        .O(\REC[0]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h8AFA8A8AFFFFFFFF)) 
    \REC[0]_i_2 
       (.I0(\REC[8]_i_13_n_0 ),
        .I1(\REC[0]_i_3_n_0 ),
        .I2(\REC_reg[8]_0 [0]),
        .I3(\State_reg[0]_1 ),
        .I4(req_Error_RX),
        .I5(\REC[8]_i_6_n_0 ),
        .O(\REC[0]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h1000000000000000)) 
    \REC[0]_i_3 
       (.I0(\REC[0]_i_4_n_0 ),
        .I1(imTX),
        .I2(\REC_reg[8]_0 [8]),
        .I3(\State[2]_i_6_n_0 ),
        .I4(\REC[8]_i_15_n_0 ),
        .I5(\REC[0]_i_2_0 ),
        .O(\REC[0]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000000002)) 
    \REC[0]_i_4 
       (.I0(\REC[5]_i_7_n_0 ),
        .I1(\REC_reg[8]_0 [5]),
        .I2(\REC_reg[8]_0 [0]),
        .I3(\REC_reg[8]_0 [1]),
        .I4(\REC_reg[8]_0 [7]),
        .I5(\REC_reg[8]_0 [6]),
        .O(\REC[0]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h5F7FFF3F55550000)) 
    \REC[1]_i_1 
       (.I0(\REC[1]_i_2_n_0 ),
        .I1(\REC[1]_i_3_n_0 ),
        .I2(\REC[8]_i_5_n_0 ),
        .I3(\REC[8]_i_9_n_0 ),
        .I4(\REC[1]_i_4_n_0 ),
        .I5(\REC[1]_i_5_n_0 ),
        .O(\REC[1]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair141" *) 
  LUT3 #(
    .INIT(8'hEF)) 
    \REC[1]_i_2 
       (.I0(\REC_reg[8]_0 [7]),
        .I1(\REC_reg[8]_0 [8]),
        .I2(\REC[4]_i_6_n_0 ),
        .O(\REC[1]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair159" *) 
  LUT2 #(
    .INIT(4'hB)) 
    \REC[1]_i_3 
       (.I0(\REC_reg[8]_0 [8]),
        .I1(\REC_reg[8]_0 [1]),
        .O(\REC[1]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair157" *) 
  LUT2 #(
    .INIT(4'h9)) 
    \REC[1]_i_4 
       (.I0(\REC_reg[8]_0 [1]),
        .I1(\REC_reg[8]_0 [0]),
        .O(\REC[1]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hFFFF515D00000000)) 
    \REC[1]_i_5 
       (.I0(\REC[8]_i_13_n_0 ),
        .I1(req_Error_RX),
        .I2(\State_reg[0]_1 ),
        .I3(\REC[1]_i_4_n_0 ),
        .I4(\REC[1]_i_6_n_0 ),
        .I5(\REC[8]_i_6_n_0 ),
        .O(\REC[1]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h4F44444400000000)) 
    \REC[1]_i_6 
       (.I0(\REC_reg[8]_0 [8]),
        .I1(\REC[2]_i_7_n_0 ),
        .I2(imTX),
        .I3(\Cnt[0]_i_5__0_n_0 ),
        .I4(Sampled_din),
        .I5(\REC_reg[8]_0 [1]),
        .O(\REC[1]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'hAFBFFFBFAAAAAAAA)) 
    \REC[2]_i_1 
       (.I0(\REC[2]_i_2_n_0 ),
        .I1(\REC[2]_i_3_n_0 ),
        .I2(\REC[8]_i_5_n_0 ),
        .I3(\REC[8]_i_9_n_0 ),
        .I4(\REC[2]_i_4_n_0 ),
        .I5(\REC[2]_i_5_n_0 ),
        .O(\REC[2]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair142" *) 
  LUT4 #(
    .INIT(16'h00E1)) 
    \REC[2]_i_2 
       (.I0(\REC_reg[8]_0 [1]),
        .I1(\REC_reg[8]_0 [0]),
        .I2(\REC_reg[8]_0 [2]),
        .I3(\REC[1]_i_2_n_0 ),
        .O(\REC[2]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair159" *) 
  LUT2 #(
    .INIT(4'hB)) 
    \REC[2]_i_3 
       (.I0(\REC_reg[8]_0 [8]),
        .I1(\REC_reg[8]_0 [2]),
        .O(\REC[2]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair142" *) 
  LUT3 #(
    .INIT(8'h95)) 
    \REC[2]_i_4 
       (.I0(\REC_reg[8]_0 [2]),
        .I1(\REC_reg[8]_0 [0]),
        .I2(\REC_reg[8]_0 [1]),
        .O(\REC[2]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hFFFF515D00000000)) 
    \REC[2]_i_5 
       (.I0(\REC[8]_i_13_n_0 ),
        .I1(req_Error_RX),
        .I2(\State_reg[0]_1 ),
        .I3(\REC[2]_i_4_n_0 ),
        .I4(\REC[2]_i_6_n_0 ),
        .I5(\REC[8]_i_6_n_0 ),
        .O(\REC[2]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h4F44444400000000)) 
    \REC[2]_i_6 
       (.I0(\REC_reg[8]_0 [8]),
        .I1(\REC[2]_i_7_n_0 ),
        .I2(imTX),
        .I3(\Cnt[0]_i_5__0_n_0 ),
        .I4(Sampled_din),
        .I5(\REC_reg[8]_0 [2]),
        .O(\REC[2]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'h0000001000000000)) 
    \REC[2]_i_7 
       (.I0(imTX),
        .I1(State[2]),
        .I2(State[1]),
        .I3(\State_reg[0]_0 ),
        .I4(Sampled_din),
        .I5(\State[2]_i_6_n_0 ),
        .O(\REC[2]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'hFFAFBFBFAAAAAAAA)) 
    \REC[3]_i_1 
       (.I0(\REC[3]_i_2_n_0 ),
        .I1(\REC[3]_i_3_n_0 ),
        .I2(\REC[8]_i_5_n_0 ),
        .I3(\REC[3]_i_4_n_0 ),
        .I4(\REC[8]_i_9_n_0 ),
        .I5(\REC[3]_i_5_n_0 ),
        .O(\REC[3]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h88888882AAAAAAAA)) 
    \REC[3]_i_2 
       (.I0(\REC[4]_i_6_n_0 ),
        .I1(\REC_reg[8]_0 [3]),
        .I2(\REC_reg[8]_0 [2]),
        .I3(\REC_reg[8]_0 [1]),
        .I4(\REC_reg[8]_0 [0]),
        .I5(\REC_reg[8]_1 ),
        .O(\REC[3]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair143" *) 
  LUT2 #(
    .INIT(4'hE)) 
    \REC[3]_i_3 
       (.I0(\REC_reg[8]_0 [8]),
        .I1(\REC_reg[8]_0 [3]),
        .O(\REC[3]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair134" *) 
  LUT4 #(
    .INIT(16'h6AAA)) 
    \REC[3]_i_4 
       (.I0(\REC_reg[8]_0 [3]),
        .I1(\REC_reg[8]_0 [2]),
        .I2(\REC_reg[8]_0 [1]),
        .I3(\REC_reg[8]_0 [0]),
        .O(\REC[3]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hFFCF000055C50000)) 
    \REC[3]_i_5 
       (.I0(\REC[8]_i_13_n_0 ),
        .I1(\REC[3]_i_4_n_0 ),
        .I2(req_Error_RX),
        .I3(\State_reg[0]_1 ),
        .I4(\REC[8]_i_6_n_0 ),
        .I5(\REC[3]_i_6_n_0 ),
        .O(\REC[3]_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair144" *) 
  LUT3 #(
    .INIT(8'h04)) 
    \REC[3]_i_6 
       (.I0(\REC_reg[8]_0 [3]),
        .I1(\REC[8]_i_13_n_0 ),
        .I2(\REC[0]_i_3_n_0 ),
        .O(\REC[3]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'hBABBBAAABBBBBBBB)) 
    \REC[4]_i_1 
       (.I0(\REC[4]_i_2_n_0 ),
        .I1(\REC[4]_i_3_n_0 ),
        .I2(\REC[4]_i_4_n_0 ),
        .I3(\REC[8]_i_9_n_0 ),
        .I4(\REC[4]_i_5_n_0 ),
        .I5(\REC[8]_i_5_n_0 ),
        .O(\REC[4]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h88888288AAAAAAAA)) 
    \REC[4]_i_2 
       (.I0(\REC[4]_i_6_n_0 ),
        .I1(\REC_reg[8]_0 [4]),
        .I2(\REC_reg[8]_0 [3]),
        .I3(\REC[5]_i_8_n_0 ),
        .I4(\REC_reg[8]_0 [2]),
        .I5(\REC_reg[8]_1 ),
        .O(\REC[4]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hBBBBBFBB)) 
    \REC[4]_i_3 
       (.I0(\REC[4]_i_7_n_0 ),
        .I1(\REC[8]_i_6_n_0 ),
        .I2(\State_reg[0]_1 ),
        .I3(req_Error_RX),
        .I4(\REC[4]_i_4_n_0 ),
        .O(\REC[4]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair134" *) 
  LUT5 #(
    .INIT(32'h6AAAAAAA)) 
    \REC[4]_i_4 
       (.I0(\REC_reg[8]_0 [4]),
        .I1(\REC_reg[8]_0 [0]),
        .I2(\REC_reg[8]_0 [1]),
        .I3(\REC_reg[8]_0 [2]),
        .I4(\REC_reg[8]_0 [3]),
        .O(\REC[4]_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair152" *) 
  LUT3 #(
    .INIT(8'h06)) 
    \REC[4]_i_5 
       (.I0(\REC_reg[8]_0 [3]),
        .I1(\REC_reg[8]_0 [4]),
        .I2(\REC_reg[8]_0 [8]),
        .O(\REC[4]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h00000000AA8A0000)) 
    \REC[4]_i_6 
       (.I0(\REC[4]_i_8_n_0 ),
        .I1(\State_reg[0]_0 ),
        .I2(State[2]),
        .I3(State[1]),
        .I4(\REC_reg[0]_0 ),
        .I5(donefromrxr_reg_n_0),
        .O(\REC[4]_i_6_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair144" *) 
  LUT4 #(
    .INIT(16'hA88A)) 
    \REC[4]_i_7 
       (.I0(\REC[8]_i_13_n_0 ),
        .I1(\REC[0]_i_3_n_0 ),
        .I2(\REC_reg[8]_0 [4]),
        .I3(\REC_reg[8]_0 [3]),
        .O(\REC[4]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFBFFFFFFFF)) 
    \REC[4]_i_8 
       (.I0(\REC_reg[8]_0 [6]),
        .I1(\REC_reg[8]_1 ),
        .I2(\REC_reg[8]_0 [1]),
        .I3(\REC_reg[8]_0 [0]),
        .I4(\REC_reg[8]_0 [5]),
        .I5(\REC[5]_i_7_n_0 ),
        .O(\REC[4]_i_8_n_0 ));
  LUT6 #(
    .INIT(64'hBABBBAAABBBBBBBB)) 
    \REC[5]_i_1 
       (.I0(\REC[5]_i_2_n_0 ),
        .I1(\REC[5]_i_3_n_0 ),
        .I2(\REC[5]_i_4_n_0 ),
        .I3(\REC[8]_i_9_n_0 ),
        .I4(\REC[5]_i_5_n_0 ),
        .I5(\REC[8]_i_5_n_0 ),
        .O(\REC[5]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h22AAAAAAA2222222)) 
    \REC[5]_i_2 
       (.I0(\REC[6]_i_7_n_0 ),
        .I1(\REC_reg[8]_1 ),
        .I2(\REC_reg[8]_0 [6]),
        .I3(\REC[5]_i_7_n_0 ),
        .I4(\REC[5]_i_8_n_0 ),
        .I5(\REC_reg[8]_0 [5]),
        .O(\REC[5]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hBBBBBFBB)) 
    \REC[5]_i_3 
       (.I0(\REC[5]_i_9_n_0 ),
        .I1(\REC[8]_i_6_n_0 ),
        .I2(\State_reg[0]_1 ),
        .I3(req_Error_RX),
        .I4(\REC[5]_i_4_n_0 ),
        .O(\REC[5]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h6AAAAAAAAAAAAAAA)) 
    \REC[5]_i_4 
       (.I0(\REC_reg[8]_0 [5]),
        .I1(\REC_reg[8]_0 [0]),
        .I2(\REC_reg[8]_0 [1]),
        .I3(\REC_reg[8]_0 [2]),
        .I4(\REC_reg[8]_0 [4]),
        .I5(\REC_reg[8]_0 [3]),
        .O(\REC[5]_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair120" *) 
  LUT4 #(
    .INIT(16'h1540)) 
    \REC[5]_i_5 
       (.I0(\REC_reg[8]_0 [8]),
        .I1(\REC_reg[8]_0 [4]),
        .I2(\REC_reg[8]_0 [3]),
        .I3(\REC_reg[8]_0 [5]),
        .O(\REC[5]_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair126" *) 
  LUT2 #(
    .INIT(4'h1)) 
    \REC[5]_i_6 
       (.I0(\REC_reg[8]_0 [8]),
        .I1(\REC_reg[8]_0 [7]),
        .O(\REC_reg[8]_1 ));
  (* SOFT_HLUTNM = "soft_lutpair152" *) 
  LUT3 #(
    .INIT(8'h01)) 
    \REC[5]_i_7 
       (.I0(\REC_reg[8]_0 [2]),
        .I1(\REC_reg[8]_0 [3]),
        .I2(\REC_reg[8]_0 [4]),
        .O(\REC[5]_i_7_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair157" *) 
  LUT2 #(
    .INIT(4'h1)) 
    \REC[5]_i_8 
       (.I0(\REC_reg[8]_0 [1]),
        .I1(\REC_reg[8]_0 [0]),
        .O(\REC[5]_i_8_n_0 ));
  LUT5 #(
    .INIT(32'hAAAA8222)) 
    \REC[5]_i_9 
       (.I0(\REC[8]_i_13_n_0 ),
        .I1(\REC_reg[8]_0 [5]),
        .I2(\REC_reg[8]_0 [3]),
        .I3(\REC_reg[8]_0 [4]),
        .I4(\REC[7]_i_7_n_0 ),
        .O(\REC[5]_i_9_n_0 ));
  LUT6 #(
    .INIT(64'hBABBBAAABBBBBBBB)) 
    \REC[6]_i_1 
       (.I0(\REC[6]_i_2_n_0 ),
        .I1(\REC[6]_i_3_n_0 ),
        .I2(\REC[6]_i_4_n_0 ),
        .I3(\REC[8]_i_9_n_0 ),
        .I4(\REC[6]_i_5_n_0 ),
        .I5(\REC[8]_i_5_n_0 ),
        .O(\REC[6]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair126" *) 
  LUT5 #(
    .INIT(32'h88888880)) 
    \REC[6]_i_2 
       (.I0(\REC[6]_i_6_n_0 ),
        .I1(\REC[6]_i_7_n_0 ),
        .I2(\REC_reg[8]_0 [8]),
        .I3(\REC_reg[8]_0 [6]),
        .I4(\REC_reg[8]_0 [7]),
        .O(\REC[6]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFF4004FFFFFFFF)) 
    \REC[6]_i_3 
       (.I0(\State_reg[0]_1 ),
        .I1(req_Error_RX),
        .I2(\REC[6]_i_8_n_0 ),
        .I3(\REC_reg[8]_0 [6]),
        .I4(\REC[6]_i_9_n_0 ),
        .I5(\REC[8]_i_6_n_0 ),
        .O(\REC[6]_i_3_n_0 ));
  LUT5 #(
    .INIT(32'h6AAAAAAA)) 
    \REC[6]_i_4 
       (.I0(\REC_reg[8]_0 [6]),
        .I1(\REC[7]_i_5_n_0 ),
        .I2(\REC_reg[8]_0 [3]),
        .I3(\REC_reg[8]_0 [4]),
        .I4(\REC_reg[8]_0 [5]),
        .O(\REC[6]_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair120" *) 
  LUT5 #(
    .INIT(32'h15554000)) 
    \REC[6]_i_5 
       (.I0(\REC_reg[8]_0 [8]),
        .I1(\REC_reg[8]_0 [3]),
        .I2(\REC_reg[8]_0 [4]),
        .I3(\REC_reg[8]_0 [5]),
        .I4(\REC_reg[8]_0 [6]),
        .O(\REC[6]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFFFD)) 
    \REC[6]_i_6 
       (.I0(\REC[5]_i_7_n_0 ),
        .I1(\REC_reg[8]_0 [5]),
        .I2(\REC_reg[8]_0 [0]),
        .I3(\REC_reg[8]_0 [1]),
        .I4(\REC_reg[8]_0 [7]),
        .I5(\REC_reg[8]_0 [8]),
        .O(\REC[6]_i_6_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair113" *) 
  LUT5 #(
    .INIT(32'h44444044)) 
    \REC[6]_i_7 
       (.I0(donefromrxr_reg_n_0),
        .I1(\REC_reg[0]_0 ),
        .I2(State[1]),
        .I3(State[2]),
        .I4(\State_reg[0]_0 ),
        .O(\REC[6]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'h8000000000000000)) 
    \REC[6]_i_8 
       (.I0(\REC_reg[8]_0 [5]),
        .I1(\REC_reg[8]_0 [4]),
        .I2(\REC_reg[8]_0 [3]),
        .I3(\REC_reg[8]_0 [2]),
        .I4(\REC_reg[8]_0 [1]),
        .I5(\REC_reg[8]_0 [0]),
        .O(\REC[6]_i_8_n_0 ));
  LUT6 #(
    .INIT(64'hAAAAAAAA82222222)) 
    \REC[6]_i_9 
       (.I0(\REC[8]_i_13_n_0 ),
        .I1(\REC_reg[8]_0 [6]),
        .I2(\REC_reg[8]_0 [5]),
        .I3(\REC_reg[8]_0 [4]),
        .I4(\REC_reg[8]_0 [3]),
        .I5(\REC[7]_i_7_n_0 ),
        .O(\REC[6]_i_9_n_0 ));
  LUT6 #(
    .INIT(64'h000000008F8FDF8F)) 
    \REC[7]_i_1 
       (.I0(\REC[8]_i_9_n_0 ),
        .I1(\REC[7]_i_2_n_0 ),
        .I2(\REC[8]_i_5_n_0 ),
        .I3(\REC[7]_i_3_n_0 ),
        .I4(\REC_reg[8]_0 [8]),
        .I5(\REC[7]_i_4_n_0 ),
        .O(\REC[7]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h6AAAAAAAAAAAAAAA)) 
    \REC[7]_i_2 
       (.I0(\REC_reg[8]_0 [7]),
        .I1(\REC_reg[8]_0 [6]),
        .I2(\REC_reg[8]_0 [5]),
        .I3(\REC_reg[8]_0 [4]),
        .I4(\REC_reg[8]_0 [3]),
        .I5(\REC[7]_i_5_n_0 ),
        .O(\REC[7]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair119" *) 
  LUT5 #(
    .INIT(32'h6AAAAAAA)) 
    \REC[7]_i_3 
       (.I0(\REC_reg[8]_0 [7]),
        .I1(\REC_reg[8]_0 [6]),
        .I2(\REC_reg[8]_0 [3]),
        .I3(\REC_reg[8]_0 [4]),
        .I4(\REC_reg[8]_0 [5]),
        .O(\REC[7]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h0404FF04FFFFFFFF)) 
    \REC[7]_i_4 
       (.I0(\State_reg[0]_1 ),
        .I1(req_Error_RX),
        .I2(\REC[7]_i_2_n_0 ),
        .I3(\REC[8]_i_13_n_0 ),
        .I4(\REC[7]_i_6_n_0 ),
        .I5(\REC[8]_i_6_n_0 ),
        .O(\REC[7]_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair118" *) 
  LUT3 #(
    .INIT(8'h80)) 
    \REC[7]_i_5 
       (.I0(\REC_reg[8]_0 [0]),
        .I1(\REC_reg[8]_0 [1]),
        .I2(\REC_reg[8]_0 [2]),
        .O(\REC[7]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h000000007FFF8000)) 
    \REC[7]_i_6 
       (.I0(\REC_reg[8]_0 [5]),
        .I1(\REC_reg[8]_0 [4]),
        .I2(\REC_reg[8]_0 [3]),
        .I3(\REC_reg[8]_0 [6]),
        .I4(\REC_reg[8]_0 [7]),
        .I5(\REC[7]_i_7_n_0 ),
        .O(\REC[7]_i_6_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \REC[7]_i_7 
       (.I0(\REC[8]_i_17_n_0 ),
        .I1(imTX),
        .O(\REC[7]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'h0222AAAAAAAAAAAA)) 
    \REC[8]_i_1 
       (.I0(\Cnt_reg[0]_0 ),
        .I1(imTX),
        .I2(\REC[8]_i_3_n_0 ),
        .I3(\REC[8]_i_4_n_0 ),
        .I4(\REC[8]_i_5_n_0 ),
        .I5(\REC[8]_i_6_n_0 ),
        .O(\REC[8]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair119" *) 
  LUT5 #(
    .INIT(32'h80000000)) 
    \REC[8]_i_10 
       (.I0(\REC_reg[8]_0 [6]),
        .I1(\REC_reg[8]_0 [3]),
        .I2(\REC_reg[8]_0 [4]),
        .I3(\REC_reg[8]_0 [5]),
        .I4(\REC_reg[8]_0 [7]),
        .O(\REC[8]_i_10_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair118" *) 
  LUT5 #(
    .INIT(32'h6AAAAAAA)) 
    \REC[8]_i_11 
       (.I0(\REC_reg[8]_0 [8]),
        .I1(\REC_reg[8]_0 [0]),
        .I2(\REC_reg[8]_0 [1]),
        .I3(\REC_reg[8]_0 [2]),
        .I4(\REC[8]_i_10_n_0 ),
        .O(\REC[8]_i_11_n_0 ));
  LUT5 #(
    .INIT(32'hFBAAEAAA)) 
    \REC[8]_i_12 
       (.I0(\State[2]_i_4_n_0 ),
        .I1(\REC[8]_i_7_0 ),
        .I2(\State_reg[0]_5 ),
        .I3(\State_reg[0]_2 ),
        .I4(Q[8]),
        .O(\REC[8]_i_12_n_0 ));
  LUT6 #(
    .INIT(64'h5054505000040000)) 
    \REC[8]_i_13 
       (.I0(imTX),
        .I1(\State[2]_i_6_n_0 ),
        .I2(Sampled_din),
        .I3(\State_reg[0]_0 ),
        .I4(\REC[8]_i_15_n_0 ),
        .I5(\Cnt[0]_i_5__0_n_0 ),
        .O(\REC[8]_i_13_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair143" *) 
  LUT4 #(
    .INIT(16'h0082)) 
    \REC[8]_i_14 
       (.I0(\REC[8]_i_13_n_0 ),
        .I1(\REC_reg[8]_0 [8]),
        .I2(\REC[8]_i_10_n_0 ),
        .I3(\REC[8]_i_17_n_0 ),
        .O(\REC[8]_i_14_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair138" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \REC[8]_i_15 
       (.I0(State[1]),
        .I1(State[2]),
        .O(\REC[8]_i_15_n_0 ));
  LUT6 #(
    .INIT(64'h0004000000000000)) 
    \REC[8]_i_17 
       (.I0(\REC[0]_i_4_n_0 ),
        .I1(\State[2]_i_6_n_0 ),
        .I2(Sampled_din),
        .I3(\State_reg[0]_0 ),
        .I4(\REC[8]_i_15_n_0 ),
        .I5(\REC_reg[8]_0 [8]),
        .O(\REC[8]_i_17_n_0 ));
  LUT6 #(
    .INIT(64'hBBBBBBBBABAABBBB)) 
    \REC[8]_i_2 
       (.I0(\REC[8]_i_7_n_0 ),
        .I1(\REC[8]_i_8_n_0 ),
        .I2(\REC[8]_i_9_n_0 ),
        .I3(\REC[8]_i_10_n_0 ),
        .I4(\REC[8]_i_5_n_0 ),
        .I5(\REC[8]_i_11_n_0 ),
        .O(\REC[8]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFB8FFFF)) 
    \REC[8]_i_3 
       (.I0(\State[2]_i_3_n_0 ),
        .I1(State[2]),
        .I2(\REC[8]_i_12_n_0 ),
        .I3(\State[1]_i_2_n_0 ),
        .I4(\TEC[8]_i_18_n_0 ),
        .I5(\State[0]_i_2_n_0 ),
        .O(\REC[8]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair131" *) 
  LUT4 #(
    .INIT(16'hDFFF)) 
    \REC[8]_i_4 
       (.I0(Sampled_din),
        .I1(State[1]),
        .I2(State[2]),
        .I3(\State_reg[0]_0 ),
        .O(\REC[8]_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair150" *) 
  LUT3 #(
    .INIT(8'h45)) 
    \REC[8]_i_5 
       (.I0(\REC[8]_i_13_n_0 ),
        .I1(\State_reg[0]_1 ),
        .I2(req_Error_RX),
        .O(\REC[8]_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair113" *) 
  LUT5 #(
    .INIT(32'hBBBBB0BB)) 
    \REC[8]_i_6 
       (.I0(donefromrxr_reg_n_0),
        .I1(\REC_reg[0]_0 ),
        .I2(State[1]),
        .I3(State[2]),
        .I4(\State_reg[0]_0 ),
        .O(\REC[8]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'hAAA888A8AAAAAAAA)) 
    \REC[8]_i_7 
       (.I0(\TEC[8]_i_19_n_0 ),
        .I1(\State[1]_i_2_n_0 ),
        .I2(\REC[8]_i_12_n_0 ),
        .I3(State[2]),
        .I4(\State[2]_i_3_n_0 ),
        .I5(\State[0]_i_2_n_0 ),
        .O(\REC[8]_i_7_n_0 ));
  LUT5 #(
    .INIT(32'hFFFF5575)) 
    \REC[8]_i_8 
       (.I0(\REC[8]_i_6_n_0 ),
        .I1(\State_reg[0]_1 ),
        .I2(req_Error_RX),
        .I3(\REC[8]_i_11_n_0 ),
        .I4(\REC[8]_i_14_n_0 ),
        .O(\REC[8]_i_8_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000001000)) 
    \REC[8]_i_9 
       (.I0(imTX),
        .I1(\State[0]_i_2_n_0 ),
        .I2(\State_reg[0]_0 ),
        .I3(\REC[8]_i_15_n_0 ),
        .I4(\State[1]_i_2_n_0 ),
        .I5(\TEC[8]_i_17_n_0 ),
        .O(\REC[8]_i_9_n_0 ));
  FDCE \REC_reg[0] 
       (.C(clk),
        .CE(\REC[8]_i_1_n_0 ),
        .CLR(ack_error_reg_0),
        .D(\REC[0]_i_1_n_0 ),
        .Q(\REC_reg[8]_0 [0]));
  FDCE \REC_reg[1] 
       (.C(clk),
        .CE(\REC[8]_i_1_n_0 ),
        .CLR(ack_error_reg_0),
        .D(\REC[1]_i_1_n_0 ),
        .Q(\REC_reg[8]_0 [1]));
  FDCE \REC_reg[2] 
       (.C(clk),
        .CE(\REC[8]_i_1_n_0 ),
        .CLR(ack_error_reg_0),
        .D(\REC[2]_i_1_n_0 ),
        .Q(\REC_reg[8]_0 [2]));
  FDCE \REC_reg[3] 
       (.C(clk),
        .CE(\REC[8]_i_1_n_0 ),
        .CLR(ack_error_reg_0),
        .D(\REC[3]_i_1_n_0 ),
        .Q(\REC_reg[8]_0 [3]));
  FDCE \REC_reg[4] 
       (.C(clk),
        .CE(\REC[8]_i_1_n_0 ),
        .CLR(ack_error_reg_0),
        .D(\REC[4]_i_1_n_0 ),
        .Q(\REC_reg[8]_0 [4]));
  FDCE \REC_reg[5] 
       (.C(clk),
        .CE(\REC[8]_i_1_n_0 ),
        .CLR(ack_error_reg_0),
        .D(\REC[5]_i_1_n_0 ),
        .Q(\REC_reg[8]_0 [5]));
  FDCE \REC_reg[6] 
       (.C(clk),
        .CE(\REC[8]_i_1_n_0 ),
        .CLR(ack_error_reg_0),
        .D(\REC[6]_i_1_n_0 ),
        .Q(\REC_reg[8]_0 [6]));
  FDCE \REC_reg[7] 
       (.C(clk),
        .CE(\REC[8]_i_1_n_0 ),
        .CLR(ack_error_reg_0),
        .D(\REC[7]_i_1_n_0 ),
        .Q(\REC_reg[8]_0 [7]));
  FDCE \REC_reg[8] 
       (.C(clk),
        .CE(\REC[8]_i_1_n_0 ),
        .CLR(ack_error_reg_0),
        .D(\REC[8]_i_2_n_0 ),
        .Q(\REC_reg[8]_0 [8]));
  FDCE \RECin_reg[7] 
       (.C(clk),
        .CE(RECin),
        .CLR(ack_error_reg_0),
        .D(\REC_reg[8]_0 [7]),
        .Q(\RECin_reg_n_0_[7] ));
  FDCE \RECin_reg[8] 
       (.C(clk),
        .CE(RECin),
        .CLR(ack_error_reg_0),
        .D(\REC_reg[8]_0 [8]),
        .Q(\RECin_reg_n_0_[8] ));
  LUT1 #(
    .INIT(2'h1)) 
    RXBUS_d_i_1
       (.I0(q_reg),
        .O(RXBUS));
  (* SOFT_HLUTNM = "soft_lutpair145" *) 
  LUT3 #(
    .INIT(8'hB7)) 
    \RXSTATES[0]_i_2 
       (.I0(\State_reg[0]_0 ),
        .I1(State[2]),
        .I2(State[1]),
        .O(\State_reg[0]_3 ));
  (* SOFT_HLUTNM = "soft_lutpair123" *) 
  LUT3 #(
    .INIT(8'h54)) 
    \RXSTATES[0]_i_5 
       (.I0(State[2]),
        .I1(State[1]),
        .I2(\State_reg[0]_0 ),
        .O(\State_reg[2]_0 ));
  LUT6 #(
    .INIT(64'h000000000000800A)) 
    \RXSTATES[1]_i_1 
       (.I0(SRST_0),
        .I1(State[2]),
        .I2(State[1]),
        .I3(\State_reg[0]_0 ),
        .I4(req_Error_RX),
        .I5(\RXSTATES_reg[1] ),
        .O(SRST_0_0));
  (* SOFT_HLUTNM = "soft_lutpair140" *) 
  LUT4 #(
    .INIT(16'h0083)) 
    \RXSTATES[3]_i_3 
       (.I0(State[2]),
        .I1(State[1]),
        .I2(\State_reg[0]_0 ),
        .I3(req_Error_RX),
        .O(\State_reg[2]_1 ));
  (* SOFT_HLUTNM = "soft_lutpair153" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \Reck[0]_i_1 
       (.I0(\Reck[4]_i_2_n_0 ),
        .I1(\Reck_reg_n_0_[0] ),
        .O(Reckr[0]));
  (* SOFT_HLUTNM = "soft_lutpair153" *) 
  LUT3 #(
    .INIT(8'h28)) 
    \Reck[1]_i_1 
       (.I0(\Reck[4]_i_2_n_0 ),
        .I1(\Reck_reg_n_0_[1] ),
        .I2(\Reck_reg_n_0_[0] ),
        .O(Reckr[1]));
  (* SOFT_HLUTNM = "soft_lutpair129" *) 
  LUT4 #(
    .INIT(16'h2A80)) 
    \Reck[2]_i_1 
       (.I0(\Reck[4]_i_2_n_0 ),
        .I1(\Reck_reg_n_0_[0] ),
        .I2(\Reck_reg_n_0_[1] ),
        .I3(\Reck_reg_n_0_[2] ),
        .O(Reckr[2]));
  (* SOFT_HLUTNM = "soft_lutpair129" *) 
  LUT5 #(
    .INIT(32'h2AAA8000)) 
    \Reck[3]_i_1 
       (.I0(\Reck[4]_i_2_n_0 ),
        .I1(\Reck_reg_n_0_[1] ),
        .I2(\Reck_reg_n_0_[0] ),
        .I3(\Reck_reg_n_0_[2] ),
        .I4(\Reck_reg_n_0_[3] ),
        .O(Reckr[3]));
  LUT6 #(
    .INIT(64'h2AAAAAAA80000000)) 
    \Reck[4]_i_1 
       (.I0(\Reck[4]_i_2_n_0 ),
        .I1(\Reck_reg_n_0_[3] ),
        .I2(\Reck_reg_n_0_[2] ),
        .I3(\Reck_reg_n_0_[0] ),
        .I4(\Reck_reg_n_0_[1] ),
        .I5(\Reck_reg_n_0_[4] ),
        .O(Reckr[4]));
  (* SOFT_HLUTNM = "soft_lutpair145" *) 
  LUT4 #(
    .INIT(16'h0400)) 
    \Reck[4]_i_2 
       (.I0(State[1]),
        .I1(State[2]),
        .I2(\State_reg[0]_0 ),
        .I3(\State[2]_i_7_n_0 ),
        .O(\Reck[4]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair123" *) 
  LUT5 #(
    .INIT(32'h00101000)) 
    \Reck[5]_i_1 
       (.I0(State[1]),
        .I1(\State_reg[0]_0 ),
        .I2(State[2]),
        .I3(\Reck_reg_n_0_[5] ),
        .I4(\Reck[5]_i_2_n_0 ),
        .O(Reckr[5]));
  LUT5 #(
    .INIT(32'h80000000)) 
    \Reck[5]_i_2 
       (.I0(\Reck_reg_n_0_[4] ),
        .I1(\Reck_reg_n_0_[1] ),
        .I2(\Reck_reg_n_0_[0] ),
        .I3(\Reck_reg_n_0_[2] ),
        .I4(\Reck_reg_n_0_[3] ),
        .O(\Reck[5]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAAAAAAAAAA80AAAA)) 
    \Reck[6]_i_1 
       (.I0(\Cnt_reg[0]_0 ),
        .I1(\Reck[6]_i_3_n_0 ),
        .I2(Sampled_din),
        .I3(\State_reg[0]_0 ),
        .I4(State[2]),
        .I5(State[1]),
        .O(Reck));
  (* SOFT_HLUTNM = "soft_lutpair124" *) 
  LUT5 #(
    .INIT(32'h01100000)) 
    \Reck[6]_i_2 
       (.I0(State[1]),
        .I1(\State_reg[0]_0 ),
        .I2(\Reck_reg_n_0_[6] ),
        .I3(\Reck[6]_i_4_n_0 ),
        .I4(State[2]),
        .O(Reckr[6]));
  (* SOFT_HLUTNM = "soft_lutpair147" *) 
  LUT4 #(
    .INIT(16'h1000)) 
    \Reck[6]_i_3 
       (.I0(\Cnt_reg_n_0_[0] ),
        .I1(\Cnt_reg_n_0_[2] ),
        .I2(\Cnt_reg_n_0_[3] ),
        .I3(\Cnt_reg_n_0_[1] ),
        .O(\Reck[6]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h8000000000000000)) 
    \Reck[6]_i_4 
       (.I0(\Reck_reg_n_0_[3] ),
        .I1(\Reck_reg_n_0_[2] ),
        .I2(\Reck_reg_n_0_[0] ),
        .I3(\Reck_reg_n_0_[1] ),
        .I4(\Reck_reg_n_0_[4] ),
        .I5(\Reck_reg_n_0_[5] ),
        .O(\Reck[6]_i_4_n_0 ));
  FDCE \Reck_reg[0] 
       (.C(clk),
        .CE(Reck),
        .CLR(ack_error_reg_0),
        .D(Reckr[0]),
        .Q(\Reck_reg_n_0_[0] ));
  FDCE \Reck_reg[1] 
       (.C(clk),
        .CE(Reck),
        .CLR(ack_error_reg_0),
        .D(Reckr[1]),
        .Q(\Reck_reg_n_0_[1] ));
  FDCE \Reck_reg[2] 
       (.C(clk),
        .CE(Reck),
        .CLR(ack_error_reg_0),
        .D(Reckr[2]),
        .Q(\Reck_reg_n_0_[2] ));
  FDCE \Reck_reg[3] 
       (.C(clk),
        .CE(Reck),
        .CLR(ack_error_reg_0),
        .D(Reckr[3]),
        .Q(\Reck_reg_n_0_[3] ));
  FDCE \Reck_reg[4] 
       (.C(clk),
        .CE(Reck),
        .CLR(ack_error_reg_0),
        .D(Reckr[4]),
        .Q(\Reck_reg_n_0_[4] ));
  FDCE \Reck_reg[5] 
       (.C(clk),
        .CE(Reck),
        .CLR(ack_error_reg_0),
        .D(Reckr[5]),
        .Q(\Reck_reg_n_0_[5] ));
  FDCE \Reck_reg[6] 
       (.C(clk),
        .CE(Reck),
        .CLR(ack_error_reg_0),
        .D(Reckr[6]),
        .Q(\Reck_reg_n_0_[6] ));
  LUT6 #(
    .INIT(64'h0404040404440404)) 
    \State[0]_i_1 
       (.I0(\State[0]_i_2_n_0 ),
        .I1(SRST_0),
        .I2(Q[8]),
        .I3(State[1]),
        .I4(State[2]),
        .I5(\State_reg[0]_0 ),
        .O(\State[0]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h00000000AABABBBA)) 
    \State[0]_i_2 
       (.I0(\State[0]_i_3_n_0 ),
        .I1(\State_reg[0]_0 ),
        .I2(Q[8]),
        .I3(\State_reg[0]_4 ),
        .I4(\State_reg[0]_5 ),
        .I5(\State[0]_i_5_n_0 ),
        .O(\State[0]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair128" *) 
  LUT5 #(
    .INIT(32'hEEEEFEEE)) 
    \State[0]_i_3 
       (.I0(State[1]),
        .I1(State[2]),
        .I2(\State_reg[0]_0 ),
        .I3(\Cnt[3]_i_7__0_n_0 ),
        .I4(\Cnt[0]_i_2__1_n_0 ),
        .O(\State[0]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair125" *) 
  LUT5 #(
    .INIT(32'hFFFF4440)) 
    \State[0]_i_5 
       (.I0(\State[0]_i_8_n_0 ),
        .I1(State[2]),
        .I2(State[1]),
        .I3(\State_reg[0]_0 ),
        .I4(\State[0]_i_9_n_0 ),
        .O(\State[0]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hFFBAFFBAF0BAF000)) 
    \State[0]_i_8 
       (.I0(\State_reg[0]_0 ),
        .I1(\State[2]_i_6_n_0 ),
        .I2(Q[8]),
        .I3(Sampled_din),
        .I4(\Cnt[3]_i_7__0_n_0 ),
        .I5(State[1]),
        .O(\State[0]_i_8_n_0 ));
  LUT6 #(
    .INIT(64'h0440440004404440)) 
    \State[0]_i_9 
       (.I0(State[2]),
        .I1(State[1]),
        .I2(\State_reg[0]_0 ),
        .I3(Sampled_din),
        .I4(\State[2]_i_8_n_0 ),
        .I5(Q[8]),
        .O(\State[0]_i_9_n_0 ));
  LUT6 #(
    .INIT(64'h0808080808880808)) 
    \State[1]_i_1 
       (.I0(\State[1]_i_2_n_0 ),
        .I1(SRST_0),
        .I2(Q[8]),
        .I3(State[1]),
        .I4(State[2]),
        .I5(\State_reg[0]_0 ),
        .O(\State[1]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF33333F77)) 
    \State[1]_i_2 
       (.I0(\State[1]_i_3_n_0 ),
        .I1(\State[1]_i_4_n_0 ),
        .I2(\State_reg[0]_0 ),
        .I3(State[1]),
        .I4(State[2]),
        .I5(\State[1]_i_5_n_0 ),
        .O(\State[1]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'h06FFFFFF)) 
    \State[1]_i_3 
       (.I0(Sampled_din),
        .I1(lastvalue),
        .I2(\Cnt[3]_i_10__0_n_0 ),
        .I3(\Cnt[3]_i_7__0_n_0 ),
        .I4(\State_reg[0]_0 ),
        .O(\State[1]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hFFF3BFFFFFFFBFFF)) 
    \State[1]_i_4 
       (.I0(\State[2]_i_6_n_0 ),
        .I1(State[2]),
        .I2(State[1]),
        .I3(Sampled_din),
        .I4(\State_reg[0]_0 ),
        .I5(\Cnt[3]_i_7__0_n_0 ),
        .O(\State[1]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h8888888880888888)) 
    \State[1]_i_5 
       (.I0(Sampled_din),
        .I1(\REC[8]_i_15_n_0 ),
        .I2(\Cnt_reg_n_0_[0] ),
        .I3(\Cnt_reg_n_0_[1] ),
        .I4(\Cnt_reg_n_0_[2] ),
        .I5(\Cnt_reg_n_0_[3] ),
        .O(\State[1]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hA8AAA8AAA8AAA888)) 
    \State[2]_i_1 
       (.I0(SRST_0),
        .I1(\State[2]_i_2_n_0 ),
        .I2(\State[2]_i_3_n_0 ),
        .I3(State[2]),
        .I4(\State[2]_i_4_n_0 ),
        .I5(\State[2]_i_5_n_0 ),
        .O(\State[2]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair146" *) 
  LUT4 #(
    .INIT(16'hAA8A)) 
    \State[2]_i_2 
       (.I0(Q[8]),
        .I1(State[1]),
        .I2(State[2]),
        .I3(\State_reg[0]_0 ),
        .O(\State[2]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h3077304433FB33FB)) 
    \State[2]_i_3 
       (.I0(\State[2]_i_6_n_0 ),
        .I1(State[1]),
        .I2(Q[8]),
        .I3(\State_reg[0]_0 ),
        .I4(\State[2]_i_7_n_0 ),
        .I5(Sampled_din),
        .O(\State[2]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair132" *) 
  LUT5 #(
    .INIT(32'h08080800)) 
    \State[2]_i_4 
       (.I0(State[1]),
        .I1(\State_reg[0]_0 ),
        .I2(Sampled_din),
        .I3(\State[2]_i_8_n_0 ),
        .I4(Q[8]),
        .O(\State[2]_i_4_n_0 ));
  LUT5 #(
    .INIT(32'h888888C0)) 
    \State[2]_i_5 
       (.I0(Q[8]),
        .I1(\State_reg[0]_2 ),
        .I2(\State_reg[0]_5 ),
        .I3(\TEC_reg[0]_0 ),
        .I4(req_Error_RX),
        .O(\State[2]_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair114" *) 
  LUT4 #(
    .INIT(16'h4000)) 
    \State[2]_i_6 
       (.I0(\Cnt_reg_n_0_[3] ),
        .I1(\Cnt_reg_n_0_[2] ),
        .I2(\Cnt_reg_n_0_[0] ),
        .I3(\Cnt_reg_n_0_[1] ),
        .O(\State[2]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFF7FFF)) 
    \State[2]_i_7 
       (.I0(\Reck[6]_i_4_n_0 ),
        .I1(\Reck_reg_n_0_[6] ),
        .I2(\Cnt_reg_n_0_[1] ),
        .I3(\Cnt_reg_n_0_[3] ),
        .I4(\Cnt_reg_n_0_[2] ),
        .I5(\Cnt_reg_n_0_[0] ),
        .O(\State[2]_i_7_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair147" *) 
  LUT4 #(
    .INIT(16'h0040)) 
    \State[2]_i_8 
       (.I0(\Cnt_reg_n_0_[3] ),
        .I1(\Cnt_reg_n_0_[2] ),
        .I2(\Cnt_reg_n_0_[1] ),
        .I3(\Cnt_reg_n_0_[0] ),
        .O(\State[2]_i_8_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair132" *) 
  LUT2 #(
    .INIT(4'h1)) 
    \State[2]_i_9 
       (.I0(\State_reg[0]_0 ),
        .I1(State[1]),
        .O(\State_reg[0]_2 ));
  FDCE \State_reg[0] 
       (.C(clk),
        .CE(E),
        .CLR(ack_error_reg_0),
        .D(\State[0]_i_1_n_0 ),
        .Q(\State_reg[0]_0 ));
  FDCE \State_reg[1] 
       (.C(clk),
        .CE(E),
        .CLR(ack_error_reg_0),
        .D(\State[1]_i_1_n_0 ),
        .Q(State[1]));
  FDCE \State_reg[2] 
       (.C(clk),
        .CE(E),
        .CLR(ack_error_reg_0),
        .D(\State[2]_i_1_n_0 ),
        .Q(State[2]));
  LUT6 #(
    .INIT(64'hBB33BB33AA33AB00)) 
    \TEC[0]_i_1 
       (.I0(\TEC[0]_i_2_n_0 ),
        .I1(\TEC[0]_i_3_n_0 ),
        .I2(Q[8]),
        .I3(Q[0]),
        .I4(\TEC[8]_i_7_n_0 ),
        .I5(\TEC[8]_i_6_n_0 ),
        .O(\TEC[0]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair136" *) 
  LUT4 #(
    .INIT(16'hA082)) 
    \TEC[0]_i_2 
       (.I0(\TEC_reg[0]_0 ),
        .I1(State[1]),
        .I2(State[2]),
        .I3(\State_reg[0]_0 ),
        .O(\TEC[0]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFEFEFEFEEEEEEEE)) 
    \TEC[0]_i_3 
       (.I0(\TEC[8]_i_14_n_0 ),
        .I1(\TEC[8]_i_19_n_0 ),
        .I2(Q[0]),
        .I3(Q[8]),
        .I4(\TEC[8]_i_16_n_0 ),
        .I5(\TEC[8]_i_6_n_0 ),
        .O(\TEC[0]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hBBBBBBBBAAABBBAB)) 
    \TEC[1]_i_1 
       (.I0(\TEC[1]_i_2_n_0 ),
        .I1(\TEC[1]_i_3_n_0 ),
        .I2(\TEC[1]_i_4_n_0 ),
        .I3(\TEC[8]_i_7_n_0 ),
        .I4(\TEC[1]_i_5_n_0 ),
        .I5(\TEC[8]_i_6_n_0 ),
        .O(\TEC[1]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair156" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \TEC[1]_i_2 
       (.I0(Q[1]),
        .I1(\TEC[0]_i_2_n_0 ),
        .O(\TEC[1]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFEFEFEFEEEEEEEE)) 
    \TEC[1]_i_3 
       (.I0(\TEC[8]_i_14_n_0 ),
        .I1(\TEC[8]_i_19_n_0 ),
        .I2(Q[1]),
        .I3(Q[8]),
        .I4(\TEC[8]_i_16_n_0 ),
        .I5(\TEC[8]_i_6_n_0 ),
        .O(\TEC[1]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair158" *) 
  LUT2 #(
    .INIT(4'hB)) 
    \TEC[1]_i_4 
       (.I0(Q[8]),
        .I1(Q[1]),
        .O(\TEC[1]_i_4_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \TEC[1]_i_5 
       (.I0(Q[0]),
        .I1(Q[1]),
        .O(\TEC[1]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hBBBBBBBBABAAABBB)) 
    \TEC[2]_i_1 
       (.I0(\TEC[2]_i_2_n_0 ),
        .I1(\TEC[2]_i_3_n_0 ),
        .I2(\TEC[2]_i_4_n_0 ),
        .I3(\TEC[8]_i_7_n_0 ),
        .I4(\TEC[2]_i_5_n_0 ),
        .I5(\TEC[8]_i_6_n_0 ),
        .O(\TEC[2]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair156" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \TEC[2]_i_2 
       (.I0(\TEC[0]_i_2_n_0 ),
        .I1(Q[2]),
        .O(\TEC[2]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFEFEFEFEEEEEEEE)) 
    \TEC[2]_i_3 
       (.I0(\TEC[8]_i_14_n_0 ),
        .I1(\TEC[8]_i_19_n_0 ),
        .I2(Q[2]),
        .I3(Q[8]),
        .I4(\TEC[8]_i_16_n_0 ),
        .I5(\TEC[8]_i_6_n_0 ),
        .O(\TEC[2]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair151" *) 
  LUT3 #(
    .INIT(8'h56)) 
    \TEC[2]_i_4 
       (.I0(Q[2]),
        .I1(Q[1]),
        .I2(Q[0]),
        .O(\TEC[2]_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair158" *) 
  LUT2 #(
    .INIT(4'hB)) 
    \TEC[2]_i_5 
       (.I0(Q[8]),
        .I1(Q[2]),
        .O(\TEC[2]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hBBBBBBBBAAABBBAB)) 
    \TEC[3]_i_1 
       (.I0(\TEC[3]_i_2_n_0 ),
        .I1(\TEC[3]_i_3_n_0 ),
        .I2(\TEC[3]_i_4_n_0 ),
        .I3(\TEC[8]_i_7_n_0 ),
        .I4(\TEC[3]_i_5_n_0 ),
        .I5(\TEC[8]_i_6_n_0 ),
        .O(\TEC[3]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair149" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \TEC[3]_i_2 
       (.I0(\TEC[0]_i_2_n_0 ),
        .I1(Q[3]),
        .O(\TEC[3]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFEFEFEEEEEEEEE)) 
    \TEC[3]_i_3 
       (.I0(\TEC[8]_i_14_n_0 ),
        .I1(\TEC[8]_i_19_n_0 ),
        .I2(Q[3]),
        .I3(Q[8]),
        .I4(\TEC[8]_i_16_n_0 ),
        .I5(\TEC[8]_i_6_n_0 ),
        .O(\TEC[3]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair135" *) 
  LUT2 #(
    .INIT(4'hE)) 
    \TEC[3]_i_4 
       (.I0(Q[8]),
        .I1(Q[3]),
        .O(\TEC[3]_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair133" *) 
  LUT4 #(
    .INIT(16'h5556)) 
    \TEC[3]_i_5 
       (.I0(Q[3]),
        .I1(Q[2]),
        .I2(Q[0]),
        .I3(Q[1]),
        .O(\TEC[3]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hBBBBBBBBAABABBBA)) 
    \TEC[4]_i_1 
       (.I0(\TEC[4]_i_2_n_0 ),
        .I1(\TEC[4]_i_3_n_0 ),
        .I2(\TEC[4]_i_4_n_0 ),
        .I3(\TEC[8]_i_7_n_0 ),
        .I4(\TEC[4]_i_5_n_0 ),
        .I5(\TEC[8]_i_6_n_0 ),
        .O(\TEC[4]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair149" *) 
  LUT3 #(
    .INIT(8'h28)) 
    \TEC[4]_i_2 
       (.I0(\TEC[0]_i_2_n_0 ),
        .I1(Q[3]),
        .I2(Q[4]),
        .O(\TEC[4]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFEEEFEFFFEEE)) 
    \TEC[4]_i_3 
       (.I0(\TEC[8]_i_14_n_0 ),
        .I1(\TEC[8]_i_19_n_0 ),
        .I2(\TEC[8]_i_15_n_0 ),
        .I3(\TEC[4]_i_6_n_0 ),
        .I4(\TEC[8]_i_16_n_0 ),
        .I5(Q[8]),
        .O(\TEC[4]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair155" *) 
  LUT3 #(
    .INIT(8'h06)) 
    \TEC[4]_i_4 
       (.I0(Q[3]),
        .I1(Q[4]),
        .I2(Q[8]),
        .O(\TEC[4]_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair133" *) 
  LUT5 #(
    .INIT(32'h55555556)) 
    \TEC[4]_i_5 
       (.I0(Q[4]),
        .I1(Q[1]),
        .I2(Q[0]),
        .I3(Q[2]),
        .I4(Q[3]),
        .O(\TEC[4]_i_5_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \TEC[4]_i_6 
       (.I0(Q[4]),
        .I1(Q[3]),
        .O(\TEC[4]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'hBBBBBBBBAAABBBAB)) 
    \TEC[5]_i_1 
       (.I0(\TEC[5]_i_2_n_0 ),
        .I1(\TEC[5]_i_3_n_0 ),
        .I2(\TEC[5]_i_4_n_0 ),
        .I3(\TEC[8]_i_7_n_0 ),
        .I4(\TEC[5]_i_5_n_0 ),
        .I5(\TEC[8]_i_6_n_0 ),
        .O(\TEC[5]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair121" *) 
  LUT4 #(
    .INIT(16'h2A80)) 
    \TEC[5]_i_2 
       (.I0(\TEC[0]_i_2_n_0 ),
        .I1(Q[4]),
        .I2(Q[3]),
        .I3(Q[5]),
        .O(\TEC[5]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00000000FFFFFF04)) 
    \TEC[5]_i_3 
       (.I0(State[1]),
        .I1(State[2]),
        .I2(\State_reg[0]_0 ),
        .I3(\TEC[8]_i_14_n_0 ),
        .I4(\TEC[8]_i_6_n_0 ),
        .I5(\TEC[5]_i_6_n_0 ),
        .O(\TEC[5]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair117" *) 
  LUT4 #(
    .INIT(16'hEABF)) 
    \TEC[5]_i_4 
       (.I0(Q[8]),
        .I1(Q[4]),
        .I2(Q[3]),
        .I3(Q[5]),
        .O(\TEC[5]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h5555555555555556)) 
    \TEC[5]_i_5 
       (.I0(Q[5]),
        .I1(Q[4]),
        .I2(Q[3]),
        .I3(Q[1]),
        .I4(Q[0]),
        .I5(Q[2]),
        .O(\TEC[5]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hABB3300AAAA0000A)) 
    \TEC[5]_i_6 
       (.I0(\TEC[8]_i_15_n_0 ),
        .I1(Q[8]),
        .I2(Q[4]),
        .I3(Q[3]),
        .I4(Q[5]),
        .I5(\TEC[8]_i_16_n_0 ),
        .O(\TEC[5]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'hBBBBBBBBAABABBBA)) 
    \TEC[6]_i_1 
       (.I0(\TEC[6]_i_2_n_0 ),
        .I1(\TEC[6]_i_3_n_0 ),
        .I2(\TEC[6]_i_4_n_0 ),
        .I3(\TEC[8]_i_7_n_0 ),
        .I4(\TEC[6]_i_5_n_0 ),
        .I5(\TEC[8]_i_6_n_0 ),
        .O(\TEC[6]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair121" *) 
  LUT5 #(
    .INIT(32'h2AAA8000)) 
    \TEC[6]_i_2 
       (.I0(\TEC[0]_i_2_n_0 ),
        .I1(Q[3]),
        .I2(Q[4]),
        .I3(Q[5]),
        .I4(Q[6]),
        .O(\TEC[6]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFEEEEEFE)) 
    \TEC[6]_i_3 
       (.I0(\TEC[8]_i_14_n_0 ),
        .I1(\TEC[8]_i_19_n_0 ),
        .I2(\TEC[8]_i_15_n_0 ),
        .I3(\TEC[6]_i_6_n_0 ),
        .I4(Q[6]),
        .I5(\TEC[6]_i_7_n_0 ),
        .O(\TEC[6]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair117" *) 
  LUT5 #(
    .INIT(32'h15554000)) 
    \TEC[6]_i_4 
       (.I0(Q[8]),
        .I1(Q[3]),
        .I2(Q[4]),
        .I3(Q[5]),
        .I4(Q[6]),
        .O(\TEC[6]_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair116" *) 
  LUT5 #(
    .INIT(32'h55565555)) 
    \TEC[6]_i_5 
       (.I0(Q[6]),
        .I1(Q[3]),
        .I2(Q[4]),
        .I3(Q[5]),
        .I4(\TEC[8]_i_12_n_0 ),
        .O(\TEC[6]_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair155" *) 
  LUT3 #(
    .INIT(8'h01)) 
    \TEC[6]_i_6 
       (.I0(Q[3]),
        .I1(Q[4]),
        .I2(Q[5]),
        .O(\TEC[6]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'hAAAAAAAA82222222)) 
    \TEC[6]_i_7 
       (.I0(\TEC[8]_i_16_n_0 ),
        .I1(Q[6]),
        .I2(Q[5]),
        .I3(Q[4]),
        .I4(Q[3]),
        .I5(Q[8]),
        .O(\TEC[6]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF55550151)) 
    \TEC[7]_i_1 
       (.I0(\TEC[7]_i_2_n_0 ),
        .I1(\TEC[7]_i_3_n_0 ),
        .I2(\TEC[8]_i_7_n_0 ),
        .I3(\TEC[7]_i_4_n_0 ),
        .I4(\TEC[8]_i_6_n_0 ),
        .I5(\TEC[7]_i_5_n_0 ),
        .O(\TEC[7]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hFFFEFEFE)) 
    \TEC[7]_i_2 
       (.I0(\TEC[8]_i_14_n_0 ),
        .I1(\TEC[8]_i_19_n_0 ),
        .I2(\TEC[7]_i_6_n_0 ),
        .I3(\TEC[8]_i_16_n_0 ),
        .I4(\TEC[7]_i_3_n_0 ),
        .O(\TEC[7]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hEAAAAAAABFFFFFFF)) 
    \TEC[7]_i_3 
       (.I0(Q[8]),
        .I1(Q[5]),
        .I2(Q[4]),
        .I3(Q[3]),
        .I4(Q[6]),
        .I5(Q[7]),
        .O(\TEC[7]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h5555555655555555)) 
    \TEC[7]_i_4 
       (.I0(Q[7]),
        .I1(Q[5]),
        .I2(Q[4]),
        .I3(Q[3]),
        .I4(Q[6]),
        .I5(\TEC[8]_i_12_n_0 ),
        .O(\TEC[7]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h2AAAAAAA80000000)) 
    \TEC[7]_i_5 
       (.I0(\TEC[0]_i_2_n_0 ),
        .I1(Q[5]),
        .I2(Q[4]),
        .I3(Q[3]),
        .I4(Q[6]),
        .I5(Q[7]),
        .O(\TEC[7]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h00000002AAAAAAA8)) 
    \TEC[7]_i_6 
       (.I0(\TEC[8]_i_15_n_0 ),
        .I1(Q[5]),
        .I2(Q[4]),
        .I3(Q[3]),
        .I4(Q[6]),
        .I5(Q[7]),
        .O(\TEC[7]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'h8888888088888888)) 
    \TEC[8]_i_1 
       (.I0(SRST_0),
        .I1(ack_error_reg_1),
        .I2(\TEC[8]_i_4_n_0 ),
        .I3(\TEC[8]_i_5_n_0 ),
        .I4(\TEC[8]_i_6_n_0 ),
        .I5(\TEC[8]_i_7_n_0 ),
        .O(\TEC[8]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hEAAAAAAAAAAAAAAA)) 
    \TEC[8]_i_10 
       (.I0(Q[8]),
        .I1(Q[7]),
        .I2(Q[5]),
        .I3(Q[4]),
        .I4(Q[3]),
        .I5(Q[6]),
        .O(\TEC[8]_i_10_n_0 ));
  LUT6 #(
    .INIT(64'hFD00FFFFFD00FD00)) 
    \TEC[8]_i_11 
       (.I0(\State[0]_i_2_n_0 ),
        .I1(\TEC[8]_i_17_n_0 ),
        .I2(\State[1]_i_2_n_0 ),
        .I3(\TEC[8]_i_19_n_0 ),
        .I4(\TEC[8]_i_21_n_0 ),
        .I5(\TEC[0]_i_2_n_0 ),
        .O(\TEC[8]_i_11_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair151" *) 
  LUT3 #(
    .INIT(8'h01)) 
    \TEC[8]_i_12 
       (.I0(Q[1]),
        .I1(Q[0]),
        .I2(Q[2]),
        .O(\TEC[8]_i_12_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair116" *) 
  LUT4 #(
    .INIT(16'h0001)) 
    \TEC[8]_i_13 
       (.I0(Q[5]),
        .I1(Q[4]),
        .I2(Q[3]),
        .I3(Q[6]),
        .O(\TEC[8]_i_13_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair136" *) 
  LUT4 #(
    .INIT(16'hAA02)) 
    \TEC[8]_i_14 
       (.I0(\TEC_reg[0]_0 ),
        .I1(\State_reg[0]_0 ),
        .I2(State[1]),
        .I3(State[2]),
        .O(\TEC[8]_i_14_n_0 ));
  LUT6 #(
    .INIT(64'h0200000000000000)) 
    \TEC[8]_i_15 
       (.I0(ack_error_i_4_n_0),
        .I1(\Cnt_reg_n_0_[0] ),
        .I2(\Cnt_reg_n_0_[2] ),
        .I3(ack_error_reg_n_0),
        .I4(nozero_reg_n_0),
        .I5(\Cnt[3]_i_9__0_n_0 ),
        .O(\TEC[8]_i_15_n_0 ));
  LUT6 #(
    .INIT(64'hA0A8A0A000080000)) 
    \TEC[8]_i_16 
       (.I0(imTX),
        .I1(\State[2]_i_6_n_0 ),
        .I2(Sampled_din),
        .I3(\State_reg[0]_0 ),
        .I4(\REC[8]_i_15_n_0 ),
        .I5(\Cnt[0]_i_5__0_n_0 ),
        .O(\TEC[8]_i_16_n_0 ));
  LUT6 #(
    .INIT(64'hB8BBB8BBB8BBB8B8)) 
    \TEC[8]_i_17 
       (.I0(\State[2]_i_3_n_0 ),
        .I1(State[2]),
        .I2(\State[2]_i_4_n_0 ),
        .I3(\TEC[8]_i_11_0 ),
        .I4(Q[8]),
        .I5(\State_reg[0]_4 ),
        .O(\TEC[8]_i_17_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair125" *) 
  LUT3 #(
    .INIT(8'h40)) 
    \TEC[8]_i_18 
       (.I0(State[2]),
        .I1(State[1]),
        .I2(\State_reg[0]_0 ),
        .O(\TEC[8]_i_18_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair124" *) 
  LUT3 #(
    .INIT(8'h04)) 
    \TEC[8]_i_19 
       (.I0(\State_reg[0]_0 ),
        .I1(State[2]),
        .I2(State[1]),
        .O(\TEC[8]_i_19_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF54555444)) 
    \TEC[8]_i_2 
       (.I0(\TEC[8]_i_8_n_0 ),
        .I1(\TEC[8]_i_6_n_0 ),
        .I2(\TEC[8]_i_9_n_0 ),
        .I3(\TEC[8]_i_7_n_0 ),
        .I4(\TEC[8]_i_10_n_0 ),
        .I5(\TEC[8]_i_11_n_0 ),
        .O(\TEC[8]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAAAAAAAAAAAAAAA9)) 
    \TEC[8]_i_20 
       (.I0(Q[8]),
        .I1(Q[7]),
        .I2(Q[5]),
        .I3(Q[4]),
        .I4(Q[3]),
        .I5(Q[6]),
        .O(\TEC[8]_i_20_n_0 ));
  LUT6 #(
    .INIT(64'h9555555555555555)) 
    \TEC[8]_i_21 
       (.I0(Q[8]),
        .I1(Q[7]),
        .I2(Q[5]),
        .I3(Q[4]),
        .I4(Q[3]),
        .I5(Q[6]),
        .O(\TEC[8]_i_21_n_0 ));
  LUT6 #(
    .INIT(64'h00000000FFDF0000)) 
    \TEC[8]_i_4 
       (.I0(\TEC[8]_i_12_n_0 ),
        .I1(Q[7]),
        .I2(\TEC[8]_i_13_n_0 ),
        .I3(Q[8]),
        .I4(\TEC_reg[0]_1 ),
        .I5(donefromtxr_reg_n_0),
        .O(\TEC[8]_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair137" *) 
  LUT4 #(
    .INIT(16'hFF04)) 
    \TEC[8]_i_5 
       (.I0(State[1]),
        .I1(State[2]),
        .I2(\State_reg[0]_0 ),
        .I3(\TEC[8]_i_14_n_0 ),
        .O(\TEC[8]_i_5_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \TEC[8]_i_6 
       (.I0(\TEC[8]_i_15_n_0 ),
        .I1(\TEC[8]_i_16_n_0 ),
        .O(\TEC[8]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'hFFEF0000FFFFFFFF)) 
    \TEC[8]_i_7 
       (.I0(\TEC[8]_i_17_n_0 ),
        .I1(\State[1]_i_2_n_0 ),
        .I2(\TEC[8]_i_18_n_0 ),
        .I3(\State[0]_i_2_n_0 ),
        .I4(\REC[8]_i_4_n_0 ),
        .I5(imTX),
        .O(\TEC[8]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'hEFEEEFFFEEEEEEEE)) 
    \TEC[8]_i_8 
       (.I0(\TEC[8]_i_14_n_0 ),
        .I1(\TEC[8]_i_19_n_0 ),
        .I2(\TEC[8]_i_10_n_0 ),
        .I3(\TEC[8]_i_16_n_0 ),
        .I4(\TEC[8]_i_20_n_0 ),
        .I5(\TEC[8]_i_6_n_0 ),
        .O(\TEC[8]_i_8_n_0 ));
  LUT6 #(
    .INIT(64'hAAAAAAAAAAAAAAA6)) 
    \TEC[8]_i_9 
       (.I0(Q[8]),
        .I1(\TEC[8]_i_13_n_0 ),
        .I2(Q[7]),
        .I3(Q[1]),
        .I4(Q[0]),
        .I5(Q[2]),
        .O(\TEC[8]_i_9_n_0 ));
  FDCE \TEC_reg[0] 
       (.C(clk),
        .CE(\TEC[8]_i_1_n_0 ),
        .CLR(ack_error_reg_0),
        .D(\TEC[0]_i_1_n_0 ),
        .Q(Q[0]));
  FDCE \TEC_reg[1] 
       (.C(clk),
        .CE(\TEC[8]_i_1_n_0 ),
        .CLR(ack_error_reg_0),
        .D(\TEC[1]_i_1_n_0 ),
        .Q(Q[1]));
  FDCE \TEC_reg[2] 
       (.C(clk),
        .CE(\TEC[8]_i_1_n_0 ),
        .CLR(ack_error_reg_0),
        .D(\TEC[2]_i_1_n_0 ),
        .Q(Q[2]));
  FDCE \TEC_reg[3] 
       (.C(clk),
        .CE(\TEC[8]_i_1_n_0 ),
        .CLR(ack_error_reg_0),
        .D(\TEC[3]_i_1_n_0 ),
        .Q(Q[3]));
  FDCE \TEC_reg[4] 
       (.C(clk),
        .CE(\TEC[8]_i_1_n_0 ),
        .CLR(ack_error_reg_0),
        .D(\TEC[4]_i_1_n_0 ),
        .Q(Q[4]));
  FDCE \TEC_reg[5] 
       (.C(clk),
        .CE(\TEC[8]_i_1_n_0 ),
        .CLR(ack_error_reg_0),
        .D(\TEC[5]_i_1_n_0 ),
        .Q(Q[5]));
  FDCE \TEC_reg[6] 
       (.C(clk),
        .CE(\TEC[8]_i_1_n_0 ),
        .CLR(ack_error_reg_0),
        .D(\TEC[6]_i_1_n_0 ),
        .Q(Q[6]));
  FDCE \TEC_reg[7] 
       (.C(clk),
        .CE(\TEC[8]_i_1_n_0 ),
        .CLR(ack_error_reg_0),
        .D(\TEC[7]_i_1_n_0 ),
        .Q(Q[7]));
  FDCE \TEC_reg[8] 
       (.C(clk),
        .CE(\TEC[8]_i_1_n_0 ),
        .CLR(ack_error_reg_0),
        .D(\TEC[8]_i_2_n_0 ),
        .Q(Q[8]));
  LUT5 #(
    .INIT(32'hB0B0B0BB)) 
    \TECin[8]_i_1 
       (.I0(ack_error_reg_1),
        .I1(SRST_0),
        .I2(\TECin[8]_i_2_n_0 ),
        .I3(State[2]),
        .I4(\TECin[8]_i_3_n_0 ),
        .O(RECin));
  LUT6 #(
    .INIT(64'h0A100000FFFFFFFF)) 
    \TECin[8]_i_2 
       (.I0(\State_reg[0]_0 ),
        .I1(\State[2]_i_6_n_0 ),
        .I2(State[1]),
        .I3(Sampled_din),
        .I4(State[2]),
        .I5(SRST_0),
        .O(\TECin[8]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFF0FFFFFFFF1111)) 
    \TECin[8]_i_3 
       (.I0(req_Error_RX),
        .I1(\TEC_reg[0]_0 ),
        .I2(\State[2]_i_8_n_0 ),
        .I3(Sampled_din),
        .I4(\State_reg[0]_0 ),
        .I5(State[1]),
        .O(\TECin[8]_i_3_n_0 ));
  FDCE \TECin_reg[7] 
       (.C(clk),
        .CE(RECin),
        .CLR(ack_error_reg_0),
        .D(Q[7]),
        .Q(\TECin_reg_n_0_[7] ));
  FDCE \TECin_reg[8] 
       (.C(clk),
        .CE(RECin),
        .CLR(ack_error_reg_0),
        .D(Q[8]),
        .Q(\TECin_reg_n_0_[8] ));
  (* SOFT_HLUTNM = "soft_lutpair150" *) 
  LUT3 #(
    .INIT(8'hA8)) 
    \TXSTATES[2]_i_1 
       (.I0(SRST_0),
        .I1(\State_reg[0]_1 ),
        .I2(\TXSTATES_reg[2] ),
        .O(D[0]));
  LUT3 #(
    .INIT(8'hA8)) 
    \TXSTATES[3]_i_2 
       (.I0(SRST_0),
        .I1(\State_reg[0]_1 ),
        .I2(\TXSTATES_reg[3] ),
        .O(D[1]));
  (* SOFT_HLUTNM = "soft_lutpair137" *) 
  LUT4 #(
    .INIT(16'hFF0E)) 
    \TXSTATES[3]_i_3 
       (.I0(\State_reg[0]_0 ),
        .I1(State[1]),
        .I2(State[2]),
        .I3(\TEC_reg[0]_0 ),
        .O(\State_reg[0]_1 ));
  (* SOFT_HLUTNM = "soft_lutpair138" *) 
  LUT4 #(
    .INIT(16'h57F7)) 
    TXpin_i_1
       (.I0(SRST_0),
        .I1(TXpin_i_2_n_0),
        .I2(State[2]),
        .I3(TXpin_i_3_n_0),
        .O(TXpin_i_1_n_0));
  LUT6 #(
    .INIT(64'h88B8BBBB88B88888)) 
    TXpin_i_2
       (.I0(TXpin_i_4_n_0),
        .I1(State[1]),
        .I2(\Cnt[3]_i_10__0_n_0 ),
        .I3(\Cnt[3]_i_7__0_n_0 ),
        .I4(\State_reg[0]_0 ),
        .I5(TXpin_reg_0),
        .O(TXpin_i_2_n_0));
  LUT6 #(
    .INIT(64'h300033030C080C08)) 
    TXpin_i_3
       (.I0(\State[2]_i_6_n_0 ),
        .I1(State[1]),
        .I2(Sampled_din),
        .I3(\REC_reg[7]_0 ),
        .I4(\Cnt[3]_i_7__0_n_0 ),
        .I5(\State_reg[0]_0 ),
        .O(TXpin_i_3_n_0));
  LUT6 #(
    .INIT(64'h4040404040404440)) 
    TXpin_i_4
       (.I0(Sampled_din),
        .I1(\State_reg[0]_0 ),
        .I2(\State[2]_i_8_n_0 ),
        .I3(\REC_reg[8]_1 ),
        .I4(Q[7]),
        .I5(Q[8]),
        .O(TXpin_i_4_n_0));
  (* SOFT_HLUTNM = "soft_lutpair141" *) 
  LUT4 #(
    .INIT(16'h0001)) 
    TXpin_i_6
       (.I0(\REC_reg[8]_0 [7]),
        .I1(\REC_reg[8]_0 [8]),
        .I2(Q[7]),
        .I3(Q[8]),
        .O(\REC_reg[7]_0 ));
  FDPE TXpin_reg
       (.C(clk),
        .CE(E),
        .D(TXpin_i_1_n_0),
        .PRE(ack_error_reg_0),
        .Q(TX_from_Err));
  LUT6 #(
    .INIT(64'hFEFFAAAA0200AAAA)) 
    ack_error_i_1
       (.I0(ack_error),
        .I1(ack_error_i_3_n_0),
        .I2(ack_error_i_4_n_0),
        .I3(ack_error_reg_1),
        .I4(SRST_0),
        .I5(ack_error_reg_n_0),
        .O(ack_error_i_1_n_0));
  LUT6 #(
    .INIT(64'h0000000000000008)) 
    ack_error_i_2
       (.I0(SRST_0),
        .I1(ack_error_reg_2),
        .I2(State[2]),
        .I3(State[1]),
        .I4(\State_reg[0]_0 ),
        .I5(ack_error_reg_3),
        .O(ack_error));
  (* SOFT_HLUTNM = "soft_lutpair140" *) 
  LUT3 #(
    .INIT(8'h02)) 
    ack_error_i_3
       (.I0(\State_reg[0]_0 ),
        .I1(State[1]),
        .I2(State[2]),
        .O(ack_error_i_3_n_0));
  (* SOFT_HLUTNM = "soft_lutpair146" *) 
  LUT3 #(
    .INIT(8'h04)) 
    ack_error_i_4
       (.I0(State[2]),
        .I1(State[1]),
        .I2(\State_reg[0]_0 ),
        .O(ack_error_i_4_n_0));
  FDCE ack_error_reg
       (.C(clk),
        .CE(1'b1),
        .CLR(ack_error_reg_0),
        .D(ack_error_i_1_n_0),
        .Q(ack_error_reg_n_0));
  FDCE donefromrxr_reg
       (.C(clk),
        .CE(E),
        .CLR(ack_error_reg_0),
        .D(donefromrxr),
        .Q(donefromrxr_reg_n_0));
  FDCE donefromtxr_reg
       (.C(clk),
        .CE(E),
        .CLR(ack_error_reg_0),
        .D(donefromtxr),
        .Q(donefromtxr_reg_n_0));
  FDPE lastvalue_reg
       (.C(clk),
        .CE(E),
        .D(lastvalue_reg_0),
        .PRE(ack_error_reg_0),
        .Q(lastvalue));
  LUT6 #(
    .INIT(64'hFFEFEFEFFFFFFFFF)) 
    nozero_i_1
       (.I0(State[2]),
        .I1(State[1]),
        .I2(\State_reg[0]_0 ),
        .I3(Sampled_din),
        .I4(nozero_reg_n_0),
        .I5(SRST_0),
        .O(nozero_i_1_n_0));
  FDPE nozero_reg
       (.C(clk),
        .CE(E),
        .D(nozero_i_1_n_0),
        .PRE(ack_error_reg_0),
        .Q(nozero_reg_n_0));
endmodule

(* ORIG_REF_NAME = "ErrorHandler" *) 
module design_1_FPGAPROJECT_0_0_ErrorHandler_3
   (Q,
    \State_reg[2]_0 ,
    \TEC_reg[8]_0 ,
    \State_reg[2]_1 ,
    \REC_reg[8]_0 ,
    \State_reg[0]_0 ,
    D,
    \State_reg[0]_1 ,
    RXBUS,
    q_reg,
    TX,
    \Mode_1[1] ,
    SRST_1,
    \REC_reg[8]_1 ,
    \State_reg[2]_2 ,
    req_Error_reg,
    \State_reg[2]_3 ,
    \State_reg[0]_2 ,
    \State_reg[0]_3 ,
    lastvalue_reg_0,
    Tq,
    ack_error_reg_0,
    donefromtxr,
    donefromrxr,
    \RECin_reg[7]_0 ,
    \TEC_reg[0]_0 ,
    SRST,
    ack_error_reg_1,
    \State_reg[0]_4 ,
    req_Error_RX,
    \REC_reg[8]_2 ,
    imTX,
    \REC_reg[0]_0 ,
    E,
    \REC[0]_i_3_0 ,
    \REC[0]_i_3_1 ,
    \State_reg[2]_i_2_0 ,
    \State_reg[0]_5 ,
    Sampled_din,
    \TXSTATES_reg[2] ,
    \REC_reg[8]_3 ,
    \TXSTATES_reg[3] ,
    ack_error_reg_2,
    ack_error_reg_3,
    RXBUSs,
    Mode,
    \RXSTATES_reg[1] ,
    \REC_reg[6]_0 ,
    \TEC_reg[0]_1 ,
    AckTakeOver,
    IDE_i_2_0,
    \TXSTATES_reg[0] ,
    \TXSTATES_reg[1] );
  output [8:0]Q;
  output [2:0]\State_reg[2]_0 ;
  output \TEC_reg[8]_0 ;
  output \State_reg[2]_1 ;
  output [8:0]\REC_reg[8]_0 ;
  output \State_reg[0]_0 ;
  output [3:0]D;
  output \State_reg[0]_1 ;
  output RXBUS;
  output q_reg;
  output TX;
  output \Mode_1[1] ;
  output [0:0]SRST_1;
  output \REC_reg[8]_1 ;
  output \State_reg[2]_2 ;
  output req_Error_reg;
  output \State_reg[2]_3 ;
  output \State_reg[0]_2 ;
  input \State_reg[0]_3 ;
  input lastvalue_reg_0;
  input Tq;
  input ack_error_reg_0;
  input donefromtxr;
  input donefromrxr;
  input \RECin_reg[7]_0 ;
  input \TEC_reg[0]_0 ;
  input SRST;
  input ack_error_reg_1;
  input \State_reg[0]_4 ;
  input req_Error_RX;
  input \REC_reg[8]_2 ;
  input imTX;
  input \REC_reg[0]_0 ;
  input [0:0]E;
  input \REC[0]_i_3_0 ;
  input \REC[0]_i_3_1 ;
  input \State_reg[2]_i_2_0 ;
  input \State_reg[0]_5 ;
  input Sampled_din;
  input \TXSTATES_reg[2] ;
  input \REC_reg[8]_3 ;
  input \TXSTATES_reg[3] ;
  input ack_error_reg_2;
  input ack_error_reg_3;
  input RXBUSs;
  input [2:0]Mode;
  input \RXSTATES_reg[1] ;
  input \REC_reg[6]_0 ;
  input \TEC_reg[0]_1 ;
  input AckTakeOver;
  input IDE_i_2_0;
  input \TXSTATES_reg[0] ;
  input \TXSTATES_reg[1] ;

  wire AckTakeOver;
  wire \Cnt[0]_i_2__1_n_0 ;
  wire \Cnt[0]_i_3__1_n_0 ;
  wire \Cnt[0]_i_4__1_n_0 ;
  wire \Cnt[0]_i_5__1_n_0 ;
  wire \Cnt[1]_i_2__1_n_0 ;
  wire \Cnt[1]_i_3__1_n_0 ;
  wire \Cnt[2]_i_2__1_n_0 ;
  wire \Cnt[2]_i_3__1_n_0 ;
  wire \Cnt[3]_i_10_n_0 ;
  wire \Cnt[3]_i_3__1_n_0 ;
  wire \Cnt[3]_i_4__1_n_0 ;
  wire \Cnt[3]_i_5__0_n_0 ;
  wire \Cnt[3]_i_6_n_0 ;
  wire \Cnt[3]_i_7_n_0 ;
  wire \Cnt[3]_i_8_n_0 ;
  wire \Cnt[3]_i_9_n_0 ;
  wire \Cnt_reg_n_0_[0] ;
  wire \Cnt_reg_n_0_[1] ;
  wire \Cnt_reg_n_0_[2] ;
  wire \Cnt_reg_n_0_[3] ;
  wire [3:0]Cntr;
  wire [3:0]D;
  wire [0:0]E;
  wire IDE_i_2_0;
  wire [2:0]Mode;
  wire \Mode_1[1] ;
  wire [8:0]Q;
  wire \REC[0]_i_1_n_0 ;
  wire \REC[0]_i_3_0 ;
  wire \REC[0]_i_3_1 ;
  wire \REC[0]_i_3_n_0 ;
  wire \REC[0]_i_4_n_0 ;
  wire \REC[0]_i_5_n_0 ;
  wire \REC[0]_i_8_n_0 ;
  wire \REC[1]_i_1_n_0 ;
  wire \REC[1]_i_2_n_0 ;
  wire \REC[1]_i_3_n_0 ;
  wire \REC[1]_i_4_n_0 ;
  wire \REC[1]_i_5_n_0 ;
  wire \REC[1]_i_6_n_0 ;
  wire \REC[2]_i_1_n_0 ;
  wire \REC[2]_i_2_n_0 ;
  wire \REC[2]_i_3_n_0 ;
  wire \REC[2]_i_4_n_0 ;
  wire \REC[2]_i_5_n_0 ;
  wire \REC[2]_i_6_n_0 ;
  wire \REC[3]_i_1_n_0 ;
  wire \REC[3]_i_2_n_0 ;
  wire \REC[3]_i_3_n_0 ;
  wire \REC[3]_i_4_n_0 ;
  wire \REC[3]_i_5_n_0 ;
  wire \REC[3]_i_6_n_0 ;
  wire \REC[4]_i_1_n_0 ;
  wire \REC[4]_i_2_n_0 ;
  wire \REC[4]_i_3_n_0 ;
  wire \REC[4]_i_4_n_0 ;
  wire \REC[4]_i_5_n_0 ;
  wire \REC[4]_i_6_n_0 ;
  wire \REC[4]_i_7_n_0 ;
  wire \REC[4]_i_8_n_0 ;
  wire \REC[5]_i_1_n_0 ;
  wire \REC[5]_i_2_n_0 ;
  wire \REC[5]_i_3_n_0 ;
  wire \REC[5]_i_4_n_0 ;
  wire \REC[5]_i_5_n_0 ;
  wire \REC[5]_i_6_n_0 ;
  wire \REC[5]_i_7_n_0 ;
  wire \REC[5]_i_8_n_0 ;
  wire \REC[5]_i_9_n_0 ;
  wire \REC[6]_i_1_n_0 ;
  wire \REC[6]_i_2_n_0 ;
  wire \REC[6]_i_3_n_0 ;
  wire \REC[6]_i_4_n_0 ;
  wire \REC[6]_i_5_n_0 ;
  wire \REC[6]_i_6_n_0 ;
  wire \REC[6]_i_8_n_0 ;
  wire \REC[6]_i_9_n_0 ;
  wire \REC[7]_i_1_n_0 ;
  wire \REC[7]_i_2_n_0 ;
  wire \REC[7]_i_3_n_0 ;
  wire \REC[7]_i_4_n_0 ;
  wire \REC[7]_i_5_n_0 ;
  wire \REC[7]_i_6_n_0 ;
  wire \REC[7]_i_7_n_0 ;
  wire \REC[7]_i_8_n_0 ;
  wire \REC[7]_i_9_n_0 ;
  wire \REC[8]_i_10_n_0 ;
  wire \REC[8]_i_11_n_0 ;
  wire \REC[8]_i_13_n_0 ;
  wire \REC[8]_i_14_n_0 ;
  wire \REC[8]_i_15_n_0 ;
  wire \REC[8]_i_16_n_0 ;
  wire \REC[8]_i_1_n_0 ;
  wire \REC[8]_i_2_n_0 ;
  wire \REC[8]_i_3_n_0 ;
  wire \REC[8]_i_4_n_0 ;
  wire \REC[8]_i_6_n_0 ;
  wire \REC[8]_i_7_n_0 ;
  wire \REC[8]_i_8_n_0 ;
  wire \REC[8]_i_9_n_0 ;
  wire \REC_reg[0]_0 ;
  wire \REC_reg[6]_0 ;
  wire [8:0]\REC_reg[8]_0 ;
  wire \REC_reg[8]_1 ;
  wire \REC_reg[8]_2 ;
  wire \REC_reg[8]_3 ;
  wire [0:0]RECin;
  wire \RECin_reg[7]_0 ;
  wire \RECin_reg_n_0_[7] ;
  wire \RECin_reg_n_0_[8] ;
  wire RXBUS;
  wire RXBUSs;
  wire \RXSTATES_reg[1] ;
  wire [0:0]Reck;
  wire \Reck[4]_i_2_n_0 ;
  wire \Reck[4]_i_3_n_0 ;
  wire \Reck[5]_i_2_n_0 ;
  wire \Reck[6]_i_3_n_0 ;
  wire \Reck[6]_i_4_n_0 ;
  wire \Reck_reg_n_0_[0] ;
  wire \Reck_reg_n_0_[1] ;
  wire \Reck_reg_n_0_[2] ;
  wire \Reck_reg_n_0_[3] ;
  wire \Reck_reg_n_0_[4] ;
  wire \Reck_reg_n_0_[5] ;
  wire \Reck_reg_n_0_[6] ;
  wire [6:0]Reckr;
  wire SRST;
  wire [0:0]SRST_1;
  wire Sampled_din;
  wire \State[0]_i_10_n_0 ;
  wire \State[0]_i_1_n_0 ;
  wire \State[0]_i_2_n_0 ;
  wire \State[0]_i_3_n_0 ;
  wire \State[0]_i_6_n_0 ;
  wire \State[0]_i_9_n_0 ;
  wire \State[1]_i_1_n_0 ;
  wire \State[1]_i_2_n_0 ;
  wire \State[1]_i_3_n_0 ;
  wire \State[1]_i_4_n_0 ;
  wire \State[1]_i_5_n_0 ;
  wire \State[2]_i_1_n_0 ;
  wire \State[2]_i_3_n_0 ;
  wire \State[2]_i_4_n_0 ;
  wire \State_reg[0]_0 ;
  wire \State_reg[0]_1 ;
  wire \State_reg[0]_2 ;
  wire \State_reg[0]_3 ;
  wire \State_reg[0]_4 ;
  wire \State_reg[0]_5 ;
  wire [2:0]\State_reg[2]_0 ;
  wire \State_reg[2]_1 ;
  wire \State_reg[2]_2 ;
  wire \State_reg[2]_3 ;
  wire \State_reg[2]_i_2_0 ;
  wire \State_reg[2]_i_2_n_0 ;
  wire \TEC[0]_i_1_n_0 ;
  wire \TEC[0]_i_2_n_0 ;
  wire \TEC[0]_i_3_n_0 ;
  wire \TEC[0]_i_4_n_0 ;
  wire \TEC[0]_i_5_n_0 ;
  wire \TEC[0]_i_6_n_0 ;
  wire \TEC[1]_i_1_n_0 ;
  wire \TEC[1]_i_2_n_0 ;
  wire \TEC[1]_i_3_n_0 ;
  wire \TEC[1]_i_4_n_0 ;
  wire \TEC[1]_i_5_n_0 ;
  wire \TEC[1]_i_6_n_0 ;
  wire \TEC[2]_i_1_n_0 ;
  wire \TEC[2]_i_2_n_0 ;
  wire \TEC[2]_i_3_n_0 ;
  wire \TEC[2]_i_4_n_0 ;
  wire \TEC[2]_i_5_n_0 ;
  wire \TEC[2]_i_6_n_0 ;
  wire \TEC[3]_i_1_n_0 ;
  wire \TEC[3]_i_2_n_0 ;
  wire \TEC[3]_i_3_n_0 ;
  wire \TEC[3]_i_4_n_0 ;
  wire \TEC[3]_i_5_n_0 ;
  wire \TEC[3]_i_6_n_0 ;
  wire \TEC[4]_i_1_n_0 ;
  wire \TEC[4]_i_2_n_0 ;
  wire \TEC[4]_i_3_n_0 ;
  wire \TEC[4]_i_4_n_0 ;
  wire \TEC[4]_i_5_n_0 ;
  wire \TEC[4]_i_6_n_0 ;
  wire \TEC[4]_i_7_n_0 ;
  wire \TEC[5]_i_1_n_0 ;
  wire \TEC[5]_i_2_n_0 ;
  wire \TEC[5]_i_3_n_0 ;
  wire \TEC[5]_i_4_n_0 ;
  wire \TEC[5]_i_5_n_0 ;
  wire \TEC[5]_i_6_n_0 ;
  wire \TEC[5]_i_7_n_0 ;
  wire \TEC[6]_i_1_n_0 ;
  wire \TEC[6]_i_2_n_0 ;
  wire \TEC[6]_i_3_n_0 ;
  wire \TEC[6]_i_4_n_0 ;
  wire \TEC[6]_i_5_n_0 ;
  wire \TEC[6]_i_6_n_0 ;
  wire \TEC[6]_i_7_n_0 ;
  wire \TEC[6]_i_8_n_0 ;
  wire \TEC[7]_i_1_n_0 ;
  wire \TEC[7]_i_2_n_0 ;
  wire \TEC[7]_i_3_n_0 ;
  wire \TEC[7]_i_4_n_0 ;
  wire \TEC[7]_i_5_n_0 ;
  wire \TEC[7]_i_6_n_0 ;
  wire \TEC[7]_i_7_n_0 ;
  wire \TEC[7]_i_8_n_0 ;
  wire \TEC[8]_i_10_n_0 ;
  wire \TEC[8]_i_11_n_0 ;
  wire \TEC[8]_i_12_n_0 ;
  wire \TEC[8]_i_13_n_0 ;
  wire \TEC[8]_i_15_n_0 ;
  wire \TEC[8]_i_16_n_0 ;
  wire \TEC[8]_i_17_n_0 ;
  wire \TEC[8]_i_18_n_0 ;
  wire \TEC[8]_i_19_n_0 ;
  wire \TEC[8]_i_1_n_0 ;
  wire \TEC[8]_i_20_n_0 ;
  wire \TEC[8]_i_21_n_0 ;
  wire \TEC[8]_i_22_n_0 ;
  wire \TEC[8]_i_2_n_0 ;
  wire \TEC[8]_i_4_n_0 ;
  wire \TEC[8]_i_5_n_0 ;
  wire \TEC[8]_i_6_n_0 ;
  wire \TEC[8]_i_7_n_0 ;
  wire \TEC[8]_i_8_n_0 ;
  wire \TEC[8]_i_9_n_0 ;
  wire \TEC_reg[0]_0 ;
  wire \TEC_reg[0]_1 ;
  wire \TEC_reg[8]_0 ;
  wire \TECin[8]_i_2_n_0 ;
  wire \TECin[8]_i_3_n_0 ;
  wire \TECin_reg_n_0_[7] ;
  wire \TECin_reg_n_0_[8] ;
  wire TX;
  wire \TXSTATES_reg[0] ;
  wire \TXSTATES_reg[1] ;
  wire \TXSTATES_reg[2] ;
  wire \TXSTATES_reg[3] ;
  wire TX_INST_0_i_2_n_0;
  wire TX_from_Err;
  wire TXpin_i_1_n_0;
  wire TXpin_i_2_n_0;
  wire TXpin_i_3_n_0;
  wire TXpin_i_4_n_0;
  wire TXpin_i_5_n_0;
  wire TXpin_i_6_n_0;
  wire Tq;
  wire ack_error;
  wire ack_error_i_1_n_0;
  wire ack_error_i_3_n_0;
  wire ack_error_reg_0;
  wire ack_error_reg_1;
  wire ack_error_reg_2;
  wire ack_error_reg_3;
  wire ack_error_reg_n_0;
  wire donefromrxr;
  wire donefromrxr_reg_n_0;
  wire donefromtxr;
  wire donefromtxr_reg_n_0;
  wire imTX;
  wire lastvalue;
  wire lastvalue_reg_0;
  wire nozero_i_1_n_0;
  wire nozero_reg_n_0;
  wire q_reg;
  wire req_Error_RX;
  wire req_Error_reg;

  LUT5 #(
    .INIT(32'h30007575)) 
    \Cnt[0]_i_1__1 
       (.I0(\Cnt[0]_i_2__1_n_0 ),
        .I1(\Cnt[0]_i_3__1_n_0 ),
        .I2(\Cnt[0]_i_4__1_n_0 ),
        .I3(\Cnt[0]_i_5__1_n_0 ),
        .I4(\Cnt_reg_n_0_[0] ),
        .O(Cntr[0]));
  LUT6 #(
    .INIT(64'hFFAFF0FF03FFFF0F)) 
    \Cnt[0]_i_2__1 
       (.I0(\Cnt[3]_i_9_n_0 ),
        .I1(\Reck[6]_i_3_n_0 ),
        .I2(\State_reg[2]_0 [1]),
        .I3(\State_reg[2]_0 [2]),
        .I4(Sampled_din),
        .I5(\State_reg[2]_0 [0]),
        .O(\Cnt[0]_i_2__1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair30" *) 
  LUT4 #(
    .INIT(16'h0008)) 
    \Cnt[0]_i_3__1 
       (.I0(\Cnt_reg_n_0_[0] ),
        .I1(\Cnt_reg_n_0_[2] ),
        .I2(\Cnt_reg_n_0_[3] ),
        .I3(\Cnt_reg_n_0_[1] ),
        .O(\Cnt[0]_i_3__1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT3 #(
    .INIT(8'h10)) 
    \Cnt[0]_i_4__1 
       (.I0(\State_reg[2]_0 [1]),
        .I1(\State_reg[2]_0 [2]),
        .I2(\State_reg[2]_0 [0]),
        .O(\Cnt[0]_i_4__1_n_0 ));
  LUT6 #(
    .INIT(64'h0000FFFEFFFE0000)) 
    \Cnt[0]_i_5__1 
       (.I0(\TECin_reg_n_0_[7] ),
        .I1(\RECin_reg_n_0_[8] ),
        .I2(\TECin_reg_n_0_[8] ),
        .I3(\RECin_reg_n_0_[7] ),
        .I4(lastvalue),
        .I5(Sampled_din),
        .O(\Cnt[0]_i_5__1_n_0 ));
  LUT5 #(
    .INIT(32'h66606666)) 
    \Cnt[1]_i_1__1 
       (.I0(\Cnt_reg_n_0_[1] ),
        .I1(\Cnt_reg_n_0_[0] ),
        .I2(\Cnt[1]_i_2__1_n_0 ),
        .I3(\Cnt[1]_i_3__1_n_0 ),
        .I4(\Cnt[2]_i_3__1_n_0 ),
        .O(Cntr[1]));
  (* SOFT_HLUTNM = "soft_lutpair14" *) 
  LUT4 #(
    .INIT(16'h0080)) 
    \Cnt[1]_i_2__1 
       (.I0(\State_reg[2]_0 [1]),
        .I1(\State_reg[2]_0 [2]),
        .I2(Sampled_din),
        .I3(\State_reg[2]_0 [0]),
        .O(\Cnt[1]_i_2__1_n_0 ));
  LUT6 #(
    .INIT(64'h00040C0000040000)) 
    \Cnt[1]_i_3__1 
       (.I0(\Cnt[0]_i_3__1_n_0 ),
        .I1(\State_reg[2]_0 [2]),
        .I2(\State_reg[2]_0 [1]),
        .I3(Sampled_din),
        .I4(\State_reg[2]_0 [0]),
        .I5(\Reck[6]_i_3_n_0 ),
        .O(\Cnt[1]_i_3__1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT3 #(
    .INIT(8'h54)) 
    \Cnt[1]_i_7 
       (.I0(\State_reg[2]_0 [2]),
        .I1(\State_reg[2]_0 [1]),
        .I2(\State_reg[2]_0 [0]),
        .O(\State_reg[2]_1 ));
  LUT5 #(
    .INIT(32'h00787878)) 
    \Cnt[2]_i_1__1 
       (.I0(\Cnt_reg_n_0_[0] ),
        .I1(\Cnt_reg_n_0_[1] ),
        .I2(\Cnt_reg_n_0_[2] ),
        .I3(\Cnt[2]_i_2__1_n_0 ),
        .I4(\Cnt[2]_i_3__1_n_0 ),
        .O(Cntr[2]));
  (* SOFT_HLUTNM = "soft_lutpair11" *) 
  LUT5 #(
    .INIT(32'hF0EFFFFF)) 
    \Cnt[2]_i_2__1 
       (.I0(\Cnt[0]_i_3__1_n_0 ),
        .I1(\State_reg[2]_0 [1]),
        .I2(\State_reg[2]_0 [0]),
        .I3(Sampled_din),
        .I4(\State_reg[2]_0 [2]),
        .O(\Cnt[2]_i_2__1_n_0 ));
  LUT6 #(
    .INIT(64'hAAAAAAAAAAAAA8AA)) 
    \Cnt[2]_i_3__1 
       (.I0(\Cnt[3]_i_8_n_0 ),
        .I1(\Cnt[3]_i_3__1_n_0 ),
        .I2(\State_reg[2]_0 [2]),
        .I3(\State_reg[2]_0 [1]),
        .I4(\State_reg[2]_0 [0]),
        .I5(Sampled_din),
        .O(\Cnt[2]_i_3__1_n_0 ));
  LUT6 #(
    .INIT(64'h14FF141414141455)) 
    \Cnt[3]_i_10 
       (.I0(TXpin_i_5_n_0),
        .I1(lastvalue),
        .I2(Sampled_din),
        .I3(\TEC[8]_i_22_n_0 ),
        .I4(\Cnt_reg_n_0_[0] ),
        .I5(\Cnt_reg_n_0_[2] ),
        .O(\Cnt[3]_i_10_n_0 ));
  LUT6 #(
    .INIT(64'hFAF8FA00FAFAFAFA)) 
    \Cnt[3]_i_2__0 
       (.I0(\Cnt[3]_i_3__1_n_0 ),
        .I1(\Cnt[3]_i_4__1_n_0 ),
        .I2(\Cnt[3]_i_5__0_n_0 ),
        .I3(\Cnt[3]_i_6_n_0 ),
        .I4(\Cnt[3]_i_7_n_0 ),
        .I5(\Cnt[3]_i_8_n_0 ),
        .O(Cntr[3]));
  (* SOFT_HLUTNM = "soft_lutpair17" *) 
  LUT4 #(
    .INIT(16'h4000)) 
    \Cnt[3]_i_3__1 
       (.I0(\Cnt_reg_n_0_[3] ),
        .I1(\Cnt_reg_n_0_[2] ),
        .I2(\Cnt_reg_n_0_[1] ),
        .I3(\Cnt_reg_n_0_[0] ),
        .O(\Cnt[3]_i_3__1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT5 #(
    .INIT(32'h00200000)) 
    \Cnt[3]_i_4__1 
       (.I0(\Reck[6]_i_3_n_0 ),
        .I1(\State_reg[2]_0 [0]),
        .I2(Sampled_din),
        .I3(\State_reg[2]_0 [1]),
        .I4(\State_reg[2]_0 [2]),
        .O(\Cnt[3]_i_4__1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair30" *) 
  LUT4 #(
    .INIT(16'h2AAA)) 
    \Cnt[3]_i_5__0 
       (.I0(\Cnt_reg_n_0_[3] ),
        .I1(\Cnt_reg_n_0_[2] ),
        .I2(\Cnt_reg_n_0_[0] ),
        .I3(\Cnt_reg_n_0_[1] ),
        .O(\Cnt[3]_i_5__0_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair11" *) 
  LUT5 #(
    .INIT(32'h00000020)) 
    \Cnt[3]_i_6 
       (.I0(\State_reg[2]_0 [2]),
        .I1(\State_reg[2]_0 [1]),
        .I2(\State_reg[2]_0 [0]),
        .I3(Sampled_din),
        .I4(\Cnt[0]_i_3__1_n_0 ),
        .O(\Cnt[3]_i_6_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT5 #(
    .INIT(32'h0000E00C)) 
    \Cnt[3]_i_7 
       (.I0(\Reck[6]_i_3_n_0 ),
        .I1(\State_reg[2]_0 [1]),
        .I2(\State_reg[2]_0 [2]),
        .I3(Sampled_din),
        .I4(\State_reg[2]_0 [0]),
        .O(\Cnt[3]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFDDF0FFFFFFFF)) 
    \Cnt[3]_i_8 
       (.I0(Sampled_din),
        .I1(\Cnt[3]_i_9_n_0 ),
        .I2(\Cnt[3]_i_10_n_0 ),
        .I3(\State_reg[2]_0 [1]),
        .I4(\State_reg[2]_0 [2]),
        .I5(\State_reg[2]_0 [0]),
        .O(\Cnt[3]_i_8_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair29" *) 
  LUT4 #(
    .INIT(16'h0040)) 
    \Cnt[3]_i_9 
       (.I0(\Cnt_reg_n_0_[3] ),
        .I1(\Cnt_reg_n_0_[2] ),
        .I2(\Cnt_reg_n_0_[1] ),
        .I3(\Cnt_reg_n_0_[0] ),
        .O(\Cnt[3]_i_9_n_0 ));
  FDCE \Cnt_reg[0] 
       (.C(Tq),
        .CE(E),
        .CLR(ack_error_reg_0),
        .D(Cntr[0]),
        .Q(\Cnt_reg_n_0_[0] ));
  FDCE \Cnt_reg[1] 
       (.C(Tq),
        .CE(E),
        .CLR(ack_error_reg_0),
        .D(Cntr[1]),
        .Q(\Cnt_reg_n_0_[1] ));
  FDCE \Cnt_reg[2] 
       (.C(Tq),
        .CE(E),
        .CLR(ack_error_reg_0),
        .D(Cntr[2]),
        .Q(\Cnt_reg_n_0_[2] ));
  FDCE \Cnt_reg[3] 
       (.C(Tq),
        .CE(E),
        .CLR(ack_error_reg_0),
        .D(Cntr[3]),
        .Q(\Cnt_reg_n_0_[3] ));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT5 #(
    .INIT(32'h00003A33)) 
    IDE_i_2
       (.I0(TX_INST_0_i_2_n_0),
        .I1(RXBUSs),
        .I2(Mode[1]),
        .I3(Mode[2]),
        .I4(Mode[0]),
        .O(q_reg));
  LUT6 #(
    .INIT(64'h0051FFFF005100F3)) 
    \REC[0]_i_1 
       (.I0(\REC_reg[0]_0 ),
        .I1(\REC_reg[8]_2 ),
        .I2(\REC[0]_i_3_n_0 ),
        .I3(\REC[0]_i_4_n_0 ),
        .I4(\REC_reg[8]_0 [0]),
        .I5(\REC[1]_i_2_n_0 ),
        .O(\REC[0]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h00000010FFEF0010)) 
    \REC[0]_i_3 
       (.I0(imTX),
        .I1(\State[0]_i_2_n_0 ),
        .I2(\TEC[8]_i_17_n_0 ),
        .I3(\REC[0]_i_5_n_0 ),
        .I4(\REC_reg[8]_0 [0]),
        .I5(\REC_reg[8]_0 [8]),
        .O(\REC[0]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair27" *) 
  LUT4 #(
    .INIT(16'hFBAA)) 
    \REC[0]_i_4 
       (.I0(\REC[8]_i_6_n_0 ),
        .I1(\REC_reg[8]_0 [0]),
        .I2(\REC[7]_i_7_n_0 ),
        .I3(\REC_reg[8]_3 ),
        .O(\REC[0]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFAEAAAAFFAE)) 
    \REC[0]_i_5 
       (.I0(\State[1]_i_2_n_0 ),
        .I1(\REC[0]_i_3_0 ),
        .I2(\REC[0]_i_3_1 ),
        .I3(\REC[0]_i_8_n_0 ),
        .I4(\State_reg[2]_0 [2]),
        .I5(\State[2]_i_4_n_0 ),
        .O(\REC[0]_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair16" *) 
  LUT5 #(
    .INIT(32'h20202000)) 
    \REC[0]_i_8 
       (.I0(\State_reg[2]_0 [0]),
        .I1(Sampled_din),
        .I2(\State_reg[2]_0 [1]),
        .I3(\Cnt[3]_i_9_n_0 ),
        .I4(Q[8]),
        .O(\REC[0]_i_8_n_0 ));
  LUT6 #(
    .INIT(64'h0A3B3A3B3B3B3A3B)) 
    \REC[1]_i_1 
       (.I0(\REC[1]_i_2_n_0 ),
        .I1(\REC[1]_i_3_n_0 ),
        .I2(\REC[1]_i_4_n_0 ),
        .I3(\REC_reg[8]_2 ),
        .I4(\REC[7]_i_2_n_0 ),
        .I5(\REC[1]_i_5_n_0 ),
        .O(\REC[1]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair34" *) 
  LUT3 #(
    .INIT(8'h01)) 
    \REC[1]_i_2 
       (.I0(\REC_reg[8]_0 [7]),
        .I1(\REC_reg[8]_0 [8]),
        .I2(\REC[4]_i_6_n_0 ),
        .O(\REC[1]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAABAFFBFAABAAABA)) 
    \REC[1]_i_3 
       (.I0(\REC[8]_i_6_n_0 ),
        .I1(\REC[1]_i_4_n_0 ),
        .I2(req_Error_RX),
        .I3(\State_reg[0]_1 ),
        .I4(\REC[1]_i_6_n_0 ),
        .I5(\REC_reg[8]_3 ),
        .O(\REC[1]_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \REC[1]_i_4 
       (.I0(\REC_reg[8]_0 [1]),
        .I1(\REC_reg[8]_0 [0]),
        .O(\REC[1]_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair45" *) 
  LUT2 #(
    .INIT(4'hB)) 
    \REC[1]_i_5 
       (.I0(\REC_reg[8]_0 [8]),
        .I1(\REC_reg[8]_0 [1]),
        .O(\REC[1]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hAAAAAA2AAAAAAAAA)) 
    \REC[1]_i_6 
       (.I0(\REC_reg[8]_0 [1]),
        .I1(\REC_reg[8]_0 [8]),
        .I2(\Cnt[3]_i_3__1_n_0 ),
        .I3(Sampled_din),
        .I4(\State_reg[2]_0 [0]),
        .I5(\REC[8]_i_14_n_0 ),
        .O(\REC[1]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'hAABBBABBBBBBBABB)) 
    \REC[2]_i_1 
       (.I0(\REC[2]_i_2_n_0 ),
        .I1(\REC[2]_i_3_n_0 ),
        .I2(\REC[2]_i_4_n_0 ),
        .I3(\REC_reg[8]_2 ),
        .I4(\REC[7]_i_2_n_0 ),
        .I5(\REC[2]_i_5_n_0 ),
        .O(\REC[2]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair25" *) 
  LUT4 #(
    .INIT(16'hA802)) 
    \REC[2]_i_2 
       (.I0(\REC[1]_i_2_n_0 ),
        .I1(\REC_reg[8]_0 [1]),
        .I2(\REC_reg[8]_0 [0]),
        .I3(\REC_reg[8]_0 [2]),
        .O(\REC[2]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAABAFFBFAABAAABA)) 
    \REC[2]_i_3 
       (.I0(\REC[8]_i_6_n_0 ),
        .I1(\REC[2]_i_4_n_0 ),
        .I2(req_Error_RX),
        .I3(\State_reg[0]_1 ),
        .I4(\REC[2]_i_6_n_0 ),
        .I5(\REC_reg[8]_3 ),
        .O(\REC[2]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair22" *) 
  LUT3 #(
    .INIT(8'h6A)) 
    \REC[2]_i_4 
       (.I0(\REC_reg[8]_0 [2]),
        .I1(\REC_reg[8]_0 [0]),
        .I2(\REC_reg[8]_0 [1]),
        .O(\REC[2]_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair45" *) 
  LUT2 #(
    .INIT(4'hB)) 
    \REC[2]_i_5 
       (.I0(\REC_reg[8]_0 [8]),
        .I1(\REC_reg[8]_0 [2]),
        .O(\REC[2]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hAAAAAA2AAAAAAAAA)) 
    \REC[2]_i_6 
       (.I0(\REC_reg[8]_0 [2]),
        .I1(\REC_reg[8]_0 [8]),
        .I2(\Cnt[3]_i_3__1_n_0 ),
        .I3(Sampled_din),
        .I4(\State_reg[2]_0 [0]),
        .I5(\REC[8]_i_14_n_0 ),
        .O(\REC[2]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'hAABBBABBBBBBBABB)) 
    \REC[3]_i_1 
       (.I0(\REC[3]_i_2_n_0 ),
        .I1(\REC[3]_i_3_n_0 ),
        .I2(\REC[3]_i_4_n_0 ),
        .I3(\REC_reg[8]_2 ),
        .I4(\REC[7]_i_2_n_0 ),
        .I5(\REC[3]_i_5_n_0 ),
        .O(\REC[3]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h4444444155555555)) 
    \REC[3]_i_2 
       (.I0(\REC[4]_i_6_n_0 ),
        .I1(\REC_reg[8]_0 [3]),
        .I2(\REC_reg[8]_0 [2]),
        .I3(\REC_reg[8]_0 [1]),
        .I4(\REC_reg[8]_0 [0]),
        .I5(\REC_reg[8]_1 ),
        .O(\REC[3]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAABAFFBFAABAAABA)) 
    \REC[3]_i_3 
       (.I0(\REC[8]_i_6_n_0 ),
        .I1(\REC[3]_i_4_n_0 ),
        .I2(req_Error_RX),
        .I3(\State_reg[0]_1 ),
        .I4(\REC[3]_i_6_n_0 ),
        .I5(\REC_reg[8]_3 ),
        .O(\REC[3]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair19" *) 
  LUT4 #(
    .INIT(16'h6AAA)) 
    \REC[3]_i_4 
       (.I0(\REC_reg[8]_0 [3]),
        .I1(\REC_reg[8]_0 [2]),
        .I2(\REC_reg[8]_0 [1]),
        .I3(\REC_reg[8]_0 [0]),
        .O(\REC[3]_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair35" *) 
  LUT2 #(
    .INIT(4'hE)) 
    \REC[3]_i_5 
       (.I0(\REC_reg[8]_0 [8]),
        .I1(\REC_reg[8]_0 [3]),
        .O(\REC[3]_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair35" *) 
  LUT4 #(
    .INIT(16'h00BF)) 
    \REC[3]_i_6 
       (.I0(imTX),
        .I1(\REC[8]_i_15_n_0 ),
        .I2(\REC[8]_i_16_n_0 ),
        .I3(\REC_reg[8]_0 [3]),
        .O(\REC[3]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'hAABBBABBBBBBBABB)) 
    \REC[4]_i_1 
       (.I0(\REC[4]_i_2_n_0 ),
        .I1(\REC[4]_i_3_n_0 ),
        .I2(\REC[4]_i_4_n_0 ),
        .I3(\REC_reg[8]_2 ),
        .I4(\REC[7]_i_2_n_0 ),
        .I5(\REC[4]_i_5_n_0 ),
        .O(\REC[4]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h00000000DDDDD7DD)) 
    \REC[4]_i_2 
       (.I0(\REC_reg[8]_1 ),
        .I1(\REC_reg[8]_0 [4]),
        .I2(\REC_reg[8]_0 [3]),
        .I3(\REC[5]_i_7_n_0 ),
        .I4(\REC_reg[8]_0 [2]),
        .I5(\REC[4]_i_6_n_0 ),
        .O(\REC[4]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hFFFFAABA)) 
    \REC[4]_i_3 
       (.I0(\REC[8]_i_6_n_0 ),
        .I1(\State_reg[0]_1 ),
        .I2(req_Error_RX),
        .I3(\REC[4]_i_4_n_0 ),
        .I4(\REC[4]_i_7_n_0 ),
        .O(\REC[4]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair19" *) 
  LUT5 #(
    .INIT(32'h6AAAAAAA)) 
    \REC[4]_i_4 
       (.I0(\REC_reg[8]_0 [4]),
        .I1(\REC_reg[8]_0 [0]),
        .I2(\REC_reg[8]_0 [1]),
        .I3(\REC_reg[8]_0 [2]),
        .I4(\REC_reg[8]_0 [3]),
        .O(\REC[4]_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair39" *) 
  LUT3 #(
    .INIT(8'hEB)) 
    \REC[4]_i_5 
       (.I0(\REC_reg[8]_0 [8]),
        .I1(\REC_reg[8]_0 [3]),
        .I2(\REC_reg[8]_0 [4]),
        .O(\REC[4]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF5575FFFF)) 
    \REC[4]_i_6 
       (.I0(\REC[4]_i_8_n_0 ),
        .I1(\State_reg[2]_0 [0]),
        .I2(\State_reg[2]_0 [2]),
        .I3(\State_reg[2]_0 [1]),
        .I4(\REC_reg[6]_0 ),
        .I5(donefromrxr_reg_n_0),
        .O(\REC[4]_i_6_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT4 #(
    .INIT(16'hA88A)) 
    \REC[4]_i_7 
       (.I0(\REC_reg[8]_3 ),
        .I1(\REC[7]_i_7_n_0 ),
        .I2(\REC_reg[8]_0 [4]),
        .I3(\REC_reg[8]_0 [3]),
        .O(\REC[4]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFFFB)) 
    \REC[4]_i_8 
       (.I0(\REC_reg[8]_0 [6]),
        .I1(\REC_reg[8]_1 ),
        .I2(\REC[5]_i_8_n_0 ),
        .I3(\REC_reg[8]_0 [1]),
        .I4(\REC_reg[8]_0 [0]),
        .I5(\REC_reg[8]_0 [5]),
        .O(\REC[4]_i_8_n_0 ));
  LUT6 #(
    .INIT(64'hAABBBABBBBBBBABB)) 
    \REC[5]_i_1 
       (.I0(\REC[5]_i_2_n_0 ),
        .I1(\REC[5]_i_3_n_0 ),
        .I2(\REC[5]_i_4_n_0 ),
        .I3(\REC_reg[8]_2 ),
        .I4(\REC[7]_i_2_n_0 ),
        .I5(\REC[5]_i_5_n_0 ),
        .O(\REC[5]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hAAAA22AA2222A222)) 
    \REC[5]_i_2 
       (.I0(\REC[5]_i_6_n_0 ),
        .I1(\REC_reg[8]_1 ),
        .I2(\REC_reg[8]_0 [6]),
        .I3(\REC[5]_i_7_n_0 ),
        .I4(\REC[5]_i_8_n_0 ),
        .I5(\REC_reg[8]_0 [5]),
        .O(\REC[5]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hFFFFAABA)) 
    \REC[5]_i_3 
       (.I0(\REC[8]_i_6_n_0 ),
        .I1(\State_reg[0]_1 ),
        .I2(req_Error_RX),
        .I3(\REC[5]_i_4_n_0 ),
        .I4(\REC[5]_i_9_n_0 ),
        .O(\REC[5]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h6AAAAAAAAAAAAAAA)) 
    \REC[5]_i_4 
       (.I0(\REC_reg[8]_0 [5]),
        .I1(\REC_reg[8]_0 [0]),
        .I2(\REC_reg[8]_0 [1]),
        .I3(\REC_reg[8]_0 [2]),
        .I4(\REC_reg[8]_0 [4]),
        .I5(\REC_reg[8]_0 [3]),
        .O(\REC[5]_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair18" *) 
  LUT4 #(
    .INIT(16'hEABF)) 
    \REC[5]_i_5 
       (.I0(\REC_reg[8]_0 [8]),
        .I1(\REC_reg[8]_0 [4]),
        .I2(\REC_reg[8]_0 [3]),
        .I3(\REC_reg[8]_0 [5]),
        .O(\REC[5]_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair10" *) 
  LUT5 #(
    .INIT(32'h44444044)) 
    \REC[5]_i_6 
       (.I0(donefromrxr_reg_n_0),
        .I1(\REC_reg[6]_0 ),
        .I2(\State_reg[2]_0 [1]),
        .I3(\State_reg[2]_0 [2]),
        .I4(\State_reg[2]_0 [0]),
        .O(\REC[5]_i_6_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair27" *) 
  LUT2 #(
    .INIT(4'h1)) 
    \REC[5]_i_7 
       (.I0(\REC_reg[8]_0 [1]),
        .I1(\REC_reg[8]_0 [0]),
        .O(\REC[5]_i_7_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair39" *) 
  LUT3 #(
    .INIT(8'hFE)) 
    \REC[5]_i_8 
       (.I0(\REC_reg[8]_0 [2]),
        .I1(\REC_reg[8]_0 [3]),
        .I2(\REC_reg[8]_0 [4]),
        .O(\REC[5]_i_8_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT5 #(
    .INIT(32'hAAAA8222)) 
    \REC[5]_i_9 
       (.I0(\REC_reg[8]_3 ),
        .I1(\REC_reg[8]_0 [5]),
        .I2(\REC_reg[8]_0 [3]),
        .I3(\REC_reg[8]_0 [4]),
        .I4(\REC[7]_i_7_n_0 ),
        .O(\REC[5]_i_9_n_0 ));
  LUT6 #(
    .INIT(64'hABBBABBBBBBBAABB)) 
    \REC[6]_i_1 
       (.I0(\REC[6]_i_2_n_0 ),
        .I1(\REC[6]_i_3_n_0 ),
        .I2(\REC[6]_i_4_n_0 ),
        .I3(\REC_reg[8]_2 ),
        .I4(\REC[6]_i_5_n_0 ),
        .I5(\REC[7]_i_2_n_0 ),
        .O(\REC[6]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h00000000008A0000)) 
    \REC[6]_i_2 
       (.I0(\REC[6]_i_6_n_0 ),
        .I1(\REC_reg[8]_0 [6]),
        .I2(\REC_reg[8]_1 ),
        .I3(donefromrxr_reg_n_0),
        .I4(\REC_reg[6]_0 ),
        .I5(\TEC[8]_i_18_n_0 ),
        .O(\REC[6]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFBAAAAABA)) 
    \REC[6]_i_3 
       (.I0(\REC[8]_i_6_n_0 ),
        .I1(\State_reg[0]_1 ),
        .I2(req_Error_RX),
        .I3(\REC[6]_i_8_n_0 ),
        .I4(\REC_reg[8]_0 [6]),
        .I5(\REC[6]_i_9_n_0 ),
        .O(\REC[6]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair18" *) 
  LUT5 #(
    .INIT(32'hEAAABFFF)) 
    \REC[6]_i_4 
       (.I0(\REC_reg[8]_0 [8]),
        .I1(\REC_reg[8]_0 [3]),
        .I2(\REC_reg[8]_0 [4]),
        .I3(\REC_reg[8]_0 [5]),
        .I4(\REC_reg[8]_0 [6]),
        .O(\REC[6]_i_4_n_0 ));
  LUT5 #(
    .INIT(32'h6AAAAAAA)) 
    \REC[6]_i_5 
       (.I0(\REC_reg[8]_0 [6]),
        .I1(\REC[7]_i_6_n_0 ),
        .I2(\REC_reg[8]_0 [3]),
        .I3(\REC_reg[8]_0 [4]),
        .I4(\REC_reg[8]_0 [5]),
        .O(\REC[6]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFFFE)) 
    \REC[6]_i_6 
       (.I0(\REC_reg[8]_0 [5]),
        .I1(\REC_reg[8]_0 [0]),
        .I2(\REC_reg[8]_0 [1]),
        .I3(\REC[5]_i_8_n_0 ),
        .I4(\REC_reg[8]_0 [7]),
        .I5(\REC_reg[8]_0 [8]),
        .O(\REC[6]_i_6_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair28" *) 
  LUT2 #(
    .INIT(4'h1)) 
    \REC[6]_i_7 
       (.I0(\REC_reg[8]_0 [8]),
        .I1(\REC_reg[8]_0 [7]),
        .O(\REC_reg[8]_1 ));
  LUT6 #(
    .INIT(64'h8000000000000000)) 
    \REC[6]_i_8 
       (.I0(\REC_reg[8]_0 [5]),
        .I1(\REC_reg[8]_0 [4]),
        .I2(\REC_reg[8]_0 [3]),
        .I3(\REC_reg[8]_0 [2]),
        .I4(\REC_reg[8]_0 [1]),
        .I5(\REC_reg[8]_0 [0]),
        .O(\REC[6]_i_8_n_0 ));
  LUT6 #(
    .INIT(64'hAAAAAAAA82222222)) 
    \REC[6]_i_9 
       (.I0(\REC_reg[8]_3 ),
        .I1(\REC_reg[8]_0 [6]),
        .I2(\REC_reg[8]_0 [5]),
        .I3(\REC_reg[8]_0 [4]),
        .I4(\REC_reg[8]_0 [3]),
        .I5(\REC[7]_i_7_n_0 ),
        .O(\REC[6]_i_9_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000004FEF)) 
    \REC[7]_i_1 
       (.I0(\REC[7]_i_2_n_0 ),
        .I1(\REC[7]_i_3_n_0 ),
        .I2(\REC_reg[8]_2 ),
        .I3(\REC[7]_i_4_n_0 ),
        .I4(\REC[7]_i_5_n_0 ),
        .I5(\REC[8]_i_6_n_0 ),
        .O(\REC[7]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFEFFF)) 
    \REC[7]_i_2 
       (.I0(\State_reg[2]_i_2_n_0 ),
        .I1(\State[1]_i_2_n_0 ),
        .I2(\REC[8]_i_14_n_0 ),
        .I3(\State_reg[2]_0 [0]),
        .I4(\State[0]_i_2_n_0 ),
        .I5(imTX),
        .O(\REC[7]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h6AAAAAAAAAAAAAAA)) 
    \REC[7]_i_3 
       (.I0(\REC_reg[8]_0 [7]),
        .I1(\REC_reg[8]_0 [6]),
        .I2(\REC_reg[8]_0 [5]),
        .I3(\REC_reg[8]_0 [4]),
        .I4(\REC_reg[8]_0 [3]),
        .I5(\REC[7]_i_6_n_0 ),
        .O(\REC[7]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hEAAAAAAABFFFFFFF)) 
    \REC[7]_i_4 
       (.I0(\REC_reg[8]_0 [8]),
        .I1(\REC_reg[8]_0 [5]),
        .I2(\REC_reg[8]_0 [4]),
        .I3(\REC_reg[8]_0 [3]),
        .I4(\REC_reg[8]_0 [6]),
        .I5(\REC_reg[8]_0 [7]),
        .O(\REC[7]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hE0E0E0E0E0FFE0E0)) 
    \REC[7]_i_5 
       (.I0(\REC[7]_i_7_n_0 ),
        .I1(\REC[7]_i_8_n_0 ),
        .I2(\REC_reg[8]_3 ),
        .I3(\REC[7]_i_3_n_0 ),
        .I4(req_Error_RX),
        .I5(\State_reg[0]_1 ),
        .O(\REC[7]_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair25" *) 
  LUT3 #(
    .INIT(8'h80)) 
    \REC[7]_i_6 
       (.I0(\REC_reg[8]_0 [0]),
        .I1(\REC_reg[8]_0 [1]),
        .I2(\REC_reg[8]_0 [2]),
        .O(\REC[7]_i_6_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair28" *) 
  LUT4 #(
    .INIT(16'h0800)) 
    \REC[7]_i_7 
       (.I0(\REC[8]_i_16_n_0 ),
        .I1(\REC_reg[8]_0 [8]),
        .I2(imTX),
        .I3(\REC[7]_i_9_n_0 ),
        .O(\REC[7]_i_7_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair21" *) 
  LUT5 #(
    .INIT(32'h95555555)) 
    \REC[7]_i_8 
       (.I0(\REC_reg[8]_0 [7]),
        .I1(\REC_reg[8]_0 [6]),
        .I2(\REC_reg[8]_0 [3]),
        .I3(\REC_reg[8]_0 [4]),
        .I4(\REC_reg[8]_0 [5]),
        .O(\REC[7]_i_8_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair15" *) 
  LUT5 #(
    .INIT(32'h00000200)) 
    \REC[7]_i_9 
       (.I0(\Cnt[3]_i_3__1_n_0 ),
        .I1(Sampled_din),
        .I2(\State_reg[2]_0 [0]),
        .I3(\State_reg[2]_0 [1]),
        .I4(\State_reg[2]_0 [2]),
        .O(\REC[7]_i_9_n_0 ));
  LUT6 #(
    .INIT(64'hAAAAAAAA0222AAAA)) 
    \REC[8]_i_1 
       (.I0(E),
        .I1(imTX),
        .I2(\REC[8]_i_3_n_0 ),
        .I3(\REC[8]_i_4_n_0 ),
        .I4(\REC_reg[8]_2 ),
        .I5(\REC[8]_i_6_n_0 ),
        .O(\REC[8]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair21" *) 
  LUT5 #(
    .INIT(32'h80000000)) 
    \REC[8]_i_10 
       (.I0(\REC_reg[8]_0 [6]),
        .I1(\REC_reg[8]_0 [3]),
        .I2(\REC_reg[8]_0 [4]),
        .I3(\REC_reg[8]_0 [5]),
        .I4(\REC_reg[8]_0 [7]),
        .O(\REC[8]_i_10_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair22" *) 
  LUT5 #(
    .INIT(32'h95555555)) 
    \REC[8]_i_11 
       (.I0(\REC_reg[8]_0 [8]),
        .I1(\REC_reg[8]_0 [0]),
        .I2(\REC_reg[8]_0 [1]),
        .I3(\REC_reg[8]_0 [2]),
        .I4(\REC[8]_i_10_n_0 ),
        .O(\REC[8]_i_11_n_0 ));
  LUT6 #(
    .INIT(64'h40FFFF4040404040)) 
    \REC[8]_i_13 
       (.I0(imTX),
        .I1(\REC[8]_i_15_n_0 ),
        .I2(\REC[8]_i_16_n_0 ),
        .I3(\REC_reg[8]_0 [8]),
        .I4(\REC[8]_i_10_n_0 ),
        .I5(\REC_reg[8]_3 ),
        .O(\REC[8]_i_13_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair32" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \REC[8]_i_14 
       (.I0(\State_reg[2]_0 [1]),
        .I1(\State_reg[2]_0 [2]),
        .O(\REC[8]_i_14_n_0 ));
  LUT6 #(
    .INIT(64'h0004000000000000)) 
    \REC[8]_i_15 
       (.I0(\State_reg[2]_0 [2]),
        .I1(\State_reg[2]_0 [1]),
        .I2(\State_reg[2]_0 [0]),
        .I3(Sampled_din),
        .I4(\Cnt[3]_i_3__1_n_0 ),
        .I5(\REC_reg[8]_0 [8]),
        .O(\REC[8]_i_15_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFFFE)) 
    \REC[8]_i_16 
       (.I0(\REC[5]_i_8_n_0 ),
        .I1(\REC_reg[8]_0 [5]),
        .I2(\REC_reg[8]_0 [0]),
        .I3(\REC_reg[8]_0 [1]),
        .I4(\REC_reg[8]_0 [7]),
        .I5(\REC_reg[8]_0 [6]),
        .O(\REC[8]_i_16_n_0 ));
  LUT6 #(
    .INIT(64'hABAABBBBBBBBBBBB)) 
    \REC[8]_i_2 
       (.I0(\REC[8]_i_7_n_0 ),
        .I1(\REC[8]_i_8_n_0 ),
        .I2(\REC[8]_i_9_n_0 ),
        .I3(\REC[8]_i_10_n_0 ),
        .I4(\REC[8]_i_11_n_0 ),
        .I5(\REC_reg[8]_2 ),
        .O(\REC[8]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFEFFFFFF)) 
    \REC[8]_i_3 
       (.I0(\State_reg[2]_i_2_n_0 ),
        .I1(\State[1]_i_2_n_0 ),
        .I2(\State_reg[2]_0 [2]),
        .I3(\State_reg[2]_0 [1]),
        .I4(\State_reg[2]_0 [0]),
        .I5(\State[0]_i_2_n_0 ),
        .O(\REC[8]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair15" *) 
  LUT4 #(
    .INIT(16'hDFFF)) 
    \REC[8]_i_4 
       (.I0(\State_reg[2]_0 [0]),
        .I1(\State_reg[2]_0 [1]),
        .I2(\State_reg[2]_0 [2]),
        .I3(Sampled_din),
        .O(\REC[8]_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair10" *) 
  LUT5 #(
    .INIT(32'h04FF0404)) 
    \REC[8]_i_6 
       (.I0(\State_reg[2]_0 [1]),
        .I1(\State_reg[2]_0 [2]),
        .I2(\State_reg[2]_0 [0]),
        .I3(donefromrxr_reg_n_0),
        .I4(\REC_reg[6]_0 ),
        .O(\REC[8]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'h0404040004040404)) 
    \REC[8]_i_7 
       (.I0(\State_reg[2]_0 [1]),
        .I1(\State_reg[2]_0 [2]),
        .I2(\State_reg[2]_0 [0]),
        .I3(\State[1]_i_2_n_0 ),
        .I4(\State_reg[2]_i_2_n_0 ),
        .I5(\State[0]_i_2_n_0 ),
        .O(\REC[8]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'hAAAAFFAEAAAAFBAA)) 
    \REC[8]_i_8 
       (.I0(\REC[8]_i_6_n_0 ),
        .I1(req_Error_RX),
        .I2(\State_reg[0]_1 ),
        .I3(\REC_reg[8]_3 ),
        .I4(\REC[8]_i_13_n_0 ),
        .I5(\REC[8]_i_11_n_0 ),
        .O(\REC[8]_i_8_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000001000)) 
    \REC[8]_i_9 
       (.I0(imTX),
        .I1(\State[0]_i_2_n_0 ),
        .I2(\State_reg[2]_0 [0]),
        .I3(\REC[8]_i_14_n_0 ),
        .I4(\State[1]_i_2_n_0 ),
        .I5(\State_reg[2]_i_2_n_0 ),
        .O(\REC[8]_i_9_n_0 ));
  FDCE \REC_reg[0] 
       (.C(Tq),
        .CE(\REC[8]_i_1_n_0 ),
        .CLR(ack_error_reg_0),
        .D(\REC[0]_i_1_n_0 ),
        .Q(\REC_reg[8]_0 [0]));
  FDCE \REC_reg[1] 
       (.C(Tq),
        .CE(\REC[8]_i_1_n_0 ),
        .CLR(ack_error_reg_0),
        .D(\REC[1]_i_1_n_0 ),
        .Q(\REC_reg[8]_0 [1]));
  FDCE \REC_reg[2] 
       (.C(Tq),
        .CE(\REC[8]_i_1_n_0 ),
        .CLR(ack_error_reg_0),
        .D(\REC[2]_i_1_n_0 ),
        .Q(\REC_reg[8]_0 [2]));
  FDCE \REC_reg[3] 
       (.C(Tq),
        .CE(\REC[8]_i_1_n_0 ),
        .CLR(ack_error_reg_0),
        .D(\REC[3]_i_1_n_0 ),
        .Q(\REC_reg[8]_0 [3]));
  FDCE \REC_reg[4] 
       (.C(Tq),
        .CE(\REC[8]_i_1_n_0 ),
        .CLR(ack_error_reg_0),
        .D(\REC[4]_i_1_n_0 ),
        .Q(\REC_reg[8]_0 [4]));
  FDCE \REC_reg[5] 
       (.C(Tq),
        .CE(\REC[8]_i_1_n_0 ),
        .CLR(ack_error_reg_0),
        .D(\REC[5]_i_1_n_0 ),
        .Q(\REC_reg[8]_0 [5]));
  FDCE \REC_reg[6] 
       (.C(Tq),
        .CE(\REC[8]_i_1_n_0 ),
        .CLR(ack_error_reg_0),
        .D(\REC[6]_i_1_n_0 ),
        .Q(\REC_reg[8]_0 [6]));
  FDCE \REC_reg[7] 
       (.C(Tq),
        .CE(\REC[8]_i_1_n_0 ),
        .CLR(ack_error_reg_0),
        .D(\REC[7]_i_1_n_0 ),
        .Q(\REC_reg[8]_0 [7]));
  FDCE \REC_reg[8] 
       (.C(Tq),
        .CE(\REC[8]_i_1_n_0 ),
        .CLR(ack_error_reg_0),
        .D(\REC[8]_i_2_n_0 ),
        .Q(\REC_reg[8]_0 [8]));
  FDCE \RECin_reg[7] 
       (.C(Tq),
        .CE(RECin),
        .CLR(ack_error_reg_0),
        .D(\REC_reg[8]_0 [7]),
        .Q(\RECin_reg_n_0_[7] ));
  FDCE \RECin_reg[8] 
       (.C(Tq),
        .CE(RECin),
        .CLR(ack_error_reg_0),
        .D(\REC_reg[8]_0 [8]),
        .Q(\RECin_reg_n_0_[8] ));
  LUT1 #(
    .INIT(2'h1)) 
    RXBUS_d_i_1
       (.I0(q_reg),
        .O(RXBUS));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT3 #(
    .INIT(8'hB7)) 
    \RXSTATES[0]_i_2 
       (.I0(\State_reg[2]_0 [0]),
        .I1(\State_reg[2]_0 [2]),
        .I2(\State_reg[2]_0 [1]),
        .O(\State_reg[0]_2 ));
  (* SOFT_HLUTNM = "soft_lutpair26" *) 
  LUT4 #(
    .INIT(16'hAAFE)) 
    \RXSTATES[0]_i_5 
       (.I0(req_Error_RX),
        .I1(\State_reg[2]_0 [0]),
        .I2(\State_reg[2]_0 [1]),
        .I3(\State_reg[2]_0 [2]),
        .O(req_Error_reg));
  LUT6 #(
    .INIT(64'h000000000000800A)) 
    \RXSTATES[1]_i_1 
       (.I0(SRST),
        .I1(\State_reg[2]_0 [2]),
        .I2(\State_reg[2]_0 [1]),
        .I3(\State_reg[2]_0 [0]),
        .I4(req_Error_RX),
        .I5(\RXSTATES_reg[1] ),
        .O(SRST_1));
  (* SOFT_HLUTNM = "soft_lutpair24" *) 
  LUT4 #(
    .INIT(16'h0083)) 
    \RXSTATES[3]_i_3 
       (.I0(\State_reg[2]_0 [2]),
        .I1(\State_reg[2]_0 [1]),
        .I2(\State_reg[2]_0 [0]),
        .I3(req_Error_RX),
        .O(\State_reg[2]_2 ));
  (* SOFT_HLUTNM = "soft_lutpair37" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \Reck[0]_i_1 
       (.I0(\Reck[4]_i_2_n_0 ),
        .I1(\Reck_reg_n_0_[0] ),
        .O(Reckr[0]));
  (* SOFT_HLUTNM = "soft_lutpair37" *) 
  LUT3 #(
    .INIT(8'h28)) 
    \Reck[1]_i_1 
       (.I0(\Reck[4]_i_2_n_0 ),
        .I1(\Reck_reg_n_0_[1] ),
        .I2(\Reck_reg_n_0_[0] ),
        .O(Reckr[1]));
  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT4 #(
    .INIT(16'h2A80)) 
    \Reck[2]_i_1 
       (.I0(\Reck[4]_i_2_n_0 ),
        .I1(\Reck_reg_n_0_[0] ),
        .I2(\Reck_reg_n_0_[1] ),
        .I3(\Reck_reg_n_0_[2] ),
        .O(Reckr[2]));
  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT5 #(
    .INIT(32'h2AAA8000)) 
    \Reck[3]_i_1 
       (.I0(\Reck[4]_i_2_n_0 ),
        .I1(\Reck_reg_n_0_[1] ),
        .I2(\Reck_reg_n_0_[0] ),
        .I3(\Reck_reg_n_0_[2] ),
        .I4(\Reck_reg_n_0_[3] ),
        .O(Reckr[3]));
  LUT6 #(
    .INIT(64'h2AAAAAAA80000000)) 
    \Reck[4]_i_1 
       (.I0(\Reck[4]_i_2_n_0 ),
        .I1(\Reck_reg_n_0_[3] ),
        .I2(\Reck_reg_n_0_[2] ),
        .I3(\Reck_reg_n_0_[0] ),
        .I4(\Reck_reg_n_0_[1] ),
        .I5(\Reck_reg_n_0_[4] ),
        .O(Reckr[4]));
  (* SOFT_HLUTNM = "soft_lutpair26" *) 
  LUT4 #(
    .INIT(16'h0400)) 
    \Reck[4]_i_2 
       (.I0(\State_reg[2]_0 [1]),
        .I1(\State_reg[2]_0 [2]),
        .I2(\State_reg[2]_0 [0]),
        .I3(\Reck[4]_i_3_n_0 ),
        .O(\Reck[4]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFF7FFFFFFFFFFFF)) 
    \Reck[4]_i_3 
       (.I0(\Cnt_reg_n_0_[1] ),
        .I1(\Cnt_reg_n_0_[3] ),
        .I2(\Cnt_reg_n_0_[2] ),
        .I3(\Cnt_reg_n_0_[0] ),
        .I4(\Reck[6]_i_4_n_0 ),
        .I5(\Reck_reg_n_0_[6] ),
        .O(\Reck[4]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT5 #(
    .INIT(32'h00101000)) 
    \Reck[5]_i_1 
       (.I0(\State_reg[2]_0 [1]),
        .I1(\State_reg[2]_0 [0]),
        .I2(\State_reg[2]_0 [2]),
        .I3(\Reck_reg_n_0_[5] ),
        .I4(\Reck[5]_i_2_n_0 ),
        .O(Reckr[5]));
  LUT5 #(
    .INIT(32'h80000000)) 
    \Reck[5]_i_2 
       (.I0(\Reck_reg_n_0_[4] ),
        .I1(\Reck_reg_n_0_[1] ),
        .I2(\Reck_reg_n_0_[0] ),
        .I3(\Reck_reg_n_0_[2] ),
        .I4(\Reck_reg_n_0_[3] ),
        .O(\Reck[5]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAAAAAAAAAA08AAAA)) 
    \Reck[6]_i_1 
       (.I0(E),
        .I1(Sampled_din),
        .I2(\Reck[6]_i_3_n_0 ),
        .I3(\State_reg[2]_0 [0]),
        .I4(\State_reg[2]_0 [2]),
        .I5(\State_reg[2]_0 [1]),
        .O(Reck));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT5 #(
    .INIT(32'h01100000)) 
    \Reck[6]_i_2 
       (.I0(\State_reg[2]_0 [1]),
        .I1(\State_reg[2]_0 [0]),
        .I2(\Reck_reg_n_0_[6] ),
        .I3(\Reck[6]_i_4_n_0 ),
        .I4(\State_reg[2]_0 [2]),
        .O(Reckr[6]));
  (* SOFT_HLUTNM = "soft_lutpair29" *) 
  LUT4 #(
    .INIT(16'hEFFF)) 
    \Reck[6]_i_3 
       (.I0(\Cnt_reg_n_0_[0] ),
        .I1(\Cnt_reg_n_0_[2] ),
        .I2(\Cnt_reg_n_0_[3] ),
        .I3(\Cnt_reg_n_0_[1] ),
        .O(\Reck[6]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h8000000000000000)) 
    \Reck[6]_i_4 
       (.I0(\Reck_reg_n_0_[3] ),
        .I1(\Reck_reg_n_0_[2] ),
        .I2(\Reck_reg_n_0_[0] ),
        .I3(\Reck_reg_n_0_[1] ),
        .I4(\Reck_reg_n_0_[4] ),
        .I5(\Reck_reg_n_0_[5] ),
        .O(\Reck[6]_i_4_n_0 ));
  FDCE \Reck_reg[0] 
       (.C(Tq),
        .CE(Reck),
        .CLR(ack_error_reg_0),
        .D(Reckr[0]),
        .Q(\Reck_reg_n_0_[0] ));
  FDCE \Reck_reg[1] 
       (.C(Tq),
        .CE(Reck),
        .CLR(ack_error_reg_0),
        .D(Reckr[1]),
        .Q(\Reck_reg_n_0_[1] ));
  FDCE \Reck_reg[2] 
       (.C(Tq),
        .CE(Reck),
        .CLR(ack_error_reg_0),
        .D(Reckr[2]),
        .Q(\Reck_reg_n_0_[2] ));
  FDCE \Reck_reg[3] 
       (.C(Tq),
        .CE(Reck),
        .CLR(ack_error_reg_0),
        .D(Reckr[3]),
        .Q(\Reck_reg_n_0_[3] ));
  FDCE \Reck_reg[4] 
       (.C(Tq),
        .CE(Reck),
        .CLR(ack_error_reg_0),
        .D(Reckr[4]),
        .Q(\Reck_reg_n_0_[4] ));
  FDCE \Reck_reg[5] 
       (.C(Tq),
        .CE(Reck),
        .CLR(ack_error_reg_0),
        .D(Reckr[5]),
        .Q(\Reck_reg_n_0_[5] ));
  FDCE \Reck_reg[6] 
       (.C(Tq),
        .CE(Reck),
        .CLR(ack_error_reg_0),
        .D(Reckr[6]),
        .Q(\Reck_reg_n_0_[6] ));
  LUT6 #(
    .INIT(64'h0404040404440404)) 
    \State[0]_i_1 
       (.I0(\State[0]_i_2_n_0 ),
        .I1(SRST),
        .I2(Q[8]),
        .I3(\State_reg[2]_0 [1]),
        .I4(\State_reg[2]_0 [2]),
        .I5(\State_reg[2]_0 [0]),
        .O(\State[0]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFF0F0DDD0CCC0)) 
    \State[0]_i_10 
       (.I0(\Cnt[3]_i_3__1_n_0 ),
        .I1(\State_reg[2]_0 [0]),
        .I2(\State_reg[2]_0 [1]),
        .I3(\Cnt[0]_i_3__1_n_0 ),
        .I4(Q[8]),
        .I5(Sampled_din),
        .O(\State[0]_i_10_n_0 ));
  LUT6 #(
    .INIT(64'h00000000AABABBBA)) 
    \State[0]_i_2 
       (.I0(\State[0]_i_3_n_0 ),
        .I1(\State_reg[2]_0 [0]),
        .I2(Q[8]),
        .I3(\State_reg[0]_5 ),
        .I4(\State_reg[0]_4 ),
        .I5(\State[0]_i_6_n_0 ),
        .O(\State[0]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT5 #(
    .INIT(32'hFFFFFF08)) 
    \State[0]_i_3 
       (.I0(\State_reg[2]_0 [0]),
        .I1(\Cnt[0]_i_3__1_n_0 ),
        .I2(\Cnt[0]_i_5__1_n_0 ),
        .I3(\State_reg[2]_0 [1]),
        .I4(\State_reg[2]_0 [2]),
        .O(\State[0]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT5 #(
    .INIT(32'hBABABAAA)) 
    \State[0]_i_6 
       (.I0(\State[0]_i_9_n_0 ),
        .I1(\State[0]_i_10_n_0 ),
        .I2(\State_reg[2]_0 [2]),
        .I3(\State_reg[2]_0 [1]),
        .I4(\State_reg[2]_0 [0]),
        .O(\State[0]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'h0440404004444040)) 
    \State[0]_i_9 
       (.I0(\State_reg[2]_0 [2]),
        .I1(\State_reg[2]_0 [1]),
        .I2(Sampled_din),
        .I3(\Cnt[3]_i_9_n_0 ),
        .I4(\State_reg[2]_0 [0]),
        .I5(Q[8]),
        .O(\State[0]_i_9_n_0 ));
  LUT6 #(
    .INIT(64'h0808080808880808)) 
    \State[1]_i_1 
       (.I0(\State[1]_i_2_n_0 ),
        .I1(SRST),
        .I2(Q[8]),
        .I3(\State_reg[2]_0 [1]),
        .I4(\State_reg[2]_0 [2]),
        .I5(\State_reg[2]_0 [0]),
        .O(\State[1]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF32023232)) 
    \State[1]_i_2 
       (.I0(\State[1]_i_3_n_0 ),
        .I1(\State_reg[2]_0 [2]),
        .I2(\State_reg[2]_0 [1]),
        .I3(\State[1]_i_4_n_0 ),
        .I4(\State_reg[2]_0 [0]),
        .I5(\State[1]_i_5_n_0 ),
        .O(\State[1]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hF9000000)) 
    \State[1]_i_3 
       (.I0(Sampled_din),
        .I1(lastvalue),
        .I2(TXpin_i_5_n_0),
        .I3(\Cnt[0]_i_3__1_n_0 ),
        .I4(\State_reg[2]_0 [0]),
        .O(\State[1]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair17" *) 
  LUT5 #(
    .INIT(32'hAAAA8AAA)) 
    \State[1]_i_4 
       (.I0(Sampled_din),
        .I1(\Cnt_reg_n_0_[0] ),
        .I2(\Cnt_reg_n_0_[1] ),
        .I3(\Cnt_reg_n_0_[2] ),
        .I4(\Cnt_reg_n_0_[3] ),
        .O(\State[1]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h00500C0000000000)) 
    \State[1]_i_5 
       (.I0(\Cnt[3]_i_3__1_n_0 ),
        .I1(\Cnt[0]_i_3__1_n_0 ),
        .I2(Sampled_din),
        .I3(\State_reg[2]_0 [0]),
        .I4(\State_reg[2]_0 [1]),
        .I5(\State_reg[2]_0 [2]),
        .O(\State[1]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hAAAAAAAA88888088)) 
    \State[2]_i_1 
       (.I0(SRST),
        .I1(Q[8]),
        .I2(\State_reg[2]_0 [1]),
        .I3(\State_reg[2]_0 [2]),
        .I4(\State_reg[2]_0 [0]),
        .I5(\State_reg[2]_i_2_n_0 ),
        .O(\State[2]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hFBAAEAAAFBAAEAAA)) 
    \State[2]_i_3 
       (.I0(\REC[0]_i_8_n_0 ),
        .I1(\State_reg[2]_i_2_0 ),
        .I2(\State_reg[0]_4 ),
        .I3(\State_reg[0]_0 ),
        .I4(Q[8]),
        .I5(\State_reg[2]_0 [2]),
        .O(\State[2]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h050E050ECFFFC0FF)) 
    \State[2]_i_4 
       (.I0(\Cnt[3]_i_3__1_n_0 ),
        .I1(Q[8]),
        .I2(\State_reg[2]_0 [0]),
        .I3(Sampled_din),
        .I4(\Reck[4]_i_3_n_0 ),
        .I5(\State_reg[2]_0 [1]),
        .O(\State[2]_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair16" *) 
  LUT2 #(
    .INIT(4'h1)) 
    \State[2]_i_6 
       (.I0(\State_reg[2]_0 [0]),
        .I1(\State_reg[2]_0 [1]),
        .O(\State_reg[0]_0 ));
  FDCE \State_reg[0] 
       (.C(Tq),
        .CE(\State_reg[0]_3 ),
        .CLR(ack_error_reg_0),
        .D(\State[0]_i_1_n_0 ),
        .Q(\State_reg[2]_0 [0]));
  FDCE \State_reg[1] 
       (.C(Tq),
        .CE(\State_reg[0]_3 ),
        .CLR(ack_error_reg_0),
        .D(\State[1]_i_1_n_0 ),
        .Q(\State_reg[2]_0 [1]));
  FDCE \State_reg[2] 
       (.C(Tq),
        .CE(\State_reg[0]_3 ),
        .CLR(ack_error_reg_0),
        .D(\State[2]_i_1_n_0 ),
        .Q(\State_reg[2]_0 [2]));
  MUXF7 \State_reg[2]_i_2 
       (.I0(\State[2]_i_3_n_0 ),
        .I1(\State[2]_i_4_n_0 ),
        .O(\State_reg[2]_i_2_n_0 ),
        .S(\State_reg[2]_0 [2]));
  LUT6 #(
    .INIT(64'hBBBBBBBBABAABBBB)) 
    \TEC[0]_i_1 
       (.I0(\TEC[0]_i_2_n_0 ),
        .I1(\TEC[0]_i_3_n_0 ),
        .I2(\TEC[0]_i_4_n_0 ),
        .I3(\TEC[8]_i_7_n_0 ),
        .I4(\TEC[8]_i_5_n_0 ),
        .I5(\TEC[0]_i_5_n_0 ),
        .O(\TEC[0]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair46" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \TEC[0]_i_2 
       (.I0(\TEC[8]_i_21_n_0 ),
        .I1(Q[0]),
        .O(\TEC[0]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFF8FFF8FFF8FFFF)) 
    \TEC[0]_i_3 
       (.I0(\TEC_reg[0]_0 ),
        .I1(Q[8]),
        .I2(\TEC[8]_i_18_n_0 ),
        .I3(\TEC[8]_i_12_n_0 ),
        .I4(\TEC[8]_i_5_n_0 ),
        .I5(Q[0]),
        .O(\TEC[0]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair44" *) 
  LUT2 #(
    .INIT(4'hB)) 
    \TEC[0]_i_4 
       (.I0(Q[8]),
        .I1(Q[0]),
        .O(\TEC[0]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h00000000FFFFFDFF)) 
    \TEC[0]_i_5 
       (.I0(imTX),
        .I1(\State_reg[2]_i_2_n_0 ),
        .I2(\State[1]_i_2_n_0 ),
        .I3(\TEC[8]_i_17_n_0 ),
        .I4(\State[0]_i_2_n_0 ),
        .I5(\TEC[0]_i_6_n_0 ),
        .O(\TEC[0]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hAEAAAAAAAAAAAAAA)) 
    \TEC[0]_i_6 
       (.I0(Q[0]),
        .I1(\State_reg[2]_0 [0]),
        .I2(\State_reg[2]_0 [1]),
        .I3(\State_reg[2]_0 [2]),
        .I4(Sampled_din),
        .I5(imTX),
        .O(\TEC[0]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'hBBBBBBBBABAABBBB)) 
    \TEC[1]_i_1 
       (.I0(\TEC[1]_i_2_n_0 ),
        .I1(\TEC[1]_i_3_n_0 ),
        .I2(\TEC[1]_i_4_n_0 ),
        .I3(\TEC[8]_i_7_n_0 ),
        .I4(\TEC[8]_i_5_n_0 ),
        .I5(\TEC[1]_i_5_n_0 ),
        .O(\TEC[1]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair46" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \TEC[1]_i_2 
       (.I0(\TEC[8]_i_21_n_0 ),
        .I1(Q[1]),
        .O(\TEC[1]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFF8FFF8FFF8FFFF)) 
    \TEC[1]_i_3 
       (.I0(\TEC_reg[0]_0 ),
        .I1(Q[8]),
        .I2(\TEC[8]_i_18_n_0 ),
        .I3(\TEC[8]_i_12_n_0 ),
        .I4(\TEC[8]_i_5_n_0 ),
        .I5(Q[1]),
        .O(\TEC[1]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair44" *) 
  LUT2 #(
    .INIT(4'hB)) 
    \TEC[1]_i_4 
       (.I0(Q[8]),
        .I1(Q[1]),
        .O(\TEC[1]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h00000000FFFFFDFF)) 
    \TEC[1]_i_5 
       (.I0(imTX),
        .I1(\State_reg[2]_i_2_n_0 ),
        .I2(\State[1]_i_2_n_0 ),
        .I3(\TEC[8]_i_17_n_0 ),
        .I4(\State[0]_i_2_n_0 ),
        .I5(\TEC[1]_i_6_n_0 ),
        .O(\TEC[1]_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair38" *) 
  LUT3 #(
    .INIT(8'hBE)) 
    \TEC[1]_i_6 
       (.I0(\TEC[7]_i_8_n_0 ),
        .I1(Q[1]),
        .I2(Q[0]),
        .O(\TEC[1]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF55551055)) 
    \TEC[2]_i_1 
       (.I0(\TEC[2]_i_2_n_0 ),
        .I1(\TEC[2]_i_3_n_0 ),
        .I2(\TEC[8]_i_7_n_0 ),
        .I3(\TEC[8]_i_5_n_0 ),
        .I4(\TEC[2]_i_4_n_0 ),
        .I5(\TEC[2]_i_5_n_0 ),
        .O(\TEC[2]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hFFF8FFF8FFF8FFFF)) 
    \TEC[2]_i_2 
       (.I0(\TEC_reg[0]_0 ),
        .I1(Q[8]),
        .I2(\TEC[8]_i_18_n_0 ),
        .I3(\TEC[8]_i_12_n_0 ),
        .I4(\TEC[8]_i_5_n_0 ),
        .I5(Q[2]),
        .O(\TEC[2]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair42" *) 
  LUT2 #(
    .INIT(4'hB)) 
    \TEC[2]_i_3 
       (.I0(Q[8]),
        .I1(Q[2]),
        .O(\TEC[2]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h00000000FFFFFDFF)) 
    \TEC[2]_i_4 
       (.I0(imTX),
        .I1(\State_reg[2]_i_2_n_0 ),
        .I2(\State[1]_i_2_n_0 ),
        .I3(\TEC[8]_i_17_n_0 ),
        .I4(\State[0]_i_2_n_0 ),
        .I5(\TEC[2]_i_6_n_0 ),
        .O(\TEC[2]_i_4_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \TEC[2]_i_5 
       (.I0(\TEC[8]_i_21_n_0 ),
        .I1(Q[2]),
        .O(\TEC[2]_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair12" *) 
  LUT4 #(
    .INIT(16'hABFE)) 
    \TEC[2]_i_6 
       (.I0(\TEC[7]_i_8_n_0 ),
        .I1(Q[0]),
        .I2(Q[1]),
        .I3(Q[2]),
        .O(\TEC[2]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF55551055)) 
    \TEC[3]_i_1 
       (.I0(\TEC[3]_i_2_n_0 ),
        .I1(\TEC[3]_i_3_n_0 ),
        .I2(\TEC[8]_i_7_n_0 ),
        .I3(\TEC[8]_i_5_n_0 ),
        .I4(\TEC[3]_i_4_n_0 ),
        .I5(\TEC[3]_i_5_n_0 ),
        .O(\TEC[3]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hEEEEEEEEFFFEFEFE)) 
    \TEC[3]_i_2 
       (.I0(\TEC[8]_i_12_n_0 ),
        .I1(\TEC[8]_i_18_n_0 ),
        .I2(Q[3]),
        .I3(Q[8]),
        .I4(\TEC_reg[0]_0 ),
        .I5(\TEC[8]_i_5_n_0 ),
        .O(\TEC[3]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair33" *) 
  LUT2 #(
    .INIT(4'hE)) 
    \TEC[3]_i_3 
       (.I0(Q[8]),
        .I1(Q[3]),
        .O(\TEC[3]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h00000000FFFFFDFF)) 
    \TEC[3]_i_4 
       (.I0(imTX),
        .I1(\State_reg[2]_i_2_n_0 ),
        .I2(\State[1]_i_2_n_0 ),
        .I3(\TEC[8]_i_17_n_0 ),
        .I4(\State[0]_i_2_n_0 ),
        .I5(\TEC[3]_i_6_n_0 ),
        .O(\TEC[3]_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair40" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \TEC[3]_i_5 
       (.I0(\TEC[8]_i_21_n_0 ),
        .I1(Q[3]),
        .O(\TEC[3]_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair12" *) 
  LUT5 #(
    .INIT(32'hAAABFFFE)) 
    \TEC[3]_i_6 
       (.I0(\TEC[7]_i_8_n_0 ),
        .I1(Q[1]),
        .I2(Q[0]),
        .I3(Q[2]),
        .I4(Q[3]),
        .O(\TEC[3]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'hBBBBBBBBABAABBBB)) 
    \TEC[4]_i_1 
       (.I0(\TEC[4]_i_2_n_0 ),
        .I1(\TEC[4]_i_3_n_0 ),
        .I2(\TEC[4]_i_4_n_0 ),
        .I3(\TEC[8]_i_7_n_0 ),
        .I4(\TEC[8]_i_5_n_0 ),
        .I5(\TEC[4]_i_5_n_0 ),
        .O(\TEC[4]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair40" *) 
  LUT3 #(
    .INIT(8'h28)) 
    \TEC[4]_i_2 
       (.I0(\TEC[8]_i_21_n_0 ),
        .I1(Q[3]),
        .I2(Q[4]),
        .O(\TEC[4]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFEEEEFEFFEEE)) 
    \TEC[4]_i_3 
       (.I0(\TEC[8]_i_12_n_0 ),
        .I1(\TEC[8]_i_18_n_0 ),
        .I2(\TEC[4]_i_6_n_0 ),
        .I3(\TEC[8]_i_13_n_0 ),
        .I4(\TEC_reg[0]_0 ),
        .I5(Q[8]),
        .O(\TEC[4]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair42" *) 
  LUT3 #(
    .INIT(8'hEB)) 
    \TEC[4]_i_4 
       (.I0(Q[8]),
        .I1(Q[3]),
        .I2(Q[4]),
        .O(\TEC[4]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h00000000FFFFFDFF)) 
    \TEC[4]_i_5 
       (.I0(imTX),
        .I1(\State_reg[2]_i_2_n_0 ),
        .I2(\State[1]_i_2_n_0 ),
        .I3(\TEC[8]_i_17_n_0 ),
        .I4(\State[0]_i_2_n_0 ),
        .I5(\TEC[4]_i_7_n_0 ),
        .O(\TEC[4]_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair31" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \TEC[4]_i_6 
       (.I0(Q[4]),
        .I1(Q[3]),
        .O(\TEC[4]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'hAAAAAAABFFFFFFFE)) 
    \TEC[4]_i_7 
       (.I0(\TEC[7]_i_8_n_0 ),
        .I1(Q[2]),
        .I2(Q[0]),
        .I3(Q[1]),
        .I4(Q[3]),
        .I5(Q[4]),
        .O(\TEC[4]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'hBBBBBBBBBAAABBBB)) 
    \TEC[5]_i_1 
       (.I0(\TEC[5]_i_2_n_0 ),
        .I1(\TEC[5]_i_3_n_0 ),
        .I2(\TEC[5]_i_4_n_0 ),
        .I3(\TEC[8]_i_7_n_0 ),
        .I4(\TEC[8]_i_5_n_0 ),
        .I5(\TEC[5]_i_5_n_0 ),
        .O(\TEC[5]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT4 #(
    .INIT(16'h2A80)) 
    \TEC[5]_i_2 
       (.I0(\TEC[8]_i_21_n_0 ),
        .I1(Q[4]),
        .I2(Q[3]),
        .I3(Q[5]),
        .O(\TEC[5]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT5 #(
    .INIT(32'hFFFFAABA)) 
    \TEC[5]_i_3 
       (.I0(\TEC[8]_i_12_n_0 ),
        .I1(\State_reg[2]_0 [0]),
        .I2(\State_reg[2]_0 [2]),
        .I3(\State_reg[2]_0 [1]),
        .I4(\TEC[5]_i_6_n_0 ),
        .O(\TEC[5]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair20" *) 
  LUT4 #(
    .INIT(16'h1540)) 
    \TEC[5]_i_4 
       (.I0(Q[8]),
        .I1(Q[4]),
        .I2(Q[3]),
        .I3(Q[5]),
        .O(\TEC[5]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h00000000FFFFFDFF)) 
    \TEC[5]_i_5 
       (.I0(imTX),
        .I1(\State_reg[2]_i_2_n_0 ),
        .I2(\State[1]_i_2_n_0 ),
        .I3(\TEC[8]_i_17_n_0 ),
        .I4(\State[0]_i_2_n_0 ),
        .I5(\TEC[5]_i_7_n_0 ),
        .O(\TEC[5]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hFCCEEFFF000AAAA0)) 
    \TEC[5]_i_6 
       (.I0(\TEC[8]_i_13_n_0 ),
        .I1(Q[8]),
        .I2(Q[4]),
        .I3(Q[3]),
        .I4(Q[5]),
        .I5(\TEC_reg[0]_0 ),
        .O(\TEC[5]_i_6_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair13" *) 
  LUT5 #(
    .INIT(32'hAAAEFFFB)) 
    \TEC[5]_i_7 
       (.I0(\TEC[7]_i_8_n_0 ),
        .I1(\TEC[8]_i_15_n_0 ),
        .I2(Q[3]),
        .I3(Q[4]),
        .I4(Q[5]),
        .O(\TEC[5]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'hBBBBBBBBBAAABBBB)) 
    \TEC[6]_i_1 
       (.I0(\TEC[6]_i_2_n_0 ),
        .I1(\TEC[6]_i_3_n_0 ),
        .I2(\TEC[6]_i_4_n_0 ),
        .I3(\TEC[8]_i_7_n_0 ),
        .I4(\TEC[8]_i_5_n_0 ),
        .I5(\TEC[6]_i_5_n_0 ),
        .O(\TEC[6]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT5 #(
    .INIT(32'h2AAA8000)) 
    \TEC[6]_i_2 
       (.I0(\TEC[8]_i_21_n_0 ),
        .I1(Q[3]),
        .I2(Q[4]),
        .I3(Q[5]),
        .I4(Q[6]),
        .O(\TEC[6]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFEFEFEFEFEFFFE)) 
    \TEC[6]_i_3 
       (.I0(\TEC[8]_i_12_n_0 ),
        .I1(\TEC[8]_i_18_n_0 ),
        .I2(\TEC[6]_i_6_n_0 ),
        .I3(\TEC[8]_i_13_n_0 ),
        .I4(\TEC[6]_i_7_n_0 ),
        .I5(Q[6]),
        .O(\TEC[6]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair20" *) 
  LUT5 #(
    .INIT(32'h15554000)) 
    \TEC[6]_i_4 
       (.I0(Q[8]),
        .I1(Q[3]),
        .I2(Q[4]),
        .I3(Q[5]),
        .I4(Q[6]),
        .O(\TEC[6]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h00000000FFFFFDFF)) 
    \TEC[6]_i_5 
       (.I0(imTX),
        .I1(\State_reg[2]_i_2_n_0 ),
        .I2(\State[1]_i_2_n_0 ),
        .I3(\TEC[8]_i_17_n_0 ),
        .I4(\State[0]_i_2_n_0 ),
        .I5(\TEC[6]_i_8_n_0 ),
        .O(\TEC[6]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hAAAAAAAA82222222)) 
    \TEC[6]_i_6 
       (.I0(\TEC_reg[0]_0 ),
        .I1(Q[6]),
        .I2(Q[5]),
        .I3(Q[4]),
        .I4(Q[3]),
        .I5(Q[8]),
        .O(\TEC[6]_i_6_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair13" *) 
  LUT3 #(
    .INIT(8'h01)) 
    \TEC[6]_i_7 
       (.I0(Q[3]),
        .I1(Q[4]),
        .I2(Q[5]),
        .O(\TEC[6]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'hAAAAAAAEFFFFFFFB)) 
    \TEC[6]_i_8 
       (.I0(\TEC[7]_i_8_n_0 ),
        .I1(\TEC[8]_i_15_n_0 ),
        .I2(Q[5]),
        .I3(Q[4]),
        .I4(Q[3]),
        .I5(Q[6]),
        .O(\TEC[6]_i_8_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF55554055)) 
    \TEC[7]_i_1 
       (.I0(\TEC[7]_i_2_n_0 ),
        .I1(\TEC[7]_i_3_n_0 ),
        .I2(\TEC[8]_i_7_n_0 ),
        .I3(\TEC[8]_i_5_n_0 ),
        .I4(\TEC[7]_i_4_n_0 ),
        .I5(\TEC[7]_i_5_n_0 ),
        .O(\TEC[7]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hFFFFEEFE)) 
    \TEC[7]_i_2 
       (.I0(\TEC[8]_i_12_n_0 ),
        .I1(\TEC[8]_i_18_n_0 ),
        .I2(\TEC_reg[0]_0 ),
        .I3(\TEC[7]_i_3_n_0 ),
        .I4(\TEC[7]_i_6_n_0 ),
        .O(\TEC[7]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h1555555540000000)) 
    \TEC[7]_i_3 
       (.I0(Q[8]),
        .I1(Q[5]),
        .I2(Q[4]),
        .I3(Q[3]),
        .I4(Q[6]),
        .I5(Q[7]),
        .O(\TEC[7]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h00000000FFFFFDFF)) 
    \TEC[7]_i_4 
       (.I0(imTX),
        .I1(\State_reg[2]_i_2_n_0 ),
        .I2(\State[1]_i_2_n_0 ),
        .I3(\TEC[8]_i_17_n_0 ),
        .I4(\State[0]_i_2_n_0 ),
        .I5(\TEC[7]_i_7_n_0 ),
        .O(\TEC[7]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h2AAAAAAA80000000)) 
    \TEC[7]_i_5 
       (.I0(\TEC[8]_i_21_n_0 ),
        .I1(Q[5]),
        .I2(Q[4]),
        .I3(Q[3]),
        .I4(Q[6]),
        .I5(Q[7]),
        .O(\TEC[7]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h00000002AAAAAAA8)) 
    \TEC[7]_i_6 
       (.I0(\TEC[8]_i_13_n_0 ),
        .I1(Q[5]),
        .I2(Q[4]),
        .I3(Q[3]),
        .I4(Q[6]),
        .I5(Q[7]),
        .O(\TEC[7]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'hAAABAAAAFFFEFFFF)) 
    \TEC[7]_i_7 
       (.I0(\TEC[7]_i_8_n_0 ),
        .I1(Q[2]),
        .I2(Q[0]),
        .I3(Q[1]),
        .I4(\TEC[8]_i_16_n_0 ),
        .I5(Q[7]),
        .O(\TEC[7]_i_7_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair14" *) 
  LUT5 #(
    .INIT(32'h00800000)) 
    \TEC[7]_i_8 
       (.I0(imTX),
        .I1(Sampled_din),
        .I2(\State_reg[2]_0 [2]),
        .I3(\State_reg[2]_0 [1]),
        .I4(\State_reg[2]_0 [0]),
        .O(\TEC[7]_i_8_n_0 ));
  LUT6 #(
    .INIT(64'h8888888888888088)) 
    \TEC[8]_i_1 
       (.I0(SRST),
        .I1(ack_error_reg_1),
        .I2(\TEC[8]_i_4_n_0 ),
        .I3(\TEC[8]_i_5_n_0 ),
        .I4(\TEC[8]_i_6_n_0 ),
        .I5(\TEC[8]_i_7_n_0 ),
        .O(\TEC[8]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h1555555555555555)) 
    \TEC[8]_i_10 
       (.I0(Q[8]),
        .I1(Q[7]),
        .I2(Q[5]),
        .I3(Q[4]),
        .I4(Q[3]),
        .I5(Q[6]),
        .O(\TEC[8]_i_10_n_0 ));
  LUT6 #(
    .INIT(64'hFD00FFFFFD00FD00)) 
    \TEC[8]_i_11 
       (.I0(\State[0]_i_2_n_0 ),
        .I1(\State_reg[2]_i_2_n_0 ),
        .I2(\State[1]_i_2_n_0 ),
        .I3(\TEC[8]_i_18_n_0 ),
        .I4(\TEC[8]_i_20_n_0 ),
        .I5(\TEC[8]_i_21_n_0 ),
        .O(\TEC[8]_i_11_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair23" *) 
  LUT4 #(
    .INIT(16'hAA02)) 
    \TEC[8]_i_12 
       (.I0(\RECin_reg[7]_0 ),
        .I1(\State_reg[2]_0 [0]),
        .I2(\State_reg[2]_0 [1]),
        .I3(\State_reg[2]_0 [2]),
        .O(\TEC[8]_i_12_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000002000)) 
    \TEC[8]_i_13 
       (.I0(ack_error_i_3_n_0),
        .I1(\TEC[8]_i_22_n_0 ),
        .I2(ack_error_reg_n_0),
        .I3(nozero_reg_n_0),
        .I4(\Cnt_reg_n_0_[2] ),
        .I5(\Cnt_reg_n_0_[0] ),
        .O(\TEC[8]_i_13_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair38" *) 
  LUT3 #(
    .INIT(8'h01)) 
    \TEC[8]_i_15 
       (.I0(Q[1]),
        .I1(Q[0]),
        .I2(Q[2]),
        .O(\TEC[8]_i_15_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair31" *) 
  LUT4 #(
    .INIT(16'h0001)) 
    \TEC[8]_i_16 
       (.I0(Q[5]),
        .I1(Q[4]),
        .I2(Q[3]),
        .I3(Q[6]),
        .O(\TEC[8]_i_16_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair41" *) 
  LUT3 #(
    .INIT(8'h40)) 
    \TEC[8]_i_17 
       (.I0(\State_reg[2]_0 [2]),
        .I1(\State_reg[2]_0 [1]),
        .I2(\State_reg[2]_0 [0]),
        .O(\TEC[8]_i_17_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair41" *) 
  LUT3 #(
    .INIT(8'h04)) 
    \TEC[8]_i_18 
       (.I0(\State_reg[2]_0 [0]),
        .I1(\State_reg[2]_0 [2]),
        .I2(\State_reg[2]_0 [1]),
        .O(\TEC[8]_i_18_n_0 ));
  LUT6 #(
    .INIT(64'h5555555555555556)) 
    \TEC[8]_i_19 
       (.I0(Q[8]),
        .I1(Q[7]),
        .I2(Q[5]),
        .I3(Q[4]),
        .I4(Q[3]),
        .I5(Q[6]),
        .O(\TEC[8]_i_19_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF11155515)) 
    \TEC[8]_i_2 
       (.I0(\TEC[8]_i_8_n_0 ),
        .I1(\TEC[8]_i_5_n_0 ),
        .I2(\TEC[8]_i_9_n_0 ),
        .I3(\TEC[8]_i_7_n_0 ),
        .I4(\TEC[8]_i_10_n_0 ),
        .I5(\TEC[8]_i_11_n_0 ),
        .O(\TEC[8]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h9555555555555555)) 
    \TEC[8]_i_20 
       (.I0(Q[8]),
        .I1(Q[7]),
        .I2(Q[5]),
        .I3(Q[4]),
        .I4(Q[3]),
        .I5(Q[6]),
        .O(\TEC[8]_i_20_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair23" *) 
  LUT4 #(
    .INIT(16'hA082)) 
    \TEC[8]_i_21 
       (.I0(\RECin_reg[7]_0 ),
        .I1(\State_reg[2]_0 [1]),
        .I2(\State_reg[2]_0 [2]),
        .I3(\State_reg[2]_0 [0]),
        .O(\TEC[8]_i_21_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \TEC[8]_i_22 
       (.I0(\Cnt_reg_n_0_[1] ),
        .I1(\Cnt_reg_n_0_[3] ),
        .O(\TEC[8]_i_22_n_0 ));
  LUT6 #(
    .INIT(64'hFDFFFFCFFDFFFFFF)) 
    \TEC[8]_i_23 
       (.I0(TXpin_i_5_n_0),
        .I1(\State_reg[2]_0 [2]),
        .I2(\State_reg[2]_0 [1]),
        .I3(\State_reg[2]_0 [0]),
        .I4(Sampled_din),
        .I5(\Cnt[3]_i_3__1_n_0 ),
        .O(\State_reg[2]_3 ));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT4 #(
    .INIT(16'hFF04)) 
    \TEC[8]_i_4 
       (.I0(\State_reg[2]_0 [1]),
        .I1(\State_reg[2]_0 [2]),
        .I2(\State_reg[2]_0 [0]),
        .I3(\TEC[8]_i_12_n_0 ),
        .O(\TEC[8]_i_4_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \TEC[8]_i_5 
       (.I0(\TEC[8]_i_13_n_0 ),
        .I1(\TEC_reg[0]_0 ),
        .O(\TEC[8]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h00000000FFDF0000)) 
    \TEC[8]_i_6 
       (.I0(\TEC[8]_i_15_n_0 ),
        .I1(Q[7]),
        .I2(\TEC[8]_i_16_n_0 ),
        .I3(Q[8]),
        .I4(\TEC_reg[0]_1 ),
        .I5(donefromtxr_reg_n_0),
        .O(\TEC[8]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'h00000200AAAAAAAA)) 
    \TEC[8]_i_7 
       (.I0(imTX),
        .I1(\State_reg[2]_i_2_n_0 ),
        .I2(\State[1]_i_2_n_0 ),
        .I3(\TEC[8]_i_17_n_0 ),
        .I4(\State[0]_i_2_n_0 ),
        .I5(\REC[8]_i_4_n_0 ),
        .O(\TEC[8]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'hFEFFEEEEFEEEFEEE)) 
    \TEC[8]_i_8 
       (.I0(\TEC[8]_i_12_n_0 ),
        .I1(\TEC[8]_i_18_n_0 ),
        .I2(\TEC[8]_i_19_n_0 ),
        .I3(\TEC[8]_i_13_n_0 ),
        .I4(\TEC[8]_i_10_n_0 ),
        .I5(\TEC_reg[0]_0 ),
        .O(\TEC[8]_i_8_n_0 ));
  LUT6 #(
    .INIT(64'h5555555555555559)) 
    \TEC[8]_i_9 
       (.I0(Q[8]),
        .I1(\TEC[8]_i_16_n_0 ),
        .I2(Q[7]),
        .I3(Q[1]),
        .I4(Q[0]),
        .I5(Q[2]),
        .O(\TEC[8]_i_9_n_0 ));
  FDCE \TEC_reg[0] 
       (.C(Tq),
        .CE(\TEC[8]_i_1_n_0 ),
        .CLR(ack_error_reg_0),
        .D(\TEC[0]_i_1_n_0 ),
        .Q(Q[0]));
  FDCE \TEC_reg[1] 
       (.C(Tq),
        .CE(\TEC[8]_i_1_n_0 ),
        .CLR(ack_error_reg_0),
        .D(\TEC[1]_i_1_n_0 ),
        .Q(Q[1]));
  FDCE \TEC_reg[2] 
       (.C(Tq),
        .CE(\TEC[8]_i_1_n_0 ),
        .CLR(ack_error_reg_0),
        .D(\TEC[2]_i_1_n_0 ),
        .Q(Q[2]));
  FDCE \TEC_reg[3] 
       (.C(Tq),
        .CE(\TEC[8]_i_1_n_0 ),
        .CLR(ack_error_reg_0),
        .D(\TEC[3]_i_1_n_0 ),
        .Q(Q[3]));
  FDCE \TEC_reg[4] 
       (.C(Tq),
        .CE(\TEC[8]_i_1_n_0 ),
        .CLR(ack_error_reg_0),
        .D(\TEC[4]_i_1_n_0 ),
        .Q(Q[4]));
  FDCE \TEC_reg[5] 
       (.C(Tq),
        .CE(\TEC[8]_i_1_n_0 ),
        .CLR(ack_error_reg_0),
        .D(\TEC[5]_i_1_n_0 ),
        .Q(Q[5]));
  FDCE \TEC_reg[6] 
       (.C(Tq),
        .CE(\TEC[8]_i_1_n_0 ),
        .CLR(ack_error_reg_0),
        .D(\TEC[6]_i_1_n_0 ),
        .Q(Q[6]));
  FDCE \TEC_reg[7] 
       (.C(Tq),
        .CE(\TEC[8]_i_1_n_0 ),
        .CLR(ack_error_reg_0),
        .D(\TEC[7]_i_1_n_0 ),
        .Q(Q[7]));
  FDCE \TEC_reg[8] 
       (.C(Tq),
        .CE(\TEC[8]_i_1_n_0 ),
        .CLR(ack_error_reg_0),
        .D(\TEC[8]_i_2_n_0 ),
        .Q(Q[8]));
  LUT5 #(
    .INIT(32'hB0B0B0BB)) 
    \TECin[8]_i_1 
       (.I0(ack_error_reg_1),
        .I1(SRST),
        .I2(\TECin[8]_i_2_n_0 ),
        .I3(\State_reg[2]_0 [2]),
        .I4(\TECin[8]_i_3_n_0 ),
        .O(RECin));
  LUT6 #(
    .INIT(64'h0C100000FFFFFFFF)) 
    \TECin[8]_i_2 
       (.I0(\Cnt[3]_i_3__1_n_0 ),
        .I1(\State_reg[2]_0 [0]),
        .I2(\State_reg[2]_0 [1]),
        .I3(Sampled_din),
        .I4(\State_reg[2]_0 [2]),
        .I5(SRST),
        .O(\TECin[8]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFF0FFFF11FF11)) 
    \TECin[8]_i_3 
       (.I0(req_Error_RX),
        .I1(\RECin_reg[7]_0 ),
        .I2(\Cnt[3]_i_9_n_0 ),
        .I3(\State_reg[2]_0 [1]),
        .I4(Sampled_din),
        .I5(\State_reg[2]_0 [0]),
        .O(\TECin[8]_i_3_n_0 ));
  FDCE \TECin_reg[7] 
       (.C(Tq),
        .CE(RECin),
        .CLR(ack_error_reg_0),
        .D(Q[7]),
        .Q(\TECin_reg_n_0_[7] ));
  FDCE \TECin_reg[8] 
       (.C(Tq),
        .CE(RECin),
        .CLR(ack_error_reg_0),
        .D(Q[8]),
        .Q(\TECin_reg_n_0_[8] ));
  (* SOFT_HLUTNM = "soft_lutpair43" *) 
  LUT3 #(
    .INIT(8'h40)) 
    \TXSTATES[0]_i_1 
       (.I0(\State_reg[0]_1 ),
        .I1(SRST),
        .I2(\TXSTATES_reg[0] ),
        .O(D[0]));
  (* SOFT_HLUTNM = "soft_lutpair43" *) 
  LUT3 #(
    .INIT(8'h40)) 
    \TXSTATES[1]_i_1 
       (.I0(\State_reg[0]_1 ),
        .I1(SRST),
        .I2(\TXSTATES_reg[1] ),
        .O(D[1]));
  (* SOFT_HLUTNM = "soft_lutpair36" *) 
  LUT3 #(
    .INIT(8'hA8)) 
    \TXSTATES[2]_i_1 
       (.I0(SRST),
        .I1(\State_reg[0]_1 ),
        .I2(\TXSTATES_reg[2] ),
        .O(D[2]));
  (* SOFT_HLUTNM = "soft_lutpair36" *) 
  LUT3 #(
    .INIT(8'hA8)) 
    \TXSTATES[3]_i_2 
       (.I0(SRST),
        .I1(\State_reg[0]_1 ),
        .I2(\TXSTATES_reg[3] ),
        .O(D[3]));
  (* SOFT_HLUTNM = "soft_lutpair24" *) 
  LUT4 #(
    .INIT(16'hFF0E)) 
    \TXSTATES[3]_i_3 
       (.I0(\State_reg[2]_0 [0]),
        .I1(\State_reg[2]_0 [1]),
        .I2(\State_reg[2]_0 [2]),
        .I3(\RECin_reg[7]_0 ),
        .O(\State_reg[0]_1 ));
  LUT1 #(
    .INIT(2'h1)) 
    TX_INST_0
       (.I0(\Mode_1[1] ),
        .O(TX));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT4 #(
    .INIT(16'h00A2)) 
    TX_INST_0_i_1
       (.I0(TX_INST_0_i_2_n_0),
        .I1(Mode[1]),
        .I2(Mode[2]),
        .I3(Mode[0]),
        .O(\Mode_1[1] ));
  (* SOFT_HLUTNM = "soft_lutpair33" *) 
  LUT4 #(
    .INIT(16'h5515)) 
    TX_INST_0_i_2
       (.I0(Q[8]),
        .I1(TX_from_Err),
        .I2(AckTakeOver),
        .I3(IDE_i_2_0),
        .O(TX_INST_0_i_2_n_0));
  (* SOFT_HLUTNM = "soft_lutpair32" *) 
  LUT4 #(
    .INIT(16'hE2FF)) 
    TXpin_i_1
       (.I0(TXpin_i_2_n_0),
        .I1(\State_reg[2]_0 [2]),
        .I2(TXpin_i_3_n_0),
        .I3(SRST),
        .O(TXpin_i_1_n_0));
  LUT6 #(
    .INIT(64'hB8BBBBBBB8BB8888)) 
    TXpin_i_2
       (.I0(TXpin_i_4_n_0),
        .I1(\State_reg[2]_0 [1]),
        .I2(\Cnt[0]_i_3__1_n_0 ),
        .I3(TXpin_i_5_n_0),
        .I4(\State_reg[2]_0 [0]),
        .I5(TXpin_i_6_n_0),
        .O(TXpin_i_2_n_0));
  LUT6 #(
    .INIT(64'hCFCFF3C3FFFFF7C7)) 
    TXpin_i_3
       (.I0(\Cnt[3]_i_3__1_n_0 ),
        .I1(\State_reg[2]_0 [1]),
        .I2(\State_reg[2]_0 [0]),
        .I3(\Cnt[0]_i_3__1_n_0 ),
        .I4(Sampled_din),
        .I5(\TEC_reg[8]_0 ),
        .O(TXpin_i_3_n_0));
  LUT6 #(
    .INIT(64'hFFFF5545FFFFFFFF)) 
    TXpin_i_4
       (.I0(\Cnt[3]_i_9_n_0 ),
        .I1(Q[8]),
        .I2(\REC_reg[8]_1 ),
        .I3(Q[7]),
        .I4(Sampled_din),
        .I5(\State_reg[2]_0 [0]),
        .O(TXpin_i_4_n_0));
  LUT4 #(
    .INIT(16'h0001)) 
    TXpin_i_5
       (.I0(\RECin_reg_n_0_[7] ),
        .I1(\TECin_reg_n_0_[8] ),
        .I2(\RECin_reg_n_0_[8] ),
        .I3(\TECin_reg_n_0_[7] ),
        .O(TXpin_i_5_n_0));
  LUT5 #(
    .INIT(32'h35353533)) 
    TXpin_i_6
       (.I0(\TEC_reg[8]_0 ),
        .I1(\State_reg[0]_4 ),
        .I2(\State_reg[2]_1 ),
        .I3(\RECin_reg[7]_0 ),
        .I4(req_Error_RX),
        .O(TXpin_i_6_n_0));
  (* SOFT_HLUTNM = "soft_lutpair34" *) 
  LUT4 #(
    .INIT(16'h0001)) 
    TXpin_i_7
       (.I0(Q[8]),
        .I1(\REC_reg[8]_0 [8]),
        .I2(\REC_reg[8]_0 [7]),
        .I3(Q[7]),
        .O(\TEC_reg[8]_0 ));
  FDPE TXpin_reg
       (.C(Tq),
        .CE(\State_reg[0]_3 ),
        .D(TXpin_i_1_n_0),
        .PRE(ack_error_reg_0),
        .Q(TX_from_Err));
  LUT6 #(
    .INIT(64'hFEFFAAAA0200AAAA)) 
    ack_error_i_1
       (.I0(ack_error),
        .I1(\Cnt[0]_i_4__1_n_0 ),
        .I2(ack_error_i_3_n_0),
        .I3(ack_error_reg_1),
        .I4(SRST),
        .I5(ack_error_reg_n_0),
        .O(ack_error_i_1_n_0));
  LUT6 #(
    .INIT(64'h0000000000020000)) 
    ack_error_i_2
       (.I0(SRST),
        .I1(\State_reg[2]_0 [2]),
        .I2(\State_reg[2]_0 [1]),
        .I3(\State_reg[2]_0 [0]),
        .I4(ack_error_reg_2),
        .I5(ack_error_reg_3),
        .O(ack_error));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT3 #(
    .INIT(8'h04)) 
    ack_error_i_3
       (.I0(\State_reg[2]_0 [2]),
        .I1(\State_reg[2]_0 [1]),
        .I2(\State_reg[2]_0 [0]),
        .O(ack_error_i_3_n_0));
  FDCE ack_error_reg
       (.C(Tq),
        .CE(1'b1),
        .CLR(ack_error_reg_0),
        .D(ack_error_i_1_n_0),
        .Q(ack_error_reg_n_0));
  FDCE donefromrxr_reg
       (.C(Tq),
        .CE(\State_reg[0]_3 ),
        .CLR(ack_error_reg_0),
        .D(donefromrxr),
        .Q(donefromrxr_reg_n_0));
  FDCE donefromtxr_reg
       (.C(Tq),
        .CE(\State_reg[0]_3 ),
        .CLR(ack_error_reg_0),
        .D(donefromtxr),
        .Q(donefromtxr_reg_n_0));
  FDPE lastvalue_reg
       (.C(Tq),
        .CE(\State_reg[0]_3 ),
        .D(lastvalue_reg_0),
        .PRE(ack_error_reg_0),
        .Q(lastvalue));
  LUT6 #(
    .INIT(64'hFFFDFDFDFFFFFFFF)) 
    nozero_i_1
       (.I0(\State_reg[2]_0 [0]),
        .I1(\State_reg[2]_0 [2]),
        .I2(\State_reg[2]_0 [1]),
        .I3(Sampled_din),
        .I4(nozero_reg_n_0),
        .I5(SRST),
        .O(nozero_i_1_n_0));
  FDPE nozero_reg
       (.C(Tq),
        .CE(\State_reg[0]_3 ),
        .D(nozero_i_1_n_0),
        .PRE(ack_error_reg_0),
        .Q(nozero_reg_n_0));
endmodule

(* ORIG_REF_NAME = "FPGAPROJECT" *) 
module design_1_FPGAPROJECT_0_0_FPGAPROJECT
   (Q,
    \REC_reg[8] ,
    done_reg,
    RTR_rec_0,
    D_Len_rec_0,
    TOFILTERd_0,
    TOFILTERI_0,
    done_reg_0,
    done_RX_1,
    done_TX_1,
    IDE_rec_1,
    RTR_rec_1,
    D_Len_rec_1,
    TOFILTERd_1,
    TOFILTERI_1,
    TEC_1,
    REC_1,
    IDE_rec_0,
    SRST_0,
    IDE_TX_0,
    CAN_CLK,
    CAN_RST,
    BRP_0,
    TRANSMIT_0,
    SRST_1,
    BRP_1,
    Mode_1,
    TRANSMIT_1,
    IDE_TX_1,
    RTR_TX_1,
    D_Len_TX_1,
    ID_TX_1,
    data_TX_1,
    Mode_0,
    RTR_TX_0,
    D_Len_TX_0,
    ID_TX_0,
    data_TX_0);
  output [8:0]Q;
  output [8:0]\REC_reg[8] ;
  output done_reg;
  output RTR_rec_0;
  output [3:0]D_Len_rec_0;
  output [63:0]TOFILTERd_0;
  output [28:0]TOFILTERI_0;
  output done_reg_0;
  output done_RX_1;
  output done_TX_1;
  output IDE_rec_1;
  output RTR_rec_1;
  output [3:0]D_Len_rec_1;
  output [63:0]TOFILTERd_1;
  output [28:0]TOFILTERI_1;
  output [8:0]TEC_1;
  output [8:0]REC_1;
  output IDE_rec_0;
  input SRST_0;
  input IDE_TX_0;
  input CAN_CLK;
  input CAN_RST;
  input [4:0]BRP_0;
  input TRANSMIT_0;
  input SRST_1;
  input [4:0]BRP_1;
  input [2:0]Mode_1;
  input TRANSMIT_1;
  input IDE_TX_1;
  input RTR_TX_1;
  input [3:0]D_Len_TX_1;
  input [28:0]ID_TX_1;
  input [63:0]data_TX_1;
  input [2:0]Mode_0;
  input RTR_TX_0;
  input [3:0]D_Len_TX_0;
  input [28:0]ID_TX_0;
  input [63:0]data_TX_0;

  wire [4:0]BRP_0;
  wire [4:0]BRP_1;
  wire BUS;
  wire CAN_CLK;
  wire CAN_RST;
  wire [3:0]D_Len_TX_0;
  wire [3:0]D_Len_TX_1;
  wire [3:0]D_Len_rec_0;
  wire [3:0]D_Len_rec_1;
  wire IDE_TX_0;
  wire IDE_TX_1;
  wire IDE_rec_0;
  wire IDE_rec_1;
  wire [28:0]ID_TX_0;
  wire [28:0]ID_TX_1;
  wire [2:0]Mode_0;
  wire [2:0]Mode_1;
  wire [8:0]Q;
  wire [8:0]REC_1;
  wire [8:0]\REC_reg[8] ;
  wire RTR_TX_0;
  wire RTR_TX_1;
  wire RTR_rec_0;
  wire RTR_rec_1;
  wire SRST_0;
  wire SRST_1;
  wire [8:0]TEC_1;
  wire [28:0]TOFILTERI_0;
  wire [28:0]TOFILTERI_1;
  wire [63:0]TOFILTERd_0;
  wire [63:0]TOFILTERd_1;
  wire TRANSMIT_0;
  wire TRANSMIT_1;
  wire TX_1;
  wire [63:0]data_TX_0;
  wire [63:0]data_TX_1;
  wire done_RX_1;
  wire done_TX_1;
  wire done_reg;
  wire done_reg_0;

  design_1_FPGAPROJECT_0_0_CANCORE__2 CANCORE_0
       (.BRP_0(BRP_0),
        .CAN_CLK(CAN_CLK),
        .CAN_RST(CAN_RST),
        .D_Len_TX_0(D_Len_TX_0),
        .D_Len_rec_0(D_Len_rec_0),
        .IDE_TX_0(IDE_TX_0),
        .IDE_rec_0(IDE_rec_0),
        .ID_TX_0(ID_TX_0),
        .Mode_0(Mode_0),
        .Q(Q),
        .\REC_reg[8] (\REC_reg[8] ),
        .RTR_TX_0(RTR_TX_0),
        .RTR_rec_0(RTR_rec_0),
        .RX(BUS),
        .SRST_0(SRST_0),
        .TOFILTERI_0(TOFILTERI_0),
        .TOFILTERd_0(TOFILTERd_0),
        .TRANSMIT_0(TRANSMIT_0),
        .TX(TX_1),
        .data_TX_0(data_TX_0),
        .done_TX(done_reg_0),
        .done_reg(done_reg));
  (* KEEP_HIERARCHY = "YES" *) 
  design_1_FPGAPROJECT_0_0_CANCORE CANCORE_1
       (.BRP(BRP_1),
        .CAN_CLK(CAN_CLK),
        .CAN_RST(CAN_RST),
        .D_Len_TX(D_Len_TX_1),
        .D_Len_rec(D_Len_rec_1),
        .IDE_TX(IDE_TX_1),
        .IDE_rec(IDE_rec_1),
        .ID_TX(ID_TX_1),
        .Mode(Mode_1),
        .REC(REC_1),
        .RTR_TX(RTR_TX_1),
        .RTR_rec(RTR_rec_1),
        .RX(BUS),
        .SJW({1'b0,1'b1,1'b0}),
        .SRST(SRST_1),
        .TEC(TEC_1),
        .TOFILTERI(TOFILTERI_1),
        .TOFILTERd(TOFILTERd_1),
        .TPROP({1'b0,1'b1,1'b0,1'b0}),
        .TRANSMIT(TRANSMIT_1),
        .TSEG1({1'b0,1'b1,1'b0,1'b0}),
        .TSEG2({1'b0,1'b1,1'b0,1'b0}),
        .TX(TX_1),
        .data_TX(data_TX_1),
        .done_RX(done_RX_1),
        .done_TX(done_TX_1));
endmodule

(* ORIG_REF_NAME = "Prescaler" *) 
module design_1_FPGAPROJECT_0_0_Prescaler
   (\count_reg[4]_0 ,
    clk,
    \count_reg[0]_0 ,
    CAN_CLK,
    \count_reg[0]_1 ,
    Tq_reg_0,
    BRP_0);
  output [1:0]\count_reg[4]_0 ;
  output clk;
  output \count_reg[0]_0 ;
  input CAN_CLK;
  input \count_reg[0]_1 ;
  input Tq_reg_0;
  input [4:0]BRP_0;

  wire [4:0]BRP_0;
  wire CAN_CLK;
  wire Tq_reg_0;
  wire clk;
  wire \count[0]_i_1_n_0 ;
  wire \count[4]_i_3_n_0 ;
  wire [2:0]count_reg;
  wire \count_reg[0]_0 ;
  wire \count_reg[0]_1 ;
  wire [1:0]\count_reg[4]_0 ;
  wire [4:1]ncount;
  wire ncount1__20;

  LUT6 #(
    .INIT(64'h9009000000009009)) 
    Tq_i_2
       (.I0(count_reg[0]),
        .I1(BRP_0[0]),
        .I2(BRP_0[2]),
        .I3(count_reg[2]),
        .I4(BRP_0[1]),
        .I5(count_reg[1]),
        .O(\count_reg[0]_0 ));
  FDCE Tq_reg
       (.C(CAN_CLK),
        .CE(1'b1),
        .CLR(\count_reg[0]_1 ),
        .D(Tq_reg_0),
        .Q(clk));
  (* SOFT_HLUTNM = "soft_lutpair161" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \count[0]_i_1 
       (.I0(ncount1__20),
        .I1(count_reg[0]),
        .O(\count[0]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair161" *) 
  LUT3 #(
    .INIT(8'h60)) 
    \count[1]_i_1 
       (.I0(count_reg[1]),
        .I1(count_reg[0]),
        .I2(ncount1__20),
        .O(ncount[1]));
  (* SOFT_HLUTNM = "soft_lutpair160" *) 
  LUT4 #(
    .INIT(16'h6A00)) 
    \count[2]_i_1 
       (.I0(count_reg[2]),
        .I1(count_reg[1]),
        .I2(count_reg[0]),
        .I3(ncount1__20),
        .O(ncount[2]));
  (* SOFT_HLUTNM = "soft_lutpair160" *) 
  LUT5 #(
    .INIT(32'h6AAA0000)) 
    \count[3]_i_1 
       (.I0(\count_reg[4]_0 [0]),
        .I1(count_reg[2]),
        .I2(count_reg[0]),
        .I3(count_reg[1]),
        .I4(ncount1__20),
        .O(ncount[3]));
  LUT6 #(
    .INIT(64'h6AAAAAAA00000000)) 
    \count[4]_i_1 
       (.I0(\count_reg[4]_0 [1]),
        .I1(\count_reg[4]_0 [0]),
        .I2(count_reg[1]),
        .I3(count_reg[0]),
        .I4(count_reg[2]),
        .I5(ncount1__20),
        .O(ncount[4]));
  LUT5 #(
    .INIT(32'hB2FF00B2)) 
    \count[4]_i_2 
       (.I0(\count[4]_i_3_n_0 ),
        .I1(\count_reg[4]_0 [0]),
        .I2(BRP_0[3]),
        .I3(\count_reg[4]_0 [1]),
        .I4(BRP_0[4]),
        .O(ncount1__20));
  LUT6 #(
    .INIT(64'h2F02FFFF00002F02)) 
    \count[4]_i_3 
       (.I0(BRP_0[0]),
        .I1(count_reg[0]),
        .I2(count_reg[1]),
        .I3(BRP_0[1]),
        .I4(count_reg[2]),
        .I5(BRP_0[2]),
        .O(\count[4]_i_3_n_0 ));
  FDCE \count_reg[0] 
       (.C(CAN_CLK),
        .CE(1'b1),
        .CLR(\count_reg[0]_1 ),
        .D(\count[0]_i_1_n_0 ),
        .Q(count_reg[0]));
  FDCE \count_reg[1] 
       (.C(CAN_CLK),
        .CE(1'b1),
        .CLR(\count_reg[0]_1 ),
        .D(ncount[1]),
        .Q(count_reg[1]));
  FDCE \count_reg[2] 
       (.C(CAN_CLK),
        .CE(1'b1),
        .CLR(\count_reg[0]_1 ),
        .D(ncount[2]),
        .Q(count_reg[2]));
  FDCE \count_reg[3] 
       (.C(CAN_CLK),
        .CE(1'b1),
        .CLR(\count_reg[0]_1 ),
        .D(ncount[3]),
        .Q(\count_reg[4]_0 [0]));
  FDCE \count_reg[4] 
       (.C(CAN_CLK),
        .CE(1'b1),
        .CLR(\count_reg[0]_1 ),
        .D(ncount[4]),
        .Q(\count_reg[4]_0 [1]));
endmodule

(* ORIG_REF_NAME = "Prescaler" *) 
module design_1_FPGAPROJECT_0_0_Prescaler_4
   (Tq,
    CAN_CLK,
    \count_reg[0]_0 ,
    BRP);
  output Tq;
  input CAN_CLK;
  input \count_reg[0]_0 ;
  input [4:0]BRP;

  wire [4:0]BRP;
  wire CAN_CLK;
  wire Tq;
  wire Tq_i_1_n_0;
  wire Tq_i_2_n_0;
  wire \count[0]_i_1_n_0 ;
  wire \count[4]_i_3_n_0 ;
  wire [4:0]count_reg;
  wire \count_reg[0]_0 ;
  wire [4:1]ncount;
  wire ncount1__20;

  LUT6 #(
    .INIT(64'h6FFFFF6F90000090)) 
    Tq_i_1
       (.I0(count_reg[4]),
        .I1(BRP[4]),
        .I2(Tq_i_2_n_0),
        .I3(BRP[3]),
        .I4(count_reg[3]),
        .I5(Tq),
        .O(Tq_i_1_n_0));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    Tq_i_2
       (.I0(count_reg[0]),
        .I1(BRP[0]),
        .I2(BRP[2]),
        .I3(count_reg[2]),
        .I4(BRP[1]),
        .I5(count_reg[1]),
        .O(Tq_i_2_n_0));
  FDCE Tq_reg
       (.C(CAN_CLK),
        .CE(1'b1),
        .CLR(\count_reg[0]_0 ),
        .D(Tq_i_1_n_0),
        .Q(Tq));
  (* SOFT_HLUTNM = "soft_lutpair48" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \count[0]_i_1 
       (.I0(ncount1__20),
        .I1(count_reg[0]),
        .O(\count[0]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair48" *) 
  LUT3 #(
    .INIT(8'h60)) 
    \count[1]_i_1 
       (.I0(count_reg[1]),
        .I1(count_reg[0]),
        .I2(ncount1__20),
        .O(ncount[1]));
  (* SOFT_HLUTNM = "soft_lutpair47" *) 
  LUT4 #(
    .INIT(16'h6A00)) 
    \count[2]_i_1 
       (.I0(count_reg[2]),
        .I1(count_reg[1]),
        .I2(count_reg[0]),
        .I3(ncount1__20),
        .O(ncount[2]));
  (* SOFT_HLUTNM = "soft_lutpair47" *) 
  LUT5 #(
    .INIT(32'h6AAA0000)) 
    \count[3]_i_1 
       (.I0(count_reg[3]),
        .I1(count_reg[2]),
        .I2(count_reg[0]),
        .I3(count_reg[1]),
        .I4(ncount1__20),
        .O(ncount[3]));
  LUT6 #(
    .INIT(64'h6AAAAAAA00000000)) 
    \count[4]_i_1 
       (.I0(count_reg[4]),
        .I1(count_reg[3]),
        .I2(count_reg[1]),
        .I3(count_reg[0]),
        .I4(count_reg[2]),
        .I5(ncount1__20),
        .O(ncount[4]));
  LUT5 #(
    .INIT(32'hB2FF00B2)) 
    \count[4]_i_2 
       (.I0(\count[4]_i_3_n_0 ),
        .I1(count_reg[3]),
        .I2(BRP[3]),
        .I3(count_reg[4]),
        .I4(BRP[4]),
        .O(ncount1__20));
  LUT6 #(
    .INIT(64'h2F02FFFF00002F02)) 
    \count[4]_i_3 
       (.I0(BRP[0]),
        .I1(count_reg[0]),
        .I2(count_reg[1]),
        .I3(BRP[1]),
        .I4(count_reg[2]),
        .I5(BRP[2]),
        .O(\count[4]_i_3_n_0 ));
  FDCE \count_reg[0] 
       (.C(CAN_CLK),
        .CE(1'b1),
        .CLR(\count_reg[0]_0 ),
        .D(\count[0]_i_1_n_0 ),
        .Q(count_reg[0]));
  FDCE \count_reg[1] 
       (.C(CAN_CLK),
        .CE(1'b1),
        .CLR(\count_reg[0]_0 ),
        .D(ncount[1]),
        .Q(count_reg[1]));
  FDCE \count_reg[2] 
       (.C(CAN_CLK),
        .CE(1'b1),
        .CLR(\count_reg[0]_0 ),
        .D(ncount[2]),
        .Q(count_reg[2]));
  FDCE \count_reg[3] 
       (.C(CAN_CLK),
        .CE(1'b1),
        .CLR(\count_reg[0]_0 ),
        .D(ncount[3]),
        .Q(count_reg[3]));
  FDCE \count_reg[4] 
       (.C(CAN_CLK),
        .CE(1'b1),
        .CLR(\count_reg[0]_0 ),
        .D(ncount[4]),
        .Q(count_reg[4]));
endmodule

(* ORIG_REF_NAME = "RXMachine" *) 
module design_1_FPGAPROJECT_0_0_RXMachine
   (AckTakeOver,
    CAN_RST_0,
    RTR_rec_0,
    req_Error_RX,
    IDE_rec_0,
    done_reg_0,
    RXOUT_reg,
    \RXSTATES_reg[2]_0 ,
    req_Error_reg_0,
    Q,
    \RXSTATES_reg[2]_1 ,
    \RXSTATES_reg[1]_0 ,
    \RXSTATES_reg[3]_0 ,
    TOFILTERd_0,
    \bs_reg[1]_0 ,
    TOFILTERI_0,
    donefromrxr,
    E,
    clk,
    SRST_0,
    \TOFILTERd_reg[0]_0 ,
    \CRC_RG_reg[14] ,
    Sampled_din,
    \bs_reg[0]_0 ,
    \RXSTATES_reg[0]_0 ,
    TXpin_i_2,
    TXpin_i_2_0,
    \RXSTATES_reg[0]_1 ,
    \CNT2_reg[3] ,
    \CNT2_reg[3]_0 ,
    \RXSTATES_reg[3]_1 ,
    imTX,
    CAN_RST,
    \RXSTATES_reg[3]_2 ,
    D,
    \Cnt_reg[0]_0 );
  output AckTakeOver;
  output CAN_RST_0;
  output RTR_rec_0;
  output req_Error_RX;
  output IDE_rec_0;
  output done_reg_0;
  output RXOUT_reg;
  output \RXSTATES_reg[2]_0 ;
  output req_Error_reg_0;
  output [3:0]Q;
  output [0:0]\RXSTATES_reg[2]_1 ;
  output \RXSTATES_reg[1]_0 ;
  output \RXSTATES_reg[3]_0 ;
  output [63:0]TOFILTERd_0;
  output \bs_reg[1]_0 ;
  output [28:0]TOFILTERI_0;
  output donefromrxr;
  input [0:0]E;
  input clk;
  input SRST_0;
  input \TOFILTERd_reg[0]_0 ;
  input \CRC_RG_reg[14] ;
  input Sampled_din;
  input [0:0]\bs_reg[0]_0 ;
  input \RXSTATES_reg[0]_0 ;
  input TXpin_i_2;
  input TXpin_i_2_0;
  input \RXSTATES_reg[0]_1 ;
  input \CNT2_reg[3] ;
  input \CNT2_reg[3]_0 ;
  input \RXSTATES_reg[3]_1 ;
  input imTX;
  input CAN_RST;
  input [0:0]\RXSTATES_reg[3]_2 ;
  input [0:0]D;
  input [0:0]\Cnt_reg[0]_0 ;

  wire AckTakeOver;
  wire AckTakeOver_i_1_n_0;
  wire AckTakeOver_i_2_n_0;
  wire CAN_RST;
  wire CAN_RST_0;
  wire \CNT2_reg[3] ;
  wire \CNT2_reg[3]_0 ;
  wire \CRC_RG_reg[14] ;
  wire \Cnt[0]_i_1__0_n_0 ;
  wire \Cnt[0]_i_2__0_n_0 ;
  wire \Cnt[0]_i_3__0_n_0 ;
  wire \Cnt[0]_i_4__0_n_0 ;
  wire \Cnt[0]_i_5_n_0 ;
  wire \Cnt[1]_i_1_n_0 ;
  wire \Cnt[1]_i_2__0_n_0 ;
  wire \Cnt[1]_i_3_n_0 ;
  wire \Cnt[1]_i_4__0_n_0 ;
  wire \Cnt[1]_i_5_n_0 ;
  wire \Cnt[1]_i_6_n_0 ;
  wire \Cnt[2]_i_1_n_0 ;
  wire \Cnt[2]_i_2__0_n_0 ;
  wire \Cnt[2]_i_3__0_n_0 ;
  wire \Cnt[2]_i_4_n_0 ;
  wire \Cnt[2]_i_5_n_0 ;
  wire \Cnt[2]_i_6_n_0 ;
  wire \Cnt[3]_i_1_n_0 ;
  wire \Cnt[3]_i_2_n_0 ;
  wire \Cnt[3]_i_3_n_0 ;
  wire \Cnt[3]_i_4__0_n_0 ;
  wire \Cnt[4]_i_1_n_0 ;
  wire \Cnt[4]_i_2_n_0 ;
  wire \Cnt[4]_i_3_n_0 ;
  wire \Cnt[4]_i_4__0_n_0 ;
  wire \Cnt[4]_i_5_n_0 ;
  wire \Cnt[4]_i_6_n_0 ;
  wire \Cnt[4]_i_7_n_0 ;
  wire \Cnt[5]_i_2_n_0 ;
  wire \Cnt[5]_i_3_n_0 ;
  wire \Cnt[5]_i_4__0_n_0 ;
  wire \Cnt[5]_i_5__0_n_0 ;
  wire \Cnt[5]_i_6__0_n_0 ;
  wire \Cnt[5]_i_7_n_0 ;
  wire [0:0]\Cnt_reg[0]_0 ;
  wire \Cnt_reg_n_0_[0] ;
  wire \Cnt_reg_n_0_[1] ;
  wire \Cnt_reg_n_0_[2] ;
  wire \Cnt_reg_n_0_[3] ;
  wire \Cnt_reg_n_0_[4] ;
  wire \Cnt_reg_n_0_[5] ;
  wire [0:0]D;
  wire \D_Len[0]_i_1_n_0 ;
  wire \D_Len[1]_i_1_n_0 ;
  wire \D_Len[2]_i_1_n_0 ;
  wire \D_Len[3]_i_1_n_0 ;
  wire \D_Len[3]_i_2_n_0 ;
  wire \D_Len[3]_i_3_n_0 ;
  wire [0:0]E;
  wire [5:0]I56;
  wire I59;
  wire IDE1_out;
  wire IDE_i_1_n_0;
  wire IDE_i_2_n_0;
  wire IDE_i_3_n_0;
  wire IDE_i_4_n_0;
  wire IDE_i_5_n_0;
  wire IDE_rec_0;
  wire [3:0]Q;
  wire RTR_i_1_n_0;
  wire RTR_i_4_n_0;
  wire RTR_rec_0;
  wire RXOUT_reg;
  wire [3:0]RXSTATES;
  wire \RXSTATES[0]_i_10_n_0 ;
  wire \RXSTATES[0]_i_1_n_0 ;
  wire \RXSTATES[0]_i_3_n_0 ;
  wire \RXSTATES[0]_i_4_n_0 ;
  wire \RXSTATES[0]_i_6_n_0 ;
  wire \RXSTATES[0]_i_7_n_0 ;
  wire \RXSTATES[0]_i_8_n_0 ;
  wire \RXSTATES[0]_i_9_n_0 ;
  wire \RXSTATES[2]_i_1_n_0 ;
  wire \RXSTATES[2]_i_2_n_0 ;
  wire \RXSTATES[2]_i_3_n_0 ;
  wire \RXSTATES[2]_i_4_n_0 ;
  wire \RXSTATES[3]_i_2_n_0 ;
  wire \RXSTATES_reg[0]_0 ;
  wire \RXSTATES_reg[0]_1 ;
  wire \RXSTATES_reg[1]_0 ;
  wire \RXSTATES_reg[2]_0 ;
  wire [0:0]\RXSTATES_reg[2]_1 ;
  wire \RXSTATES_reg[3]_0 ;
  wire \RXSTATES_reg[3]_1 ;
  wire [0:0]\RXSTATES_reg[3]_2 ;
  wire SRST_0;
  wire Sampled_din;
  wire \TOFILTERI[10]_i_1_n_0 ;
  wire \TOFILTERI[11]_i_1_n_0 ;
  wire \TOFILTERI[12]_i_1_n_0 ;
  wire \TOFILTERI[13]_i_1_n_0 ;
  wire \TOFILTERI[14]_i_1_n_0 ;
  wire \TOFILTERI[15]_i_1_n_0 ;
  wire \TOFILTERI[16]_i_1_n_0 ;
  wire \TOFILTERI[17]_i_1_n_0 ;
  wire \TOFILTERI[18]_i_1_n_0 ;
  wire \TOFILTERI[19]_i_1_n_0 ;
  wire \TOFILTERI[1]_i_1_n_0 ;
  wire \TOFILTERI[20]_i_1_n_0 ;
  wire \TOFILTERI[21]_i_1_n_0 ;
  wire \TOFILTERI[22]_i_1_n_0 ;
  wire \TOFILTERI[23]_i_1_n_0 ;
  wire \TOFILTERI[24]_i_1_n_0 ;
  wire \TOFILTERI[25]_i_1_n_0 ;
  wire \TOFILTERI[26]_i_1_n_0 ;
  wire \TOFILTERI[27]_i_1_n_0 ;
  wire \TOFILTERI[28]_i_1_n_0 ;
  wire \TOFILTERI[28]_i_2_n_0 ;
  wire \TOFILTERI[28]_i_3_n_0 ;
  wire \TOFILTERI[28]_i_4_n_0 ;
  wire \TOFILTERI[2]_i_1_n_0 ;
  wire \TOFILTERI[3]_i_1_n_0 ;
  wire \TOFILTERI[4]_i_1_n_0 ;
  wire \TOFILTERI[5]_i_1_n_0 ;
  wire \TOFILTERI[6]_i_1_n_0 ;
  wire \TOFILTERI[7]_i_1_n_0 ;
  wire \TOFILTERI[8]_i_1_n_0 ;
  wire \TOFILTERI[9]_i_1_n_0 ;
  wire [28:0]TOFILTERI_0;
  wire \TOFILTERd[0]_i_1_n_0 ;
  wire \TOFILTERd[10]_i_1_n_0 ;
  wire \TOFILTERd[11]_i_1_n_0 ;
  wire \TOFILTERd[12]_i_1_n_0 ;
  wire \TOFILTERd[13]_i_1_n_0 ;
  wire \TOFILTERd[14]_i_1_n_0 ;
  wire \TOFILTERd[15]_i_1_n_0 ;
  wire \TOFILTERd[16]_i_1_n_0 ;
  wire \TOFILTERd[17]_i_1_n_0 ;
  wire \TOFILTERd[18]_i_1_n_0 ;
  wire \TOFILTERd[19]_i_1_n_0 ;
  wire \TOFILTERd[1]_i_1_n_0 ;
  wire \TOFILTERd[20]_i_1_n_0 ;
  wire \TOFILTERd[21]_i_1_n_0 ;
  wire \TOFILTERd[22]_i_1_n_0 ;
  wire \TOFILTERd[23]_i_1_n_0 ;
  wire \TOFILTERd[24]_i_1_n_0 ;
  wire \TOFILTERd[25]_i_1_n_0 ;
  wire \TOFILTERd[26]_i_1_n_0 ;
  wire \TOFILTERd[27]_i_1_n_0 ;
  wire \TOFILTERd[28]_i_1_n_0 ;
  wire \TOFILTERd[29]_i_1_n_0 ;
  wire \TOFILTERd[2]_i_1_n_0 ;
  wire \TOFILTERd[30]_i_1_n_0 ;
  wire \TOFILTERd[31]_i_1_n_0 ;
  wire \TOFILTERd[32]_i_1_n_0 ;
  wire \TOFILTERd[33]_i_1_n_0 ;
  wire \TOFILTERd[34]_i_1_n_0 ;
  wire \TOFILTERd[35]_i_1_n_0 ;
  wire \TOFILTERd[36]_i_1_n_0 ;
  wire \TOFILTERd[37]_i_1_n_0 ;
  wire \TOFILTERd[38]_i_1_n_0 ;
  wire \TOFILTERd[39]_i_1_n_0 ;
  wire \TOFILTERd[3]_i_1_n_0 ;
  wire \TOFILTERd[40]_i_1_n_0 ;
  wire \TOFILTERd[41]_i_1_n_0 ;
  wire \TOFILTERd[42]_i_1_n_0 ;
  wire \TOFILTERd[43]_i_1_n_0 ;
  wire \TOFILTERd[44]_i_1_n_0 ;
  wire \TOFILTERd[45]_i_1_n_0 ;
  wire \TOFILTERd[46]_i_1_n_0 ;
  wire \TOFILTERd[47]_i_1_n_0 ;
  wire \TOFILTERd[48]_i_1_n_0 ;
  wire \TOFILTERd[49]_i_1_n_0 ;
  wire \TOFILTERd[4]_i_1_n_0 ;
  wire \TOFILTERd[50]_i_1_n_0 ;
  wire \TOFILTERd[51]_i_1_n_0 ;
  wire \TOFILTERd[52]_i_1_n_0 ;
  wire \TOFILTERd[53]_i_1_n_0 ;
  wire \TOFILTERd[54]_i_1_n_0 ;
  wire \TOFILTERd[55]_i_1_n_0 ;
  wire \TOFILTERd[56]_i_1_n_0 ;
  wire \TOFILTERd[57]_i_1_n_0 ;
  wire \TOFILTERd[58]_i_1_n_0 ;
  wire \TOFILTERd[59]_i_1_n_0 ;
  wire \TOFILTERd[5]_i_1_n_0 ;
  wire \TOFILTERd[60]_i_1_n_0 ;
  wire \TOFILTERd[61]_i_1_n_0 ;
  wire \TOFILTERd[62]_i_1_n_0 ;
  wire \TOFILTERd[63]_i_1_n_0 ;
  wire \TOFILTERd[63]_i_2_n_0 ;
  wire \TOFILTERd[6]_i_1_n_0 ;
  wire \TOFILTERd[7]_i_1_n_0 ;
  wire \TOFILTERd[8]_i_1_n_0 ;
  wire \TOFILTERd[9]_i_1_n_0 ;
  wire [63:0]TOFILTERd_0;
  wire \TOFILTERd_reg[0]_0 ;
  wire TXpin_i_2;
  wire TXpin_i_2_0;
  wire [5:0]bs;
  wire [0:0]\bs_reg[0]_0 ;
  wire \bs_reg[1]_0 ;
  wire clk;
  wire done_i_1__0_n_0;
  wire done_i_3__0_n_0;
  wire done_reg_0;
  wire donefromrxr;
  wire imTX;
  wire req_Error_RX;
  wire req_Error_i_2_n_0;
  wire req_Error_i_4_n_0;
  wire req_Error_i_5_n_0;
  wire req_Error_i_6_n_0;
  wire req_Error_i_8_n_0;
  wire req_Error_reg_0;
  wire rxcrc_n_0;

  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFDFFF)) 
    AckTakeOver_i_1
       (.I0(RXSTATES[2]),
        .I1(RXSTATES[3]),
        .I2(AckTakeOver_i_2_n_0),
        .I3(SRST_0),
        .I4(imTX),
        .I5(req_Error_RX),
        .O(AckTakeOver_i_1_n_0));
  (* SOFT_HLUTNM = "soft_lutpair192" *) 
  LUT2 #(
    .INIT(4'h8)) 
    AckTakeOver_i_2
       (.I0(RXSTATES[0]),
        .I1(RXSTATES[1]),
        .O(AckTakeOver_i_2_n_0));
  FDPE AckTakeOver_reg
       (.C(clk),
        .CE(E),
        .D(AckTakeOver_i_1_n_0),
        .PRE(CAN_RST_0),
        .Q(AckTakeOver));
  LUT6 #(
    .INIT(64'hAAAAAAAAAAAAAAAB)) 
    \CNT2[3]_i_1 
       (.I0(\CNT2_reg[3] ),
        .I1(\CNT2_reg[3]_0 ),
        .I2(RXSTATES[2]),
        .I3(RXSTATES[3]),
        .I4(RXSTATES[1]),
        .I5(RXSTATES[0]),
        .O(\RXSTATES_reg[2]_1 ));
  LUT6 #(
    .INIT(64'h88888A88AAAAAAAA)) 
    \Cnt[0]_i_1__0 
       (.I0(SRST_0),
        .I1(\Cnt[0]_i_2__0_n_0 ),
        .I2(\Cnt[0]_i_3__0_n_0 ),
        .I3(\Cnt[5]_i_6__0_n_0 ),
        .I4(\Cnt_reg_n_0_[0] ),
        .I5(\Cnt[0]_i_4__0_n_0 ),
        .O(\Cnt[0]_i_1__0_n_0 ));
  LUT6 #(
    .INIT(64'h00000C0008000800)) 
    \Cnt[0]_i_2__0 
       (.I0(\RXSTATES_reg[0]_1 ),
        .I1(RXSTATES[3]),
        .I2(RXSTATES[1]),
        .I3(RXSTATES[2]),
        .I4(\RXSTATES_reg[0]_0 ),
        .I5(RXSTATES[0]),
        .O(\Cnt[0]_i_2__0_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair190" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \Cnt[0]_i_3__0 
       (.I0(\RXSTATES[2]_i_3_n_0 ),
        .I1(RXSTATES[0]),
        .O(\Cnt[0]_i_3__0_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFBABABAAA)) 
    \Cnt[0]_i_4__0 
       (.I0(\Cnt[0]_i_5_n_0 ),
        .I1(RXSTATES[1]),
        .I2(RXSTATES[2]),
        .I3(\RXSTATES[2]_i_3_n_0 ),
        .I4(\Cnt_reg_n_0_[0] ),
        .I5(RXSTATES[3]),
        .O(\Cnt[0]_i_4__0_n_0 ));
  LUT6 #(
    .INIT(64'hFF2E0000FFAA00FF)) 
    \Cnt[0]_i_5 
       (.I0(\Cnt_reg_n_0_[0] ),
        .I1(\RXSTATES[2]_i_3_n_0 ),
        .I2(\RXSTATES[0]_i_9_n_0 ),
        .I3(RXSTATES[2]),
        .I4(RXSTATES[1]),
        .I5(RXSTATES[0]),
        .O(\Cnt[0]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h0000AA08AAAAAAAA)) 
    \Cnt[1]_i_1 
       (.I0(SRST_0),
        .I1(\Cnt[4]_i_4__0_n_0 ),
        .I2(\Cnt[1]_i_2__0_n_0 ),
        .I3(\Cnt[4]_i_2_n_0 ),
        .I4(\Cnt[1]_i_3_n_0 ),
        .I5(\Cnt[1]_i_4__0_n_0 ),
        .O(\Cnt[1]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair187" *) 
  LUT4 #(
    .INIT(16'h6F66)) 
    \Cnt[1]_i_2__0 
       (.I0(\Cnt_reg_n_0_[0] ),
        .I1(\Cnt_reg_n_0_[1] ),
        .I2(RXSTATES[0]),
        .I3(\RXSTATES[2]_i_3_n_0 ),
        .O(\Cnt[1]_i_2__0_n_0 ));
  LUT6 #(
    .INIT(64'hBBBBAFFAAAAAAAAA)) 
    \Cnt[1]_i_3 
       (.I0(RXSTATES[3]),
        .I1(\Cnt[1]_i_5_n_0 ),
        .I2(\Cnt_reg_n_0_[1] ),
        .I3(\Cnt_reg_n_0_[0] ),
        .I4(\RXSTATES[2]_i_3_n_0 ),
        .I5(\Cnt[1]_i_6_n_0 ),
        .O(\Cnt[1]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFDFFDDFFD5555)) 
    \Cnt[1]_i_4__0 
       (.I0(\RXSTATES[0]_i_7_n_0 ),
        .I1(\RXSTATES[2]_i_3_n_0 ),
        .I2(\Cnt_reg_n_0_[0] ),
        .I3(\Cnt_reg_n_0_[1] ),
        .I4(RXSTATES[0]),
        .I5(RXSTATES[1]),
        .O(\Cnt[1]_i_4__0_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair189" *) 
  LUT3 #(
    .INIT(8'h8A)) 
    \Cnt[1]_i_5 
       (.I0(RXSTATES[2]),
        .I1(RXSTATES[1]),
        .I2(RXSTATES[0]),
        .O(\Cnt[1]_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair191" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \Cnt[1]_i_6 
       (.I0(RXSTATES[2]),
        .I1(RXSTATES[1]),
        .O(\Cnt[1]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'hA8AAAAAA88888888)) 
    \Cnt[2]_i_1 
       (.I0(SRST_0),
        .I1(\Cnt[2]_i_2__0_n_0 ),
        .I2(\Cnt[2]_i_3__0_n_0 ),
        .I3(RXSTATES[1]),
        .I4(\Cnt[2]_i_4_n_0 ),
        .I5(\Cnt[2]_i_5_n_0 ),
        .O(\Cnt[2]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h1515010122220200)) 
    \Cnt[2]_i_2__0 
       (.I0(RXSTATES[2]),
        .I1(RXSTATES[1]),
        .I2(RXSTATES[0]),
        .I3(\RXSTATES[2]_i_3_n_0 ),
        .I4(\Cnt[2]_i_6_n_0 ),
        .I5(RXSTATES[3]),
        .O(\Cnt[2]_i_2__0_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair187" *) 
  LUT3 #(
    .INIT(8'hA9)) 
    \Cnt[2]_i_3__0 
       (.I0(\Cnt_reg_n_0_[2] ),
        .I1(\Cnt_reg_n_0_[0] ),
        .I2(\Cnt_reg_n_0_[1] ),
        .O(\Cnt[2]_i_3__0_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair175" *) 
  LUT3 #(
    .INIT(8'hDF)) 
    \Cnt[2]_i_4 
       (.I0(\TOFILTERd_reg[0]_0 ),
        .I1(RXSTATES[0]),
        .I2(\RXSTATES[0]_i_10_n_0 ),
        .O(\Cnt[2]_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair180" *) 
  LUT4 #(
    .INIT(16'h1110)) 
    \Cnt[2]_i_5 
       (.I0(RXSTATES[2]),
        .I1(RXSTATES[3]),
        .I2(RXSTATES[1]),
        .I3(RXSTATES[0]),
        .O(\Cnt[2]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hFFF0000FFFF0000E)) 
    \Cnt[2]_i_6 
       (.I0(\Cnt_reg_n_0_[5] ),
        .I1(\Cnt_reg_n_0_[3] ),
        .I2(\Cnt_reg_n_0_[0] ),
        .I3(\Cnt_reg_n_0_[1] ),
        .I4(\Cnt_reg_n_0_[2] ),
        .I5(\Cnt_reg_n_0_[4] ),
        .O(\Cnt[2]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'h00AA88AA000088A8)) 
    \Cnt[3]_i_1 
       (.I0(SRST_0),
        .I1(\Cnt[3]_i_2_n_0 ),
        .I2(\Cnt[4]_i_4__0_n_0 ),
        .I3(\Cnt[3]_i_3_n_0 ),
        .I4(\Cnt[3]_i_4__0_n_0 ),
        .I5(\Cnt[5]_i_6__0_n_0 ),
        .O(\Cnt[3]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h08FC00FC08FC08FC)) 
    \Cnt[3]_i_2 
       (.I0(\RXSTATES[2]_i_3_n_0 ),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[2]),
        .I3(RXSTATES[1]),
        .I4(\TOFILTERd_reg[0]_0 ),
        .I5(\RXSTATES[0]_i_9_n_0 ),
        .O(\Cnt[3]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h0000000FFFFFFFF1)) 
    \Cnt[3]_i_3 
       (.I0(\Cnt_reg_n_0_[5] ),
        .I1(\Cnt_reg_n_0_[4] ),
        .I2(\Cnt_reg_n_0_[0] ),
        .I3(\Cnt_reg_n_0_[1] ),
        .I4(\Cnt_reg_n_0_[2] ),
        .I5(\Cnt_reg_n_0_[3] ),
        .O(\Cnt[3]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAEAAAEAEAAAAAAAA)) 
    \Cnt[3]_i_4__0 
       (.I0(RXSTATES[3]),
        .I1(RXSTATES[2]),
        .I2(RXSTATES[1]),
        .I3(RXSTATES[0]),
        .I4(\RXSTATES[2]_i_3_n_0 ),
        .I5(\Cnt[3]_i_3_n_0 ),
        .O(\Cnt[3]_i_4__0_n_0 ));
  LUT6 #(
    .INIT(64'h0000A888AAAAAAAA)) 
    \Cnt[4]_i_1 
       (.I0(SRST_0),
        .I1(\Cnt[4]_i_2_n_0 ),
        .I2(\Cnt[4]_i_3_n_0 ),
        .I3(\Cnt[4]_i_4__0_n_0 ),
        .I4(\Cnt[4]_i_5_n_0 ),
        .I5(\Cnt[4]_i_6_n_0 ),
        .O(\Cnt[4]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair189" *) 
  LUT3 #(
    .INIT(8'h32)) 
    \Cnt[4]_i_2 
       (.I0(RXSTATES[0]),
        .I1(RXSTATES[1]),
        .I2(RXSTATES[2]),
        .O(\Cnt[4]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hBEAAAAAAAAAAAAAA)) 
    \Cnt[4]_i_3 
       (.I0(\Cnt[4]_i_7_n_0 ),
        .I1(Q[0]),
        .I2(\TOFILTERd_reg[0]_0 ),
        .I3(\RXSTATES[0]_i_9_n_0 ),
        .I4(\RXSTATES[2]_i_3_n_0 ),
        .I5(RXSTATES[0]),
        .O(\Cnt[4]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair175" *) 
  LUT5 #(
    .INIT(32'h00DF0000)) 
    \Cnt[4]_i_4__0 
       (.I0(\RXSTATES[0]_i_10_n_0 ),
        .I1(RXSTATES[0]),
        .I2(\TOFILTERd_reg[0]_0 ),
        .I3(RXSTATES[2]),
        .I4(RXSTATES[1]),
        .O(\Cnt[4]_i_4__0_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair186" *) 
  LUT4 #(
    .INIT(16'hAABA)) 
    \Cnt[4]_i_5 
       (.I0(RXSTATES[3]),
        .I1(\Cnt[4]_i_7_n_0 ),
        .I2(RXSTATES[2]),
        .I3(RXSTATES[1]),
        .O(\Cnt[4]_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair177" *) 
  LUT5 #(
    .INIT(32'hF9FFFFFF)) 
    \Cnt[4]_i_6 
       (.I0(RXSTATES[0]),
        .I1(RXSTATES[1]),
        .I2(RXSTATES[2]),
        .I3(RXSTATES[3]),
        .I4(\Cnt[4]_i_7_n_0 ),
        .O(\Cnt[4]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFC00000002)) 
    \Cnt[4]_i_7 
       (.I0(\Cnt_reg_n_0_[5] ),
        .I1(\Cnt_reg_n_0_[3] ),
        .I2(\Cnt_reg_n_0_[0] ),
        .I3(\Cnt_reg_n_0_[1] ),
        .I4(\Cnt_reg_n_0_[2] ),
        .I5(\Cnt_reg_n_0_[4] ),
        .O(\Cnt[4]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'hA0A8A0A8A0A800A8)) 
    \Cnt[5]_i_2 
       (.I0(SRST_0),
        .I1(\Cnt[5]_i_3_n_0 ),
        .I2(\Cnt[5]_i_4__0_n_0 ),
        .I3(\Cnt[5]_i_5__0_n_0 ),
        .I4(\Cnt[5]_i_6__0_n_0 ),
        .I5(\Cnt[5]_i_7_n_0 ),
        .O(\Cnt[5]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h8000808000800000)) 
    \Cnt[5]_i_3 
       (.I0(RXSTATES[0]),
        .I1(\RXSTATES[2]_i_3_n_0 ),
        .I2(\RXSTATES[0]_i_9_n_0 ),
        .I3(Q[0]),
        .I4(\TOFILTERd_reg[0]_0 ),
        .I5(Q[1]),
        .O(\Cnt[5]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAAAAAAAAAAAAAAA8)) 
    \Cnt[5]_i_4__0 
       (.I0(\Cnt_reg_n_0_[5] ),
        .I1(\Cnt_reg_n_0_[4] ),
        .I2(\Cnt_reg_n_0_[2] ),
        .I3(\Cnt_reg_n_0_[1] ),
        .I4(\Cnt_reg_n_0_[0] ),
        .I5(\Cnt_reg_n_0_[3] ),
        .O(\Cnt[5]_i_4__0_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair182" *) 
  LUT3 #(
    .INIT(8'hEF)) 
    \Cnt[5]_i_5__0 
       (.I0(RXSTATES[3]),
        .I1(RXSTATES[2]),
        .I2(RXSTATES[1]),
        .O(\Cnt[5]_i_5__0_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair177" *) 
  LUT4 #(
    .INIT(16'h0220)) 
    \Cnt[5]_i_6__0 
       (.I0(RXSTATES[3]),
        .I1(RXSTATES[2]),
        .I2(RXSTATES[1]),
        .I3(RXSTATES[0]),
        .O(\Cnt[5]_i_6__0_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair183" *) 
  LUT3 #(
    .INIT(8'h04)) 
    \Cnt[5]_i_7 
       (.I0(RXSTATES[1]),
        .I1(RXSTATES[2]),
        .I2(RXSTATES[3]),
        .O(\Cnt[5]_i_7_n_0 ));
  FDCE \Cnt_reg[0] 
       (.C(clk),
        .CE(\Cnt_reg[0]_0 ),
        .CLR(CAN_RST_0),
        .D(\Cnt[0]_i_1__0_n_0 ),
        .Q(\Cnt_reg_n_0_[0] ));
  FDCE \Cnt_reg[1] 
       (.C(clk),
        .CE(\Cnt_reg[0]_0 ),
        .CLR(CAN_RST_0),
        .D(\Cnt[1]_i_1_n_0 ),
        .Q(\Cnt_reg_n_0_[1] ));
  FDCE \Cnt_reg[2] 
       (.C(clk),
        .CE(\Cnt_reg[0]_0 ),
        .CLR(CAN_RST_0),
        .D(\Cnt[2]_i_1_n_0 ),
        .Q(\Cnt_reg_n_0_[2] ));
  FDCE \Cnt_reg[3] 
       (.C(clk),
        .CE(\Cnt_reg[0]_0 ),
        .CLR(CAN_RST_0),
        .D(\Cnt[3]_i_1_n_0 ),
        .Q(\Cnt_reg_n_0_[3] ));
  FDCE \Cnt_reg[4] 
       (.C(clk),
        .CE(\Cnt_reg[0]_0 ),
        .CLR(CAN_RST_0),
        .D(\Cnt[4]_i_1_n_0 ),
        .Q(\Cnt_reg_n_0_[4] ));
  FDCE \Cnt_reg[5] 
       (.C(clk),
        .CE(\Cnt_reg[0]_0 ),
        .CLR(CAN_RST_0),
        .D(\Cnt[5]_i_2_n_0 ),
        .Q(\Cnt_reg_n_0_[5] ));
  LUT6 #(
    .INIT(64'h0000000004000000)) 
    \D_Len[0]_i_1 
       (.I0(\TOFILTERd_reg[0]_0 ),
        .I1(SRST_0),
        .I2(RXSTATES[3]),
        .I3(RXSTATES[1]),
        .I4(RXSTATES[0]),
        .I5(RXSTATES[2]),
        .O(\D_Len[0]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000000008000000)) 
    \D_Len[1]_i_1 
       (.I0(Q[0]),
        .I1(SRST_0),
        .I2(RXSTATES[3]),
        .I3(RXSTATES[1]),
        .I4(RXSTATES[0]),
        .I5(RXSTATES[2]),
        .O(\D_Len[1]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000000008000000)) 
    \D_Len[2]_i_1 
       (.I0(Q[1]),
        .I1(SRST_0),
        .I2(RXSTATES[3]),
        .I3(RXSTATES[1]),
        .I4(RXSTATES[0]),
        .I5(RXSTATES[2]),
        .O(\D_Len[2]_i_1_n_0 ));
  LUT3 #(
    .INIT(8'h4F)) 
    \D_Len[3]_i_1 
       (.I0(\D_Len[3]_i_3_n_0 ),
        .I1(\CRC_RG_reg[14] ),
        .I2(SRST_0),
        .O(\D_Len[3]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000000008000000)) 
    \D_Len[3]_i_2 
       (.I0(Q[2]),
        .I1(SRST_0),
        .I2(RXSTATES[3]),
        .I3(RXSTATES[1]),
        .I4(RXSTATES[0]),
        .I5(RXSTATES[2]),
        .O(\D_Len[3]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFF4FFF0FFFFFFF0)) 
    \D_Len[3]_i_3 
       (.I0(\Cnt_reg_n_0_[1] ),
        .I1(\Cnt_reg_n_0_[2] ),
        .I2(RXSTATES[3]),
        .I3(RXSTATES[2]),
        .I4(RXSTATES[1]),
        .I5(RXSTATES[0]),
        .O(\D_Len[3]_i_3_n_0 ));
  FDCE \D_Len_reg[0] 
       (.C(clk),
        .CE(\D_Len[3]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\D_Len[0]_i_1_n_0 ),
        .Q(Q[0]));
  FDCE \D_Len_reg[1] 
       (.C(clk),
        .CE(\D_Len[3]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\D_Len[1]_i_1_n_0 ),
        .Q(Q[1]));
  FDCE \D_Len_reg[2] 
       (.C(clk),
        .CE(\D_Len[3]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\D_Len[2]_i_1_n_0 ),
        .Q(Q[2]));
  FDCE \D_Len_reg[3] 
       (.C(clk),
        .CE(\D_Len[3]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\D_Len[3]_i_2_n_0 ),
        .Q(Q[3]));
  LUT6 #(
    .INIT(64'hFFBFBBBB00808888)) 
    IDE_i_1
       (.I0(IDE1_out),
        .I1(IDE_i_2_n_0),
        .I2(IDE_i_3_n_0),
        .I3(IDE_i_4_n_0),
        .I4(IDE_i_5_n_0),
        .I5(IDE_rec_0),
        .O(IDE_i_1_n_0));
  (* SOFT_HLUTNM = "soft_lutpair188" *) 
  LUT3 #(
    .INIT(8'h4F)) 
    IDE_i_2
       (.I0(RXSTATES[3]),
        .I1(\CRC_RG_reg[14] ),
        .I2(SRST_0),
        .O(IDE_i_2_n_0));
  (* SOFT_HLUTNM = "soft_lutpair191" *) 
  LUT3 #(
    .INIT(8'h04)) 
    IDE_i_3
       (.I0(RXSTATES[2]),
        .I1(RXSTATES[1]),
        .I2(RXSTATES[0]),
        .O(IDE_i_3_n_0));
  LUT6 #(
    .INIT(64'hFFFFFFFFFBFFFFFF)) 
    IDE_i_4
       (.I0(\Cnt_reg_n_0_[5] ),
        .I1(\Cnt_reg_n_0_[4] ),
        .I2(\Cnt_reg_n_0_[3] ),
        .I3(\Cnt_reg_n_0_[1] ),
        .I4(\Cnt_reg_n_0_[0] ),
        .I5(\Cnt_reg_n_0_[2] ),
        .O(IDE_i_4_n_0));
  (* SOFT_HLUTNM = "soft_lutpair184" *) 
  LUT4 #(
    .INIT(16'hAAA8)) 
    IDE_i_5
       (.I0(SRST_0),
        .I1(RXSTATES[1]),
        .I2(RXSTATES[3]),
        .I3(RXSTATES[2]),
        .O(IDE_i_5_n_0));
  FDCE IDE_reg
       (.C(clk),
        .CE(1'b1),
        .CLR(CAN_RST_0),
        .D(IDE_i_1_n_0),
        .Q(IDE_rec_0));
  LUT6 #(
    .INIT(64'hF0F0FFF4F0F000B0)) 
    RTR_i_1
       (.I0(\CRC_RG_reg[14] ),
        .I1(SRST_0),
        .I2(I59),
        .I3(IDE_i_5_n_0),
        .I4(RTR_i_4_n_0),
        .I5(RTR_rec_0),
        .O(RTR_i_1_n_0));
  LUT6 #(
    .INIT(64'h555557575555575F)) 
    RTR_i_3
       (.I0(SRST_0),
        .I1(RXSTATES[1]),
        .I2(RXSTATES[2]),
        .I3(\TOFILTERd_reg[0]_0 ),
        .I4(RXSTATES[3]),
        .I5(RXSTATES[0]),
        .O(I59));
  LUT6 #(
    .INIT(64'h0000000000000400)) 
    RTR_i_4
       (.I0(RXSTATES[3]),
        .I1(\CRC_RG_reg[14] ),
        .I2(RXSTATES[2]),
        .I3(RXSTATES[1]),
        .I4(RXSTATES[0]),
        .I5(\TOFILTERI[28]_i_3_n_0 ),
        .O(RTR_i_4_n_0));
  FDPE RTR_reg
       (.C(clk),
        .CE(1'b1),
        .D(RTR_i_1_n_0),
        .PRE(CAN_RST_0),
        .Q(RTR_rec_0));
  LUT6 #(
    .INIT(64'hAAAAAAAAAAAA8088)) 
    \RXSTATES[0]_i_1 
       (.I0(SRST_0),
        .I1(\RXSTATES_reg[0]_1 ),
        .I2(\RXSTATES[0]_i_3_n_0 ),
        .I3(\RXSTATES[0]_i_4_n_0 ),
        .I4(req_Error_RX),
        .I5(\RXSTATES_reg[0]_0 ),
        .O(\RXSTATES[0]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000100000)) 
    \RXSTATES[0]_i_10 
       (.I0(\Cnt_reg_n_0_[1] ),
        .I1(\Cnt_reg_n_0_[0] ),
        .I2(\Cnt_reg_n_0_[2] ),
        .I3(\Cnt_reg_n_0_[5] ),
        .I4(\Cnt_reg_n_0_[4] ),
        .I5(\Cnt_reg_n_0_[3] ),
        .O(\RXSTATES[0]_i_10_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFC0FFE0FFC0)) 
    \RXSTATES[0]_i_3 
       (.I0(AckTakeOver_i_2_n_0),
        .I1(\RXSTATES[0]_i_6_n_0 ),
        .I2(\RXSTATES[0]_i_7_n_0 ),
        .I3(\RXSTATES[0]_i_8_n_0 ),
        .I4(\TOFILTERd_reg[0]_0 ),
        .I5(\RXSTATES_reg[2]_0 ),
        .O(\RXSTATES[0]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hEAAAEBABEBABEBAB)) 
    \RXSTATES[0]_i_4 
       (.I0(\Cnt[5]_i_5__0_n_0 ),
        .I1(RXSTATES[0]),
        .I2(\RXSTATES[2]_i_3_n_0 ),
        .I3(\RXSTATES[0]_i_9_n_0 ),
        .I4(\TOFILTERd_reg[0]_0 ),
        .I5(\RXSTATES[0]_i_10_n_0 ),
        .O(\RXSTATES[0]_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair190" *) 
  LUT3 #(
    .INIT(8'h47)) 
    \RXSTATES[0]_i_6 
       (.I0(RXSTATES[0]),
        .I1(\RXSTATES[2]_i_3_n_0 ),
        .I2(RXSTATES[1]),
        .O(\RXSTATES[0]_i_6_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair186" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \RXSTATES[0]_i_7 
       (.I0(RXSTATES[3]),
        .I1(RXSTATES[2]),
        .O(\RXSTATES[0]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'h220003FC00000000)) 
    \RXSTATES[0]_i_8 
       (.I0(\RXSTATES_reg[0]_0 ),
        .I1(RXSTATES[1]),
        .I2(\RXSTATES[2]_i_3_n_0 ),
        .I3(RXSTATES[0]),
        .I4(RXSTATES[3]),
        .I5(RXSTATES[2]),
        .O(\RXSTATES[0]_i_8_n_0 ));
  LUT5 #(
    .INIT(32'h55555554)) 
    \RXSTATES[0]_i_9 
       (.I0(RTR_rec_0),
        .I1(Q[0]),
        .I2(Q[2]),
        .I3(Q[1]),
        .I4(Q[3]),
        .O(\RXSTATES[0]_i_9_n_0 ));
  LUT6 #(
    .INIT(64'hEECFCFC0CC333333)) 
    \RXSTATES[1]_i_2 
       (.I0(\RXSTATES_reg[0]_0 ),
        .I1(RXSTATES[1]),
        .I2(\RXSTATES[2]_i_3_n_0 ),
        .I3(RXSTATES[3]),
        .I4(RXSTATES[2]),
        .I5(RXSTATES[0]),
        .O(\RXSTATES_reg[1]_0 ));
  LUT6 #(
    .INIT(64'hA888888888888888)) 
    \RXSTATES[2]_i_1 
       (.I0(SRST_0),
        .I1(\RXSTATES[2]_i_2_n_0 ),
        .I2(RXSTATES[1]),
        .I3(RXSTATES[0]),
        .I4(\RXSTATES[2]_i_3_n_0 ),
        .I5(\RXSTATES[2]_i_4_n_0 ),
        .O(\RXSTATES[2]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h55F5757555757575)) 
    \RXSTATES[2]_i_2 
       (.I0(\RXSTATES_reg[3]_1 ),
        .I1(RXSTATES[3]),
        .I2(RXSTATES[2]),
        .I3(RXSTATES[1]),
        .I4(RXSTATES[0]),
        .I5(\RXSTATES_reg[0]_0 ),
        .O(\RXSTATES[2]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000000001)) 
    \RXSTATES[2]_i_3 
       (.I0(\Cnt_reg_n_0_[4] ),
        .I1(\Cnt_reg_n_0_[2] ),
        .I2(\Cnt_reg_n_0_[1] ),
        .I3(\Cnt_reg_n_0_[0] ),
        .I4(\Cnt_reg_n_0_[3] ),
        .I5(\Cnt_reg_n_0_[5] ),
        .O(\RXSTATES[2]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair188" *) 
  LUT2 #(
    .INIT(4'h1)) 
    \RXSTATES[2]_i_4 
       (.I0(RXSTATES[3]),
        .I1(RXSTATES[2]),
        .O(\RXSTATES[2]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h282020A0AAAAAAAA)) 
    \RXSTATES[3]_i_2 
       (.I0(SRST_0),
        .I1(RXSTATES[1]),
        .I2(RXSTATES[3]),
        .I3(RXSTATES[0]),
        .I4(RXSTATES[2]),
        .I5(\RXSTATES_reg[3]_1 ),
        .O(\RXSTATES[3]_i_2_n_0 ));
  FDCE \RXSTATES_reg[0] 
       (.C(clk),
        .CE(\RXSTATES_reg[3]_2 ),
        .CLR(CAN_RST_0),
        .D(\RXSTATES[0]_i_1_n_0 ),
        .Q(RXSTATES[0]));
  FDCE \RXSTATES_reg[1] 
       (.C(clk),
        .CE(\RXSTATES_reg[3]_2 ),
        .CLR(CAN_RST_0),
        .D(D),
        .Q(RXSTATES[1]));
  FDCE \RXSTATES_reg[2] 
       (.C(clk),
        .CE(\RXSTATES_reg[3]_2 ),
        .CLR(CAN_RST_0),
        .D(\RXSTATES[2]_i_1_n_0 ),
        .Q(RXSTATES[2]));
  FDCE \RXSTATES_reg[3] 
       (.C(clk),
        .CE(\RXSTATES_reg[3]_2 ),
        .CLR(CAN_RST_0),
        .D(\RXSTATES[3]_i_2_n_0 ),
        .Q(RXSTATES[3]));
  (* SOFT_HLUTNM = "soft_lutpair176" *) 
  LUT5 #(
    .INIT(32'h00000400)) 
    \State[2]_i_10 
       (.I0(Sampled_din),
        .I1(RXSTATES[1]),
        .I2(RXSTATES[0]),
        .I3(RXSTATES[3]),
        .I4(RXSTATES[2]),
        .O(RXOUT_reg));
  LUT6 #(
    .INIT(64'h0000000400000000)) 
    \TOFILTERI[0]_i_1 
       (.I0(\TOFILTERd_reg[0]_0 ),
        .I1(SRST_0),
        .I2(RXSTATES[2]),
        .I3(RXSTATES[3]),
        .I4(RXSTATES[0]),
        .I5(RXSTATES[1]),
        .O(IDE1_out));
  LUT6 #(
    .INIT(64'h0000000800000000)) 
    \TOFILTERI[10]_i_1 
       (.I0(TOFILTERI_0[9]),
        .I1(SRST_0),
        .I2(RXSTATES[2]),
        .I3(RXSTATES[3]),
        .I4(RXSTATES[0]),
        .I5(RXSTATES[1]),
        .O(\TOFILTERI[10]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000000800000000)) 
    \TOFILTERI[11]_i_1 
       (.I0(TOFILTERI_0[10]),
        .I1(SRST_0),
        .I2(RXSTATES[2]),
        .I3(RXSTATES[3]),
        .I4(RXSTATES[0]),
        .I5(RXSTATES[1]),
        .O(\TOFILTERI[11]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000000800000000)) 
    \TOFILTERI[12]_i_1 
       (.I0(TOFILTERI_0[11]),
        .I1(SRST_0),
        .I2(RXSTATES[2]),
        .I3(RXSTATES[3]),
        .I4(RXSTATES[0]),
        .I5(RXSTATES[1]),
        .O(\TOFILTERI[12]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000000800000000)) 
    \TOFILTERI[13]_i_1 
       (.I0(TOFILTERI_0[12]),
        .I1(SRST_0),
        .I2(RXSTATES[2]),
        .I3(RXSTATES[3]),
        .I4(RXSTATES[0]),
        .I5(RXSTATES[1]),
        .O(\TOFILTERI[13]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000000800000000)) 
    \TOFILTERI[14]_i_1 
       (.I0(TOFILTERI_0[13]),
        .I1(SRST_0),
        .I2(RXSTATES[2]),
        .I3(RXSTATES[3]),
        .I4(RXSTATES[0]),
        .I5(RXSTATES[1]),
        .O(\TOFILTERI[14]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000000800000000)) 
    \TOFILTERI[15]_i_1 
       (.I0(TOFILTERI_0[14]),
        .I1(SRST_0),
        .I2(RXSTATES[2]),
        .I3(RXSTATES[3]),
        .I4(RXSTATES[0]),
        .I5(RXSTATES[1]),
        .O(\TOFILTERI[15]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000000800000000)) 
    \TOFILTERI[16]_i_1 
       (.I0(TOFILTERI_0[15]),
        .I1(SRST_0),
        .I2(RXSTATES[2]),
        .I3(RXSTATES[3]),
        .I4(RXSTATES[0]),
        .I5(RXSTATES[1]),
        .O(\TOFILTERI[16]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000000800000000)) 
    \TOFILTERI[17]_i_1 
       (.I0(TOFILTERI_0[16]),
        .I1(SRST_0),
        .I2(RXSTATES[2]),
        .I3(RXSTATES[3]),
        .I4(RXSTATES[0]),
        .I5(RXSTATES[1]),
        .O(\TOFILTERI[17]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000000800000000)) 
    \TOFILTERI[18]_i_1 
       (.I0(TOFILTERI_0[17]),
        .I1(SRST_0),
        .I2(RXSTATES[2]),
        .I3(RXSTATES[3]),
        .I4(RXSTATES[0]),
        .I5(RXSTATES[1]),
        .O(\TOFILTERI[18]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000000800000000)) 
    \TOFILTERI[19]_i_1 
       (.I0(TOFILTERI_0[18]),
        .I1(SRST_0),
        .I2(RXSTATES[2]),
        .I3(RXSTATES[3]),
        .I4(RXSTATES[0]),
        .I5(RXSTATES[1]),
        .O(\TOFILTERI[19]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000000800000000)) 
    \TOFILTERI[1]_i_1 
       (.I0(TOFILTERI_0[0]),
        .I1(SRST_0),
        .I2(RXSTATES[2]),
        .I3(RXSTATES[3]),
        .I4(RXSTATES[0]),
        .I5(RXSTATES[1]),
        .O(\TOFILTERI[1]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000000800000000)) 
    \TOFILTERI[20]_i_1 
       (.I0(TOFILTERI_0[19]),
        .I1(SRST_0),
        .I2(RXSTATES[2]),
        .I3(RXSTATES[3]),
        .I4(RXSTATES[0]),
        .I5(RXSTATES[1]),
        .O(\TOFILTERI[20]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000000800000000)) 
    \TOFILTERI[21]_i_1 
       (.I0(TOFILTERI_0[20]),
        .I1(SRST_0),
        .I2(RXSTATES[2]),
        .I3(RXSTATES[3]),
        .I4(RXSTATES[0]),
        .I5(RXSTATES[1]),
        .O(\TOFILTERI[21]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000000800000000)) 
    \TOFILTERI[22]_i_1 
       (.I0(TOFILTERI_0[21]),
        .I1(SRST_0),
        .I2(RXSTATES[2]),
        .I3(RXSTATES[3]),
        .I4(RXSTATES[0]),
        .I5(RXSTATES[1]),
        .O(\TOFILTERI[22]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000000800000000)) 
    \TOFILTERI[23]_i_1 
       (.I0(TOFILTERI_0[22]),
        .I1(SRST_0),
        .I2(RXSTATES[2]),
        .I3(RXSTATES[3]),
        .I4(RXSTATES[0]),
        .I5(RXSTATES[1]),
        .O(\TOFILTERI[23]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000000800000000)) 
    \TOFILTERI[24]_i_1 
       (.I0(TOFILTERI_0[23]),
        .I1(SRST_0),
        .I2(RXSTATES[2]),
        .I3(RXSTATES[3]),
        .I4(RXSTATES[0]),
        .I5(RXSTATES[1]),
        .O(\TOFILTERI[24]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000000800000000)) 
    \TOFILTERI[25]_i_1 
       (.I0(TOFILTERI_0[24]),
        .I1(SRST_0),
        .I2(RXSTATES[2]),
        .I3(RXSTATES[3]),
        .I4(RXSTATES[0]),
        .I5(RXSTATES[1]),
        .O(\TOFILTERI[25]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000000800000000)) 
    \TOFILTERI[26]_i_1 
       (.I0(TOFILTERI_0[25]),
        .I1(SRST_0),
        .I2(RXSTATES[2]),
        .I3(RXSTATES[3]),
        .I4(RXSTATES[0]),
        .I5(RXSTATES[1]),
        .O(\TOFILTERI[26]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000000800000000)) 
    \TOFILTERI[27]_i_1 
       (.I0(TOFILTERI_0[26]),
        .I1(SRST_0),
        .I2(RXSTATES[2]),
        .I3(RXSTATES[3]),
        .I4(RXSTATES[0]),
        .I5(RXSTATES[1]),
        .O(\TOFILTERI[27]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h00008000AAAAAAAA)) 
    \TOFILTERI[28]_i_1 
       (.I0(IDE_i_2_n_0),
        .I1(IDE_i_4_n_0),
        .I2(\TOFILTERI[28]_i_3_n_0 ),
        .I3(\TOFILTERI[28]_i_4_n_0 ),
        .I4(RXSTATES[0]),
        .I5(IDE_i_5_n_0),
        .O(\TOFILTERI[28]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000000800000000)) 
    \TOFILTERI[28]_i_2 
       (.I0(TOFILTERI_0[27]),
        .I1(SRST_0),
        .I2(RXSTATES[2]),
        .I3(RXSTATES[3]),
        .I4(RXSTATES[0]),
        .I5(RXSTATES[1]),
        .O(\TOFILTERI[28]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFBFE)) 
    \TOFILTERI[28]_i_3 
       (.I0(\Cnt_reg_n_0_[3] ),
        .I1(\Cnt_reg_n_0_[4] ),
        .I2(\Cnt_reg_n_0_[5] ),
        .I3(\Cnt_reg_n_0_[2] ),
        .I4(\Cnt_reg_n_0_[0] ),
        .I5(\Cnt_reg_n_0_[1] ),
        .O(\TOFILTERI[28]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair192" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \TOFILTERI[28]_i_4 
       (.I0(RXSTATES[1]),
        .I1(RXSTATES[2]),
        .O(\TOFILTERI[28]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h0000000800000000)) 
    \TOFILTERI[2]_i_1 
       (.I0(TOFILTERI_0[1]),
        .I1(SRST_0),
        .I2(RXSTATES[2]),
        .I3(RXSTATES[3]),
        .I4(RXSTATES[0]),
        .I5(RXSTATES[1]),
        .O(\TOFILTERI[2]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000000800000000)) 
    \TOFILTERI[3]_i_1 
       (.I0(TOFILTERI_0[2]),
        .I1(SRST_0),
        .I2(RXSTATES[2]),
        .I3(RXSTATES[3]),
        .I4(RXSTATES[0]),
        .I5(RXSTATES[1]),
        .O(\TOFILTERI[3]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000000800000000)) 
    \TOFILTERI[4]_i_1 
       (.I0(TOFILTERI_0[3]),
        .I1(SRST_0),
        .I2(RXSTATES[2]),
        .I3(RXSTATES[3]),
        .I4(RXSTATES[0]),
        .I5(RXSTATES[1]),
        .O(\TOFILTERI[4]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000000800000000)) 
    \TOFILTERI[5]_i_1 
       (.I0(TOFILTERI_0[4]),
        .I1(SRST_0),
        .I2(RXSTATES[2]),
        .I3(RXSTATES[3]),
        .I4(RXSTATES[0]),
        .I5(RXSTATES[1]),
        .O(\TOFILTERI[5]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000000800000000)) 
    \TOFILTERI[6]_i_1 
       (.I0(TOFILTERI_0[5]),
        .I1(SRST_0),
        .I2(RXSTATES[2]),
        .I3(RXSTATES[3]),
        .I4(RXSTATES[0]),
        .I5(RXSTATES[1]),
        .O(\TOFILTERI[6]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000000800000000)) 
    \TOFILTERI[7]_i_1 
       (.I0(TOFILTERI_0[6]),
        .I1(SRST_0),
        .I2(RXSTATES[2]),
        .I3(RXSTATES[3]),
        .I4(RXSTATES[0]),
        .I5(RXSTATES[1]),
        .O(\TOFILTERI[7]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000000800000000)) 
    \TOFILTERI[8]_i_1 
       (.I0(TOFILTERI_0[7]),
        .I1(SRST_0),
        .I2(RXSTATES[2]),
        .I3(RXSTATES[3]),
        .I4(RXSTATES[0]),
        .I5(RXSTATES[1]),
        .O(\TOFILTERI[8]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000000800000000)) 
    \TOFILTERI[9]_i_1 
       (.I0(TOFILTERI_0[8]),
        .I1(SRST_0),
        .I2(RXSTATES[2]),
        .I3(RXSTATES[3]),
        .I4(RXSTATES[0]),
        .I5(RXSTATES[1]),
        .O(\TOFILTERI[9]_i_1_n_0 ));
  FDCE \TOFILTERI_reg[0] 
       (.C(clk),
        .CE(\TOFILTERI[28]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(IDE1_out),
        .Q(TOFILTERI_0[0]));
  FDCE \TOFILTERI_reg[10] 
       (.C(clk),
        .CE(\TOFILTERI[28]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERI[10]_i_1_n_0 ),
        .Q(TOFILTERI_0[10]));
  FDCE \TOFILTERI_reg[11] 
       (.C(clk),
        .CE(\TOFILTERI[28]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERI[11]_i_1_n_0 ),
        .Q(TOFILTERI_0[11]));
  FDCE \TOFILTERI_reg[12] 
       (.C(clk),
        .CE(\TOFILTERI[28]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERI[12]_i_1_n_0 ),
        .Q(TOFILTERI_0[12]));
  FDCE \TOFILTERI_reg[13] 
       (.C(clk),
        .CE(\TOFILTERI[28]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERI[13]_i_1_n_0 ),
        .Q(TOFILTERI_0[13]));
  FDCE \TOFILTERI_reg[14] 
       (.C(clk),
        .CE(\TOFILTERI[28]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERI[14]_i_1_n_0 ),
        .Q(TOFILTERI_0[14]));
  FDCE \TOFILTERI_reg[15] 
       (.C(clk),
        .CE(\TOFILTERI[28]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERI[15]_i_1_n_0 ),
        .Q(TOFILTERI_0[15]));
  FDCE \TOFILTERI_reg[16] 
       (.C(clk),
        .CE(\TOFILTERI[28]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERI[16]_i_1_n_0 ),
        .Q(TOFILTERI_0[16]));
  FDCE \TOFILTERI_reg[17] 
       (.C(clk),
        .CE(\TOFILTERI[28]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERI[17]_i_1_n_0 ),
        .Q(TOFILTERI_0[17]));
  FDCE \TOFILTERI_reg[18] 
       (.C(clk),
        .CE(\TOFILTERI[28]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERI[18]_i_1_n_0 ),
        .Q(TOFILTERI_0[18]));
  FDCE \TOFILTERI_reg[19] 
       (.C(clk),
        .CE(\TOFILTERI[28]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERI[19]_i_1_n_0 ),
        .Q(TOFILTERI_0[19]));
  FDCE \TOFILTERI_reg[1] 
       (.C(clk),
        .CE(\TOFILTERI[28]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERI[1]_i_1_n_0 ),
        .Q(TOFILTERI_0[1]));
  FDCE \TOFILTERI_reg[20] 
       (.C(clk),
        .CE(\TOFILTERI[28]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERI[20]_i_1_n_0 ),
        .Q(TOFILTERI_0[20]));
  FDCE \TOFILTERI_reg[21] 
       (.C(clk),
        .CE(\TOFILTERI[28]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERI[21]_i_1_n_0 ),
        .Q(TOFILTERI_0[21]));
  FDCE \TOFILTERI_reg[22] 
       (.C(clk),
        .CE(\TOFILTERI[28]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERI[22]_i_1_n_0 ),
        .Q(TOFILTERI_0[22]));
  FDCE \TOFILTERI_reg[23] 
       (.C(clk),
        .CE(\TOFILTERI[28]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERI[23]_i_1_n_0 ),
        .Q(TOFILTERI_0[23]));
  FDCE \TOFILTERI_reg[24] 
       (.C(clk),
        .CE(\TOFILTERI[28]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERI[24]_i_1_n_0 ),
        .Q(TOFILTERI_0[24]));
  FDCE \TOFILTERI_reg[25] 
       (.C(clk),
        .CE(\TOFILTERI[28]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERI[25]_i_1_n_0 ),
        .Q(TOFILTERI_0[25]));
  FDCE \TOFILTERI_reg[26] 
       (.C(clk),
        .CE(\TOFILTERI[28]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERI[26]_i_1_n_0 ),
        .Q(TOFILTERI_0[26]));
  FDCE \TOFILTERI_reg[27] 
       (.C(clk),
        .CE(\TOFILTERI[28]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERI[27]_i_1_n_0 ),
        .Q(TOFILTERI_0[27]));
  FDCE \TOFILTERI_reg[28] 
       (.C(clk),
        .CE(\TOFILTERI[28]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERI[28]_i_2_n_0 ),
        .Q(TOFILTERI_0[28]));
  FDCE \TOFILTERI_reg[2] 
       (.C(clk),
        .CE(\TOFILTERI[28]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERI[2]_i_1_n_0 ),
        .Q(TOFILTERI_0[2]));
  FDCE \TOFILTERI_reg[3] 
       (.C(clk),
        .CE(\TOFILTERI[28]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERI[3]_i_1_n_0 ),
        .Q(TOFILTERI_0[3]));
  FDCE \TOFILTERI_reg[4] 
       (.C(clk),
        .CE(\TOFILTERI[28]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERI[4]_i_1_n_0 ),
        .Q(TOFILTERI_0[4]));
  FDCE \TOFILTERI_reg[5] 
       (.C(clk),
        .CE(\TOFILTERI[28]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERI[5]_i_1_n_0 ),
        .Q(TOFILTERI_0[5]));
  FDCE \TOFILTERI_reg[6] 
       (.C(clk),
        .CE(\TOFILTERI[28]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERI[6]_i_1_n_0 ),
        .Q(TOFILTERI_0[6]));
  FDCE \TOFILTERI_reg[7] 
       (.C(clk),
        .CE(\TOFILTERI[28]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERI[7]_i_1_n_0 ),
        .Q(TOFILTERI_0[7]));
  FDCE \TOFILTERI_reg[8] 
       (.C(clk),
        .CE(\TOFILTERI[28]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERI[8]_i_1_n_0 ),
        .Q(TOFILTERI_0[8]));
  FDCE \TOFILTERI_reg[9] 
       (.C(clk),
        .CE(\TOFILTERI[28]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERI[9]_i_1_n_0 ),
        .Q(TOFILTERI_0[9]));
  LUT6 #(
    .INIT(64'h0000010000000000)) 
    \TOFILTERd[0]_i_1 
       (.I0(\TOFILTERd_reg[0]_0 ),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST_0),
        .I4(RXSTATES[3]),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[0]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[10]_i_1 
       (.I0(TOFILTERd_0[9]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST_0),
        .I4(RXSTATES[3]),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[10]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[11]_i_1 
       (.I0(TOFILTERd_0[10]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST_0),
        .I4(RXSTATES[3]),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[11]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[12]_i_1 
       (.I0(TOFILTERd_0[11]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST_0),
        .I4(RXSTATES[3]),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[12]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[13]_i_1 
       (.I0(TOFILTERd_0[12]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST_0),
        .I4(RXSTATES[3]),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[13]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[14]_i_1 
       (.I0(TOFILTERd_0[13]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST_0),
        .I4(RXSTATES[3]),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[14]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[15]_i_1 
       (.I0(TOFILTERd_0[14]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST_0),
        .I4(RXSTATES[3]),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[15]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[16]_i_1 
       (.I0(TOFILTERd_0[15]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST_0),
        .I4(RXSTATES[3]),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[16]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[17]_i_1 
       (.I0(TOFILTERd_0[16]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST_0),
        .I4(RXSTATES[3]),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[17]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[18]_i_1 
       (.I0(TOFILTERd_0[17]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST_0),
        .I4(RXSTATES[3]),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[18]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[19]_i_1 
       (.I0(TOFILTERd_0[18]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST_0),
        .I4(RXSTATES[3]),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[19]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[1]_i_1 
       (.I0(TOFILTERd_0[0]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST_0),
        .I4(RXSTATES[3]),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[1]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[20]_i_1 
       (.I0(TOFILTERd_0[19]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST_0),
        .I4(RXSTATES[3]),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[20]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[21]_i_1 
       (.I0(TOFILTERd_0[20]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST_0),
        .I4(RXSTATES[3]),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[21]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[22]_i_1 
       (.I0(TOFILTERd_0[21]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST_0),
        .I4(RXSTATES[3]),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[22]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[23]_i_1 
       (.I0(TOFILTERd_0[22]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST_0),
        .I4(RXSTATES[3]),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[23]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[24]_i_1 
       (.I0(TOFILTERd_0[23]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST_0),
        .I4(RXSTATES[3]),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[24]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[25]_i_1 
       (.I0(TOFILTERd_0[24]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST_0),
        .I4(RXSTATES[3]),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[25]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[26]_i_1 
       (.I0(TOFILTERd_0[25]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST_0),
        .I4(RXSTATES[3]),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[26]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[27]_i_1 
       (.I0(TOFILTERd_0[26]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST_0),
        .I4(RXSTATES[3]),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[27]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[28]_i_1 
       (.I0(TOFILTERd_0[27]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST_0),
        .I4(RXSTATES[3]),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[28]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[29]_i_1 
       (.I0(TOFILTERd_0[28]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST_0),
        .I4(RXSTATES[3]),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[29]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[2]_i_1 
       (.I0(TOFILTERd_0[1]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST_0),
        .I4(RXSTATES[3]),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[2]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[30]_i_1 
       (.I0(TOFILTERd_0[29]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST_0),
        .I4(RXSTATES[3]),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[30]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[31]_i_1 
       (.I0(TOFILTERd_0[30]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST_0),
        .I4(RXSTATES[3]),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[31]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[32]_i_1 
       (.I0(TOFILTERd_0[31]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST_0),
        .I4(RXSTATES[3]),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[32]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[33]_i_1 
       (.I0(TOFILTERd_0[32]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST_0),
        .I4(RXSTATES[3]),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[33]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[34]_i_1 
       (.I0(TOFILTERd_0[33]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST_0),
        .I4(RXSTATES[3]),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[34]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[35]_i_1 
       (.I0(TOFILTERd_0[34]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST_0),
        .I4(RXSTATES[3]),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[35]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[36]_i_1 
       (.I0(TOFILTERd_0[35]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST_0),
        .I4(RXSTATES[3]),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[36]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[37]_i_1 
       (.I0(TOFILTERd_0[36]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST_0),
        .I4(RXSTATES[3]),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[37]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[38]_i_1 
       (.I0(TOFILTERd_0[37]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST_0),
        .I4(RXSTATES[3]),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[38]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[39]_i_1 
       (.I0(TOFILTERd_0[38]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST_0),
        .I4(RXSTATES[3]),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[39]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[3]_i_1 
       (.I0(TOFILTERd_0[2]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST_0),
        .I4(RXSTATES[3]),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[3]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[40]_i_1 
       (.I0(TOFILTERd_0[39]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST_0),
        .I4(RXSTATES[3]),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[40]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[41]_i_1 
       (.I0(TOFILTERd_0[40]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST_0),
        .I4(RXSTATES[3]),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[41]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[42]_i_1 
       (.I0(TOFILTERd_0[41]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST_0),
        .I4(RXSTATES[3]),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[42]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[43]_i_1 
       (.I0(TOFILTERd_0[42]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST_0),
        .I4(RXSTATES[3]),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[43]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[44]_i_1 
       (.I0(TOFILTERd_0[43]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST_0),
        .I4(RXSTATES[3]),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[44]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[45]_i_1 
       (.I0(TOFILTERd_0[44]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST_0),
        .I4(RXSTATES[3]),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[45]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[46]_i_1 
       (.I0(TOFILTERd_0[45]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST_0),
        .I4(RXSTATES[3]),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[46]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[47]_i_1 
       (.I0(TOFILTERd_0[46]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST_0),
        .I4(RXSTATES[3]),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[47]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[48]_i_1 
       (.I0(TOFILTERd_0[47]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST_0),
        .I4(RXSTATES[3]),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[48]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[49]_i_1 
       (.I0(TOFILTERd_0[48]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST_0),
        .I4(RXSTATES[3]),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[49]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[4]_i_1 
       (.I0(TOFILTERd_0[3]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST_0),
        .I4(RXSTATES[3]),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[4]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[50]_i_1 
       (.I0(TOFILTERd_0[49]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST_0),
        .I4(RXSTATES[3]),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[50]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[51]_i_1 
       (.I0(TOFILTERd_0[50]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST_0),
        .I4(RXSTATES[3]),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[51]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[52]_i_1 
       (.I0(TOFILTERd_0[51]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST_0),
        .I4(RXSTATES[3]),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[52]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[53]_i_1 
       (.I0(TOFILTERd_0[52]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST_0),
        .I4(RXSTATES[3]),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[53]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[54]_i_1 
       (.I0(TOFILTERd_0[53]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST_0),
        .I4(RXSTATES[3]),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[54]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[55]_i_1 
       (.I0(TOFILTERd_0[54]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST_0),
        .I4(RXSTATES[3]),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[55]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[56]_i_1 
       (.I0(TOFILTERd_0[55]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST_0),
        .I4(RXSTATES[3]),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[56]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[57]_i_1 
       (.I0(TOFILTERd_0[56]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST_0),
        .I4(RXSTATES[3]),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[57]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[58]_i_1 
       (.I0(TOFILTERd_0[57]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST_0),
        .I4(RXSTATES[3]),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[58]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[59]_i_1 
       (.I0(TOFILTERd_0[58]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST_0),
        .I4(RXSTATES[3]),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[59]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[5]_i_1 
       (.I0(TOFILTERd_0[4]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST_0),
        .I4(RXSTATES[3]),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[5]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[60]_i_1 
       (.I0(TOFILTERd_0[59]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST_0),
        .I4(RXSTATES[3]),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[60]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[61]_i_1 
       (.I0(TOFILTERd_0[60]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST_0),
        .I4(RXSTATES[3]),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[61]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[62]_i_1 
       (.I0(TOFILTERd_0[61]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST_0),
        .I4(RXSTATES[3]),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[62]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h01050000FFFFFFFF)) 
    \TOFILTERd[63]_i_1 
       (.I0(RXSTATES[1]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[3]),
        .I3(RXSTATES[2]),
        .I4(\CRC_RG_reg[14] ),
        .I5(SRST_0),
        .O(\TOFILTERd[63]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[63]_i_2 
       (.I0(TOFILTERd_0[62]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST_0),
        .I4(RXSTATES[3]),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[63]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[6]_i_1 
       (.I0(TOFILTERd_0[5]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST_0),
        .I4(RXSTATES[3]),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[6]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[7]_i_1 
       (.I0(TOFILTERd_0[6]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST_0),
        .I4(RXSTATES[3]),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[7]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[8]_i_1 
       (.I0(TOFILTERd_0[7]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST_0),
        .I4(RXSTATES[3]),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[8]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[9]_i_1 
       (.I0(TOFILTERd_0[8]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST_0),
        .I4(RXSTATES[3]),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[9]_i_1_n_0 ));
  FDCE \TOFILTERd_reg[0] 
       (.C(clk),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[0]_i_1_n_0 ),
        .Q(TOFILTERd_0[0]));
  FDCE \TOFILTERd_reg[10] 
       (.C(clk),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[10]_i_1_n_0 ),
        .Q(TOFILTERd_0[10]));
  FDCE \TOFILTERd_reg[11] 
       (.C(clk),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[11]_i_1_n_0 ),
        .Q(TOFILTERd_0[11]));
  FDCE \TOFILTERd_reg[12] 
       (.C(clk),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[12]_i_1_n_0 ),
        .Q(TOFILTERd_0[12]));
  FDCE \TOFILTERd_reg[13] 
       (.C(clk),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[13]_i_1_n_0 ),
        .Q(TOFILTERd_0[13]));
  FDCE \TOFILTERd_reg[14] 
       (.C(clk),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[14]_i_1_n_0 ),
        .Q(TOFILTERd_0[14]));
  FDCE \TOFILTERd_reg[15] 
       (.C(clk),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[15]_i_1_n_0 ),
        .Q(TOFILTERd_0[15]));
  FDCE \TOFILTERd_reg[16] 
       (.C(clk),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[16]_i_1_n_0 ),
        .Q(TOFILTERd_0[16]));
  FDCE \TOFILTERd_reg[17] 
       (.C(clk),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[17]_i_1_n_0 ),
        .Q(TOFILTERd_0[17]));
  FDCE \TOFILTERd_reg[18] 
       (.C(clk),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[18]_i_1_n_0 ),
        .Q(TOFILTERd_0[18]));
  FDCE \TOFILTERd_reg[19] 
       (.C(clk),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[19]_i_1_n_0 ),
        .Q(TOFILTERd_0[19]));
  FDCE \TOFILTERd_reg[1] 
       (.C(clk),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[1]_i_1_n_0 ),
        .Q(TOFILTERd_0[1]));
  FDCE \TOFILTERd_reg[20] 
       (.C(clk),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[20]_i_1_n_0 ),
        .Q(TOFILTERd_0[20]));
  FDCE \TOFILTERd_reg[21] 
       (.C(clk),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[21]_i_1_n_0 ),
        .Q(TOFILTERd_0[21]));
  FDCE \TOFILTERd_reg[22] 
       (.C(clk),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[22]_i_1_n_0 ),
        .Q(TOFILTERd_0[22]));
  FDCE \TOFILTERd_reg[23] 
       (.C(clk),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[23]_i_1_n_0 ),
        .Q(TOFILTERd_0[23]));
  FDCE \TOFILTERd_reg[24] 
       (.C(clk),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[24]_i_1_n_0 ),
        .Q(TOFILTERd_0[24]));
  FDCE \TOFILTERd_reg[25] 
       (.C(clk),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[25]_i_1_n_0 ),
        .Q(TOFILTERd_0[25]));
  FDCE \TOFILTERd_reg[26] 
       (.C(clk),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[26]_i_1_n_0 ),
        .Q(TOFILTERd_0[26]));
  FDCE \TOFILTERd_reg[27] 
       (.C(clk),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[27]_i_1_n_0 ),
        .Q(TOFILTERd_0[27]));
  FDCE \TOFILTERd_reg[28] 
       (.C(clk),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[28]_i_1_n_0 ),
        .Q(TOFILTERd_0[28]));
  FDCE \TOFILTERd_reg[29] 
       (.C(clk),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[29]_i_1_n_0 ),
        .Q(TOFILTERd_0[29]));
  FDCE \TOFILTERd_reg[2] 
       (.C(clk),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[2]_i_1_n_0 ),
        .Q(TOFILTERd_0[2]));
  FDCE \TOFILTERd_reg[30] 
       (.C(clk),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[30]_i_1_n_0 ),
        .Q(TOFILTERd_0[30]));
  FDCE \TOFILTERd_reg[31] 
       (.C(clk),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[31]_i_1_n_0 ),
        .Q(TOFILTERd_0[31]));
  FDCE \TOFILTERd_reg[32] 
       (.C(clk),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[32]_i_1_n_0 ),
        .Q(TOFILTERd_0[32]));
  FDCE \TOFILTERd_reg[33] 
       (.C(clk),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[33]_i_1_n_0 ),
        .Q(TOFILTERd_0[33]));
  FDCE \TOFILTERd_reg[34] 
       (.C(clk),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[34]_i_1_n_0 ),
        .Q(TOFILTERd_0[34]));
  FDCE \TOFILTERd_reg[35] 
       (.C(clk),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[35]_i_1_n_0 ),
        .Q(TOFILTERd_0[35]));
  FDCE \TOFILTERd_reg[36] 
       (.C(clk),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[36]_i_1_n_0 ),
        .Q(TOFILTERd_0[36]));
  FDCE \TOFILTERd_reg[37] 
       (.C(clk),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[37]_i_1_n_0 ),
        .Q(TOFILTERd_0[37]));
  FDCE \TOFILTERd_reg[38] 
       (.C(clk),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[38]_i_1_n_0 ),
        .Q(TOFILTERd_0[38]));
  FDCE \TOFILTERd_reg[39] 
       (.C(clk),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[39]_i_1_n_0 ),
        .Q(TOFILTERd_0[39]));
  FDCE \TOFILTERd_reg[3] 
       (.C(clk),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[3]_i_1_n_0 ),
        .Q(TOFILTERd_0[3]));
  FDCE \TOFILTERd_reg[40] 
       (.C(clk),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[40]_i_1_n_0 ),
        .Q(TOFILTERd_0[40]));
  FDCE \TOFILTERd_reg[41] 
       (.C(clk),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[41]_i_1_n_0 ),
        .Q(TOFILTERd_0[41]));
  FDCE \TOFILTERd_reg[42] 
       (.C(clk),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[42]_i_1_n_0 ),
        .Q(TOFILTERd_0[42]));
  FDCE \TOFILTERd_reg[43] 
       (.C(clk),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[43]_i_1_n_0 ),
        .Q(TOFILTERd_0[43]));
  FDCE \TOFILTERd_reg[44] 
       (.C(clk),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[44]_i_1_n_0 ),
        .Q(TOFILTERd_0[44]));
  FDCE \TOFILTERd_reg[45] 
       (.C(clk),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[45]_i_1_n_0 ),
        .Q(TOFILTERd_0[45]));
  FDCE \TOFILTERd_reg[46] 
       (.C(clk),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[46]_i_1_n_0 ),
        .Q(TOFILTERd_0[46]));
  FDCE \TOFILTERd_reg[47] 
       (.C(clk),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[47]_i_1_n_0 ),
        .Q(TOFILTERd_0[47]));
  FDCE \TOFILTERd_reg[48] 
       (.C(clk),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[48]_i_1_n_0 ),
        .Q(TOFILTERd_0[48]));
  FDCE \TOFILTERd_reg[49] 
       (.C(clk),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[49]_i_1_n_0 ),
        .Q(TOFILTERd_0[49]));
  FDCE \TOFILTERd_reg[4] 
       (.C(clk),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[4]_i_1_n_0 ),
        .Q(TOFILTERd_0[4]));
  FDCE \TOFILTERd_reg[50] 
       (.C(clk),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[50]_i_1_n_0 ),
        .Q(TOFILTERd_0[50]));
  FDCE \TOFILTERd_reg[51] 
       (.C(clk),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[51]_i_1_n_0 ),
        .Q(TOFILTERd_0[51]));
  FDCE \TOFILTERd_reg[52] 
       (.C(clk),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[52]_i_1_n_0 ),
        .Q(TOFILTERd_0[52]));
  FDCE \TOFILTERd_reg[53] 
       (.C(clk),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[53]_i_1_n_0 ),
        .Q(TOFILTERd_0[53]));
  FDCE \TOFILTERd_reg[54] 
       (.C(clk),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[54]_i_1_n_0 ),
        .Q(TOFILTERd_0[54]));
  FDCE \TOFILTERd_reg[55] 
       (.C(clk),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[55]_i_1_n_0 ),
        .Q(TOFILTERd_0[55]));
  FDCE \TOFILTERd_reg[56] 
       (.C(clk),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[56]_i_1_n_0 ),
        .Q(TOFILTERd_0[56]));
  FDCE \TOFILTERd_reg[57] 
       (.C(clk),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[57]_i_1_n_0 ),
        .Q(TOFILTERd_0[57]));
  FDCE \TOFILTERd_reg[58] 
       (.C(clk),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[58]_i_1_n_0 ),
        .Q(TOFILTERd_0[58]));
  FDCE \TOFILTERd_reg[59] 
       (.C(clk),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[59]_i_1_n_0 ),
        .Q(TOFILTERd_0[59]));
  FDCE \TOFILTERd_reg[5] 
       (.C(clk),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[5]_i_1_n_0 ),
        .Q(TOFILTERd_0[5]));
  FDCE \TOFILTERd_reg[60] 
       (.C(clk),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[60]_i_1_n_0 ),
        .Q(TOFILTERd_0[60]));
  FDCE \TOFILTERd_reg[61] 
       (.C(clk),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[61]_i_1_n_0 ),
        .Q(TOFILTERd_0[61]));
  FDCE \TOFILTERd_reg[62] 
       (.C(clk),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[62]_i_1_n_0 ),
        .Q(TOFILTERd_0[62]));
  FDCE \TOFILTERd_reg[63] 
       (.C(clk),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[63]_i_2_n_0 ),
        .Q(TOFILTERd_0[63]));
  FDCE \TOFILTERd_reg[6] 
       (.C(clk),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[6]_i_1_n_0 ),
        .Q(TOFILTERd_0[6]));
  FDCE \TOFILTERd_reg[7] 
       (.C(clk),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[7]_i_1_n_0 ),
        .Q(TOFILTERd_0[7]));
  FDCE \TOFILTERd_reg[8] 
       (.C(clk),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[8]_i_1_n_0 ),
        .Q(TOFILTERd_0[8]));
  FDCE \TOFILTERd_reg[9] 
       (.C(clk),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[9]_i_1_n_0 ),
        .Q(TOFILTERd_0[9]));
  LUT5 #(
    .INIT(32'hBBBA888A)) 
    TXpin_i_5
       (.I0(RXOUT_reg),
        .I1(\RXSTATES_reg[0]_0 ),
        .I2(TXpin_i_2),
        .I3(req_Error_RX),
        .I4(TXpin_i_2_0),
        .O(req_Error_reg_0));
  (* SOFT_HLUTNM = "soft_lutpair179" *) 
  LUT5 #(
    .INIT(32'hFFF57F55)) 
    \bs[0]_i_1 
       (.I0(\TOFILTERd_reg[0]_0 ),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(RXSTATES[3]),
        .I4(RXSTATES[2]),
        .O(I56[0]));
  LUT6 #(
    .INIT(64'h000F80FE00008002)) 
    \bs[1]_i_1 
       (.I0(\TOFILTERd_reg[0]_0 ),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(RXSTATES[3]),
        .I4(RXSTATES[2]),
        .I5(bs[0]),
        .O(I56[1]));
  (* SOFT_HLUTNM = "soft_lutpair180" *) 
  LUT5 #(
    .INIT(32'h020A0208)) 
    \bs[2]_i_1 
       (.I0(bs[1]),
        .I1(RXSTATES[2]),
        .I2(RXSTATES[3]),
        .I3(RXSTATES[1]),
        .I4(RXSTATES[0]),
        .O(I56[2]));
  (* SOFT_HLUTNM = "soft_lutpair181" *) 
  LUT5 #(
    .INIT(32'h020A0208)) 
    \bs[3]_i_1 
       (.I0(bs[2]),
        .I1(RXSTATES[2]),
        .I2(RXSTATES[3]),
        .I3(RXSTATES[1]),
        .I4(RXSTATES[0]),
        .O(I56[3]));
  (* SOFT_HLUTNM = "soft_lutpair182" *) 
  LUT5 #(
    .INIT(32'h020A0208)) 
    \bs[4]_i_1 
       (.I0(bs[3]),
        .I1(RXSTATES[2]),
        .I2(RXSTATES[3]),
        .I3(RXSTATES[1]),
        .I4(RXSTATES[0]),
        .O(I56[4]));
  (* SOFT_HLUTNM = "soft_lutpair183" *) 
  LUT5 #(
    .INIT(32'h020A0208)) 
    \bs[5]_i_1 
       (.I0(bs[4]),
        .I1(RXSTATES[2]),
        .I2(RXSTATES[3]),
        .I3(RXSTATES[1]),
        .I4(RXSTATES[0]),
        .O(I56[5]));
  FDPE \bs_reg[0] 
       (.C(clk),
        .CE(\bs_reg[0]_0 ),
        .D(I56[0]),
        .PRE(CAN_RST_0),
        .Q(bs[0]));
  FDCE \bs_reg[1] 
       (.C(clk),
        .CE(\bs_reg[0]_0 ),
        .CLR(CAN_RST_0),
        .D(I56[1]),
        .Q(bs[1]));
  FDCE \bs_reg[2] 
       (.C(clk),
        .CE(\bs_reg[0]_0 ),
        .CLR(CAN_RST_0),
        .D(I56[2]),
        .Q(bs[2]));
  FDCE \bs_reg[3] 
       (.C(clk),
        .CE(\bs_reg[0]_0 ),
        .CLR(CAN_RST_0),
        .D(I56[3]),
        .Q(bs[3]));
  FDCE \bs_reg[4] 
       (.C(clk),
        .CE(\bs_reg[0]_0 ),
        .CLR(CAN_RST_0),
        .D(I56[4]),
        .Q(bs[4]));
  FDCE \bs_reg[5] 
       (.C(clk),
        .CE(\bs_reg[0]_0 ),
        .CLR(CAN_RST_0),
        .D(I56[5]),
        .Q(bs[5]));
  (* SOFT_HLUTNM = "soft_lutpair179" *) 
  LUT4 #(
    .INIT(16'h2001)) 
    done_i_14
       (.I0(RXSTATES[3]),
        .I1(RXSTATES[2]),
        .I2(RXSTATES[0]),
        .I3(RXSTATES[1]),
        .O(\RXSTATES_reg[3]_0 ));
  (* SOFT_HLUTNM = "soft_lutpair178" *) 
  LUT5 #(
    .INIT(32'hCCC88888)) 
    done_i_1__0
       (.I0(done_i_3__0_n_0),
        .I1(SRST_0),
        .I2(RXSTATES[3]),
        .I3(\RXSTATES_reg[2]_0 ),
        .I4(done_reg_0),
        .O(done_i_1__0_n_0));
  LUT6 #(
    .INIT(64'h0000000000200000)) 
    done_i_3__0
       (.I0(\RXSTATES[2]_i_3_n_0 ),
        .I1(RXSTATES[2]),
        .I2(RXSTATES[3]),
        .I3(RXSTATES[1]),
        .I4(RXSTATES[0]),
        .I5(imTX),
        .O(done_i_3__0_n_0));
  (* SOFT_HLUTNM = "soft_lutpair181" *) 
  LUT4 #(
    .INIT(16'h0001)) 
    done_i_4__0
       (.I0(RXSTATES[2]),
        .I1(RXSTATES[3]),
        .I2(RXSTATES[1]),
        .I3(RXSTATES[0]),
        .O(\RXSTATES_reg[2]_0 ));
  FDCE done_reg
       (.C(clk),
        .CE(1'b1),
        .CLR(CAN_RST_0),
        .D(done_i_1__0_n_0),
        .Q(done_reg_0));
  (* SOFT_HLUTNM = "soft_lutpair178" *) 
  LUT2 #(
    .INIT(4'h8)) 
    donefromrxr_i_1
       (.I0(SRST_0),
        .I1(done_reg_0),
        .O(donefromrxr));
  LUT6 #(
    .INIT(64'h0020020000200A00)) 
    req_Error_i_2
       (.I0(\TOFILTERd_reg[0]_0 ),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(RXSTATES[3]),
        .I4(RXSTATES[2]),
        .I5(\RXSTATES[2]_i_3_n_0 ),
        .O(req_Error_i_2_n_0));
  (* SOFT_HLUTNM = "soft_lutpair184" *) 
  LUT5 #(
    .INIT(32'h55D5555F)) 
    req_Error_i_4
       (.I0(SRST_0),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[3]),
        .I3(RXSTATES[1]),
        .I4(RXSTATES[2]),
        .O(req_Error_i_4_n_0));
  (* SOFT_HLUTNM = "soft_lutpair185" *) 
  LUT5 #(
    .INIT(32'h00000001)) 
    req_Error_i_5
       (.I0(bs[1]),
        .I1(bs[0]),
        .I2(bs[3]),
        .I3(bs[4]),
        .I4(bs[2]),
        .O(req_Error_i_5_n_0));
  (* SOFT_HLUTNM = "soft_lutpair185" *) 
  LUT5 #(
    .INIT(32'h80000000)) 
    req_Error_i_6
       (.I0(bs[1]),
        .I1(bs[0]),
        .I2(bs[3]),
        .I3(bs[4]),
        .I4(bs[2]),
        .O(req_Error_i_6_n_0));
  (* SOFT_HLUTNM = "soft_lutpair176" *) 
  LUT4 #(
    .INIT(16'h0100)) 
    req_Error_i_8
       (.I0(RXSTATES[1]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[2]),
        .I3(RXSTATES[3]),
        .O(req_Error_i_8_n_0));
  FDCE req_Error_reg
       (.C(clk),
        .CE(1'b1),
        .CLR(CAN_RST_0),
        .D(rxcrc_n_0),
        .Q(req_Error_RX));
  design_1_FPGAPROJECT_0_0_CRC_0 rxcrc
       (.CAN_RST(CAN_RST),
        .CAN_RST_0(CAN_RST_0),
        .\CRC_RG_reg[14]_0 (\CRC_RG_reg[14] ),
        .\CRC_RG_reg[3]_0 (\TOFILTERd_reg[0]_0 ),
        .Q(RXSTATES),
        .SRST_0(SRST_0),
        .SRST_0_0(rxcrc_n_0),
        .\bs_reg[1] (\bs_reg[1]_0 ),
        .clk(clk),
        .req_Error_reg(req_Error_i_2_n_0),
        .req_Error_reg_0(req_Error_i_4_n_0),
        .req_Error_reg_1(\bs_reg[0]_0 ),
        .req_Error_reg_2(req_Error_RX),
        .req_Error_reg_3(req_Error_i_5_n_0),
        .req_Error_reg_4(bs),
        .req_Error_reg_5(req_Error_i_6_n_0),
        .req_Error_reg_6(req_Error_i_8_n_0));
endmodule

(* ORIG_REF_NAME = "RXMachine" *) 
module design_1_FPGAPROJECT_0_0_RXMachine_6
   (AckTakeOver,
    CAN_RST_0,
    RTR_reg_0,
    req_Error_RX,
    IDE_rec,
    done_reg_0,
    req_Error_reg_0,
    Q,
    \D_Len_reg[3]_0 ,
    \RXSTATES_reg[2]_0 ,
    \RXSTATES_reg[0]_0 ,
    \RXSTATES_reg[0]_1 ,
    \RXSTATES_reg[1]_0 ,
    TOFILTERd,
    TOFILTERI,
    donefromrxr,
    RXOUT_reg,
    \bs_reg[1]_0 ,
    E,
    Tq,
    CAN_RST,
    \REC_reg[0] ,
    SRST,
    IDE_reg_0,
    \RXSTATES_reg[0]_2 ,
    \RXSTATES_reg[0]_3 ,
    \CNT2_reg[3] ,
    \CNT2_reg[3]_0 ,
    imTX,
    \RXSTATES_reg[1]_1 ,
    \RXSTATES_reg[3]_0 ,
    \CRC_RG_reg[14] ,
    \Cnt[0]_i_2__0_0 ,
    \bs_reg[0]_0 ,
    Sampled_din,
    \TOFILTERI_reg[28]_0 ,
    \RXSTATES_reg[3]_1 ,
    D,
    \Cnt_reg[0]_0 );
  output AckTakeOver;
  output CAN_RST_0;
  output RTR_reg_0;
  output req_Error_RX;
  output IDE_rec;
  output done_reg_0;
  output req_Error_reg_0;
  output [0:0]Q;
  output [3:0]\D_Len_reg[3]_0 ;
  output [0:0]\RXSTATES_reg[2]_0 ;
  output \RXSTATES_reg[0]_0 ;
  output \RXSTATES_reg[0]_1 ;
  output \RXSTATES_reg[1]_0 ;
  output [63:0]TOFILTERd;
  output [28:0]TOFILTERI;
  output donefromrxr;
  output RXOUT_reg;
  output \bs_reg[1]_0 ;
  input [0:0]E;
  input Tq;
  input CAN_RST;
  input \REC_reg[0] ;
  input SRST;
  input IDE_reg_0;
  input \RXSTATES_reg[0]_2 ;
  input \RXSTATES_reg[0]_3 ;
  input \CNT2_reg[3] ;
  input \CNT2_reg[3]_0 ;
  input imTX;
  input \RXSTATES_reg[1]_1 ;
  input \RXSTATES_reg[3]_0 ;
  input \CRC_RG_reg[14] ;
  input [2:0]\Cnt[0]_i_2__0_0 ;
  input [0:0]\bs_reg[0]_0 ;
  input Sampled_din;
  input \TOFILTERI_reg[28]_0 ;
  input [0:0]\RXSTATES_reg[3]_1 ;
  input [0:0]D;
  input [0:0]\Cnt_reg[0]_0 ;

  wire AckTakeOver;
  wire AckTakeOver_i_1_n_0;
  wire AckTakeOver_i_2_n_0;
  wire CAN_RST;
  wire CAN_RST_0;
  wire \CNT2_reg[3] ;
  wire \CNT2_reg[3]_0 ;
  wire \CRC_RG_reg[14] ;
  wire \Cnt[0]_i_1__0_n_0 ;
  wire [2:0]\Cnt[0]_i_2__0_0 ;
  wire \Cnt[0]_i_2__0_n_0 ;
  wire \Cnt[0]_i_3__0_n_0 ;
  wire \Cnt[0]_i_4__0_n_0 ;
  wire \Cnt[0]_i_5__0_n_0 ;
  wire \Cnt[0]_i_6_n_0 ;
  wire \Cnt[1]_i_1__0_n_0 ;
  wire \Cnt[1]_i_2__0_n_0 ;
  wire \Cnt[1]_i_3__0_n_0 ;
  wire \Cnt[1]_i_4_n_0 ;
  wire \Cnt[1]_i_5__0_n_0 ;
  wire \Cnt[1]_i_6_n_0 ;
  wire \Cnt[2]_i_1_n_0 ;
  wire \Cnt[2]_i_2_n_0 ;
  wire \Cnt[2]_i_3_n_0 ;
  wire \Cnt[2]_i_4__0_n_0 ;
  wire \Cnt[2]_i_5_n_0 ;
  wire \Cnt[2]_i_6_n_0 ;
  wire \Cnt[3]_i_1_n_0 ;
  wire \Cnt[3]_i_2_n_0 ;
  wire \Cnt[3]_i_3__0_n_0 ;
  wire \Cnt[3]_i_4__0_n_0 ;
  wire \Cnt[3]_i_5__1_n_0 ;
  wire \Cnt[4]_i_1_n_0 ;
  wire \Cnt[4]_i_2_n_0 ;
  wire \Cnt[4]_i_3_n_0 ;
  wire \Cnt[4]_i_4_n_0 ;
  wire \Cnt[4]_i_5__0_n_0 ;
  wire \Cnt[4]_i_6_n_0 ;
  wire \Cnt[4]_i_7__0_n_0 ;
  wire \Cnt[5]_i_2_n_0 ;
  wire \Cnt[5]_i_3__0_n_0 ;
  wire \Cnt[5]_i_4_n_0 ;
  wire \Cnt[5]_i_5__0_n_0 ;
  wire \Cnt[5]_i_6__0_n_0 ;
  wire \Cnt[5]_i_7__0_n_0 ;
  wire \Cnt[5]_i_8__0_n_0 ;
  wire \Cnt[5]_i_9__0_n_0 ;
  wire [0:0]\Cnt_reg[0]_0 ;
  wire \Cnt_reg_n_0_[0] ;
  wire \Cnt_reg_n_0_[1] ;
  wire \Cnt_reg_n_0_[2] ;
  wire \Cnt_reg_n_0_[3] ;
  wire \Cnt_reg_n_0_[4] ;
  wire \Cnt_reg_n_0_[5] ;
  wire [0:0]D;
  wire \D_Len[0]_i_1_n_0 ;
  wire \D_Len[1]_i_1_n_0 ;
  wire \D_Len[2]_i_1_n_0 ;
  wire \D_Len[3]_i_1_n_0 ;
  wire \D_Len[3]_i_2_n_0 ;
  wire \D_Len[3]_i_3_n_0 ;
  wire [3:0]\D_Len_reg[3]_0 ;
  wire [0:0]E;
  wire [5:0]I56;
  wire I59;
  wire IDE1_out;
  wire IDE_i_1_n_0;
  wire IDE_i_3_n_0;
  wire IDE_i_4_n_0;
  wire IDE_rec;
  wire IDE_reg_0;
  wire [0:0]Q;
  wire \REC_reg[0] ;
  wire RTR_i_1_n_0;
  wire RTR_i_4_n_0;
  wire RTR_reg_0;
  wire RXOUT_reg;
  wire [2:0]RXSTATES;
  wire \RXSTATES[0]_i_1_n_0 ;
  wire \RXSTATES[0]_i_3_n_0 ;
  wire \RXSTATES[0]_i_4_n_0 ;
  wire \RXSTATES[0]_i_6_n_0 ;
  wire \RXSTATES[0]_i_7_n_0 ;
  wire \RXSTATES[0]_i_8_n_0 ;
  wire \RXSTATES[2]_i_1_n_0 ;
  wire \RXSTATES[2]_i_2_n_0 ;
  wire \RXSTATES[2]_i_3_n_0 ;
  wire \RXSTATES[2]_i_4_n_0 ;
  wire \RXSTATES[3]_i_2_n_0 ;
  wire \RXSTATES_reg[0]_0 ;
  wire \RXSTATES_reg[0]_1 ;
  wire \RXSTATES_reg[0]_2 ;
  wire \RXSTATES_reg[0]_3 ;
  wire \RXSTATES_reg[1]_0 ;
  wire \RXSTATES_reg[1]_1 ;
  wire [0:0]\RXSTATES_reg[2]_0 ;
  wire \RXSTATES_reg[3]_0 ;
  wire [0:0]\RXSTATES_reg[3]_1 ;
  wire SRST;
  wire Sampled_din;
  wire [28:0]TOFILTERI;
  wire \TOFILTERI[10]_i_1_n_0 ;
  wire \TOFILTERI[11]_i_1_n_0 ;
  wire \TOFILTERI[12]_i_1_n_0 ;
  wire \TOFILTERI[13]_i_1_n_0 ;
  wire \TOFILTERI[14]_i_1_n_0 ;
  wire \TOFILTERI[15]_i_1_n_0 ;
  wire \TOFILTERI[16]_i_1_n_0 ;
  wire \TOFILTERI[17]_i_1_n_0 ;
  wire \TOFILTERI[18]_i_1_n_0 ;
  wire \TOFILTERI[19]_i_1_n_0 ;
  wire \TOFILTERI[1]_i_1_n_0 ;
  wire \TOFILTERI[20]_i_1_n_0 ;
  wire \TOFILTERI[21]_i_1_n_0 ;
  wire \TOFILTERI[22]_i_1_n_0 ;
  wire \TOFILTERI[23]_i_1_n_0 ;
  wire \TOFILTERI[24]_i_1_n_0 ;
  wire \TOFILTERI[25]_i_1_n_0 ;
  wire \TOFILTERI[26]_i_1_n_0 ;
  wire \TOFILTERI[27]_i_1_n_0 ;
  wire \TOFILTERI[28]_i_1_n_0 ;
  wire \TOFILTERI[28]_i_2_n_0 ;
  wire \TOFILTERI[28]_i_3_n_0 ;
  wire \TOFILTERI[28]_i_4_n_0 ;
  wire \TOFILTERI[28]_i_5_n_0 ;
  wire \TOFILTERI[28]_i_6_n_0 ;
  wire \TOFILTERI[2]_i_1_n_0 ;
  wire \TOFILTERI[3]_i_1_n_0 ;
  wire \TOFILTERI[4]_i_1_n_0 ;
  wire \TOFILTERI[5]_i_1_n_0 ;
  wire \TOFILTERI[6]_i_1_n_0 ;
  wire \TOFILTERI[7]_i_1_n_0 ;
  wire \TOFILTERI[8]_i_1_n_0 ;
  wire \TOFILTERI[9]_i_1_n_0 ;
  wire \TOFILTERI_reg[28]_0 ;
  wire [63:0]TOFILTERd;
  wire \TOFILTERd[0]_i_1_n_0 ;
  wire \TOFILTERd[10]_i_1_n_0 ;
  wire \TOFILTERd[11]_i_1_n_0 ;
  wire \TOFILTERd[12]_i_1_n_0 ;
  wire \TOFILTERd[13]_i_1_n_0 ;
  wire \TOFILTERd[14]_i_1_n_0 ;
  wire \TOFILTERd[15]_i_1_n_0 ;
  wire \TOFILTERd[16]_i_1_n_0 ;
  wire \TOFILTERd[17]_i_1_n_0 ;
  wire \TOFILTERd[18]_i_1_n_0 ;
  wire \TOFILTERd[19]_i_1_n_0 ;
  wire \TOFILTERd[1]_i_1_n_0 ;
  wire \TOFILTERd[20]_i_1_n_0 ;
  wire \TOFILTERd[21]_i_1_n_0 ;
  wire \TOFILTERd[22]_i_1_n_0 ;
  wire \TOFILTERd[23]_i_1_n_0 ;
  wire \TOFILTERd[24]_i_1_n_0 ;
  wire \TOFILTERd[25]_i_1_n_0 ;
  wire \TOFILTERd[26]_i_1_n_0 ;
  wire \TOFILTERd[27]_i_1_n_0 ;
  wire \TOFILTERd[28]_i_1_n_0 ;
  wire \TOFILTERd[29]_i_1_n_0 ;
  wire \TOFILTERd[2]_i_1_n_0 ;
  wire \TOFILTERd[30]_i_1_n_0 ;
  wire \TOFILTERd[31]_i_1_n_0 ;
  wire \TOFILTERd[32]_i_1_n_0 ;
  wire \TOFILTERd[33]_i_1_n_0 ;
  wire \TOFILTERd[34]_i_1_n_0 ;
  wire \TOFILTERd[35]_i_1_n_0 ;
  wire \TOFILTERd[36]_i_1_n_0 ;
  wire \TOFILTERd[37]_i_1_n_0 ;
  wire \TOFILTERd[38]_i_1_n_0 ;
  wire \TOFILTERd[39]_i_1_n_0 ;
  wire \TOFILTERd[3]_i_1_n_0 ;
  wire \TOFILTERd[40]_i_1_n_0 ;
  wire \TOFILTERd[41]_i_1_n_0 ;
  wire \TOFILTERd[42]_i_1_n_0 ;
  wire \TOFILTERd[43]_i_1_n_0 ;
  wire \TOFILTERd[44]_i_1_n_0 ;
  wire \TOFILTERd[45]_i_1_n_0 ;
  wire \TOFILTERd[46]_i_1_n_0 ;
  wire \TOFILTERd[47]_i_1_n_0 ;
  wire \TOFILTERd[48]_i_1_n_0 ;
  wire \TOFILTERd[49]_i_1_n_0 ;
  wire \TOFILTERd[4]_i_1_n_0 ;
  wire \TOFILTERd[50]_i_1_n_0 ;
  wire \TOFILTERd[51]_i_1_n_0 ;
  wire \TOFILTERd[52]_i_1_n_0 ;
  wire \TOFILTERd[53]_i_1_n_0 ;
  wire \TOFILTERd[54]_i_1_n_0 ;
  wire \TOFILTERd[55]_i_1_n_0 ;
  wire \TOFILTERd[56]_i_1_n_0 ;
  wire \TOFILTERd[57]_i_1_n_0 ;
  wire \TOFILTERd[58]_i_1_n_0 ;
  wire \TOFILTERd[59]_i_1_n_0 ;
  wire \TOFILTERd[5]_i_1_n_0 ;
  wire \TOFILTERd[60]_i_1_n_0 ;
  wire \TOFILTERd[61]_i_1_n_0 ;
  wire \TOFILTERd[62]_i_1_n_0 ;
  wire \TOFILTERd[63]_i_1_n_0 ;
  wire \TOFILTERd[63]_i_2_n_0 ;
  wire \TOFILTERd[6]_i_1_n_0 ;
  wire \TOFILTERd[7]_i_1_n_0 ;
  wire \TOFILTERd[8]_i_1_n_0 ;
  wire \TOFILTERd[9]_i_1_n_0 ;
  wire Tq;
  wire [5:0]bs;
  wire [0:0]\bs_reg[0]_0 ;
  wire \bs_reg[1]_0 ;
  wire done_i_1__0_n_0;
  wire done_i_3_n_0;
  wire done_reg_0;
  wire donefromrxr;
  wire imTX;
  wire req_Error_RX;
  wire req_Error_i_2_n_0;
  wire req_Error_i_4_n_0;
  wire req_Error_i_5_n_0;
  wire req_Error_i_6_n_0;
  wire req_Error_i_8_n_0;
  wire req_Error_reg_0;
  wire rxcrc_n_1;

  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFDFFF)) 
    AckTakeOver_i_1
       (.I0(RXSTATES[2]),
        .I1(Q),
        .I2(AckTakeOver_i_2_n_0),
        .I3(SRST),
        .I4(imTX),
        .I5(req_Error_RX),
        .O(AckTakeOver_i_1_n_0));
  (* SOFT_HLUTNM = "soft_lutpair82" *) 
  LUT2 #(
    .INIT(4'h8)) 
    AckTakeOver_i_2
       (.I0(RXSTATES[0]),
        .I1(RXSTATES[1]),
        .O(AckTakeOver_i_2_n_0));
  FDPE AckTakeOver_reg
       (.C(Tq),
        .CE(E),
        .D(AckTakeOver_i_1_n_0),
        .PRE(CAN_RST_0),
        .Q(AckTakeOver));
  LUT6 #(
    .INIT(64'hFFFFFFFF00010000)) 
    \CNT2[3]_i_1 
       (.I0(RXSTATES[2]),
        .I1(Q),
        .I2(RXSTATES[0]),
        .I3(RXSTATES[1]),
        .I4(\CNT2_reg[3] ),
        .I5(\CNT2_reg[3]_0 ),
        .O(\RXSTATES_reg[2]_0 ));
  LUT6 #(
    .INIT(64'h888888888A8A888A)) 
    \Cnt[0]_i_1__0 
       (.I0(SRST),
        .I1(\Cnt[0]_i_2__0_n_0 ),
        .I2(\Cnt[0]_i_3__0_n_0 ),
        .I3(\Cnt[0]_i_4__0_n_0 ),
        .I4(\Cnt[0]_i_5__0_n_0 ),
        .I5(Q),
        .O(\Cnt[0]_i_1__0_n_0 ));
  LUT6 #(
    .INIT(64'hAAABAAAAAAFAAAAA)) 
    \Cnt[0]_i_2__0 
       (.I0(\Cnt[0]_i_6_n_0 ),
        .I1(\RXSTATES[2]_i_3_n_0 ),
        .I2(RXSTATES[0]),
        .I3(\Cnt_reg_n_0_[0] ),
        .I4(\Cnt[1]_i_6_n_0 ),
        .I5(RXSTATES[1]),
        .O(\Cnt[0]_i_2__0_n_0 ));
  LUT6 #(
    .INIT(64'hFF2E0000FFAA00FF)) 
    \Cnt[0]_i_3__0 
       (.I0(\Cnt_reg_n_0_[0] ),
        .I1(\RXSTATES[2]_i_3_n_0 ),
        .I2(\RXSTATES[0]_i_7_n_0 ),
        .I3(RXSTATES[2]),
        .I4(RXSTATES[1]),
        .I5(RXSTATES[0]),
        .O(\Cnt[0]_i_3__0_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair86" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \Cnt[0]_i_4__0 
       (.I0(RXSTATES[2]),
        .I1(RXSTATES[1]),
        .O(\Cnt[0]_i_4__0_n_0 ));
  LUT6 #(
    .INIT(64'h0F0F0F0F0F0F0F0E)) 
    \Cnt[0]_i_5__0 
       (.I0(\Cnt_reg_n_0_[5] ),
        .I1(\Cnt_reg_n_0_[4] ),
        .I2(\Cnt_reg_n_0_[0] ),
        .I3(\Cnt_reg_n_0_[1] ),
        .I4(\Cnt_reg_n_0_[2] ),
        .I5(\Cnt_reg_n_0_[3] ),
        .O(\Cnt[0]_i_5__0_n_0 ));
  LUT6 #(
    .INIT(64'h8008888888880008)) 
    \Cnt[0]_i_6 
       (.I0(Q),
        .I1(\Cnt[0]_i_4__0_n_0 ),
        .I2(\Cnt[0]_i_2__0_0 [0]),
        .I3(\Cnt[0]_i_2__0_0 [1]),
        .I4(\Cnt[0]_i_2__0_0 [2]),
        .I5(\Cnt[1]_i_5__0_n_0 ),
        .O(\Cnt[0]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'h0000AA08AAAAAAAA)) 
    \Cnt[1]_i_1__0 
       (.I0(SRST),
        .I1(\Cnt[4]_i_3_n_0 ),
        .I2(\Cnt[1]_i_2__0_n_0 ),
        .I3(\Cnt[4]_i_2_n_0 ),
        .I4(\Cnt[1]_i_3__0_n_0 ),
        .I5(\Cnt[1]_i_4_n_0 ),
        .O(\Cnt[1]_i_1__0_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair84" *) 
  LUT4 #(
    .INIT(16'h4FF4)) 
    \Cnt[1]_i_2__0 
       (.I0(RXSTATES[0]),
        .I1(\RXSTATES[2]_i_3_n_0 ),
        .I2(\Cnt_reg_n_0_[0] ),
        .I3(\Cnt_reg_n_0_[1] ),
        .O(\Cnt[1]_i_2__0_n_0 ));
  LUT6 #(
    .INIT(64'hBBBBAFFAAAAAAAAA)) 
    \Cnt[1]_i_3__0 
       (.I0(Q),
        .I1(\Cnt[1]_i_5__0_n_0 ),
        .I2(\Cnt_reg_n_0_[1] ),
        .I3(\Cnt_reg_n_0_[0] ),
        .I4(\RXSTATES[2]_i_3_n_0 ),
        .I5(\Cnt[0]_i_4__0_n_0 ),
        .O(\Cnt[1]_i_3__0_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFDFFDDFFD5555)) 
    \Cnt[1]_i_4 
       (.I0(\Cnt[1]_i_6_n_0 ),
        .I1(\RXSTATES[2]_i_3_n_0 ),
        .I2(\Cnt_reg_n_0_[0] ),
        .I3(\Cnt_reg_n_0_[1] ),
        .I4(RXSTATES[0]),
        .I5(RXSTATES[1]),
        .O(\Cnt[1]_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair72" *) 
  LUT3 #(
    .INIT(8'h8A)) 
    \Cnt[1]_i_5__0 
       (.I0(RXSTATES[2]),
        .I1(RXSTATES[1]),
        .I2(RXSTATES[0]),
        .O(\Cnt[1]_i_5__0_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair83" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \Cnt[1]_i_6 
       (.I0(Q),
        .I1(RXSTATES[2]),
        .O(\Cnt[1]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'h88888888AAAAA8AA)) 
    \Cnt[2]_i_1 
       (.I0(SRST),
        .I1(\Cnt[2]_i_2_n_0 ),
        .I2(\Cnt[2]_i_3_n_0 ),
        .I3(RXSTATES[1]),
        .I4(\Cnt[2]_i_4__0_n_0 ),
        .I5(\Cnt[2]_i_5_n_0 ),
        .O(\Cnt[2]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h121A121A00120002)) 
    \Cnt[2]_i_2 
       (.I0(Q),
        .I1(RXSTATES[1]),
        .I2(RXSTATES[2]),
        .I3(RXSTATES[0]),
        .I4(\RXSTATES[2]_i_3_n_0 ),
        .I5(\Cnt[2]_i_6_n_0 ),
        .O(\Cnt[2]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair85" *) 
  LUT3 #(
    .INIT(8'h04)) 
    \Cnt[2]_i_3 
       (.I0(\RXSTATES[0]_i_8_n_0 ),
        .I1(IDE_reg_0),
        .I2(RXSTATES[0]),
        .O(\Cnt[2]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair84" *) 
  LUT3 #(
    .INIT(8'hA9)) 
    \Cnt[2]_i_4__0 
       (.I0(\Cnt_reg_n_0_[2] ),
        .I1(\Cnt_reg_n_0_[0] ),
        .I2(\Cnt_reg_n_0_[1] ),
        .O(\Cnt[2]_i_4__0_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair74" *) 
  LUT4 #(
    .INIT(16'hFFF1)) 
    \Cnt[2]_i_5 
       (.I0(RXSTATES[1]),
        .I1(RXSTATES[0]),
        .I2(Q),
        .I3(RXSTATES[2]),
        .O(\Cnt[2]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hFFF0000FFFF0000E)) 
    \Cnt[2]_i_6 
       (.I0(\Cnt_reg_n_0_[5] ),
        .I1(\Cnt_reg_n_0_[4] ),
        .I2(\Cnt_reg_n_0_[0] ),
        .I3(\Cnt_reg_n_0_[1] ),
        .I4(\Cnt_reg_n_0_[2] ),
        .I5(\Cnt_reg_n_0_[3] ),
        .O(\Cnt[2]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'h000088A800AA88AA)) 
    \Cnt[3]_i_1 
       (.I0(SRST),
        .I1(\Cnt[3]_i_2_n_0 ),
        .I2(\Cnt[4]_i_3_n_0 ),
        .I3(\Cnt[3]_i_3__0_n_0 ),
        .I4(\Cnt[3]_i_4__0_n_0 ),
        .I5(\Cnt[3]_i_5__1_n_0 ),
        .O(\Cnt[3]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h7232323272327232)) 
    \Cnt[3]_i_2 
       (.I0(RXSTATES[2]),
        .I1(RXSTATES[1]),
        .I2(RXSTATES[0]),
        .I3(\RXSTATES[2]_i_3_n_0 ),
        .I4(IDE_reg_0),
        .I5(\RXSTATES[0]_i_7_n_0 ),
        .O(\Cnt[3]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h0000000FFFFFFFF1)) 
    \Cnt[3]_i_3__0 
       (.I0(\Cnt_reg_n_0_[5] ),
        .I1(\Cnt_reg_n_0_[4] ),
        .I2(\Cnt_reg_n_0_[0] ),
        .I3(\Cnt_reg_n_0_[1] ),
        .I4(\Cnt_reg_n_0_[2] ),
        .I5(\Cnt_reg_n_0_[3] ),
        .O(\Cnt[3]_i_3__0_n_0 ));
  LUT6 #(
    .INIT(64'hAEAAAEAEAAAAAAAA)) 
    \Cnt[3]_i_4__0 
       (.I0(Q),
        .I1(RXSTATES[2]),
        .I2(RXSTATES[1]),
        .I3(RXSTATES[0]),
        .I4(\RXSTATES[2]_i_3_n_0 ),
        .I5(\Cnt[3]_i_3__0_n_0 ),
        .O(\Cnt[3]_i_4__0_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair77" *) 
  LUT4 #(
    .INIT(16'hFF9F)) 
    \Cnt[3]_i_5__1 
       (.I0(RXSTATES[0]),
        .I1(RXSTATES[1]),
        .I2(Q),
        .I3(RXSTATES[2]),
        .O(\Cnt[3]_i_5__1_n_0 ));
  LUT6 #(
    .INIT(64'h000088A8AAAAAAAA)) 
    \Cnt[4]_i_1 
       (.I0(SRST),
        .I1(\Cnt[4]_i_2_n_0 ),
        .I2(\Cnt[4]_i_3_n_0 ),
        .I3(\Cnt[4]_i_4_n_0 ),
        .I4(\Cnt[4]_i_5__0_n_0 ),
        .I5(\Cnt[4]_i_6_n_0 ),
        .O(\Cnt[4]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair78" *) 
  LUT3 #(
    .INIT(8'h32)) 
    \Cnt[4]_i_2 
       (.I0(RXSTATES[0]),
        .I1(RXSTATES[1]),
        .I2(RXSTATES[2]),
        .O(\Cnt[4]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair72" *) 
  LUT5 #(
    .INIT(32'h44444044)) 
    \Cnt[4]_i_3 
       (.I0(RXSTATES[2]),
        .I1(RXSTATES[1]),
        .I2(RXSTATES[0]),
        .I3(IDE_reg_0),
        .I4(\RXSTATES[0]_i_8_n_0 ),
        .O(\Cnt[4]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAAAA2AAA2AAAAAAA)) 
    \Cnt[4]_i_4 
       (.I0(\Cnt[4]_i_7__0_n_0 ),
        .I1(\RXSTATES[0]_i_7_n_0 ),
        .I2(RXSTATES[0]),
        .I3(\RXSTATES[2]_i_3_n_0 ),
        .I4(\D_Len_reg[3]_0 [0]),
        .I5(IDE_reg_0),
        .O(\Cnt[4]_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair83" *) 
  LUT4 #(
    .INIT(16'hAAEA)) 
    \Cnt[4]_i_5__0 
       (.I0(Q),
        .I1(\Cnt[4]_i_7__0_n_0 ),
        .I2(RXSTATES[2]),
        .I3(RXSTATES[1]),
        .O(\Cnt[4]_i_5__0_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair74" *) 
  LUT5 #(
    .INIT(32'hFFFFFBBF)) 
    \Cnt[4]_i_6 
       (.I0(RXSTATES[2]),
        .I1(Q),
        .I2(RXSTATES[1]),
        .I3(RXSTATES[0]),
        .I4(\Cnt[4]_i_7__0_n_0 ),
        .O(\Cnt[4]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'h00000003FFFFFFFD)) 
    \Cnt[4]_i_7__0 
       (.I0(\Cnt_reg_n_0_[5] ),
        .I1(\Cnt_reg_n_0_[3] ),
        .I2(\Cnt_reg_n_0_[2] ),
        .I3(\Cnt_reg_n_0_[1] ),
        .I4(\Cnt_reg_n_0_[0] ),
        .I5(\Cnt_reg_n_0_[4] ),
        .O(\Cnt[4]_i_7__0_n_0 ));
  LUT6 #(
    .INIT(64'h20202022AAAAAAAA)) 
    \Cnt[5]_i_2 
       (.I0(SRST),
        .I1(Q),
        .I2(\Cnt[5]_i_3__0_n_0 ),
        .I3(\Cnt[5]_i_4_n_0 ),
        .I4(\Cnt[5]_i_5__0_n_0 ),
        .I5(\Cnt[5]_i_6__0_n_0 ),
        .O(\Cnt[5]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair86" *) 
  LUT3 #(
    .INIT(8'h40)) 
    \Cnt[5]_i_3__0 
       (.I0(RXSTATES[1]),
        .I1(RXSTATES[2]),
        .I2(\Cnt[5]_i_7__0_n_0 ),
        .O(\Cnt[5]_i_3__0_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair85" *) 
  LUT2 #(
    .INIT(4'h1)) 
    \Cnt[5]_i_4 
       (.I0(RXSTATES[0]),
        .I1(\Cnt[5]_i_7__0_n_0 ),
        .O(\Cnt[5]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h04515555FFFFFFFF)) 
    \Cnt[5]_i_5__0 
       (.I0(\Cnt[5]_i_7__0_n_0 ),
        .I1(IDE_reg_0),
        .I2(\D_Len_reg[3]_0 [0]),
        .I3(\D_Len_reg[3]_0 [1]),
        .I4(\Cnt[5]_i_8__0_n_0 ),
        .I5(\Cnt[5]_i_9__0_n_0 ),
        .O(\Cnt[5]_i_5__0_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair73" *) 
  LUT5 #(
    .INIT(32'hFBBFFFFF)) 
    \Cnt[5]_i_6__0 
       (.I0(RXSTATES[2]),
        .I1(Q),
        .I2(RXSTATES[1]),
        .I3(RXSTATES[0]),
        .I4(\Cnt[5]_i_7__0_n_0 ),
        .O(\Cnt[5]_i_6__0_n_0 ));
  LUT6 #(
    .INIT(64'hAAAAAAAAAAAAAAA8)) 
    \Cnt[5]_i_7__0 
       (.I0(\Cnt_reg_n_0_[5] ),
        .I1(\Cnt_reg_n_0_[3] ),
        .I2(\Cnt_reg_n_0_[2] ),
        .I3(\Cnt_reg_n_0_[1] ),
        .I4(\Cnt_reg_n_0_[0] ),
        .I5(\Cnt_reg_n_0_[4] ),
        .O(\Cnt[5]_i_7__0_n_0 ));
  LUT6 #(
    .INIT(64'h00000000AAAAAAA8)) 
    \Cnt[5]_i_8__0 
       (.I0(\RXSTATES[2]_i_3_n_0 ),
        .I1(\D_Len_reg[3]_0 [3]),
        .I2(\D_Len_reg[3]_0 [1]),
        .I3(\D_Len_reg[3]_0 [2]),
        .I4(\D_Len_reg[3]_0 [0]),
        .I5(RTR_reg_0),
        .O(\Cnt[5]_i_8__0_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair87" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \Cnt[5]_i_9__0 
       (.I0(RXSTATES[1]),
        .I1(RXSTATES[2]),
        .O(\Cnt[5]_i_9__0_n_0 ));
  FDCE \Cnt_reg[0] 
       (.C(Tq),
        .CE(\Cnt_reg[0]_0 ),
        .CLR(CAN_RST_0),
        .D(\Cnt[0]_i_1__0_n_0 ),
        .Q(\Cnt_reg_n_0_[0] ));
  FDCE \Cnt_reg[1] 
       (.C(Tq),
        .CE(\Cnt_reg[0]_0 ),
        .CLR(CAN_RST_0),
        .D(\Cnt[1]_i_1__0_n_0 ),
        .Q(\Cnt_reg_n_0_[1] ));
  FDCE \Cnt_reg[2] 
       (.C(Tq),
        .CE(\Cnt_reg[0]_0 ),
        .CLR(CAN_RST_0),
        .D(\Cnt[2]_i_1_n_0 ),
        .Q(\Cnt_reg_n_0_[2] ));
  FDCE \Cnt_reg[3] 
       (.C(Tq),
        .CE(\Cnt_reg[0]_0 ),
        .CLR(CAN_RST_0),
        .D(\Cnt[3]_i_1_n_0 ),
        .Q(\Cnt_reg_n_0_[3] ));
  FDCE \Cnt_reg[4] 
       (.C(Tq),
        .CE(\Cnt_reg[0]_0 ),
        .CLR(CAN_RST_0),
        .D(\Cnt[4]_i_1_n_0 ),
        .Q(\Cnt_reg_n_0_[4] ));
  FDCE \Cnt_reg[5] 
       (.C(Tq),
        .CE(\Cnt_reg[0]_0 ),
        .CLR(CAN_RST_0),
        .D(\Cnt[5]_i_2_n_0 ),
        .Q(\Cnt_reg_n_0_[5] ));
  LUT6 #(
    .INIT(64'h0000000000400000)) 
    \D_Len[0]_i_1 
       (.I0(IDE_reg_0),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(Q),
        .I4(SRST),
        .I5(RXSTATES[2]),
        .O(\D_Len[0]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000800000)) 
    \D_Len[1]_i_1 
       (.I0(\D_Len_reg[3]_0 [0]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(Q),
        .I4(SRST),
        .I5(RXSTATES[2]),
        .O(\D_Len[1]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000800000)) 
    \D_Len[2]_i_1 
       (.I0(\D_Len_reg[3]_0 [1]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(Q),
        .I4(SRST),
        .I5(RXSTATES[2]),
        .O(\D_Len[2]_i_1_n_0 ));
  LUT3 #(
    .INIT(8'h4F)) 
    \D_Len[3]_i_1 
       (.I0(\D_Len[3]_i_3_n_0 ),
        .I1(\CRC_RG_reg[14] ),
        .I2(SRST),
        .O(\D_Len[3]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000800000)) 
    \D_Len[3]_i_2 
       (.I0(\D_Len_reg[3]_0 [2]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(Q),
        .I4(SRST),
        .I5(RXSTATES[2]),
        .O(\D_Len[3]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFF4FFF0FFFFFFF0)) 
    \D_Len[3]_i_3 
       (.I0(\Cnt_reg_n_0_[1] ),
        .I1(\Cnt_reg_n_0_[2] ),
        .I2(RXSTATES[2]),
        .I3(Q),
        .I4(RXSTATES[1]),
        .I5(RXSTATES[0]),
        .O(\D_Len[3]_i_3_n_0 ));
  FDCE \D_Len_reg[0] 
       (.C(Tq),
        .CE(\D_Len[3]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\D_Len[0]_i_1_n_0 ),
        .Q(\D_Len_reg[3]_0 [0]));
  FDCE \D_Len_reg[1] 
       (.C(Tq),
        .CE(\D_Len[3]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\D_Len[1]_i_1_n_0 ),
        .Q(\D_Len_reg[3]_0 [1]));
  FDCE \D_Len_reg[2] 
       (.C(Tq),
        .CE(\D_Len[3]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\D_Len[2]_i_1_n_0 ),
        .Q(\D_Len_reg[3]_0 [2]));
  FDCE \D_Len_reg[3] 
       (.C(Tq),
        .CE(\D_Len[3]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\D_Len[3]_i_2_n_0 ),
        .Q(\D_Len_reg[3]_0 [3]));
  LUT5 #(
    .INIT(32'h1F111011)) 
    IDE_i_1
       (.I0(IDE_reg_0),
        .I1(IDE_i_3_n_0),
        .I2(IDE_i_4_n_0),
        .I3(SRST),
        .I4(IDE_rec),
        .O(IDE_i_1_n_0));
  (* SOFT_HLUTNM = "soft_lutpair75" *) 
  LUT5 #(
    .INIT(32'hFFFFFFDF)) 
    IDE_i_3
       (.I0(SRST),
        .I1(RXSTATES[2]),
        .I2(RXSTATES[1]),
        .I3(RXSTATES[0]),
        .I4(Q),
        .O(IDE_i_3_n_0));
  LUT6 #(
    .INIT(64'h0000044400000044)) 
    IDE_i_4
       (.I0(Q),
        .I1(\CRC_RG_reg[14] ),
        .I2(RXSTATES[0]),
        .I3(RXSTATES[1]),
        .I4(RXSTATES[2]),
        .I5(\TOFILTERI[28]_i_4_n_0 ),
        .O(IDE_i_4_n_0));
  FDCE IDE_reg
       (.C(Tq),
        .CE(1'b1),
        .CLR(CAN_RST_0),
        .D(IDE_i_1_n_0),
        .Q(IDE_rec));
  LUT2 #(
    .INIT(4'h2)) 
    \REC[0]_i_2 
       (.I0(req_Error_RX),
        .I1(\REC_reg[0] ),
        .O(req_Error_reg_0));
  LUT5 #(
    .INIT(32'hFFF400B0)) 
    RTR_i_1
       (.I0(\CRC_RG_reg[14] ),
        .I1(SRST),
        .I2(I59),
        .I3(RTR_i_4_n_0),
        .I4(RTR_reg_0),
        .O(RTR_i_1_n_0));
  LUT6 #(
    .INIT(64'h555755575557555F)) 
    RTR_i_3
       (.I0(SRST),
        .I1(RXSTATES[1]),
        .I2(RXSTATES[2]),
        .I3(Q),
        .I4(RXSTATES[0]),
        .I5(IDE_reg_0),
        .O(I59));
  LUT6 #(
    .INIT(64'hAAAAAAA8AAA0AAA0)) 
    RTR_i_4
       (.I0(SRST),
        .I1(\TOFILTERI[28]_i_6_n_0 ),
        .I2(Q),
        .I3(RXSTATES[2]),
        .I4(RXSTATES[0]),
        .I5(RXSTATES[1]),
        .O(RTR_i_4_n_0));
  FDPE RTR_reg
       (.C(Tq),
        .CE(1'b1),
        .D(RTR_i_1_n_0),
        .PRE(CAN_RST_0),
        .Q(RTR_reg_0));
  LUT6 #(
    .INIT(64'hAAAAAAAA80888080)) 
    \RXSTATES[0]_i_1 
       (.I0(SRST),
        .I1(\RXSTATES_reg[0]_2 ),
        .I2(\RXSTATES[0]_i_3_n_0 ),
        .I3(\RXSTATES[0]_i_4_n_0 ),
        .I4(\RXSTATES[2]_i_4_n_0 ),
        .I5(\RXSTATES_reg[0]_3 ),
        .O(\RXSTATES[0]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF00810000)) 
    \RXSTATES[0]_i_3 
       (.I0(RXSTATES[0]),
        .I1(RXSTATES[1]),
        .I2(Q),
        .I3(RXSTATES[2]),
        .I4(IDE_reg_0),
        .I5(\RXSTATES[0]_i_6_n_0 ),
        .O(\RXSTATES[0]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h8888FFFF3033FFFF)) 
    \RXSTATES[0]_i_4 
       (.I0(\RXSTATES[0]_i_7_n_0 ),
        .I1(\RXSTATES[2]_i_3_n_0 ),
        .I2(\RXSTATES[0]_i_8_n_0 ),
        .I3(IDE_reg_0),
        .I4(RXSTATES[1]),
        .I5(RXSTATES[0]),
        .O(\RXSTATES[0]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h301E1B00001E1B00)) 
    \RXSTATES[0]_i_6 
       (.I0(\RXSTATES[2]_i_3_n_0 ),
        .I1(RXSTATES[1]),
        .I2(RXSTATES[0]),
        .I3(Q),
        .I4(RXSTATES[2]),
        .I5(\RXSTATES_reg[1]_1 ),
        .O(\RXSTATES[0]_i_6_n_0 ));
  LUT5 #(
    .INIT(32'h55555554)) 
    \RXSTATES[0]_i_7 
       (.I0(RTR_reg_0),
        .I1(\D_Len_reg[3]_0 [0]),
        .I2(\D_Len_reg[3]_0 [2]),
        .I3(\D_Len_reg[3]_0 [1]),
        .I4(\D_Len_reg[3]_0 [3]),
        .O(\RXSTATES[0]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFEFFFFF)) 
    \RXSTATES[0]_i_8 
       (.I0(\Cnt_reg_n_0_[1] ),
        .I1(\Cnt_reg_n_0_[0] ),
        .I2(\Cnt_reg_n_0_[2] ),
        .I3(\Cnt_reg_n_0_[5] ),
        .I4(\Cnt_reg_n_0_[4] ),
        .I5(\Cnt_reg_n_0_[3] ),
        .O(\RXSTATES[0]_i_8_n_0 ));
  LUT6 #(
    .INIT(64'hF8C3C3C3F8CFCF03)) 
    \RXSTATES[1]_i_2 
       (.I0(\RXSTATES_reg[1]_1 ),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(RXSTATES[2]),
        .I4(Q),
        .I5(\RXSTATES[2]_i_3_n_0 ),
        .O(\RXSTATES_reg[0]_0 ));
  LUT6 #(
    .INIT(64'hA888888888888888)) 
    \RXSTATES[2]_i_1 
       (.I0(SRST),
        .I1(\RXSTATES[2]_i_2_n_0 ),
        .I2(\RXSTATES[2]_i_3_n_0 ),
        .I3(RXSTATES[0]),
        .I4(RXSTATES[1]),
        .I5(\RXSTATES[2]_i_4_n_0 ),
        .O(\RXSTATES[2]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h55F5757555757575)) 
    \RXSTATES[2]_i_2 
       (.I0(\RXSTATES_reg[3]_0 ),
        .I1(Q),
        .I2(RXSTATES[2]),
        .I3(RXSTATES[1]),
        .I4(RXSTATES[0]),
        .I5(\RXSTATES_reg[1]_1 ),
        .O(\RXSTATES[2]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000000001)) 
    \RXSTATES[2]_i_3 
       (.I0(\Cnt_reg_n_0_[3] ),
        .I1(\Cnt_reg_n_0_[2] ),
        .I2(\Cnt_reg_n_0_[1] ),
        .I3(\Cnt_reg_n_0_[0] ),
        .I4(\Cnt_reg_n_0_[4] ),
        .I5(\Cnt_reg_n_0_[5] ),
        .O(\RXSTATES[2]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair87" *) 
  LUT2 #(
    .INIT(4'h1)) 
    \RXSTATES[2]_i_4 
       (.I0(RXSTATES[2]),
        .I1(Q),
        .O(\RXSTATES[2]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h0A802A00AAAAAAAA)) 
    \RXSTATES[3]_i_2 
       (.I0(SRST),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(Q),
        .I4(RXSTATES[2]),
        .I5(\RXSTATES_reg[3]_0 ),
        .O(\RXSTATES[3]_i_2_n_0 ));
  FDCE \RXSTATES_reg[0] 
       (.C(Tq),
        .CE(\RXSTATES_reg[3]_1 ),
        .CLR(CAN_RST_0),
        .D(\RXSTATES[0]_i_1_n_0 ),
        .Q(RXSTATES[0]));
  FDCE \RXSTATES_reg[1] 
       (.C(Tq),
        .CE(\RXSTATES_reg[3]_1 ),
        .CLR(CAN_RST_0),
        .D(D),
        .Q(RXSTATES[1]));
  FDCE \RXSTATES_reg[2] 
       (.C(Tq),
        .CE(\RXSTATES_reg[3]_1 ),
        .CLR(CAN_RST_0),
        .D(\RXSTATES[2]_i_1_n_0 ),
        .Q(RXSTATES[2]));
  FDCE \RXSTATES_reg[3] 
       (.C(Tq),
        .CE(\RXSTATES_reg[3]_1 ),
        .CLR(CAN_RST_0),
        .D(\RXSTATES[3]_i_2_n_0 ),
        .Q(Q));
  (* SOFT_HLUTNM = "soft_lutpair82" *) 
  LUT5 #(
    .INIT(32'h00000400)) 
    \State[0]_i_5 
       (.I0(Sampled_din),
        .I1(RXSTATES[1]),
        .I2(RXSTATES[0]),
        .I3(Q),
        .I4(RXSTATES[2]),
        .O(RXOUT_reg));
  LUT6 #(
    .INIT(64'h0000010000000000)) 
    \TOFILTERI[0]_i_1 
       (.I0(IDE_reg_0),
        .I1(Q),
        .I2(RXSTATES[0]),
        .I3(RXSTATES[1]),
        .I4(RXSTATES[2]),
        .I5(SRST),
        .O(IDE1_out));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERI[10]_i_1 
       (.I0(TOFILTERI[9]),
        .I1(Q),
        .I2(RXSTATES[0]),
        .I3(RXSTATES[1]),
        .I4(RXSTATES[2]),
        .I5(SRST),
        .O(\TOFILTERI[10]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERI[11]_i_1 
       (.I0(TOFILTERI[10]),
        .I1(Q),
        .I2(RXSTATES[0]),
        .I3(RXSTATES[1]),
        .I4(RXSTATES[2]),
        .I5(SRST),
        .O(\TOFILTERI[11]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERI[12]_i_1 
       (.I0(TOFILTERI[11]),
        .I1(Q),
        .I2(RXSTATES[0]),
        .I3(RXSTATES[1]),
        .I4(RXSTATES[2]),
        .I5(SRST),
        .O(\TOFILTERI[12]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERI[13]_i_1 
       (.I0(TOFILTERI[12]),
        .I1(Q),
        .I2(RXSTATES[0]),
        .I3(RXSTATES[1]),
        .I4(RXSTATES[2]),
        .I5(SRST),
        .O(\TOFILTERI[13]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERI[14]_i_1 
       (.I0(TOFILTERI[13]),
        .I1(Q),
        .I2(RXSTATES[0]),
        .I3(RXSTATES[1]),
        .I4(RXSTATES[2]),
        .I5(SRST),
        .O(\TOFILTERI[14]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERI[15]_i_1 
       (.I0(TOFILTERI[14]),
        .I1(Q),
        .I2(RXSTATES[0]),
        .I3(RXSTATES[1]),
        .I4(RXSTATES[2]),
        .I5(SRST),
        .O(\TOFILTERI[15]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERI[16]_i_1 
       (.I0(TOFILTERI[15]),
        .I1(Q),
        .I2(RXSTATES[0]),
        .I3(RXSTATES[1]),
        .I4(RXSTATES[2]),
        .I5(SRST),
        .O(\TOFILTERI[16]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERI[17]_i_1 
       (.I0(TOFILTERI[16]),
        .I1(Q),
        .I2(RXSTATES[0]),
        .I3(RXSTATES[1]),
        .I4(RXSTATES[2]),
        .I5(SRST),
        .O(\TOFILTERI[17]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERI[18]_i_1 
       (.I0(TOFILTERI[17]),
        .I1(Q),
        .I2(RXSTATES[0]),
        .I3(RXSTATES[1]),
        .I4(RXSTATES[2]),
        .I5(SRST),
        .O(\TOFILTERI[18]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERI[19]_i_1 
       (.I0(TOFILTERI[18]),
        .I1(Q),
        .I2(RXSTATES[0]),
        .I3(RXSTATES[1]),
        .I4(RXSTATES[2]),
        .I5(SRST),
        .O(\TOFILTERI[19]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERI[1]_i_1 
       (.I0(TOFILTERI[0]),
        .I1(Q),
        .I2(RXSTATES[0]),
        .I3(RXSTATES[1]),
        .I4(RXSTATES[2]),
        .I5(SRST),
        .O(\TOFILTERI[1]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERI[20]_i_1 
       (.I0(TOFILTERI[19]),
        .I1(Q),
        .I2(RXSTATES[0]),
        .I3(RXSTATES[1]),
        .I4(RXSTATES[2]),
        .I5(SRST),
        .O(\TOFILTERI[20]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERI[21]_i_1 
       (.I0(TOFILTERI[20]),
        .I1(Q),
        .I2(RXSTATES[0]),
        .I3(RXSTATES[1]),
        .I4(RXSTATES[2]),
        .I5(SRST),
        .O(\TOFILTERI[21]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERI[22]_i_1 
       (.I0(TOFILTERI[21]),
        .I1(Q),
        .I2(RXSTATES[0]),
        .I3(RXSTATES[1]),
        .I4(RXSTATES[2]),
        .I5(SRST),
        .O(\TOFILTERI[22]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERI[23]_i_1 
       (.I0(TOFILTERI[22]),
        .I1(Q),
        .I2(RXSTATES[0]),
        .I3(RXSTATES[1]),
        .I4(RXSTATES[2]),
        .I5(SRST),
        .O(\TOFILTERI[23]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERI[24]_i_1 
       (.I0(TOFILTERI[23]),
        .I1(Q),
        .I2(RXSTATES[0]),
        .I3(RXSTATES[1]),
        .I4(RXSTATES[2]),
        .I5(SRST),
        .O(\TOFILTERI[24]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERI[25]_i_1 
       (.I0(TOFILTERI[24]),
        .I1(Q),
        .I2(RXSTATES[0]),
        .I3(RXSTATES[1]),
        .I4(RXSTATES[2]),
        .I5(SRST),
        .O(\TOFILTERI[25]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERI[26]_i_1 
       (.I0(TOFILTERI[25]),
        .I1(Q),
        .I2(RXSTATES[0]),
        .I3(RXSTATES[1]),
        .I4(RXSTATES[2]),
        .I5(SRST),
        .O(\TOFILTERI[26]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERI[27]_i_1 
       (.I0(TOFILTERI[26]),
        .I1(Q),
        .I2(RXSTATES[0]),
        .I3(RXSTATES[1]),
        .I4(RXSTATES[2]),
        .I5(SRST),
        .O(\TOFILTERI[27]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hBAAA0000FFFFFFFF)) 
    \TOFILTERI[28]_i_1 
       (.I0(\TOFILTERI[28]_i_3_n_0 ),
        .I1(\TOFILTERI[28]_i_4_n_0 ),
        .I2(\TOFILTERI[28]_i_5_n_0 ),
        .I3(\TOFILTERI[28]_i_6_n_0 ),
        .I4(\TOFILTERI_reg[28]_0 ),
        .I5(SRST),
        .O(\TOFILTERI[28]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERI[28]_i_2 
       (.I0(TOFILTERI[27]),
        .I1(Q),
        .I2(RXSTATES[0]),
        .I3(RXSTATES[1]),
        .I4(RXSTATES[2]),
        .I5(SRST),
        .O(\TOFILTERI[28]_i_2_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \TOFILTERI[28]_i_3 
       (.I0(RXSTATES[2]),
        .I1(RXSTATES[1]),
        .O(\TOFILTERI[28]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h0000000004000000)) 
    \TOFILTERI[28]_i_4 
       (.I0(\Cnt_reg_n_0_[5] ),
        .I1(\Cnt_reg_n_0_[4] ),
        .I2(\Cnt_reg_n_0_[3] ),
        .I3(\Cnt_reg_n_0_[1] ),
        .I4(\Cnt_reg_n_0_[0] ),
        .I5(\Cnt_reg_n_0_[2] ),
        .O(\TOFILTERI[28]_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair79" *) 
  LUT3 #(
    .INIT(8'h04)) 
    \TOFILTERI[28]_i_5 
       (.I0(RXSTATES[2]),
        .I1(RXSTATES[1]),
        .I2(RXSTATES[0]),
        .O(\TOFILTERI[28]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFBFFFE)) 
    \TOFILTERI[28]_i_6 
       (.I0(\Cnt_reg_n_0_[5] ),
        .I1(\Cnt_reg_n_0_[4] ),
        .I2(\Cnt_reg_n_0_[0] ),
        .I3(\Cnt_reg_n_0_[1] ),
        .I4(\Cnt_reg_n_0_[2] ),
        .I5(\Cnt_reg_n_0_[3] ),
        .O(\TOFILTERI[28]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERI[2]_i_1 
       (.I0(TOFILTERI[1]),
        .I1(Q),
        .I2(RXSTATES[0]),
        .I3(RXSTATES[1]),
        .I4(RXSTATES[2]),
        .I5(SRST),
        .O(\TOFILTERI[2]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERI[3]_i_1 
       (.I0(TOFILTERI[2]),
        .I1(Q),
        .I2(RXSTATES[0]),
        .I3(RXSTATES[1]),
        .I4(RXSTATES[2]),
        .I5(SRST),
        .O(\TOFILTERI[3]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERI[4]_i_1 
       (.I0(TOFILTERI[3]),
        .I1(Q),
        .I2(RXSTATES[0]),
        .I3(RXSTATES[1]),
        .I4(RXSTATES[2]),
        .I5(SRST),
        .O(\TOFILTERI[4]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERI[5]_i_1 
       (.I0(TOFILTERI[4]),
        .I1(Q),
        .I2(RXSTATES[0]),
        .I3(RXSTATES[1]),
        .I4(RXSTATES[2]),
        .I5(SRST),
        .O(\TOFILTERI[5]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERI[6]_i_1 
       (.I0(TOFILTERI[5]),
        .I1(Q),
        .I2(RXSTATES[0]),
        .I3(RXSTATES[1]),
        .I4(RXSTATES[2]),
        .I5(SRST),
        .O(\TOFILTERI[6]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERI[7]_i_1 
       (.I0(TOFILTERI[6]),
        .I1(Q),
        .I2(RXSTATES[0]),
        .I3(RXSTATES[1]),
        .I4(RXSTATES[2]),
        .I5(SRST),
        .O(\TOFILTERI[7]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERI[8]_i_1 
       (.I0(TOFILTERI[7]),
        .I1(Q),
        .I2(RXSTATES[0]),
        .I3(RXSTATES[1]),
        .I4(RXSTATES[2]),
        .I5(SRST),
        .O(\TOFILTERI[8]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERI[9]_i_1 
       (.I0(TOFILTERI[8]),
        .I1(Q),
        .I2(RXSTATES[0]),
        .I3(RXSTATES[1]),
        .I4(RXSTATES[2]),
        .I5(SRST),
        .O(\TOFILTERI[9]_i_1_n_0 ));
  FDCE \TOFILTERI_reg[0] 
       (.C(Tq),
        .CE(\TOFILTERI[28]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(IDE1_out),
        .Q(TOFILTERI[0]));
  FDCE \TOFILTERI_reg[10] 
       (.C(Tq),
        .CE(\TOFILTERI[28]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERI[10]_i_1_n_0 ),
        .Q(TOFILTERI[10]));
  FDCE \TOFILTERI_reg[11] 
       (.C(Tq),
        .CE(\TOFILTERI[28]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERI[11]_i_1_n_0 ),
        .Q(TOFILTERI[11]));
  FDCE \TOFILTERI_reg[12] 
       (.C(Tq),
        .CE(\TOFILTERI[28]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERI[12]_i_1_n_0 ),
        .Q(TOFILTERI[12]));
  FDCE \TOFILTERI_reg[13] 
       (.C(Tq),
        .CE(\TOFILTERI[28]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERI[13]_i_1_n_0 ),
        .Q(TOFILTERI[13]));
  FDCE \TOFILTERI_reg[14] 
       (.C(Tq),
        .CE(\TOFILTERI[28]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERI[14]_i_1_n_0 ),
        .Q(TOFILTERI[14]));
  FDCE \TOFILTERI_reg[15] 
       (.C(Tq),
        .CE(\TOFILTERI[28]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERI[15]_i_1_n_0 ),
        .Q(TOFILTERI[15]));
  FDCE \TOFILTERI_reg[16] 
       (.C(Tq),
        .CE(\TOFILTERI[28]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERI[16]_i_1_n_0 ),
        .Q(TOFILTERI[16]));
  FDCE \TOFILTERI_reg[17] 
       (.C(Tq),
        .CE(\TOFILTERI[28]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERI[17]_i_1_n_0 ),
        .Q(TOFILTERI[17]));
  FDCE \TOFILTERI_reg[18] 
       (.C(Tq),
        .CE(\TOFILTERI[28]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERI[18]_i_1_n_0 ),
        .Q(TOFILTERI[18]));
  FDCE \TOFILTERI_reg[19] 
       (.C(Tq),
        .CE(\TOFILTERI[28]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERI[19]_i_1_n_0 ),
        .Q(TOFILTERI[19]));
  FDCE \TOFILTERI_reg[1] 
       (.C(Tq),
        .CE(\TOFILTERI[28]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERI[1]_i_1_n_0 ),
        .Q(TOFILTERI[1]));
  FDCE \TOFILTERI_reg[20] 
       (.C(Tq),
        .CE(\TOFILTERI[28]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERI[20]_i_1_n_0 ),
        .Q(TOFILTERI[20]));
  FDCE \TOFILTERI_reg[21] 
       (.C(Tq),
        .CE(\TOFILTERI[28]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERI[21]_i_1_n_0 ),
        .Q(TOFILTERI[21]));
  FDCE \TOFILTERI_reg[22] 
       (.C(Tq),
        .CE(\TOFILTERI[28]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERI[22]_i_1_n_0 ),
        .Q(TOFILTERI[22]));
  FDCE \TOFILTERI_reg[23] 
       (.C(Tq),
        .CE(\TOFILTERI[28]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERI[23]_i_1_n_0 ),
        .Q(TOFILTERI[23]));
  FDCE \TOFILTERI_reg[24] 
       (.C(Tq),
        .CE(\TOFILTERI[28]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERI[24]_i_1_n_0 ),
        .Q(TOFILTERI[24]));
  FDCE \TOFILTERI_reg[25] 
       (.C(Tq),
        .CE(\TOFILTERI[28]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERI[25]_i_1_n_0 ),
        .Q(TOFILTERI[25]));
  FDCE \TOFILTERI_reg[26] 
       (.C(Tq),
        .CE(\TOFILTERI[28]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERI[26]_i_1_n_0 ),
        .Q(TOFILTERI[26]));
  FDCE \TOFILTERI_reg[27] 
       (.C(Tq),
        .CE(\TOFILTERI[28]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERI[27]_i_1_n_0 ),
        .Q(TOFILTERI[27]));
  FDCE \TOFILTERI_reg[28] 
       (.C(Tq),
        .CE(\TOFILTERI[28]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERI[28]_i_2_n_0 ),
        .Q(TOFILTERI[28]));
  FDCE \TOFILTERI_reg[2] 
       (.C(Tq),
        .CE(\TOFILTERI[28]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERI[2]_i_1_n_0 ),
        .Q(TOFILTERI[2]));
  FDCE \TOFILTERI_reg[3] 
       (.C(Tq),
        .CE(\TOFILTERI[28]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERI[3]_i_1_n_0 ),
        .Q(TOFILTERI[3]));
  FDCE \TOFILTERI_reg[4] 
       (.C(Tq),
        .CE(\TOFILTERI[28]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERI[4]_i_1_n_0 ),
        .Q(TOFILTERI[4]));
  FDCE \TOFILTERI_reg[5] 
       (.C(Tq),
        .CE(\TOFILTERI[28]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERI[5]_i_1_n_0 ),
        .Q(TOFILTERI[5]));
  FDCE \TOFILTERI_reg[6] 
       (.C(Tq),
        .CE(\TOFILTERI[28]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERI[6]_i_1_n_0 ),
        .Q(TOFILTERI[6]));
  FDCE \TOFILTERI_reg[7] 
       (.C(Tq),
        .CE(\TOFILTERI[28]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERI[7]_i_1_n_0 ),
        .Q(TOFILTERI[7]));
  FDCE \TOFILTERI_reg[8] 
       (.C(Tq),
        .CE(\TOFILTERI[28]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERI[8]_i_1_n_0 ),
        .Q(TOFILTERI[8]));
  FDCE \TOFILTERI_reg[9] 
       (.C(Tq),
        .CE(\TOFILTERI[28]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERI[9]_i_1_n_0 ),
        .Q(TOFILTERI[9]));
  LUT6 #(
    .INIT(64'h0000010000000000)) 
    \TOFILTERd[0]_i_1 
       (.I0(IDE_reg_0),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST),
        .I4(Q),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[0]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[10]_i_1 
       (.I0(TOFILTERd[9]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST),
        .I4(Q),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[10]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[11]_i_1 
       (.I0(TOFILTERd[10]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST),
        .I4(Q),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[11]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[12]_i_1 
       (.I0(TOFILTERd[11]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST),
        .I4(Q),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[12]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[13]_i_1 
       (.I0(TOFILTERd[12]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST),
        .I4(Q),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[13]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[14]_i_1 
       (.I0(TOFILTERd[13]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST),
        .I4(Q),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[14]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[15]_i_1 
       (.I0(TOFILTERd[14]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST),
        .I4(Q),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[15]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[16]_i_1 
       (.I0(TOFILTERd[15]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST),
        .I4(Q),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[16]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[17]_i_1 
       (.I0(TOFILTERd[16]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST),
        .I4(Q),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[17]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[18]_i_1 
       (.I0(TOFILTERd[17]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST),
        .I4(Q),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[18]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[19]_i_1 
       (.I0(TOFILTERd[18]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST),
        .I4(Q),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[19]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[1]_i_1 
       (.I0(TOFILTERd[0]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST),
        .I4(Q),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[1]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[20]_i_1 
       (.I0(TOFILTERd[19]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST),
        .I4(Q),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[20]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[21]_i_1 
       (.I0(TOFILTERd[20]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST),
        .I4(Q),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[21]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[22]_i_1 
       (.I0(TOFILTERd[21]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST),
        .I4(Q),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[22]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[23]_i_1 
       (.I0(TOFILTERd[22]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST),
        .I4(Q),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[23]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[24]_i_1 
       (.I0(TOFILTERd[23]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST),
        .I4(Q),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[24]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[25]_i_1 
       (.I0(TOFILTERd[24]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST),
        .I4(Q),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[25]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[26]_i_1 
       (.I0(TOFILTERd[25]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST),
        .I4(Q),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[26]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[27]_i_1 
       (.I0(TOFILTERd[26]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST),
        .I4(Q),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[27]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[28]_i_1 
       (.I0(TOFILTERd[27]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST),
        .I4(Q),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[28]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[29]_i_1 
       (.I0(TOFILTERd[28]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST),
        .I4(Q),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[29]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[2]_i_1 
       (.I0(TOFILTERd[1]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST),
        .I4(Q),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[2]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[30]_i_1 
       (.I0(TOFILTERd[29]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST),
        .I4(Q),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[30]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[31]_i_1 
       (.I0(TOFILTERd[30]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST),
        .I4(Q),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[31]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[32]_i_1 
       (.I0(TOFILTERd[31]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST),
        .I4(Q),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[32]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[33]_i_1 
       (.I0(TOFILTERd[32]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST),
        .I4(Q),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[33]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[34]_i_1 
       (.I0(TOFILTERd[33]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST),
        .I4(Q),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[34]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[35]_i_1 
       (.I0(TOFILTERd[34]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST),
        .I4(Q),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[35]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[36]_i_1 
       (.I0(TOFILTERd[35]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST),
        .I4(Q),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[36]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[37]_i_1 
       (.I0(TOFILTERd[36]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST),
        .I4(Q),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[37]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[38]_i_1 
       (.I0(TOFILTERd[37]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST),
        .I4(Q),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[38]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[39]_i_1 
       (.I0(TOFILTERd[38]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST),
        .I4(Q),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[39]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[3]_i_1 
       (.I0(TOFILTERd[2]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST),
        .I4(Q),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[3]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[40]_i_1 
       (.I0(TOFILTERd[39]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST),
        .I4(Q),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[40]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[41]_i_1 
       (.I0(TOFILTERd[40]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST),
        .I4(Q),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[41]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[42]_i_1 
       (.I0(TOFILTERd[41]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST),
        .I4(Q),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[42]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[43]_i_1 
       (.I0(TOFILTERd[42]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST),
        .I4(Q),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[43]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[44]_i_1 
       (.I0(TOFILTERd[43]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST),
        .I4(Q),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[44]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[45]_i_1 
       (.I0(TOFILTERd[44]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST),
        .I4(Q),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[45]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[46]_i_1 
       (.I0(TOFILTERd[45]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST),
        .I4(Q),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[46]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[47]_i_1 
       (.I0(TOFILTERd[46]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST),
        .I4(Q),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[47]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[48]_i_1 
       (.I0(TOFILTERd[47]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST),
        .I4(Q),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[48]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[49]_i_1 
       (.I0(TOFILTERd[48]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST),
        .I4(Q),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[49]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[4]_i_1 
       (.I0(TOFILTERd[3]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST),
        .I4(Q),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[4]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[50]_i_1 
       (.I0(TOFILTERd[49]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST),
        .I4(Q),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[50]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[51]_i_1 
       (.I0(TOFILTERd[50]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST),
        .I4(Q),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[51]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[52]_i_1 
       (.I0(TOFILTERd[51]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST),
        .I4(Q),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[52]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[53]_i_1 
       (.I0(TOFILTERd[52]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST),
        .I4(Q),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[53]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[54]_i_1 
       (.I0(TOFILTERd[53]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST),
        .I4(Q),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[54]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[55]_i_1 
       (.I0(TOFILTERd[54]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST),
        .I4(Q),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[55]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[56]_i_1 
       (.I0(TOFILTERd[55]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST),
        .I4(Q),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[56]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[57]_i_1 
       (.I0(TOFILTERd[56]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST),
        .I4(Q),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[57]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[58]_i_1 
       (.I0(TOFILTERd[57]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST),
        .I4(Q),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[58]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[59]_i_1 
       (.I0(TOFILTERd[58]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST),
        .I4(Q),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[59]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[5]_i_1 
       (.I0(TOFILTERd[4]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST),
        .I4(Q),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[5]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[60]_i_1 
       (.I0(TOFILTERd[59]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST),
        .I4(Q),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[60]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[61]_i_1 
       (.I0(TOFILTERd[60]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST),
        .I4(Q),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[61]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[62]_i_1 
       (.I0(TOFILTERd[61]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST),
        .I4(Q),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[62]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h00001300FFFFFFFF)) 
    \TOFILTERd[63]_i_1 
       (.I0(RXSTATES[0]),
        .I1(RXSTATES[1]),
        .I2(RXSTATES[2]),
        .I3(\CRC_RG_reg[14] ),
        .I4(Q),
        .I5(SRST),
        .O(\TOFILTERd[63]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[63]_i_2 
       (.I0(TOFILTERd[62]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST),
        .I4(Q),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[63]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[6]_i_1 
       (.I0(TOFILTERd[5]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST),
        .I4(Q),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[6]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[7]_i_1 
       (.I0(TOFILTERd[6]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST),
        .I4(Q),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[7]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[8]_i_1 
       (.I0(TOFILTERd[7]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST),
        .I4(Q),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[8]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    \TOFILTERd[9]_i_1 
       (.I0(TOFILTERd[8]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(SRST),
        .I4(Q),
        .I5(RXSTATES[2]),
        .O(\TOFILTERd[9]_i_1_n_0 ));
  FDCE \TOFILTERd_reg[0] 
       (.C(Tq),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[0]_i_1_n_0 ),
        .Q(TOFILTERd[0]));
  FDCE \TOFILTERd_reg[10] 
       (.C(Tq),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[10]_i_1_n_0 ),
        .Q(TOFILTERd[10]));
  FDCE \TOFILTERd_reg[11] 
       (.C(Tq),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[11]_i_1_n_0 ),
        .Q(TOFILTERd[11]));
  FDCE \TOFILTERd_reg[12] 
       (.C(Tq),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[12]_i_1_n_0 ),
        .Q(TOFILTERd[12]));
  FDCE \TOFILTERd_reg[13] 
       (.C(Tq),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[13]_i_1_n_0 ),
        .Q(TOFILTERd[13]));
  FDCE \TOFILTERd_reg[14] 
       (.C(Tq),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[14]_i_1_n_0 ),
        .Q(TOFILTERd[14]));
  FDCE \TOFILTERd_reg[15] 
       (.C(Tq),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[15]_i_1_n_0 ),
        .Q(TOFILTERd[15]));
  FDCE \TOFILTERd_reg[16] 
       (.C(Tq),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[16]_i_1_n_0 ),
        .Q(TOFILTERd[16]));
  FDCE \TOFILTERd_reg[17] 
       (.C(Tq),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[17]_i_1_n_0 ),
        .Q(TOFILTERd[17]));
  FDCE \TOFILTERd_reg[18] 
       (.C(Tq),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[18]_i_1_n_0 ),
        .Q(TOFILTERd[18]));
  FDCE \TOFILTERd_reg[19] 
       (.C(Tq),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[19]_i_1_n_0 ),
        .Q(TOFILTERd[19]));
  FDCE \TOFILTERd_reg[1] 
       (.C(Tq),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[1]_i_1_n_0 ),
        .Q(TOFILTERd[1]));
  FDCE \TOFILTERd_reg[20] 
       (.C(Tq),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[20]_i_1_n_0 ),
        .Q(TOFILTERd[20]));
  FDCE \TOFILTERd_reg[21] 
       (.C(Tq),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[21]_i_1_n_0 ),
        .Q(TOFILTERd[21]));
  FDCE \TOFILTERd_reg[22] 
       (.C(Tq),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[22]_i_1_n_0 ),
        .Q(TOFILTERd[22]));
  FDCE \TOFILTERd_reg[23] 
       (.C(Tq),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[23]_i_1_n_0 ),
        .Q(TOFILTERd[23]));
  FDCE \TOFILTERd_reg[24] 
       (.C(Tq),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[24]_i_1_n_0 ),
        .Q(TOFILTERd[24]));
  FDCE \TOFILTERd_reg[25] 
       (.C(Tq),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[25]_i_1_n_0 ),
        .Q(TOFILTERd[25]));
  FDCE \TOFILTERd_reg[26] 
       (.C(Tq),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[26]_i_1_n_0 ),
        .Q(TOFILTERd[26]));
  FDCE \TOFILTERd_reg[27] 
       (.C(Tq),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[27]_i_1_n_0 ),
        .Q(TOFILTERd[27]));
  FDCE \TOFILTERd_reg[28] 
       (.C(Tq),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[28]_i_1_n_0 ),
        .Q(TOFILTERd[28]));
  FDCE \TOFILTERd_reg[29] 
       (.C(Tq),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[29]_i_1_n_0 ),
        .Q(TOFILTERd[29]));
  FDCE \TOFILTERd_reg[2] 
       (.C(Tq),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[2]_i_1_n_0 ),
        .Q(TOFILTERd[2]));
  FDCE \TOFILTERd_reg[30] 
       (.C(Tq),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[30]_i_1_n_0 ),
        .Q(TOFILTERd[30]));
  FDCE \TOFILTERd_reg[31] 
       (.C(Tq),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[31]_i_1_n_0 ),
        .Q(TOFILTERd[31]));
  FDCE \TOFILTERd_reg[32] 
       (.C(Tq),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[32]_i_1_n_0 ),
        .Q(TOFILTERd[32]));
  FDCE \TOFILTERd_reg[33] 
       (.C(Tq),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[33]_i_1_n_0 ),
        .Q(TOFILTERd[33]));
  FDCE \TOFILTERd_reg[34] 
       (.C(Tq),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[34]_i_1_n_0 ),
        .Q(TOFILTERd[34]));
  FDCE \TOFILTERd_reg[35] 
       (.C(Tq),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[35]_i_1_n_0 ),
        .Q(TOFILTERd[35]));
  FDCE \TOFILTERd_reg[36] 
       (.C(Tq),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[36]_i_1_n_0 ),
        .Q(TOFILTERd[36]));
  FDCE \TOFILTERd_reg[37] 
       (.C(Tq),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[37]_i_1_n_0 ),
        .Q(TOFILTERd[37]));
  FDCE \TOFILTERd_reg[38] 
       (.C(Tq),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[38]_i_1_n_0 ),
        .Q(TOFILTERd[38]));
  FDCE \TOFILTERd_reg[39] 
       (.C(Tq),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[39]_i_1_n_0 ),
        .Q(TOFILTERd[39]));
  FDCE \TOFILTERd_reg[3] 
       (.C(Tq),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[3]_i_1_n_0 ),
        .Q(TOFILTERd[3]));
  FDCE \TOFILTERd_reg[40] 
       (.C(Tq),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[40]_i_1_n_0 ),
        .Q(TOFILTERd[40]));
  FDCE \TOFILTERd_reg[41] 
       (.C(Tq),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[41]_i_1_n_0 ),
        .Q(TOFILTERd[41]));
  FDCE \TOFILTERd_reg[42] 
       (.C(Tq),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[42]_i_1_n_0 ),
        .Q(TOFILTERd[42]));
  FDCE \TOFILTERd_reg[43] 
       (.C(Tq),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[43]_i_1_n_0 ),
        .Q(TOFILTERd[43]));
  FDCE \TOFILTERd_reg[44] 
       (.C(Tq),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[44]_i_1_n_0 ),
        .Q(TOFILTERd[44]));
  FDCE \TOFILTERd_reg[45] 
       (.C(Tq),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[45]_i_1_n_0 ),
        .Q(TOFILTERd[45]));
  FDCE \TOFILTERd_reg[46] 
       (.C(Tq),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[46]_i_1_n_0 ),
        .Q(TOFILTERd[46]));
  FDCE \TOFILTERd_reg[47] 
       (.C(Tq),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[47]_i_1_n_0 ),
        .Q(TOFILTERd[47]));
  FDCE \TOFILTERd_reg[48] 
       (.C(Tq),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[48]_i_1_n_0 ),
        .Q(TOFILTERd[48]));
  FDCE \TOFILTERd_reg[49] 
       (.C(Tq),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[49]_i_1_n_0 ),
        .Q(TOFILTERd[49]));
  FDCE \TOFILTERd_reg[4] 
       (.C(Tq),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[4]_i_1_n_0 ),
        .Q(TOFILTERd[4]));
  FDCE \TOFILTERd_reg[50] 
       (.C(Tq),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[50]_i_1_n_0 ),
        .Q(TOFILTERd[50]));
  FDCE \TOFILTERd_reg[51] 
       (.C(Tq),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[51]_i_1_n_0 ),
        .Q(TOFILTERd[51]));
  FDCE \TOFILTERd_reg[52] 
       (.C(Tq),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[52]_i_1_n_0 ),
        .Q(TOFILTERd[52]));
  FDCE \TOFILTERd_reg[53] 
       (.C(Tq),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[53]_i_1_n_0 ),
        .Q(TOFILTERd[53]));
  FDCE \TOFILTERd_reg[54] 
       (.C(Tq),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[54]_i_1_n_0 ),
        .Q(TOFILTERd[54]));
  FDCE \TOFILTERd_reg[55] 
       (.C(Tq),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[55]_i_1_n_0 ),
        .Q(TOFILTERd[55]));
  FDCE \TOFILTERd_reg[56] 
       (.C(Tq),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[56]_i_1_n_0 ),
        .Q(TOFILTERd[56]));
  FDCE \TOFILTERd_reg[57] 
       (.C(Tq),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[57]_i_1_n_0 ),
        .Q(TOFILTERd[57]));
  FDCE \TOFILTERd_reg[58] 
       (.C(Tq),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[58]_i_1_n_0 ),
        .Q(TOFILTERd[58]));
  FDCE \TOFILTERd_reg[59] 
       (.C(Tq),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[59]_i_1_n_0 ),
        .Q(TOFILTERd[59]));
  FDCE \TOFILTERd_reg[5] 
       (.C(Tq),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[5]_i_1_n_0 ),
        .Q(TOFILTERd[5]));
  FDCE \TOFILTERd_reg[60] 
       (.C(Tq),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[60]_i_1_n_0 ),
        .Q(TOFILTERd[60]));
  FDCE \TOFILTERd_reg[61] 
       (.C(Tq),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[61]_i_1_n_0 ),
        .Q(TOFILTERd[61]));
  FDCE \TOFILTERd_reg[62] 
       (.C(Tq),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[62]_i_1_n_0 ),
        .Q(TOFILTERd[62]));
  FDCE \TOFILTERd_reg[63] 
       (.C(Tq),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[63]_i_2_n_0 ),
        .Q(TOFILTERd[63]));
  FDCE \TOFILTERd_reg[6] 
       (.C(Tq),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[6]_i_1_n_0 ),
        .Q(TOFILTERd[6]));
  FDCE \TOFILTERd_reg[7] 
       (.C(Tq),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[7]_i_1_n_0 ),
        .Q(TOFILTERd[7]));
  FDCE \TOFILTERd_reg[8] 
       (.C(Tq),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[8]_i_1_n_0 ),
        .Q(TOFILTERd[8]));
  FDCE \TOFILTERd_reg[9] 
       (.C(Tq),
        .CE(\TOFILTERd[63]_i_1_n_0 ),
        .CLR(CAN_RST_0),
        .D(\TOFILTERd[9]_i_1_n_0 ),
        .Q(TOFILTERd[9]));
  (* SOFT_HLUTNM = "soft_lutpair71" *) 
  LUT5 #(
    .INIT(32'hFFF57F55)) 
    \bs[0]_i_1 
       (.I0(IDE_reg_0),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[1]),
        .I3(Q),
        .I4(RXSTATES[2]),
        .O(I56[0]));
  LUT6 #(
    .INIT(64'h08000FFE08000002)) 
    \bs[1]_i_1 
       (.I0(IDE_reg_0),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[2]),
        .I3(RXSTATES[1]),
        .I4(Q),
        .I5(bs[0]),
        .O(I56[1]));
  (* SOFT_HLUTNM = "soft_lutpair76" *) 
  LUT5 #(
    .INIT(32'h02220220)) 
    \bs[2]_i_1 
       (.I0(bs[1]),
        .I1(Q),
        .I2(RXSTATES[1]),
        .I3(RXSTATES[2]),
        .I4(RXSTATES[0]),
        .O(I56[2]));
  (* SOFT_HLUTNM = "soft_lutpair77" *) 
  LUT5 #(
    .INIT(32'h02220220)) 
    \bs[3]_i_1 
       (.I0(bs[2]),
        .I1(Q),
        .I2(RXSTATES[1]),
        .I3(RXSTATES[2]),
        .I4(RXSTATES[0]),
        .O(I56[3]));
  (* SOFT_HLUTNM = "soft_lutpair78" *) 
  LUT5 #(
    .INIT(32'h02220220)) 
    \bs[4]_i_1 
       (.I0(bs[3]),
        .I1(Q),
        .I2(RXSTATES[1]),
        .I3(RXSTATES[2]),
        .I4(RXSTATES[0]),
        .O(I56[4]));
  (* SOFT_HLUTNM = "soft_lutpair79" *) 
  LUT5 #(
    .INIT(32'h02220220)) 
    \bs[5]_i_1 
       (.I0(bs[4]),
        .I1(Q),
        .I2(RXSTATES[1]),
        .I3(RXSTATES[2]),
        .I4(RXSTATES[0]),
        .O(I56[5]));
  FDPE \bs_reg[0] 
       (.C(Tq),
        .CE(\bs_reg[0]_0 ),
        .D(I56[0]),
        .PRE(CAN_RST_0),
        .Q(bs[0]));
  FDCE \bs_reg[1] 
       (.C(Tq),
        .CE(\bs_reg[0]_0 ),
        .CLR(CAN_RST_0),
        .D(I56[1]),
        .Q(bs[1]));
  FDCE \bs_reg[2] 
       (.C(Tq),
        .CE(\bs_reg[0]_0 ),
        .CLR(CAN_RST_0),
        .D(I56[2]),
        .Q(bs[2]));
  FDCE \bs_reg[3] 
       (.C(Tq),
        .CE(\bs_reg[0]_0 ),
        .CLR(CAN_RST_0),
        .D(I56[3]),
        .Q(bs[3]));
  FDCE \bs_reg[4] 
       (.C(Tq),
        .CE(\bs_reg[0]_0 ),
        .CLR(CAN_RST_0),
        .D(I56[4]),
        .Q(bs[4]));
  FDCE \bs_reg[5] 
       (.C(Tq),
        .CE(\bs_reg[0]_0 ),
        .CLR(CAN_RST_0),
        .D(I56[5]),
        .Q(bs[5]));
  (* SOFT_HLUTNM = "soft_lutpair71" *) 
  LUT4 #(
    .INIT(16'hFF7E)) 
    done_i_15
       (.I0(RXSTATES[0]),
        .I1(RXSTATES[1]),
        .I2(Q),
        .I3(RXSTATES[2]),
        .O(\RXSTATES_reg[0]_1 ));
  (* SOFT_HLUTNM = "soft_lutpair81" *) 
  LUT5 #(
    .INIT(32'hCCC88888)) 
    done_i_1__0
       (.I0(done_i_3_n_0),
        .I1(SRST),
        .I2(Q),
        .I3(\RXSTATES_reg[1]_0 ),
        .I4(done_reg_0),
        .O(done_i_1__0_n_0));
  LUT6 #(
    .INIT(64'h0000000000200000)) 
    done_i_3
       (.I0(\RXSTATES[2]_i_3_n_0 ),
        .I1(RXSTATES[2]),
        .I2(Q),
        .I3(RXSTATES[1]),
        .I4(RXSTATES[0]),
        .I5(imTX),
        .O(done_i_3_n_0));
  (* SOFT_HLUTNM = "soft_lutpair76" *) 
  LUT4 #(
    .INIT(16'h0001)) 
    done_i_4__0
       (.I0(RXSTATES[1]),
        .I1(RXSTATES[0]),
        .I2(Q),
        .I3(RXSTATES[2]),
        .O(\RXSTATES_reg[1]_0 ));
  FDCE done_reg
       (.C(Tq),
        .CE(1'b1),
        .CLR(CAN_RST_0),
        .D(done_i_1__0_n_0),
        .Q(done_reg_0));
  (* SOFT_HLUTNM = "soft_lutpair81" *) 
  LUT2 #(
    .INIT(4'h8)) 
    donefromrxr_i_1
       (.I0(SRST),
        .I1(done_reg_0),
        .O(donefromrxr));
  LUT6 #(
    .INIT(64'h0000080800202020)) 
    req_Error_i_2
       (.I0(IDE_reg_0),
        .I1(RXSTATES[2]),
        .I2(Q),
        .I3(\RXSTATES[2]_i_3_n_0 ),
        .I4(RXSTATES[0]),
        .I5(RXSTATES[1]),
        .O(req_Error_i_2_n_0));
  (* SOFT_HLUTNM = "soft_lutpair75" *) 
  LUT5 #(
    .INIT(32'h55D5555F)) 
    req_Error_i_4
       (.I0(SRST),
        .I1(RXSTATES[0]),
        .I2(Q),
        .I3(RXSTATES[1]),
        .I4(RXSTATES[2]),
        .O(req_Error_i_4_n_0));
  (* SOFT_HLUTNM = "soft_lutpair80" *) 
  LUT5 #(
    .INIT(32'h00000001)) 
    req_Error_i_5
       (.I0(bs[1]),
        .I1(bs[0]),
        .I2(bs[3]),
        .I3(bs[4]),
        .I4(bs[2]),
        .O(req_Error_i_5_n_0));
  (* SOFT_HLUTNM = "soft_lutpair80" *) 
  LUT5 #(
    .INIT(32'h80000000)) 
    req_Error_i_6
       (.I0(bs[1]),
        .I1(bs[0]),
        .I2(bs[3]),
        .I3(bs[4]),
        .I4(bs[2]),
        .O(req_Error_i_6_n_0));
  (* SOFT_HLUTNM = "soft_lutpair73" *) 
  LUT4 #(
    .INIT(16'h0100)) 
    req_Error_i_8
       (.I0(RXSTATES[1]),
        .I1(RXSTATES[0]),
        .I2(RXSTATES[2]),
        .I3(Q),
        .O(req_Error_i_8_n_0));
  FDCE req_Error_reg
       (.C(Tq),
        .CE(1'b1),
        .CLR(CAN_RST_0),
        .D(rxcrc_n_1),
        .Q(req_Error_RX));
  design_1_FPGAPROJECT_0_0_CRC_10 rxcrc
       (.CAN_RST(CAN_RST),
        .CAN_RST_0(CAN_RST_0),
        .\CRC_RG_reg[14]_0 (\CRC_RG_reg[14] ),
        .\CRC_RG_reg[3]_0 (IDE_reg_0),
        .Q({Q,RXSTATES}),
        .SRST(SRST),
        .SRST_1(rxcrc_n_1),
        .Tq(Tq),
        .\bs_reg[1] (\bs_reg[1]_0 ),
        .req_Error_reg(req_Error_i_5_n_0),
        .req_Error_reg_0(bs),
        .req_Error_reg_1(req_Error_i_6_n_0),
        .req_Error_reg_2(req_Error_i_8_n_0),
        .req_Error_reg_3(req_Error_i_2_n_0),
        .req_Error_reg_4(req_Error_i_4_n_0),
        .req_Error_reg_5(\bs_reg[0]_0 ),
        .req_Error_reg_6(req_Error_RX));
endmodule

(* ORIG_REF_NAME = "Rengine" *) 
module design_1_FPGAPROJECT_0_0_Rengine
   (RXBUS_d,
    Sampled_din,
    \CNT1_reg[4]_0 ,
    E,
    \CNT1_reg[4]_1 ,
    SRST_0_0,
    \CNT2_reg[0]_0 ,
    SRST_0_1,
    RXOUT_reg_0,
    RXBUS_d_reg_0,
    \CNT1_reg[3]_0 ,
    SRST_0_2,
    RXOUT_reg_1,
    RXOUT_reg_2,
    RXBUS,
    clk,
    RXOUT_reg_3,
    \CNT2_reg[1]_0 ,
    \CNT2_reg[0]_1 ,
    SRST_0,
    lastvalue,
    \CNT1_reg[0]_0 ,
    \CNT1_reg[3]_1 ,
    \RXSTATES_reg[3] ,
    \RXSTATES_reg[3]_0 ,
    \REC[0]_i_3 ,
    \CNT2_reg[3]_0 );
  output RXBUS_d;
  output Sampled_din;
  output \CNT1_reg[4]_0 ;
  output [0:0]E;
  output \CNT1_reg[4]_1 ;
  output [0:0]SRST_0_0;
  output \CNT2_reg[0]_0 ;
  output [0:0]SRST_0_1;
  output RXOUT_reg_0;
  output RXBUS_d_reg_0;
  output \CNT1_reg[3]_0 ;
  output [0:0]SRST_0_2;
  output RXOUT_reg_1;
  output RXOUT_reg_2;
  input RXBUS;
  input clk;
  input RXOUT_reg_3;
  input \CNT2_reg[1]_0 ;
  input \CNT2_reg[0]_1 ;
  input SRST_0;
  input lastvalue;
  input \CNT1_reg[0]_0 ;
  input \CNT1_reg[3]_1 ;
  input \RXSTATES_reg[3] ;
  input \RXSTATES_reg[3]_0 ;
  input [0:0]\REC[0]_i_3 ;
  input [0:0]\CNT2_reg[3]_0 ;

  wire \CNT1[1]_i_2_n_0 ;
  wire \CNT1[3]_i_2_n_0 ;
  wire \CNT1[3]_i_3_n_0 ;
  wire \CNT1[3]_i_4_n_0 ;
  wire \CNT1[4]_i_1_n_0 ;
  wire \CNT1[4]_i_4_n_0 ;
  wire \CNT1[4]_i_5_n_0 ;
  wire \CNT1[4]_i_7_n_0 ;
  wire \CNT1_reg[0]_0 ;
  wire \CNT1_reg[3]_0 ;
  wire \CNT1_reg[3]_1 ;
  wire \CNT1_reg[4]_0 ;
  wire \CNT1_reg[4]_1 ;
  wire \CNT1_reg_n_0_[0] ;
  wire \CNT1_reg_n_0_[1] ;
  wire \CNT1_reg_n_0_[2] ;
  wire \CNT1_reg_n_0_[3] ;
  wire \CNT1_reg_n_0_[4] ;
  wire [4:0]CNT1r;
  wire CNT1r1;
  wire \CNT1r1_inferred__0/i__carry_n_3 ;
  wire [3:0]CNT2;
  wire \CNT2[0]_i_2_n_0 ;
  wire \CNT2[1]_i_2_n_0 ;
  wire \CNT2[1]_i_3_n_0 ;
  wire \CNT2[2]_i_2_n_0 ;
  wire \CNT2[2]_i_3_n_0 ;
  wire \CNT2[3]_i_3_n_0 ;
  wire \CNT2[3]_i_4_n_0 ;
  wire \CNT2_reg[0]_0 ;
  wire \CNT2_reg[0]_1 ;
  wire \CNT2_reg[1]_0 ;
  wire [0:0]\CNT2_reg[3]_0 ;
  wire [3:0]CNT2r;
  wire [0:0]E;
  wire [0:0]\REC[0]_i_3 ;
  wire RXBUS;
  wire RXBUS_d;
  wire RXBUS_d_reg_0;
  wire RXOUT_reg_0;
  wire RXOUT_reg_1;
  wire RXOUT_reg_2;
  wire RXOUT_reg_3;
  wire \RXSTATES_reg[3] ;
  wire \RXSTATES_reg[3]_0 ;
  wire SRST_0;
  wire [0:0]SRST_0_0;
  wire [0:0]SRST_0_1;
  wire [0:0]SRST_0_2;
  wire Sampled_din;
  wire clk;
  wire i__carry_i_1_n_0;
  wire i__carry_i_2_n_0;
  wire lastvalue;
  wire [3:2]\NLW_CNT1r1_inferred__0/i__carry_CO_UNCONNECTED ;
  wire [3:0]\NLW_CNT1r1_inferred__0/i__carry_O_UNCONNECTED ;

  LUT6 #(
    .INIT(64'h0C110C1100000C11)) 
    \CNT1[0]_i_1 
       (.I0(\CNT1_reg[3]_0 ),
        .I1(\CNT1_reg_n_0_[0] ),
        .I2(\CNT1[1]_i_2_n_0 ),
        .I3(\CNT1_reg[0]_0 ),
        .I4(\CNT2_reg[1]_0 ),
        .I5(RXBUS_d_reg_0),
        .O(CNT1r[0]));
  LUT6 #(
    .INIT(64'h0000000000093039)) 
    \CNT1[1]_i_1 
       (.I0(\CNT1_reg_n_0_[0] ),
        .I1(\CNT1_reg_n_0_[1] ),
        .I2(\CNT1_reg[0]_0 ),
        .I3(\CNT1_reg[3]_0 ),
        .I4(\CNT1[1]_i_2_n_0 ),
        .I5(\CNT1[3]_i_3_n_0 ),
        .O(CNT1r[1]));
  (* SOFT_HLUTNM = "soft_lutpair162" *) 
  LUT5 #(
    .INIT(32'h00010081)) 
    \CNT1[1]_i_2 
       (.I0(\CNT1_reg_n_0_[2] ),
        .I1(\CNT1_reg_n_0_[1] ),
        .I2(\CNT1_reg_n_0_[0] ),
        .I3(\CNT1_reg_n_0_[4] ),
        .I4(\CNT1_reg_n_0_[3] ),
        .O(\CNT1[1]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000005AE1)) 
    \CNT1[2]_i_1 
       (.I0(\CNT1_reg_n_0_[1] ),
        .I1(\CNT1_reg_n_0_[0] ),
        .I2(\CNT1_reg_n_0_[2] ),
        .I3(\CNT1_reg[0]_0 ),
        .I4(\CNT1[3]_i_3_n_0 ),
        .I5(\CNT1_reg[3]_0 ),
        .O(CNT1r[2]));
  (* SOFT_HLUTNM = "soft_lutpair163" *) 
  LUT5 #(
    .INIT(32'h00000001)) 
    \CNT1[2]_i_2 
       (.I0(\CNT1_reg_n_0_[3] ),
        .I1(\CNT1_reg_n_0_[0] ),
        .I2(\CNT1_reg_n_0_[1] ),
        .I3(\CNT1_reg_n_0_[2] ),
        .I4(\CNT1_reg_n_0_[4] ),
        .O(\CNT1_reg[3]_0 ));
  LUT6 #(
    .INIT(64'hFCFEFFFEFFFEFCFE)) 
    \CNT1[3]_i_1 
       (.I0(\CNT1[3]_i_2_n_0 ),
        .I1(\CNT2_reg[0]_0 ),
        .I2(\CNT1[3]_i_3_n_0 ),
        .I3(\CNT1_reg[0]_0 ),
        .I4(\CNT1[3]_i_4_n_0 ),
        .I5(\CNT1_reg_n_0_[3] ),
        .O(CNT1r[3]));
  (* SOFT_HLUTNM = "soft_lutpair162" *) 
  LUT5 #(
    .INIT(32'hFFFC0002)) 
    \CNT1[3]_i_2 
       (.I0(\CNT1_reg_n_0_[4] ),
        .I1(\CNT1_reg_n_0_[0] ),
        .I2(\CNT1_reg_n_0_[1] ),
        .I3(\CNT1_reg_n_0_[2] ),
        .I4(\CNT1_reg_n_0_[3] ),
        .O(\CNT1[3]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair165" *) 
  LUT4 #(
    .INIT(16'h8000)) 
    \CNT1[3]_i_3 
       (.I0(\CNT2_reg[1]_0 ),
        .I1(Sampled_din),
        .I2(RXBUS_d),
        .I3(\CNT1_reg[3]_1 ),
        .O(\CNT1[3]_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \CNT1[3]_i_4 
       (.I0(\CNT1_reg_n_0_[1] ),
        .I1(\CNT1_reg_n_0_[2] ),
        .O(\CNT1[3]_i_4_n_0 ));
  LUT4 #(
    .INIT(16'hFDFF)) 
    \CNT1[4]_i_1 
       (.I0(\CNT1_reg[0]_0 ),
        .I1(\CNT2_reg[1]_0 ),
        .I2(\CNT1[4]_i_4_n_0 ),
        .I3(\CNT1_reg[4]_0 ),
        .O(\CNT1[4]_i_1_n_0 ));
  LUT4 #(
    .INIT(16'h88B8)) 
    \CNT1[4]_i_2 
       (.I0(\CNT1[4]_i_5_n_0 ),
        .I1(RXBUS_d_reg_0),
        .I2(\CNT1[4]_i_7_n_0 ),
        .I3(\CNT2_reg[1]_0 ),
        .O(CNT1r[4]));
  (* SOFT_HLUTNM = "soft_lutpair164" *) 
  LUT4 #(
    .INIT(16'h0001)) 
    \CNT1[4]_i_4 
       (.I0(CNT2[3]),
        .I1(CNT2[1]),
        .I2(CNT2[2]),
        .I3(CNT2[0]),
        .O(\CNT1[4]_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair163" *) 
  LUT5 #(
    .INIT(32'hAAAAAAA8)) 
    \CNT1[4]_i_5 
       (.I0(\CNT1_reg_n_0_[4] ),
        .I1(\CNT1_reg_n_0_[3] ),
        .I2(\CNT1_reg_n_0_[0] ),
        .I3(\CNT1_reg_n_0_[1] ),
        .I4(\CNT1_reg_n_0_[2] ),
        .O(\CNT1[4]_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair165" *) 
  LUT3 #(
    .INIT(8'h7F)) 
    \CNT1[4]_i_6 
       (.I0(\CNT1_reg[3]_1 ),
        .I1(RXBUS_d),
        .I2(Sampled_din),
        .O(RXBUS_d_reg_0));
  LUT6 #(
    .INIT(64'hC3F0F0F0F0F0F0B0)) 
    \CNT1[4]_i_7 
       (.I0(\CNT1_reg_n_0_[0] ),
        .I1(\CNT2_reg[0]_1 ),
        .I2(\CNT1_reg_n_0_[4] ),
        .I3(\CNT1_reg_n_0_[3] ),
        .I4(\CNT1_reg_n_0_[1] ),
        .I5(\CNT1_reg_n_0_[2] ),
        .O(\CNT1[4]_i_7_n_0 ));
  FDCE \CNT1_reg[0] 
       (.C(clk),
        .CE(\CNT1[4]_i_1_n_0 ),
        .CLR(RXOUT_reg_3),
        .D(CNT1r[0]),
        .Q(\CNT1_reg_n_0_[0] ));
  FDCE \CNT1_reg[1] 
       (.C(clk),
        .CE(\CNT1[4]_i_1_n_0 ),
        .CLR(RXOUT_reg_3),
        .D(CNT1r[1]),
        .Q(\CNT1_reg_n_0_[1] ));
  FDCE \CNT1_reg[2] 
       (.C(clk),
        .CE(\CNT1[4]_i_1_n_0 ),
        .CLR(RXOUT_reg_3),
        .D(CNT1r[2]),
        .Q(\CNT1_reg_n_0_[2] ));
  FDCE \CNT1_reg[3] 
       (.C(clk),
        .CE(\CNT1[4]_i_1_n_0 ),
        .CLR(RXOUT_reg_3),
        .D(CNT1r[3]),
        .Q(\CNT1_reg_n_0_[3] ));
  FDCE \CNT1_reg[4] 
       (.C(clk),
        .CE(\CNT1[4]_i_1_n_0 ),
        .CLR(RXOUT_reg_3),
        .D(CNT1r[4]),
        .Q(\CNT1_reg_n_0_[4] ));
  CARRY4 \CNT1r1_inferred__0/i__carry 
       (.CI(1'b0),
        .CO({\NLW_CNT1r1_inferred__0/i__carry_CO_UNCONNECTED [3:2],CNT1r1,\CNT1r1_inferred__0/i__carry_n_3 }),
        .CYINIT(1'b1),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(\NLW_CNT1r1_inferred__0/i__carry_O_UNCONNECTED [3:0]),
        .S({1'b0,1'b0,i__carry_i_1_n_0,i__carry_i_2_n_0}));
  LUT3 #(
    .INIT(8'h74)) 
    \CNT2[0]_i_1 
       (.I0(CNT2[0]),
        .I1(RXBUS_d_reg_0),
        .I2(\CNT2[0]_i_2_n_0 ),
        .O(CNT2r[0]));
  LUT6 #(
    .INIT(64'hAFFAAFFAFFFFAEBE)) 
    \CNT2[0]_i_2 
       (.I0(\CNT2_reg[1]_0 ),
        .I1(CNT1r1),
        .I2(CNT2[0]),
        .I3(\CNT2[1]_i_3_n_0 ),
        .I4(\CNT2_reg[0]_0 ),
        .I5(\CNT2_reg[0]_1 ),
        .O(\CNT2[0]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'h9F9F9F90)) 
    \CNT2[1]_i_1 
       (.I0(CNT2[1]),
        .I1(CNT2[0]),
        .I2(RXBUS_d_reg_0),
        .I3(\CNT2_reg[1]_0 ),
        .I4(\CNT2[1]_i_2_n_0 ),
        .O(CNT2r[1]));
  LUT6 #(
    .INIT(64'h554E444FE4FFE4EF)) 
    \CNT2[1]_i_2 
       (.I0(\CNT2_reg[0]_1 ),
        .I1(\CNT2_reg[0]_0 ),
        .I2(\CNT2[1]_i_3_n_0 ),
        .I3(CNT2[1]),
        .I4(CNT1r1),
        .I5(CNT2[0]),
        .O(\CNT2[1]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair167" *) 
  LUT3 #(
    .INIT(8'h01)) 
    \CNT2[1]_i_3 
       (.I0(CNT2[2]),
        .I1(CNT2[1]),
        .I2(CNT2[3]),
        .O(\CNT2[1]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hFC02FFFFFC020000)) 
    \CNT2[2]_i_1 
       (.I0(CNT2[3]),
        .I1(CNT2[1]),
        .I2(CNT2[0]),
        .I3(CNT2[2]),
        .I4(RXBUS_d_reg_0),
        .I5(\CNT2[2]_i_2_n_0 ),
        .O(CNT2r[2]));
  LUT6 #(
    .INIT(64'h5151010101015101)) 
    \CNT2[2]_i_2 
       (.I0(\CNT2_reg[1]_0 ),
        .I1(\CNT2[2]_i_3_n_0 ),
        .I2(\CNT2_reg[0]_1 ),
        .I3(CNT2[3]),
        .I4(CNT2[1]),
        .I5(CNT2[2]),
        .O(\CNT2[2]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAAFFAFFBAFFAAFFB)) 
    \CNT2[2]_i_3 
       (.I0(\CNT2_reg[0]_0 ),
        .I1(CNT2[3]),
        .I2(CNT2[1]),
        .I3(CNT2[2]),
        .I4(CNT1r1),
        .I5(CNT2[0]),
        .O(\CNT2[2]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h8A008A008A008AFF)) 
    \CNT2[3]_i_2 
       (.I0(CNT2[3]),
        .I1(CNT2[0]),
        .I2(\CNT2[3]_i_3_n_0 ),
        .I3(RXBUS_d_reg_0),
        .I4(\CNT2_reg[1]_0 ),
        .I5(\CNT2[3]_i_4_n_0 ),
        .O(CNT2r[3]));
  (* SOFT_HLUTNM = "soft_lutpair167" *) 
  LUT2 #(
    .INIT(4'h1)) 
    \CNT2[3]_i_3 
       (.I0(CNT2[1]),
        .I1(CNT2[2]),
        .O(\CNT2[3]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hEF4FFF4FFE4FFF4F)) 
    \CNT2[3]_i_4 
       (.I0(\CNT2_reg[0]_1 ),
        .I1(\CNT2_reg[0]_0 ),
        .I2(CNT2[3]),
        .I3(\CNT2[3]_i_3_n_0 ),
        .I4(CNT1r1),
        .I5(CNT2[0]),
        .O(\CNT2[3]_i_4_n_0 ));
  FDCE \CNT2_reg[0] 
       (.C(clk),
        .CE(\CNT2_reg[3]_0 ),
        .CLR(RXOUT_reg_3),
        .D(CNT2r[0]),
        .Q(CNT2[0]));
  FDCE \CNT2_reg[1] 
       (.C(clk),
        .CE(\CNT2_reg[3]_0 ),
        .CLR(RXOUT_reg_3),
        .D(CNT2r[1]),
        .Q(CNT2[1]));
  FDCE \CNT2_reg[2] 
       (.C(clk),
        .CE(\CNT2_reg[3]_0 ),
        .CLR(RXOUT_reg_3),
        .D(CNT2r[2]),
        .Q(CNT2[2]));
  FDCE \CNT2_reg[3] 
       (.C(clk),
        .CE(\CNT2_reg[3]_0 ),
        .CLR(RXOUT_reg_3),
        .D(CNT2r[3]),
        .Q(CNT2[3]));
  (* SOFT_HLUTNM = "soft_lutpair168" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \Cnt[3]_i_1__1 
       (.I0(\CNT2_reg[0]_0 ),
        .I1(SRST_0),
        .O(SRST_0_0));
  (* SOFT_HLUTNM = "soft_lutpair170" *) 
  LUT2 #(
    .INIT(4'h9)) 
    \Cnt[3]_i_8__0 
       (.I0(Sampled_din),
        .I1(lastvalue),
        .O(RXOUT_reg_0));
  (* SOFT_HLUTNM = "soft_lutpair168" *) 
  LUT2 #(
    .INIT(4'hB)) 
    \Cnt[5]_i_1__0 
       (.I0(\CNT1_reg[4]_1 ),
        .I1(SRST_0),
        .O(E));
  (* SOFT_HLUTNM = "soft_lutpair170" *) 
  LUT2 #(
    .INIT(4'h1)) 
    \REC[0]_i_5 
       (.I0(Sampled_din),
        .I1(\REC[0]_i_3 ),
        .O(RXOUT_reg_2));
  (* SOFT_HLUTNM = "soft_lutpair166" *) 
  LUT2 #(
    .INIT(4'h2)) 
    RTR_i_2
       (.I0(\CNT1_reg[4]_0 ),
        .I1(\RXSTATES_reg[3] ),
        .O(\CNT1_reg[4]_1 ));
  FDCE RXBUS_d_reg
       (.C(clk),
        .CE(1'b1),
        .CLR(RXOUT_reg_3),
        .D(RXBUS),
        .Q(RXBUS_d));
  LUT6 #(
    .INIT(64'h0000000100000000)) 
    RXOUT_i_1
       (.I0(\CNT1_reg_n_0_[4] ),
        .I1(\CNT1_reg_n_0_[2] ),
        .I2(\CNT1_reg_n_0_[1] ),
        .I3(\CNT1_reg_n_0_[0] ),
        .I4(\CNT1_reg_n_0_[3] ),
        .I5(CNT1r1),
        .O(\CNT1_reg[4]_0 ));
  FDPE RXOUT_reg
       (.C(clk),
        .CE(\CNT1_reg[4]_0 ),
        .D(RXBUS),
        .PRE(RXOUT_reg_3),
        .Q(Sampled_din));
  (* SOFT_HLUTNM = "soft_lutpair166" *) 
  LUT4 #(
    .INIT(16'h2FAF)) 
    \RXSTATES[3]_i_1 
       (.I0(\CNT1_reg[4]_0 ),
        .I1(\RXSTATES_reg[3]_0 ),
        .I2(SRST_0),
        .I3(\RXSTATES_reg[3] ),
        .O(SRST_0_2));
  (* SOFT_HLUTNM = "soft_lutpair164" *) 
  LUT5 #(
    .INIT(32'h00010000)) 
    \TEC[8]_i_3 
       (.I0(CNT2[0]),
        .I1(CNT2[2]),
        .I2(CNT2[1]),
        .I3(CNT2[3]),
        .I4(\CNT1_reg[3]_0 ),
        .O(\CNT2_reg[0]_0 ));
  (* SOFT_HLUTNM = "soft_lutpair169" *) 
  LUT2 #(
    .INIT(4'hB)) 
    \TXSTATES[3]_i_1 
       (.I0(\CNT2_reg[0]_0 ),
        .I1(SRST_0),
        .O(SRST_0_1));
  LUT1 #(
    .INIT(2'h1)) 
    i__carry_i_1
       (.I0(CNT2[3]),
        .O(i__carry_i_1_n_0));
  LUT3 #(
    .INIT(8'h40)) 
    i__carry_i_2
       (.I0(CNT2[2]),
        .I1(CNT2[0]),
        .I2(CNT2[1]),
        .O(i__carry_i_2_n_0));
  (* SOFT_HLUTNM = "soft_lutpair169" *) 
  LUT2 #(
    .INIT(4'hB)) 
    lastvalue_i_1
       (.I0(Sampled_din),
        .I1(SRST_0),
        .O(RXOUT_reg_1));
endmodule

(* ORIG_REF_NAME = "Rengine" *) 
module design_1_FPGAPROJECT_0_0_Rengine_5
   (Sampled_din,
    E,
    RXBUS_d_reg_0,
    \CNT1_reg[3]_0 ,
    \CNT2_reg[3]_0 ,
    \RXSTATES_reg[3] ,
    \CNT1_reg[3]_1 ,
    SRST_1,
    RXOUT_reg_0,
    SRST_1_0,
    SRST_1_1,
    SRST_1_2,
    RXBUS,
    Tq,
    RXOUT_reg_1,
    \CNT1_reg[4]_0 ,
    \CNT1_reg[4]_1 ,
    \CNT1_reg[4]_2 ,
    Q,
    \RXSTATES_reg[3]_0 ,
    \RXSTATES_reg[3]_1 ,
    SRST,
    TPROP,
    TSEG1,
    TSEG2,
    SJW,
    \CNT2_reg[3]_1 );
  output Sampled_din;
  output [0:0]E;
  output RXBUS_d_reg_0;
  output \CNT1_reg[3]_0 ;
  output \CNT2_reg[3]_0 ;
  output \RXSTATES_reg[3] ;
  output \CNT1_reg[3]_1 ;
  output [0:0]SRST_1;
  output RXOUT_reg_0;
  output [0:0]SRST_1_0;
  output [0:0]SRST_1_1;
  output [0:0]SRST_1_2;
  input RXBUS;
  input Tq;
  input RXOUT_reg_1;
  input \CNT1_reg[4]_0 ;
  input \CNT1_reg[4]_1 ;
  input \CNT1_reg[4]_2 ;
  input [0:0]Q;
  input \RXSTATES_reg[3]_0 ;
  input \RXSTATES_reg[3]_1 ;
  input SRST;
  input [3:0]TPROP;
  input [3:0]TSEG1;
  input [3:0]TSEG2;
  input [2:0]SJW;
  input [0:0]\CNT2_reg[3]_1 ;

  wire \CNT1[0]_i_10_n_0 ;
  wire \CNT1[0]_i_11_n_0 ;
  wire \CNT1[0]_i_12_n_0 ;
  wire \CNT1[0]_i_13_n_0 ;
  wire \CNT1[0]_i_14_n_0 ;
  wire \CNT1[0]_i_15_n_0 ;
  wire \CNT1[0]_i_16_n_0 ;
  wire \CNT1[0]_i_17_n_0 ;
  wire \CNT1[0]_i_18_n_0 ;
  wire \CNT1[0]_i_19_n_0 ;
  wire \CNT1[0]_i_20_n_0 ;
  wire \CNT1[0]_i_21_n_0 ;
  wire \CNT1[0]_i_2_n_0 ;
  wire \CNT1[0]_i_3_n_0 ;
  wire \CNT1[0]_i_4_n_0 ;
  wire \CNT1[0]_i_5_n_0 ;
  wire \CNT1[0]_i_6_n_0 ;
  wire \CNT1[0]_i_7_n_0 ;
  wire \CNT1[0]_i_8_n_0 ;
  wire \CNT1[0]_i_9_n_0 ;
  wire \CNT1[1]_i_10_n_0 ;
  wire \CNT1[1]_i_11_n_0 ;
  wire \CNT1[1]_i_12_n_0 ;
  wire \CNT1[1]_i_13_n_0 ;
  wire \CNT1[1]_i_2_n_0 ;
  wire \CNT1[1]_i_3_n_0 ;
  wire \CNT1[1]_i_4_n_0 ;
  wire \CNT1[1]_i_5_n_0 ;
  wire \CNT1[1]_i_6_n_0 ;
  wire \CNT1[1]_i_7_n_0 ;
  wire \CNT1[1]_i_8_n_0 ;
  wire \CNT1[1]_i_9_n_0 ;
  wire \CNT1[2]_i_2_n_0 ;
  wire \CNT1[2]_i_3_n_0 ;
  wire \CNT1[2]_i_4_n_0 ;
  wire \CNT1[2]_i_5_n_0 ;
  wire \CNT1[2]_i_6_n_0 ;
  wire \CNT1[2]_i_7_n_0 ;
  wire \CNT1[2]_i_8_n_0 ;
  wire \CNT1[2]_i_9_n_0 ;
  wire \CNT1[3]_i_2_n_0 ;
  wire \CNT1[3]_i_3_n_0 ;
  wire \CNT1[3]_i_4_n_0 ;
  wire \CNT1[3]_i_5_n_0 ;
  wire \CNT1[3]_i_6_n_0 ;
  wire \CNT1[4]_i_10_n_0 ;
  wire \CNT1[4]_i_11_n_0 ;
  wire \CNT1[4]_i_12_n_0 ;
  wire \CNT1[4]_i_13_n_0 ;
  wire \CNT1[4]_i_14_n_0 ;
  wire \CNT1[4]_i_15_n_0 ;
  wire \CNT1[4]_i_1_n_0 ;
  wire \CNT1[4]_i_4_n_0 ;
  wire \CNT1[4]_i_6_n_0 ;
  wire \CNT1[4]_i_7_n_0 ;
  wire \CNT1[4]_i_8_n_0 ;
  wire \CNT1[4]_i_9_n_0 ;
  wire \CNT1_reg[3]_0 ;
  wire \CNT1_reg[3]_1 ;
  wire \CNT1_reg[4]_0 ;
  wire \CNT1_reg[4]_1 ;
  wire \CNT1_reg[4]_2 ;
  wire \CNT1_reg_n_0_[0] ;
  wire \CNT1_reg_n_0_[1] ;
  wire \CNT1_reg_n_0_[2] ;
  wire \CNT1_reg_n_0_[3] ;
  wire \CNT1_reg_n_0_[4] ;
  wire [4:0]CNT1r;
  wire \CNT1r1_inferred__0/i__carry_n_2 ;
  wire \CNT1r1_inferred__0/i__carry_n_3 ;
  wire [3:0]CNT2;
  wire \CNT2[0]_i_2_n_0 ;
  wire \CNT2[0]_i_3_n_0 ;
  wire \CNT2[0]_i_4_n_0 ;
  wire \CNT2[0]_i_5_n_0 ;
  wire \CNT2[1]_i_2_n_0 ;
  wire \CNT2[1]_i_3_n_0 ;
  wire \CNT2[1]_i_4_n_0 ;
  wire \CNT2[1]_i_5_n_0 ;
  wire \CNT2[1]_i_6_n_0 ;
  wire \CNT2[2]_i_2_n_0 ;
  wire \CNT2[2]_i_3_n_0 ;
  wire \CNT2[2]_i_4_n_0 ;
  wire \CNT2[2]_i_5_n_0 ;
  wire \CNT2[2]_i_6_n_0 ;
  wire \CNT2[2]_i_7_n_0 ;
  wire \CNT2[3]_i_3_n_0 ;
  wire \CNT2[3]_i_4_n_0 ;
  wire \CNT2[3]_i_5_n_0 ;
  wire \CNT2_reg[3]_0 ;
  wire [0:0]\CNT2_reg[3]_1 ;
  wire [3:0]CNT2r;
  wire [0:0]E;
  wire [0:0]Q;
  wire RXBUS;
  wire RXBUS_d;
  wire RXBUS_d_reg_0;
  wire RXOUT_reg_0;
  wire RXOUT_reg_1;
  wire \RXSTATES_reg[3] ;
  wire \RXSTATES_reg[3]_0 ;
  wire \RXSTATES_reg[3]_1 ;
  wire [2:0]SJW;
  wire SRST;
  wire [0:0]SRST_1;
  wire [0:0]SRST_1_0;
  wire [0:0]SRST_1_1;
  wire [0:0]SRST_1_2;
  wire Sampled_din;
  wire [3:0]TPROP;
  wire [3:0]TSEG1;
  wire [3:0]TSEG2;
  wire Tq;
  wire i__carry_i_1_n_0;
  wire i__carry_i_2_n_0;
  wire i__carry_i_3_n_0;
  wire [3:2]\NLW_CNT1r1_inferred__0/i__carry_CO_UNCONNECTED ;
  wire [3:0]\NLW_CNT1r1_inferred__0/i__carry_O_UNCONNECTED ;

  LUT6 #(
    .INIT(64'hBBB8FFFF8B880000)) 
    \CNT1[0]_i_1 
       (.I0(\CNT1[0]_i_2_n_0 ),
        .I1(\CNT1_reg[4]_0 ),
        .I2(\CNT1_reg[4]_1 ),
        .I3(\CNT1[0]_i_3_n_0 ),
        .I4(RXBUS_d_reg_0),
        .I5(\CNT1[0]_i_4_n_0 ),
        .O(CNT1r[0]));
  LUT6 #(
    .INIT(64'hEEFE00F0FFFFEEFE)) 
    \CNT1[0]_i_10 
       (.I0(SJW[0]),
        .I1(\CNT1[1]_i_5_n_0 ),
        .I2(SJW[2]),
        .I3(\CNT1[0]_i_17_n_0 ),
        .I4(SJW[1]),
        .I5(\CNT1[1]_i_6_n_0 ),
        .O(\CNT1[0]_i_10_n_0 ));
  LUT6 #(
    .INIT(64'h010101FF01010101)) 
    \CNT1[0]_i_11 
       (.I0(SJW[2]),
        .I1(SJW[0]),
        .I2(SJW[1]),
        .I3(TSEG1[2]),
        .I4(\CNT1[1]_i_5_n_0 ),
        .I5(\CNT1[0]_i_10_n_0 ),
        .O(\CNT1[0]_i_11_n_0 ));
  LUT6 #(
    .INIT(64'h18E700009EF71086)) 
    \CNT1[0]_i_12 
       (.I0(\CNT1[1]_i_5_n_0 ),
        .I1(\CNT1_reg_n_0_[0] ),
        .I2(\CNT1[0]_i_9_n_0 ),
        .I3(\CNT1[0]_i_18_n_0 ),
        .I4(\CNT1[1]_i_10_n_0 ),
        .I5(\CNT1[0]_i_6_n_0 ),
        .O(\CNT1[0]_i_12_n_0 ));
  LUT6 #(
    .INIT(64'h9696699669699669)) 
    \CNT1[0]_i_13 
       (.I0(\CNT1[0]_i_19_n_0 ),
        .I1(\CNT1[0]_i_20_n_0 ),
        .I2(\CNT1_reg_n_0_[2] ),
        .I3(TPROP[2]),
        .I4(TPROP[3]),
        .I5(\CNT1[0]_i_17_n_0 ),
        .O(\CNT1[0]_i_13_n_0 ));
  LUT6 #(
    .INIT(64'hFF44502B00BBAFD4)) 
    \CNT1[0]_i_14 
       (.I0(\CNT1_reg_n_0_[2] ),
        .I1(TPROP[2]),
        .I2(TSEG1[2]),
        .I3(TPROP[3]),
        .I4(TSEG1[3]),
        .I5(\CNT1_reg_n_0_[3] ),
        .O(\CNT1[0]_i_14_n_0 ));
  LUT6 #(
    .INIT(64'h8E8EE88EE8E88EE8)) 
    \CNT1[0]_i_15 
       (.I0(\CNT1[0]_i_19_n_0 ),
        .I1(\CNT1[0]_i_20_n_0 ),
        .I2(\CNT1_reg_n_0_[2] ),
        .I3(TPROP[2]),
        .I4(TPROP[3]),
        .I5(\CNT1[0]_i_17_n_0 ),
        .O(\CNT1[0]_i_15_n_0 ));
  LUT6 #(
    .INIT(64'hE87E7E17178181E8)) 
    \CNT1[0]_i_16 
       (.I0(\CNT1[0]_i_21_n_0 ),
        .I1(\CNT1[0]_i_15_n_0 ),
        .I2(\CNT1_reg_n_0_[3] ),
        .I3(TSEG1[3]),
        .I4(TPROP[3]),
        .I5(\CNT1_reg_n_0_[4] ),
        .O(\CNT1[0]_i_16_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair55" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \CNT1[0]_i_17 
       (.I0(TSEG1[2]),
        .I1(TSEG1[3]),
        .O(\CNT1[0]_i_17_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair56" *) 
  LUT5 #(
    .INIT(32'hBB4B44B4)) 
    \CNT1[0]_i_18 
       (.I0(TPROP[3]),
        .I1(TPROP[1]),
        .I2(TSEG1[1]),
        .I3(TSEG1[3]),
        .I4(\CNT1_reg_n_0_[1] ),
        .O(\CNT1[0]_i_18_n_0 ));
  LUT6 #(
    .INIT(64'h96FF969696960096)) 
    \CNT1[0]_i_19 
       (.I0(\CNT1[1]_i_13_n_0 ),
        .I1(\CNT1[1]_i_6_n_0 ),
        .I2(\CNT1_reg_n_0_[1] ),
        .I3(\CNT1[0]_i_9_n_0 ),
        .I4(\CNT1_reg_n_0_[0] ),
        .I5(\CNT1[1]_i_5_n_0 ),
        .O(\CNT1[0]_i_19_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair57" *) 
  LUT5 #(
    .INIT(32'h5555AA56)) 
    \CNT1[0]_i_2 
       (.I0(\CNT1[1]_i_5_n_0 ),
        .I1(TPROP[1]),
        .I2(TPROP[2]),
        .I3(TPROP[0]),
        .I4(TPROP[3]),
        .O(\CNT1[0]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair56" *) 
  LUT5 #(
    .INIT(32'hFBFFB0BB)) 
    \CNT1[0]_i_20 
       (.I0(TSEG1[3]),
        .I1(TSEG1[1]),
        .I2(TPROP[3]),
        .I3(TPROP[1]),
        .I4(\CNT1_reg_n_0_[1] ),
        .O(\CNT1[0]_i_20_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair55" *) 
  LUT5 #(
    .INIT(32'hFBFFB0BB)) 
    \CNT1[0]_i_21 
       (.I0(TSEG1[3]),
        .I1(TSEG1[2]),
        .I2(TPROP[3]),
        .I3(TPROP[2]),
        .I4(\CNT1_reg_n_0_[2] ),
        .O(\CNT1[0]_i_21_n_0 ));
  LUT6 #(
    .INIT(64'hAAAAAAAAEEEBBBEB)) 
    \CNT1[0]_i_3 
       (.I0(\CNT1[0]_i_5_n_0 ),
        .I1(\CNT1_reg_n_0_[0] ),
        .I2(\CNT1[0]_i_6_n_0 ),
        .I3(\CNT1[0]_i_7_n_0 ),
        .I4(\CNT1[0]_i_8_n_0 ),
        .I5(\CNT1_reg[3]_0 ),
        .O(\CNT1[0]_i_3_n_0 ));
  LUT5 #(
    .INIT(32'hF11F1111)) 
    \CNT1[0]_i_4 
       (.I0(\CNT1_reg[3]_0 ),
        .I1(\CNT1_reg_n_0_[0] ),
        .I2(\CNT1[1]_i_5_n_0 ),
        .I3(\CNT1[0]_i_9_n_0 ),
        .I4(\CNT2_reg[3]_0 ),
        .O(\CNT1[0]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h202020228A8A8A88)) 
    \CNT1[0]_i_5 
       (.I0(\CNT2_reg[3]_0 ),
        .I1(TPROP[3]),
        .I2(TPROP[0]),
        .I3(TPROP[2]),
        .I4(TPROP[1]),
        .I5(\CNT1[1]_i_5_n_0 ),
        .O(\CNT1[0]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h00000000BBBBBBFB)) 
    \CNT1[0]_i_6 
       (.I0(SJW[2]),
        .I1(SJW[0]),
        .I2(\CNT1[0]_i_10_n_0 ),
        .I3(TSEG1[2]),
        .I4(TSEG1[3]),
        .I5(\CNT1[0]_i_11_n_0 ),
        .O(\CNT1[0]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'h0000000032000032)) 
    \CNT1[0]_i_7 
       (.I0(\CNT1[0]_i_12_n_0 ),
        .I1(\CNT1[0]_i_13_n_0 ),
        .I2(\CNT1[2]_i_8_n_0 ),
        .I3(\CNT1[0]_i_14_n_0 ),
        .I4(\CNT1[0]_i_15_n_0 ),
        .I5(\CNT1[0]_i_16_n_0 ),
        .O(\CNT1[0]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'h00F1FF0EFF0E00F1)) 
    \CNT1[0]_i_8 
       (.I0(TPROP[1]),
        .I1(TPROP[2]),
        .I2(TPROP[0]),
        .I3(TPROP[3]),
        .I4(\CNT1[1]_i_5_n_0 ),
        .I5(\CNT1_reg_n_0_[0] ),
        .O(\CNT1[0]_i_8_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair62" *) 
  LUT4 #(
    .INIT(16'h4445)) 
    \CNT1[0]_i_9 
       (.I0(TPROP[3]),
        .I1(TPROP[0]),
        .I2(TPROP[2]),
        .I3(TPROP[1]),
        .O(\CNT1[0]_i_9_n_0 ));
  LUT6 #(
    .INIT(64'hBBB8FFFF8B880000)) 
    \CNT1[1]_i_1 
       (.I0(\CNT1[1]_i_2_n_0 ),
        .I1(\CNT1_reg[4]_0 ),
        .I2(\CNT1_reg[4]_1 ),
        .I3(\CNT1[1]_i_3_n_0 ),
        .I4(RXBUS_d_reg_0),
        .I5(\CNT1[1]_i_4_n_0 ),
        .O(CNT1r[1]));
  LUT6 #(
    .INIT(64'h00FF08FB00000808)) 
    \CNT1[1]_i_10 
       (.I0(TSEG1[1]),
        .I1(\CNT1[0]_i_10_n_0 ),
        .I2(TSEG1[2]),
        .I3(SJW[2]),
        .I4(TSEG1[3]),
        .I5(SJW[1]),
        .O(\CNT1[1]_i_10_n_0 ));
  LUT6 #(
    .INIT(64'h6996696969699669)) 
    \CNT1[1]_i_11 
       (.I0(\CNT1_reg_n_0_[1] ),
        .I1(\CNT1[1]_i_6_n_0 ),
        .I2(\CNT1[1]_i_13_n_0 ),
        .I3(\CNT1[0]_i_9_n_0 ),
        .I4(\CNT1_reg_n_0_[0] ),
        .I5(\CNT1[1]_i_5_n_0 ),
        .O(\CNT1[1]_i_11_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair57" *) 
  LUT5 #(
    .INIT(32'h000000F1)) 
    \CNT1[1]_i_12 
       (.I0(TPROP[1]),
        .I1(TPROP[2]),
        .I2(TPROP[0]),
        .I3(TPROP[3]),
        .I4(\CNT1[1]_i_5_n_0 ),
        .O(\CNT1[1]_i_12_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair62" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \CNT1[1]_i_13 
       (.I0(TPROP[1]),
        .I1(TPROP[3]),
        .O(\CNT1[1]_i_13_n_0 ));
  LUT6 #(
    .INIT(64'hFFFF44BA0000BB45)) 
    \CNT1[1]_i_2 
       (.I0(\CNT1[1]_i_5_n_0 ),
        .I1(TPROP[0]),
        .I2(TPROP[2]),
        .I3(TPROP[1]),
        .I4(TPROP[3]),
        .I5(\CNT1[1]_i_6_n_0 ),
        .O(\CNT1[1]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hFF141414)) 
    \CNT1[1]_i_3 
       (.I0(\CNT1_reg[3]_0 ),
        .I1(\CNT1[1]_i_7_n_0 ),
        .I2(\CNT1[1]_i_8_n_0 ),
        .I3(\CNT1[1]_i_2_n_0 ),
        .I4(\CNT2_reg[3]_0 ),
        .O(\CNT1[1]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF99999998)) 
    \CNT1[1]_i_4 
       (.I0(\CNT1_reg_n_0_[1] ),
        .I1(\CNT1_reg_n_0_[0] ),
        .I2(\CNT1_reg_n_0_[3] ),
        .I3(\CNT1_reg_n_0_[2] ),
        .I4(\CNT1_reg_n_0_[4] ),
        .I5(\CNT1[1]_i_9_n_0 ),
        .O(\CNT1[1]_i_4_n_0 ));
  LUT4 #(
    .INIT(16'hBBBA)) 
    \CNT1[1]_i_5 
       (.I0(TSEG1[3]),
        .I1(TSEG1[0]),
        .I2(TSEG1[2]),
        .I3(TSEG1[1]),
        .O(\CNT1[1]_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair61" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \CNT1[1]_i_6 
       (.I0(TSEG1[1]),
        .I1(TSEG1[3]),
        .O(\CNT1[1]_i_6_n_0 ));
  LUT5 #(
    .INIT(32'h10D0D010)) 
    \CNT1[1]_i_7 
       (.I0(\CNT1[0]_i_6_n_0 ),
        .I1(\CNT1[0]_i_7_n_0 ),
        .I2(\CNT1_reg_n_0_[0] ),
        .I3(\CNT1[1]_i_5_n_0 ),
        .I4(\CNT1[0]_i_9_n_0 ),
        .O(\CNT1[1]_i_7_n_0 ));
  LUT4 #(
    .INIT(16'hA656)) 
    \CNT1[1]_i_8 
       (.I0(\CNT1_reg_n_0_[1] ),
        .I1(\CNT1[1]_i_10_n_0 ),
        .I2(\CNT1[0]_i_7_n_0 ),
        .I3(\CNT1[1]_i_11_n_0 ),
        .O(\CNT1[1]_i_8_n_0 ));
  LUT6 #(
    .INIT(64'h8A208A8A208A2020)) 
    \CNT1[1]_i_9 
       (.I0(\CNT2_reg[3]_0 ),
        .I1(TSEG1[3]),
        .I2(TSEG1[1]),
        .I3(TPROP[3]),
        .I4(TPROP[1]),
        .I5(\CNT1[1]_i_12_n_0 ),
        .O(\CNT1[1]_i_9_n_0 ));
  LUT6 #(
    .INIT(64'hEEEBEEEBEEEBEEEA)) 
    \CNT1[2]_i_2 
       (.I0(\CNT1[2]_i_4_n_0 ),
        .I1(\CNT1_reg_n_0_[2] ),
        .I2(\CNT1_reg_n_0_[0] ),
        .I3(\CNT1_reg_n_0_[1] ),
        .I4(\CNT1_reg_n_0_[3] ),
        .I5(\CNT1_reg_n_0_[4] ),
        .O(\CNT1[2]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h000088FFFFFFF8FF)) 
    \CNT1[2]_i_3 
       (.I0(\CNT1_reg[4]_1 ),
        .I1(\CNT1[2]_i_5_n_0 ),
        .I2(\CNT2_reg[3]_0 ),
        .I3(\CNT1[2]_i_6_n_0 ),
        .I4(\CNT1_reg[4]_0 ),
        .I5(\CNT1[2]_i_7_n_0 ),
        .O(\CNT1[2]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h2822828828222822)) 
    \CNT1[2]_i_4 
       (.I0(\CNT2_reg[3]_0 ),
        .I1(\CNT1[3]_i_6_n_0 ),
        .I2(TSEG1[3]),
        .I3(TSEG1[2]),
        .I4(TPROP[3]),
        .I5(TPROP[2]),
        .O(\CNT1[2]_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair50" *) 
  LUT5 #(
    .INIT(32'hFFF0000E)) 
    \CNT1[2]_i_5 
       (.I0(\CNT1_reg_n_0_[4] ),
        .I1(\CNT1_reg_n_0_[3] ),
        .I2(\CNT1_reg_n_0_[1] ),
        .I3(\CNT1_reg_n_0_[0] ),
        .I4(\CNT1_reg_n_0_[2] ),
        .O(\CNT1[2]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hEFEFFEEFFEFEEFFE)) 
    \CNT1[2]_i_6 
       (.I0(\CNT1_reg[3]_0 ),
        .I1(\CNT1_reg[4]_1 ),
        .I2(\CNT1_reg_n_0_[2] ),
        .I3(\CNT1[2]_i_8_n_0 ),
        .I4(\CNT1[0]_i_7_n_0 ),
        .I5(\CNT1[2]_i_9_n_0 ),
        .O(\CNT1[2]_i_6_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair54" *) 
  LUT5 #(
    .INIT(32'hDD2D22D2)) 
    \CNT1[2]_i_7 
       (.I0(TPROP[2]),
        .I1(TPROP[3]),
        .I2(TSEG1[2]),
        .I3(TSEG1[3]),
        .I4(\CNT1[3]_i_6_n_0 ),
        .O(\CNT1[2]_i_7_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair61" *) 
  LUT4 #(
    .INIT(16'hA8AA)) 
    \CNT1[2]_i_8 
       (.I0(SJW[2]),
        .I1(TSEG1[2]),
        .I2(TSEG1[3]),
        .I3(\CNT1[0]_i_10_n_0 ),
        .O(\CNT1[2]_i_8_n_0 ));
  LUT6 #(
    .INIT(64'h8BFF008B8BFF8BFF)) 
    \CNT1[2]_i_9 
       (.I0(\CNT1[1]_i_11_n_0 ),
        .I1(\CNT1[0]_i_7_n_0 ),
        .I2(\CNT1[1]_i_10_n_0 ),
        .I3(\CNT1_reg_n_0_[1] ),
        .I4(\CNT1[4]_i_12_n_0 ),
        .I5(\CNT1_reg_n_0_[0] ),
        .O(\CNT1[2]_i_9_n_0 ));
  LUT6 #(
    .INIT(64'h0FEEFFFF0F440000)) 
    \CNT1[3]_i_1 
       (.I0(\CNT1_reg[4]_1 ),
        .I1(\CNT1[3]_i_2_n_0 ),
        .I2(\CNT1[3]_i_3_n_0 ),
        .I3(\CNT1_reg[4]_0 ),
        .I4(RXBUS_d_reg_0),
        .I5(\CNT1[3]_i_4_n_0 ),
        .O(CNT1r[3]));
  LUT3 #(
    .INIT(8'hBE)) 
    \CNT1[3]_i_2 
       (.I0(\CNT1[3]_i_5_n_0 ),
        .I1(\CNT1[4]_i_9_n_0 ),
        .I2(\CNT1_reg_n_0_[3] ),
        .O(\CNT1[3]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair54" *) 
  LUT5 #(
    .INIT(32'hCC13CC01)) 
    \CNT1[3]_i_3 
       (.I0(TPROP[2]),
        .I1(TPROP[3]),
        .I2(TSEG1[2]),
        .I3(TSEG1[3]),
        .I4(\CNT1[3]_i_6_n_0 ),
        .O(\CNT1[3]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hEEEEEEEBEEEEEEEA)) 
    \CNT1[3]_i_4 
       (.I0(\CNT1[3]_i_5_n_0 ),
        .I1(\CNT1_reg_n_0_[3] ),
        .I2(\CNT1_reg_n_0_[0] ),
        .I3(\CNT1_reg_n_0_[1] ),
        .I4(\CNT1_reg_n_0_[2] ),
        .I5(\CNT1_reg_n_0_[4] ),
        .O(\CNT1[3]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h0A0AAAA20A0AA2A0)) 
    \CNT1[3]_i_5 
       (.I0(\CNT2_reg[3]_0 ),
        .I1(\CNT1[3]_i_6_n_0 ),
        .I2(TSEG1[3]),
        .I3(TSEG1[2]),
        .I4(TPROP[3]),
        .I5(TPROP[2]),
        .O(\CNT1[3]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hDFDFDFDFCDCDDFDD)) 
    \CNT1[3]_i_6 
       (.I0(\CNT1[1]_i_6_n_0 ),
        .I1(TPROP[3]),
        .I2(TPROP[1]),
        .I3(TPROP[2]),
        .I4(TPROP[0]),
        .I5(\CNT1[1]_i_5_n_0 ),
        .O(\CNT1[3]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFDFFFFFF)) 
    \CNT1[4]_i_1 
       (.I0(RXBUS_d_reg_0),
        .I1(\CNT1_reg[4]_0 ),
        .I2(\CNT1[4]_i_4_n_0 ),
        .I3(\CNT1r1_inferred__0/i__carry_n_2 ),
        .I4(\CNT1_reg[3]_0 ),
        .I5(\CNT1_reg[4]_1 ),
        .O(\CNT1[4]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair63" *) 
  LUT3 #(
    .INIT(8'h80)) 
    \CNT1[4]_i_10 
       (.I0(\CNT2_reg[3]_0 ),
        .I1(TSEG1[3]),
        .I2(TPROP[3]),
        .O(\CNT1[4]_i_10_n_0 ));
  LUT6 #(
    .INIT(64'h00000002FFFFFFFE)) 
    \CNT1[4]_i_11 
       (.I0(\CNT1[1]_i_11_n_0 ),
        .I1(\CNT1[0]_i_13_n_0 ),
        .I2(\CNT1[4]_i_14_n_0 ),
        .I3(\CNT1[4]_i_15_n_0 ),
        .I4(\CNT1[0]_i_16_n_0 ),
        .I5(\CNT1[1]_i_10_n_0 ),
        .O(\CNT1[4]_i_11_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFE00000002)) 
    \CNT1[4]_i_12 
       (.I0(\CNT1[0]_i_8_n_0 ),
        .I1(\CNT1[0]_i_13_n_0 ),
        .I2(\CNT1[4]_i_14_n_0 ),
        .I3(\CNT1[4]_i_15_n_0 ),
        .I4(\CNT1[0]_i_16_n_0 ),
        .I5(\CNT1[0]_i_6_n_0 ),
        .O(\CNT1[4]_i_12_n_0 ));
  LUT6 #(
    .INIT(64'h00410041FFFFFFFF)) 
    \CNT1[4]_i_13 
       (.I0(\CNT1[0]_i_16_n_0 ),
        .I1(\CNT1[0]_i_15_n_0 ),
        .I2(\CNT1[0]_i_14_n_0 ),
        .I3(\CNT1[0]_i_13_n_0 ),
        .I4(\CNT1[0]_i_12_n_0 ),
        .I5(\CNT1[2]_i_8_n_0 ),
        .O(\CNT1[4]_i_13_n_0 ));
  LUT6 #(
    .INIT(64'h0000D0DDD0DDDDDD)) 
    \CNT1[4]_i_14 
       (.I0(\CNT1[2]_i_8_n_0 ),
        .I1(\CNT1[0]_i_13_n_0 ),
        .I2(\CNT1[0]_i_6_n_0 ),
        .I3(\CNT1[0]_i_8_n_0 ),
        .I4(\CNT1[1]_i_10_n_0 ),
        .I5(\CNT1[1]_i_11_n_0 ),
        .O(\CNT1[4]_i_14_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair53" *) 
  LUT5 #(
    .INIT(32'h69969669)) 
    \CNT1[4]_i_15 
       (.I0(\CNT1[0]_i_15_n_0 ),
        .I1(\CNT1_reg_n_0_[3] ),
        .I2(TSEG1[3]),
        .I3(TPROP[3]),
        .I4(\CNT1[0]_i_21_n_0 ),
        .O(\CNT1[4]_i_15_n_0 ));
  LUT6 #(
    .INIT(64'hBBB8FFFF8B880000)) 
    \CNT1[4]_i_2 
       (.I0(\CNT1[4]_i_6_n_0 ),
        .I1(\CNT1_reg[4]_0 ),
        .I2(\CNT1_reg[4]_1 ),
        .I3(\CNT1[4]_i_7_n_0 ),
        .I4(RXBUS_d_reg_0),
        .I5(\CNT1[4]_i_8_n_0 ),
        .O(CNT1r[4]));
  LUT3 #(
    .INIT(8'h80)) 
    \CNT1[4]_i_3 
       (.I0(\CNT1_reg[4]_2 ),
        .I1(RXBUS_d),
        .I2(Sampled_din),
        .O(RXBUS_d_reg_0));
  (* SOFT_HLUTNM = "soft_lutpair51" *) 
  LUT4 #(
    .INIT(16'h0001)) 
    \CNT1[4]_i_4 
       (.I0(CNT2[2]),
        .I1(CNT2[0]),
        .I2(CNT2[1]),
        .I3(CNT2[3]),
        .O(\CNT1[4]_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair50" *) 
  LUT5 #(
    .INIT(32'h00000001)) 
    \CNT1[4]_i_5 
       (.I0(\CNT1_reg_n_0_[3] ),
        .I1(\CNT1_reg_n_0_[0] ),
        .I2(\CNT1_reg_n_0_[1] ),
        .I3(\CNT1_reg_n_0_[2] ),
        .I4(\CNT1_reg_n_0_[4] ),
        .O(\CNT1_reg[3]_0 ));
  (* SOFT_HLUTNM = "soft_lutpair53" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \CNT1[4]_i_6 
       (.I0(TPROP[3]),
        .I1(TSEG1[3]),
        .O(\CNT1[4]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'h80FFFFFFFF808080)) 
    \CNT1[4]_i_7 
       (.I0(TPROP[3]),
        .I1(TSEG1[3]),
        .I2(\CNT2_reg[3]_0 ),
        .I3(\CNT1[4]_i_9_n_0 ),
        .I4(\CNT1_reg_n_0_[3] ),
        .I5(\CNT1_reg_n_0_[4] ),
        .O(\CNT1[4]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFEAAAAAAAA)) 
    \CNT1[4]_i_8 
       (.I0(\CNT1[4]_i_10_n_0 ),
        .I1(\CNT1_reg_n_0_[2] ),
        .I2(\CNT1_reg_n_0_[1] ),
        .I3(\CNT1_reg_n_0_[0] ),
        .I4(\CNT1_reg_n_0_[3] ),
        .I5(\CNT1_reg_n_0_[4] ),
        .O(\CNT1[4]_i_8_n_0 ));
  LUT6 #(
    .INIT(64'h4D44FFFF00000000)) 
    \CNT1[4]_i_9 
       (.I0(\CNT1[4]_i_11_n_0 ),
        .I1(\CNT1_reg_n_0_[1] ),
        .I2(\CNT1[4]_i_12_n_0 ),
        .I3(\CNT1_reg_n_0_[0] ),
        .I4(\CNT1[4]_i_13_n_0 ),
        .I5(\CNT1_reg_n_0_[2] ),
        .O(\CNT1[4]_i_9_n_0 ));
  FDCE \CNT1_reg[0] 
       (.C(Tq),
        .CE(\CNT1[4]_i_1_n_0 ),
        .CLR(RXOUT_reg_1),
        .D(CNT1r[0]),
        .Q(\CNT1_reg_n_0_[0] ));
  FDCE \CNT1_reg[1] 
       (.C(Tq),
        .CE(\CNT1[4]_i_1_n_0 ),
        .CLR(RXOUT_reg_1),
        .D(CNT1r[1]),
        .Q(\CNT1_reg_n_0_[1] ));
  FDCE \CNT1_reg[2] 
       (.C(Tq),
        .CE(\CNT1[4]_i_1_n_0 ),
        .CLR(RXOUT_reg_1),
        .D(CNT1r[2]),
        .Q(\CNT1_reg_n_0_[2] ));
  MUXF7 \CNT1_reg[2]_i_1 
       (.I0(\CNT1[2]_i_2_n_0 ),
        .I1(\CNT1[2]_i_3_n_0 ),
        .O(CNT1r[2]),
        .S(RXBUS_d_reg_0));
  FDCE \CNT1_reg[3] 
       (.C(Tq),
        .CE(\CNT1[4]_i_1_n_0 ),
        .CLR(RXOUT_reg_1),
        .D(CNT1r[3]),
        .Q(\CNT1_reg_n_0_[3] ));
  FDCE \CNT1_reg[4] 
       (.C(Tq),
        .CE(\CNT1[4]_i_1_n_0 ),
        .CLR(RXOUT_reg_1),
        .D(CNT1r[4]),
        .Q(\CNT1_reg_n_0_[4] ));
  CARRY4 \CNT1r1_inferred__0/i__carry 
       (.CI(1'b0),
        .CO({\NLW_CNT1r1_inferred__0/i__carry_CO_UNCONNECTED [3:2],\CNT1r1_inferred__0/i__carry_n_2 ,\CNT1r1_inferred__0/i__carry_n_3 }),
        .CYINIT(1'b1),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(\NLW_CNT1r1_inferred__0/i__carry_O_UNCONNECTED [3:0]),
        .S({1'b0,1'b0,i__carry_i_1_n_0,i__carry_i_2_n_0}));
  LUT6 #(
    .INIT(64'h40EF40E040EF4FEF)) 
    \CNT2[0]_i_1 
       (.I0(\CNT1_reg[4]_0 ),
        .I1(\CNT2[0]_i_2_n_0 ),
        .I2(RXBUS_d_reg_0),
        .I3(\CNT2[0]_i_3_n_0 ),
        .I4(\CNT1[4]_i_4_n_0 ),
        .I5(CNT2[0]),
        .O(CNT2r[0]));
  LUT6 #(
    .INIT(64'hA0EFAFEFA0EFA0E0)) 
    \CNT2[0]_i_2 
       (.I0(\CNT2[0]_i_4_n_0 ),
        .I1(\CNT1[4]_i_4_n_0 ),
        .I2(\CNT1_reg[4]_1 ),
        .I3(\CNT2[0]_i_3_n_0 ),
        .I4(\CNT2_reg[3]_0 ),
        .I5(\CNT2[0]_i_5_n_0 ),
        .O(\CNT2[0]_i_2_n_0 ));
  LUT4 #(
    .INIT(16'h4445)) 
    \CNT2[0]_i_3 
       (.I0(TSEG2[3]),
        .I1(TSEG2[0]),
        .I2(TSEG2[2]),
        .I3(TSEG2[1]),
        .O(\CNT2[0]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair59" *) 
  LUT4 #(
    .INIT(16'h9990)) 
    \CNT2[0]_i_4 
       (.I0(\CNT1[0]_i_6_n_0 ),
        .I1(CNT2[0]),
        .I2(\CNT2[3]_i_5_n_0 ),
        .I3(CNT2[3]),
        .O(\CNT2[0]_i_4_n_0 ));
  LUT3 #(
    .INIT(8'h74)) 
    \CNT2[0]_i_5 
       (.I0(CNT2[0]),
        .I1(\CNT1r1_inferred__0/i__carry_n_2 ),
        .I2(\CNT2[0]_i_4_n_0 ),
        .O(\CNT2[0]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h65FF6500650065FF)) 
    \CNT2[1]_i_2 
       (.I0(\CNT2[0]_i_3_n_0 ),
        .I1(TSEG2[3]),
        .I2(TSEG2[1]),
        .I3(\CNT1[4]_i_4_n_0 ),
        .I4(CNT2[0]),
        .I5(CNT2[1]),
        .O(\CNT2[1]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h4F4E5F5F4F4E0A0A)) 
    \CNT2[1]_i_3 
       (.I0(\CNT1_reg[4]_0 ),
        .I1(\CNT2[1]_i_4_n_0 ),
        .I2(i__carry_i_3_n_0),
        .I3(\CNT1[4]_i_4_n_0 ),
        .I4(\CNT1_reg[4]_1 ),
        .I5(\CNT2[1]_i_5_n_0 ),
        .O(\CNT2[1]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h9696969602960002)) 
    \CNT2[1]_i_4 
       (.I0(CNT2[1]),
        .I1(\CNT1[1]_i_10_n_0 ),
        .I2(\CNT2[1]_i_6_n_0 ),
        .I3(\CNT1[2]_i_8_n_0 ),
        .I4(CNT2[2]),
        .I5(CNT2[3]),
        .O(\CNT2[1]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h7447777774474444)) 
    \CNT2[1]_i_5 
       (.I0(i__carry_i_3_n_0),
        .I1(\CNT2_reg[3]_0 ),
        .I2(CNT2[1]),
        .I3(CNT2[0]),
        .I4(\CNT1r1_inferred__0/i__carry_n_2 ),
        .I5(\CNT2[1]_i_4_n_0 ),
        .O(\CNT2[1]_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair59" *) 
  LUT2 #(
    .INIT(4'h1)) 
    \CNT2[1]_i_6 
       (.I0(CNT2[0]),
        .I1(\CNT1[0]_i_6_n_0 ),
        .O(\CNT2[1]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'hEF40EF4FEF40E040)) 
    \CNT2[2]_i_1 
       (.I0(\CNT1_reg[4]_0 ),
        .I1(\CNT2[2]_i_2_n_0 ),
        .I2(RXBUS_d_reg_0),
        .I3(\CNT2[2]_i_3_n_0 ),
        .I4(\CNT1[4]_i_4_n_0 ),
        .I5(\CNT2[2]_i_4_n_0 ),
        .O(CNT2r[2]));
  LUT6 #(
    .INIT(64'hEFC0EFCFEFC0E0C0)) 
    \CNT2[2]_i_2 
       (.I0(\CNT1[4]_i_4_n_0 ),
        .I1(\CNT2[2]_i_5_n_0 ),
        .I2(\CNT1_reg[4]_1 ),
        .I3(\CNT2[2]_i_3_n_0 ),
        .I4(\CNT2_reg[3]_0 ),
        .I5(\CNT2[2]_i_6_n_0 ),
        .O(\CNT2[2]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair58" *) 
  LUT4 #(
    .INIT(16'hFEF0)) 
    \CNT2[2]_i_3 
       (.I0(TSEG2[1]),
        .I1(TSEG2[0]),
        .I2(TSEG2[3]),
        .I3(TSEG2[2]),
        .O(\CNT2[2]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair52" *) 
  LUT3 #(
    .INIT(8'hA9)) 
    \CNT2[2]_i_4 
       (.I0(CNT2[2]),
        .I1(CNT2[1]),
        .I2(CNT2[0]),
        .O(\CNT2[2]_i_4_n_0 ));
  LUT4 #(
    .INIT(16'h2C82)) 
    \CNT2[2]_i_5 
       (.I0(CNT2[3]),
        .I1(CNT2[2]),
        .I2(\CNT1[2]_i_8_n_0 ),
        .I3(\CNT2[2]_i_7_n_0 ),
        .O(\CNT2[2]_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair52" *) 
  LUT5 #(
    .INIT(32'hA9FFA900)) 
    \CNT2[2]_i_6 
       (.I0(CNT2[2]),
        .I1(CNT2[1]),
        .I2(CNT2[0]),
        .I3(\CNT1r1_inferred__0/i__carry_n_2 ),
        .I4(\CNT2[2]_i_5_n_0 ),
        .O(\CNT2[2]_i_6_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair60" *) 
  LUT4 #(
    .INIT(16'hBBB2)) 
    \CNT2[2]_i_7 
       (.I0(CNT2[1]),
        .I1(\CNT1[1]_i_10_n_0 ),
        .I2(CNT2[0]),
        .I3(\CNT1[0]_i_6_n_0 ),
        .O(\CNT2[2]_i_7_n_0 ));
  LUT5 #(
    .INIT(32'h10101F10)) 
    \CNT2[3]_i_2 
       (.I0(\CNT1_reg[4]_0 ),
        .I1(\CNT2[3]_i_3_n_0 ),
        .I2(RXBUS_d_reg_0),
        .I3(CNT2[3]),
        .I4(\CNT2[3]_i_4_n_0 ),
        .O(CNT2r[3]));
  LUT6 #(
    .INIT(64'h7F7A7F777F757F77)) 
    \CNT2[3]_i_3 
       (.I0(CNT2[3]),
        .I1(\CNT2[3]_i_5_n_0 ),
        .I2(\CNT1_reg[4]_1 ),
        .I3(\CNT2_reg[3]_0 ),
        .I4(\CNT1r1_inferred__0/i__carry_n_2 ),
        .I5(\CNT2[3]_i_4_n_0 ),
        .O(\CNT2[3]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair60" *) 
  LUT3 #(
    .INIT(8'h01)) 
    \CNT2[3]_i_4 
       (.I0(CNT2[1]),
        .I1(CNT2[0]),
        .I2(CNT2[2]),
        .O(\CNT2[3]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hBBB2FFFF0000BBB2)) 
    \CNT2[3]_i_5 
       (.I0(CNT2[1]),
        .I1(\CNT1[1]_i_10_n_0 ),
        .I2(CNT2[0]),
        .I3(\CNT1[0]_i_6_n_0 ),
        .I4(\CNT1[2]_i_8_n_0 ),
        .I5(CNT2[2]),
        .O(\CNT2[3]_i_5_n_0 ));
  FDCE \CNT2_reg[0] 
       (.C(Tq),
        .CE(\CNT2_reg[3]_1 ),
        .CLR(RXOUT_reg_1),
        .D(CNT2r[0]),
        .Q(CNT2[0]));
  FDCE \CNT2_reg[1] 
       (.C(Tq),
        .CE(\CNT2_reg[3]_1 ),
        .CLR(RXOUT_reg_1),
        .D(CNT2r[1]),
        .Q(CNT2[1]));
  MUXF7 \CNT2_reg[1]_i_1 
       (.I0(\CNT2[1]_i_2_n_0 ),
        .I1(\CNT2[1]_i_3_n_0 ),
        .O(CNT2r[1]),
        .S(RXBUS_d_reg_0));
  FDCE \CNT2_reg[2] 
       (.C(Tq),
        .CE(\CNT2_reg[3]_1 ),
        .CLR(RXOUT_reg_1),
        .D(CNT2r[2]),
        .Q(CNT2[2]));
  FDCE \CNT2_reg[3] 
       (.C(Tq),
        .CE(\CNT2_reg[3]_1 ),
        .CLR(RXOUT_reg_1),
        .D(CNT2r[3]),
        .Q(CNT2[3]));
  (* SOFT_HLUTNM = "soft_lutpair63" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \Cnt[3]_i_1__1 
       (.I0(\CNT2_reg[3]_0 ),
        .I1(SRST),
        .O(SRST_1_1));
  (* SOFT_HLUTNM = "soft_lutpair64" *) 
  LUT2 #(
    .INIT(4'hB)) 
    \Cnt[5]_i_1__0 
       (.I0(\CNT1_reg[3]_1 ),
        .I1(SRST),
        .O(SRST_1_0));
  (* SOFT_HLUTNM = "soft_lutpair49" *) 
  LUT3 #(
    .INIT(8'h08)) 
    RTR_i_2
       (.I0(\CNT1r1_inferred__0/i__carry_n_2 ),
        .I1(\CNT1_reg[3]_0 ),
        .I2(\RXSTATES_reg[3]_0 ),
        .O(\CNT1_reg[3]_1 ));
  FDCE RXBUS_d_reg
       (.C(Tq),
        .CE(1'b1),
        .CLR(RXOUT_reg_1),
        .D(RXBUS),
        .Q(RXBUS_d));
  LUT6 #(
    .INIT(64'h0000000100000000)) 
    RXOUT_i_1
       (.I0(\CNT1_reg_n_0_[4] ),
        .I1(\CNT1_reg_n_0_[2] ),
        .I2(\CNT1_reg_n_0_[1] ),
        .I3(\CNT1_reg_n_0_[0] ),
        .I4(\CNT1_reg_n_0_[3] ),
        .I5(\CNT1r1_inferred__0/i__carry_n_2 ),
        .O(E));
  FDPE RXOUT_reg
       (.C(Tq),
        .CE(E),
        .D(RXBUS),
        .PRE(RXOUT_reg_1),
        .Q(Sampled_din));
  (* SOFT_HLUTNM = "soft_lutpair49" *) 
  LUT5 #(
    .INIT(32'h08FF88FF)) 
    \RXSTATES[3]_i_1 
       (.I0(\CNT1_reg[3]_0 ),
        .I1(\CNT1r1_inferred__0/i__carry_n_2 ),
        .I2(\RXSTATES_reg[3]_1 ),
        .I3(SRST),
        .I4(\RXSTATES_reg[3]_0 ),
        .O(SRST_1));
  (* SOFT_HLUTNM = "soft_lutpair51" *) 
  LUT5 #(
    .INIT(32'h00010000)) 
    \TEC[8]_i_3 
       (.I0(CNT2[3]),
        .I1(CNT2[1]),
        .I2(CNT2[0]),
        .I3(CNT2[2]),
        .I4(\CNT1_reg[3]_0 ),
        .O(\CNT2_reg[3]_0 ));
  (* SOFT_HLUTNM = "soft_lutpair64" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \TOFILTERI[28]_i_7 
       (.I0(\CNT1_reg[3]_1 ),
        .I1(Q),
        .O(\RXSTATES_reg[3] ));
  (* SOFT_HLUTNM = "soft_lutpair65" *) 
  LUT2 #(
    .INIT(4'hB)) 
    \TXSTATES[3]_i_1 
       (.I0(\CNT2_reg[3]_0 ),
        .I1(SRST),
        .O(SRST_1_2));
  LUT1 #(
    .INIT(2'h1)) 
    i__carry_i_1
       (.I0(CNT2[3]),
        .O(i__carry_i_1_n_0));
  LUT6 #(
    .INIT(64'h0000099009900000)) 
    i__carry_i_2
       (.I0(\CNT2[2]_i_3_n_0 ),
        .I1(CNT2[2]),
        .I2(CNT2[1]),
        .I3(i__carry_i_3_n_0),
        .I4(CNT2[0]),
        .I5(\CNT2[0]_i_3_n_0 ),
        .O(i__carry_i_2_n_0));
  (* SOFT_HLUTNM = "soft_lutpair58" *) 
  LUT4 #(
    .INIT(16'h030D)) 
    i__carry_i_3
       (.I0(TSEG2[2]),
        .I1(TSEG2[0]),
        .I2(TSEG2[3]),
        .I3(TSEG2[1]),
        .O(i__carry_i_3_n_0));
  (* SOFT_HLUTNM = "soft_lutpair65" *) 
  LUT2 #(
    .INIT(4'hB)) 
    lastvalue_i_1
       (.I0(Sampled_din),
        .I1(SRST),
        .O(RXOUT_reg_0));
endmodule

(* ORIG_REF_NAME = "TFF" *) 
module design_1_FPGAPROJECT_0_0_TFF
   (q,
    RX,
    clk,
    q_reg);
  output q;
  input RX;
  input clk;
  input q_reg;

  wire RX;
  wire clk;
  wire d1_n_0;
  wire q;
  wire q_reg;

  design_1_FPGAPROJECT_0_0_dff d1
       (.RX(RX),
        .clk(clk),
        .q_reg_0(d1_n_0),
        .q_reg_1(q_reg));
  design_1_FPGAPROJECT_0_0_dff_1 d2
       (.clk(clk),
        .q(q),
        .q_reg_0(d1_n_0),
        .q_reg_1(q_reg));
endmodule

(* ORIG_REF_NAME = "TFF" *) 
module design_1_FPGAPROJECT_0_0_TFF_2
   (RXBUSs,
    RX,
    Tq,
    q_reg);
  output RXBUSs;
  input RX;
  input Tq;
  input q_reg;

  wire RX;
  wire RXBUSs;
  wire Tq;
  wire d1_n_0;
  wire q_reg;

  design_1_FPGAPROJECT_0_0_dff_11 d1
       (.RX(RX),
        .Tq(Tq),
        .q_reg_0(d1_n_0),
        .q_reg_1(q_reg));
  design_1_FPGAPROJECT_0_0_dff_12 d2
       (.RXBUSs(RXBUSs),
        .Tq(Tq),
        .q_reg_0(d1_n_0),
        .q_reg_1(q_reg));
endmodule

(* ORIG_REF_NAME = "TXMachine" *) 
module design_1_FPGAPROJECT_0_0_TXMachine
   (imTX,
    done_reg_0,
    req_Error_reg,
    \TXSTATES_reg[1]_0 ,
    req_Error_reg_0,
    req_Error_reg_1,
    \TXSTATES_reg[0]_0 ,
    \TXSTATES_reg[1]_1 ,
    RXOUT_reg,
    \TXSTATES_reg[0]_1 ,
    \TXSTATES_reg[2]_0 ,
    donefromtxr,
    E,
    clk,
    \CRC_RG_reg[0] ,
    SRST_0,
    IDE_TX_0,
    \serial_reg[4] ,
    \Cnt_reg[1]_0 ,
    req_Error_RX,
    \TEC[8]_i_17 ,
    \TEC[8]_i_17_0 ,
    Sampled_din,
    \TXSTATES_reg[0]_2 ,
    Q,
    \Cnt[0]_i_3 ,
    TRANSMITr,
    done_i_11,
    RTR_TX_0,
    D_Len_TX_0,
    done_i_11_0,
    ID_TX_0,
    data_TX_0,
    D);
  output imTX;
  output done_reg_0;
  output req_Error_reg;
  output \TXSTATES_reg[1]_0 ;
  output req_Error_reg_0;
  output req_Error_reg_1;
  output \TXSTATES_reg[0]_0 ;
  output \TXSTATES_reg[1]_1 ;
  output RXOUT_reg;
  output \TXSTATES_reg[0]_1 ;
  output \TXSTATES_reg[2]_0 ;
  output donefromtxr;
  input [0:0]E;
  input clk;
  input \CRC_RG_reg[0] ;
  input SRST_0;
  input IDE_TX_0;
  input \serial_reg[4] ;
  input \Cnt_reg[1]_0 ;
  input req_Error_RX;
  input \TEC[8]_i_17 ;
  input \TEC[8]_i_17_0 ;
  input Sampled_din;
  input \TXSTATES_reg[0]_2 ;
  input [1:0]Q;
  input \Cnt[0]_i_3 ;
  input TRANSMITr;
  input done_i_11;
  input RTR_TX_0;
  input [3:0]D_Len_TX_0;
  input done_i_11_0;
  input [28:0]ID_TX_0;
  input [63:0]data_TX_0;
  input [1:0]D;

  wire \CRC_RG_reg[0] ;
  wire \Cnt[0]_i_3 ;
  wire \Cnt[1]_i_4_n_0 ;
  wire \Cnt[2]_i_2_n_0 ;
  wire \Cnt[2]_i_5__0_n_0 ;
  wire \Cnt[3]_i_10_n_0 ;
  wire \Cnt[3]_i_2__0_n_0 ;
  wire \Cnt[3]_i_4_n_0 ;
  wire \Cnt[3]_i_5_n_0 ;
  wire \Cnt[4]_i_3__0_n_0 ;
  wire \Cnt[4]_i_4_n_0 ;
  wire \Cnt[5]_i_4_n_0 ;
  wire \Cnt[5]_i_8_n_0 ;
  wire \Cnt[5]_i_9_n_0 ;
  wire \Cnt_reg[1]_0 ;
  wire \Cnt_reg_n_0_[0] ;
  wire \Cnt_reg_n_0_[1] ;
  wire \Cnt_reg_n_0_[2] ;
  wire \Cnt_reg_n_0_[3] ;
  wire \Cnt_reg_n_0_[4] ;
  wire \Cnt_reg_n_0_[5] ;
  wire [1:0]D;
  wire [3:0]D_Len_TX_0;
  wire [0:0]E;
  wire IDE_TX_0;
  wire [28:0]ID_TX_0;
  wire [1:0]Q;
  wire RTR_TX_0;
  wire RXOUT_reg;
  wire SRST_0;
  wire Sampled_din;
  wire \State[0]_i_10_n_0 ;
  wire \State[0]_i_6_n_0 ;
  wire \TEC[8]_i_17 ;
  wire \TEC[8]_i_17_0 ;
  wire TRANSMITr;
  wire [3:0]TXSTATES;
  wire \TXSTATES[2]_i_3_n_0 ;
  wire \TXSTATES_reg[0]_0 ;
  wire \TXSTATES_reg[0]_1 ;
  wire \TXSTATES_reg[0]_2 ;
  wire \TXSTATES_reg[1]_0 ;
  wire \TXSTATES_reg[1]_1 ;
  wire \TXSTATES_reg[2]_0 ;
  wire TransBS_n_0;
  wire TransBS_n_1;
  wire TransBS_n_11;
  wire TransBS_n_12;
  wire TransBS_n_13;
  wire TransBS_n_14;
  wire TransBS_n_15;
  wire TransBS_n_16;
  wire TransBS_n_20;
  wire TransBS_n_8;
  wire TransBS_n_9;
  wire clk;
  wire [63:0]data_TX_0;
  wire done_i_11;
  wire done_i_11_0;
  wire done_i_15_n_0;
  wire done_i_16_n_0;
  wire done_i_17_n_0;
  wire done_i_18_n_0;
  wire done_i_19_n_0;
  wire done_i_20_n_0;
  wire done_i_2__0_n_0;
  wire done_i_6_n_0;
  wire done_i_9_n_0;
  wire done_reg_0;
  wire donefromtxr;
  wire imTX;
  wire imTX0_out;
  wire imTX_i_2_n_0;
  wire req_Error_RX;
  wire req_Error_reg;
  wire req_Error_reg_0;
  wire req_Error_reg_1;
  wire req_Errorr;
  wire req_Errorr_reg_n_0;
  wire \serial_reg[4] ;
  wire txcrc_n_0;
  wire txcrc_n_1;
  wire txcrc_n_2;
  wire txcrc_n_3;
  wire txcrc_n_4;
  wire txcrc_n_5;
  wire txcrc_n_6;
  wire txcrc_n_7;

  LUT2 #(
    .INIT(4'h6)) 
    \Cnt[1]_i_4 
       (.I0(\Cnt_reg_n_0_[0] ),
        .I1(\Cnt_reg_n_0_[1] ),
        .O(\Cnt[1]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h4040404E4E4E4E40)) 
    \Cnt[2]_i_2 
       (.I0(TXSTATES[1]),
        .I1(TXSTATES[0]),
        .I2(txcrc_n_4),
        .I3(\Cnt_reg_n_0_[0] ),
        .I4(\Cnt_reg_n_0_[1] ),
        .I5(\Cnt_reg_n_0_[2] ),
        .O(\Cnt[2]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair214" *) 
  LUT4 #(
    .INIT(16'hF8FF)) 
    \Cnt[2]_i_5__0 
       (.I0(TXSTATES[0]),
        .I1(txcrc_n_4),
        .I2(TXSTATES[1]),
        .I3(TXSTATES[2]),
        .O(\Cnt[2]_i_5__0_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair216" *) 
  LUT4 #(
    .INIT(16'h003E)) 
    \Cnt[3]_i_10 
       (.I0(TXSTATES[0]),
        .I1(TXSTATES[2]),
        .I2(TXSTATES[1]),
        .I3(TXSTATES[3]),
        .O(\Cnt[3]_i_10_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair213" *) 
  LUT5 #(
    .INIT(32'h55007500)) 
    \Cnt[3]_i_2__0 
       (.I0(TXSTATES[3]),
        .I1(txcrc_n_4),
        .I2(txcrc_n_5),
        .I3(TXSTATES[0]),
        .I4(TXSTATES[1]),
        .O(\Cnt[3]_i_2__0_n_0 ));
  LUT6 #(
    .INIT(64'h1D110000DDDDDDDD)) 
    \Cnt[3]_i_4 
       (.I0(txcrc_n_5),
        .I1(txcrc_n_4),
        .I2(RTR_TX_0),
        .I3(D_Len_TX_0[0]),
        .I4(TXSTATES[1]),
        .I5(\Cnt[3]_i_2__0_n_0 ),
        .O(\Cnt[3]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFF8FFFFFFFFF)) 
    \Cnt[3]_i_5 
       (.I0(TXSTATES[0]),
        .I1(txcrc_n_4),
        .I2(txcrc_n_5),
        .I3(TXSTATES[3]),
        .I4(TXSTATES[1]),
        .I5(TXSTATES[2]),
        .O(\Cnt[3]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h00000003FFFFFFFD)) 
    \Cnt[4]_i_3__0 
       (.I0(\Cnt_reg_n_0_[5] ),
        .I1(\Cnt_reg_n_0_[3] ),
        .I2(\Cnt_reg_n_0_[2] ),
        .I3(\Cnt_reg_n_0_[0] ),
        .I4(\Cnt_reg_n_0_[1] ),
        .I5(\Cnt_reg_n_0_[4] ),
        .O(\Cnt[4]_i_3__0_n_0 ));
  LUT6 #(
    .INIT(64'h2002200220022000)) 
    \Cnt[4]_i_4 
       (.I0(\Cnt[5]_i_9_n_0 ),
        .I1(RTR_TX_0),
        .I2(D_Len_TX_0[1]),
        .I3(D_Len_TX_0[0]),
        .I4(D_Len_TX_0[3]),
        .I5(D_Len_TX_0[2]),
        .O(\Cnt[4]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hAAAAAAAAAAAAAAA8)) 
    \Cnt[5]_i_4 
       (.I0(\Cnt_reg_n_0_[5] ),
        .I1(\Cnt_reg_n_0_[3] ),
        .I2(\Cnt_reg_n_0_[2] ),
        .I3(\Cnt_reg_n_0_[0] ),
        .I4(\Cnt_reg_n_0_[1] ),
        .I5(\Cnt_reg_n_0_[4] ),
        .O(\Cnt[5]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h4444440000000040)) 
    \Cnt[5]_i_8 
       (.I0(RTR_TX_0),
        .I1(\Cnt[5]_i_9_n_0 ),
        .I2(D_Len_TX_0[3]),
        .I3(D_Len_TX_0[1]),
        .I4(D_Len_TX_0[0]),
        .I5(D_Len_TX_0[2]),
        .O(\Cnt[5]_i_8_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair212" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \Cnt[5]_i_9 
       (.I0(txcrc_n_4),
        .I1(TXSTATES[0]),
        .O(\Cnt[5]_i_9_n_0 ));
  FDCE \Cnt_reg[0] 
       (.C(clk),
        .CE(TransBS_n_0),
        .CLR(\CRC_RG_reg[0] ),
        .D(TransBS_n_16),
        .Q(\Cnt_reg_n_0_[0] ));
  FDCE \Cnt_reg[1] 
       (.C(clk),
        .CE(TransBS_n_0),
        .CLR(\CRC_RG_reg[0] ),
        .D(TransBS_n_15),
        .Q(\Cnt_reg_n_0_[1] ));
  FDCE \Cnt_reg[2] 
       (.C(clk),
        .CE(TransBS_n_0),
        .CLR(\CRC_RG_reg[0] ),
        .D(TransBS_n_14),
        .Q(\Cnt_reg_n_0_[2] ));
  FDCE \Cnt_reg[3] 
       (.C(clk),
        .CE(TransBS_n_0),
        .CLR(\CRC_RG_reg[0] ),
        .D(TransBS_n_13),
        .Q(\Cnt_reg_n_0_[3] ));
  FDCE \Cnt_reg[4] 
       (.C(clk),
        .CE(TransBS_n_0),
        .CLR(\CRC_RG_reg[0] ),
        .D(TransBS_n_12),
        .Q(\Cnt_reg_n_0_[4] ));
  FDCE \Cnt_reg[5] 
       (.C(clk),
        .CE(TransBS_n_0),
        .CLR(\CRC_RG_reg[0] ),
        .D(TransBS_n_11),
        .Q(\Cnt_reg_n_0_[5] ));
  (* SOFT_HLUTNM = "soft_lutpair215" *) 
  LUT4 #(
    .INIT(16'hF7FB)) 
    \State[0]_i_10 
       (.I0(TXSTATES[2]),
        .I1(TXSTATES[1]),
        .I2(TXSTATES[3]),
        .I3(TXSTATES[0]),
        .O(\State[0]_i_10_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair217" *) 
  LUT4 #(
    .INIT(16'hFC01)) 
    \State[0]_i_6 
       (.I0(TXSTATES[0]),
        .I1(TXSTATES[2]),
        .I2(TXSTATES[1]),
        .I3(TXSTATES[3]),
        .O(\State[0]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'h0033300033BB0000)) 
    \TXSTATES[2]_i_3 
       (.I0(\Cnt_reg[1]_0 ),
        .I1(TXSTATES[3]),
        .I2(txcrc_n_4),
        .I3(TXSTATES[0]),
        .I4(TXSTATES[2]),
        .I5(TXSTATES[1]),
        .O(\TXSTATES[2]_i_3_n_0 ));
  FDCE \TXSTATES_reg[0] 
       (.C(clk),
        .CE(E),
        .CLR(\CRC_RG_reg[0] ),
        .D(TransBS_n_9),
        .Q(TXSTATES[0]));
  FDCE \TXSTATES_reg[1] 
       (.C(clk),
        .CE(E),
        .CLR(\CRC_RG_reg[0] ),
        .D(TransBS_n_8),
        .Q(TXSTATES[1]));
  FDCE \TXSTATES_reg[2] 
       (.C(clk),
        .CE(E),
        .CLR(\CRC_RG_reg[0] ),
        .D(D[0]),
        .Q(TXSTATES[2]));
  FDCE \TXSTATES_reg[3] 
       (.C(clk),
        .CE(E),
        .CLR(\CRC_RG_reg[0] ),
        .D(D[1]),
        .Q(TXSTATES[3]));
  design_1_FPGAPROJECT_0_0_bitstuffer TransBS
       (.\CRC_RG_reg[14] (txcrc_n_3),
        .\CRC_RG_reg[14]_0 (txcrc_n_2),
        .\Cnt[0]_i_2_0 (done_i_17_n_0),
        .\Cnt[0]_i_2_1 (\Cnt[5]_i_9_n_0 ),
        .\Cnt[0]_i_3_0 (Q),
        .\Cnt[0]_i_3_1 (\Cnt[0]_i_3 ),
        .\Cnt_reg[0] (\Cnt_reg_n_0_[0] ),
        .\Cnt_reg[1] (\Cnt_reg[1]_0 ),
        .\Cnt_reg[1]_0 (\Cnt[1]_i_4_n_0 ),
        .\Cnt_reg[2] (\Cnt[2]_i_2_n_0 ),
        .\Cnt_reg[2]_0 (\Cnt[2]_i_5__0_n_0 ),
        .\Cnt_reg[2]_1 (txcrc_n_1),
        .\Cnt_reg[3] (\Cnt[3]_i_2__0_n_0 ),
        .\Cnt_reg[3]_0 (\Cnt[3]_i_4_n_0 ),
        .\Cnt_reg[3]_1 (\Cnt[3]_i_5_n_0 ),
        .\Cnt_reg[4] (\Cnt[4]_i_3__0_n_0 ),
        .\Cnt_reg[4]_0 (\Cnt[4]_i_4_n_0 ),
        .\Cnt_reg[4]_1 (txcrc_n_7),
        .\Cnt_reg[5] (\Cnt[5]_i_4_n_0 ),
        .\Cnt_reg[5]_0 (\Cnt[5]_i_8_n_0 ),
        .D({TransBS_n_8,TransBS_n_9}),
        .\D_Len[0]_i_3 (\Cnt[3]_i_10_n_0 ),
        .E(TransBS_n_0),
        .IDE_TX_0(IDE_TX_0),
        .Q(TXSTATES),
        .\REC[8]_i_12 (\State[0]_i_6_n_0 ),
        .RXOUT_reg(RXOUT_reg),
        .SRST_0(SRST_0),
        .SRST_0_0({TransBS_n_11,TransBS_n_12,TransBS_n_13,TransBS_n_14,TransBS_n_15,TransBS_n_16}),
        .Sampled_din(Sampled_din),
        .\State[0]_i_2 (\TXSTATES_reg[1]_0 ),
        .\State[0]_i_4_0 (\State[0]_i_10_n_0 ),
        .\TEC[8]_i_17 (\TEC[8]_i_17 ),
        .\TEC[8]_i_17_0 (\TEC[8]_i_17_0 ),
        .\TXSTATES_reg[0] (\TXSTATES_reg[0]_0 ),
        .\TXSTATES_reg[0]_0 (\TXSTATES_reg[0]_1 ),
        .\TXSTATES_reg[0]_1 (\TXSTATES_reg[0]_2 ),
        .\TXSTATES_reg[1] (\TXSTATES_reg[1]_1 ),
        .\TXSTATES_reg[2] (\TXSTATES_reg[2]_0 ),
        .\TXSTATES_reg[2]_0 (\TXSTATES[2]_i_3_n_0 ),
        .\TXSTATES_reg[3] (TransBS_n_20),
        .clk(clk),
        .done_i_4_0(done_i_15_n_0),
        .done_i_4_1(done_i_16_n_0),
        .done_i_4_2(done_i_18_n_0),
        .done_i_4_3(done_i_19_n_0),
        .done_i_4_4(done_i_20_n_0),
        .done_reg(TransBS_n_1),
        .done_reg_0(txcrc_n_6),
        .done_reg_1(txcrc_n_4),
        .done_reg_2(done_i_2__0_n_0),
        .done_reg_3(done_i_6_n_0),
        .done_reg_4(done_reg_0),
        .done_reg_5(done_i_9_n_0),
        .imTX(imTX),
        .imTX0_out(imTX0_out),
        .imTX_reg(imTX_i_2_n_0),
        .req_Error_RX(req_Error_RX),
        .req_Error_reg(req_Error_reg),
        .req_Error_reg_0(req_Error_reg_0),
        .req_Error_reg_1(req_Error_reg_1),
        .req_Errorr(req_Errorr),
        .req_Errorr_reg(req_Errorr_reg_n_0),
        .\serial_reg[0]_0 (txcrc_n_0),
        .\serial_reg[0]_1 (\CRC_RG_reg[0] ),
        .\serial_reg[4]_0 (\serial_reg[4] ));
  (* SOFT_HLUTNM = "soft_lutpair215" *) 
  LUT4 #(
    .INIT(16'h0800)) 
    ack_error_i_5
       (.I0(TXSTATES[1]),
        .I1(TXSTATES[2]),
        .I2(TXSTATES[3]),
        .I3(TXSTATES[0]),
        .O(\TXSTATES_reg[1]_0 ));
  (* SOFT_HLUTNM = "soft_lutpair218" *) 
  LUT2 #(
    .INIT(4'hB)) 
    done_i_15
       (.I0(TXSTATES[2]),
        .I1(TXSTATES[1]),
        .O(done_i_15_n_0));
  (* SOFT_HLUTNM = "soft_lutpair213" *) 
  LUT2 #(
    .INIT(4'h1)) 
    done_i_16
       (.I0(TXSTATES[0]),
        .I1(txcrc_n_4),
        .O(done_i_16_n_0));
  LUT6 #(
    .INIT(64'h00000000FFFE0000)) 
    done_i_17
       (.I0(D_Len_TX_0[2]),
        .I1(D_Len_TX_0[3]),
        .I2(D_Len_TX_0[1]),
        .I3(D_Len_TX_0[0]),
        .I4(\Cnt[5]_i_9_n_0 ),
        .I5(RTR_TX_0),
        .O(done_i_17_n_0));
  (* SOFT_HLUTNM = "soft_lutpair214" *) 
  LUT4 #(
    .INIT(16'hF5D7)) 
    done_i_18
       (.I0(TXSTATES[2]),
        .I1(TXSTATES[1]),
        .I2(TXSTATES[0]),
        .I3(txcrc_n_4),
        .O(done_i_18_n_0));
  (* SOFT_HLUTNM = "soft_lutpair212" *) 
  LUT5 #(
    .INIT(32'h70707F0F)) 
    done_i_19
       (.I0(TRANSMITr),
        .I1(done_i_11),
        .I2(txcrc_n_4),
        .I3(done_i_11_0),
        .I4(TXSTATES[0]),
        .O(done_i_19_n_0));
  (* SOFT_HLUTNM = "soft_lutpair218" *) 
  LUT2 #(
    .INIT(4'hB)) 
    done_i_20
       (.I0(TXSTATES[2]),
        .I1(TXSTATES[3]),
        .O(done_i_20_n_0));
  (* SOFT_HLUTNM = "soft_lutpair216" *) 
  LUT4 #(
    .INIT(16'h0010)) 
    done_i_2__0
       (.I0(TXSTATES[0]),
        .I1(TXSTATES[3]),
        .I2(TXSTATES[1]),
        .I3(TXSTATES[2]),
        .O(done_i_2__0_n_0));
  LUT6 #(
    .INIT(64'hCFFE0000FFFFFFFF)) 
    done_i_6
       (.I0(TXSTATES[0]),
        .I1(TXSTATES[2]),
        .I2(TXSTATES[3]),
        .I3(TXSTATES[1]),
        .I4(\serial_reg[4] ),
        .I5(SRST_0),
        .O(done_i_6_n_0));
  LUT6 #(
    .INIT(64'h0000000000000008)) 
    done_i_9
       (.I0(TRANSMITr),
        .I1(done_i_11),
        .I2(TXSTATES[1]),
        .I3(TXSTATES[2]),
        .I4(TXSTATES[0]),
        .I5(TXSTATES[3]),
        .O(done_i_9_n_0));
  FDPE done_reg
       (.C(clk),
        .CE(1'b1),
        .D(TransBS_n_1),
        .PRE(\CRC_RG_reg[0] ),
        .Q(done_reg_0));
  LUT2 #(
    .INIT(4'h8)) 
    donefromtxr_i_1
       (.I0(SRST_0),
        .I1(done_reg_0),
        .O(donefromtxr));
  (* SOFT_HLUTNM = "soft_lutpair217" *) 
  LUT4 #(
    .INIT(16'h0001)) 
    imTX_i_2
       (.I0(TXSTATES[1]),
        .I1(TXSTATES[2]),
        .I2(TXSTATES[0]),
        .I3(TXSTATES[3]),
        .O(imTX_i_2_n_0));
  FDCE imTX_reg
       (.C(clk),
        .CE(E),
        .CLR(\CRC_RG_reg[0] ),
        .D(imTX0_out),
        .Q(imTX));
  FDCE req_Errorr_reg
       (.C(clk),
        .CE(E),
        .CLR(\CRC_RG_reg[0] ),
        .D(req_Errorr),
        .Q(req_Errorr_reg_n_0));
  design_1_FPGAPROJECT_0_0_CRC txcrc
       (.\CRC_RG_reg[0]_0 (\CRC_RG_reg[0] ),
        .\CRC_RG_reg[14]_0 (\serial_reg[4] ),
        .\Cnt_reg[0] (txcrc_n_1),
        .\Cnt_reg[2] (txcrc_n_4),
        .\Cnt_reg[3] (txcrc_n_5),
        .D_Len_TX_0(D_Len_TX_0),
        .E(TransBS_n_20),
        .IDE_TX_0(IDE_TX_0),
        .ID_TX_0(ID_TX_0),
        .Q(TXSTATES),
        .RTR_TX_0(RTR_TX_0),
        .SRST_0(SRST_0),
        .SRST_0_0(txcrc_n_3),
        .\TXSTATES_reg[0] (txcrc_n_6),
        .\TXSTATES_reg[2] (txcrc_n_7),
        .\TXSTATES_reg[3] (txcrc_n_0),
        .\TXSTATES_reg[3]_0 (txcrc_n_2),
        .clk(clk),
        .data_TX_0(data_TX_0),
        .\serial[0]_i_12_0 ({\Cnt_reg_n_0_[5] ,\Cnt_reg_n_0_[4] ,\Cnt_reg_n_0_[3] ,\Cnt_reg_n_0_[2] ,\Cnt_reg_n_0_[1] ,\Cnt_reg_n_0_[0] }));
endmodule

(* ORIG_REF_NAME = "TXMachine" *) 
module design_1_FPGAPROJECT_0_0_TXMachine_7
   (imTX,
    done_reg_0,
    \TEC_reg[8] ,
    req_Error_reg,
    \TXSTATES_reg[1]_0 ,
    req_Error_reg_0,
    req_Error_reg_1,
    \TXSTATES_reg[3]_0 ,
    \TXSTATES_reg[1]_1 ,
    RXOUT_reg,
    \TXSTATES_reg[3]_1 ,
    \TXSTATES_reg[3]_2 ,
    \TXSTATES_reg[2]_0 ,
    \TXSTATES_reg[1]_2 ,
    donefromtxr,
    imTX_reg_0,
    TRANSMIT_1,
    req_Error_reg_2,
    imTX_reg_1,
    E,
    Tq,
    \CRC_RG_reg[0] ,
    TEC,
    req_Error_RX,
    \Cnt_reg[1]_0 ,
    \REC[0]_i_5 ,
    \REC[0]_i_5_0 ,
    Sampled_din,
    SRST,
    IDE_TX,
    \Cnt[0]_i_2 ,
    \Cnt_reg[5]_0 ,
    TRANSMITr,
    done_i_12,
    done_i_12_0,
    RTR_TX,
    D_Len_TX,
    data_TX,
    ID_TX,
    \TEC[8]_i_5 ,
    TRANSMIT,
    TRANSMIT_reg,
    done_TXr,
    \REC_reg[8] ,
    D);
  output imTX;
  output done_reg_0;
  output \TEC_reg[8] ;
  output req_Error_reg;
  output \TXSTATES_reg[1]_0 ;
  output req_Error_reg_0;
  output req_Error_reg_1;
  output \TXSTATES_reg[3]_0 ;
  output \TXSTATES_reg[1]_1 ;
  output RXOUT_reg;
  output \TXSTATES_reg[3]_1 ;
  output \TXSTATES_reg[3]_2 ;
  output \TXSTATES_reg[2]_0 ;
  output \TXSTATES_reg[1]_2 ;
  output donefromtxr;
  output imTX_reg_0;
  output TRANSMIT_1;
  output req_Error_reg_2;
  output imTX_reg_1;
  input [0:0]E;
  input Tq;
  input \CRC_RG_reg[0] ;
  input [1:0]TEC;
  input req_Error_RX;
  input \Cnt_reg[1]_0 ;
  input \REC[0]_i_5 ;
  input \REC[0]_i_5_0 ;
  input Sampled_din;
  input SRST;
  input IDE_TX;
  input \Cnt[0]_i_2 ;
  input \Cnt_reg[5]_0 ;
  input TRANSMITr;
  input done_i_12;
  input done_i_12_0;
  input RTR_TX;
  input [3:0]D_Len_TX;
  input [63:0]data_TX;
  input [28:0]ID_TX;
  input \TEC[8]_i_5 ;
  input TRANSMIT;
  input TRANSMIT_reg;
  input done_TXr;
  input \REC_reg[8] ;
  input [3:0]D;

  wire \CRC_RG[14]_i_12_n_0 ;
  wire \CRC_RG[14]_i_9_n_0 ;
  wire \CRC_RG_reg[0] ;
  wire \Cnt[0]_i_2 ;
  wire \Cnt[0]_i_3_n_0 ;
  wire \Cnt[0]_i_5_n_0 ;
  wire \Cnt[1]_i_4__0_n_0 ;
  wire \Cnt[1]_i_5_n_0 ;
  wire \Cnt[1]_i_6__0_n_0 ;
  wire \Cnt[1]_i_8_n_0 ;
  wire \Cnt[2]_i_2__0_n_0 ;
  wire \Cnt[3]_i_2__1_n_0 ;
  wire \Cnt[3]_i_4_n_0 ;
  wire \Cnt[4]_i_3__0_n_0 ;
  wire \Cnt[4]_i_5_n_0 ;
  wire \Cnt[5]_i_10_n_0 ;
  wire \Cnt[5]_i_5_n_0 ;
  wire \Cnt[5]_i_9_n_0 ;
  wire \Cnt_reg[1]_0 ;
  wire \Cnt_reg[5]_0 ;
  wire \Cnt_reg_n_0_[0] ;
  wire \Cnt_reg_n_0_[1] ;
  wire \Cnt_reg_n_0_[2] ;
  wire \Cnt_reg_n_0_[3] ;
  wire \Cnt_reg_n_0_[4] ;
  wire \Cnt_reg_n_0_[5] ;
  wire [3:0]D;
  wire [3:0]D_Len_TX;
  wire [0:0]E;
  wire IDE_TX;
  wire [28:0]ID_TX;
  wire \REC[0]_i_5 ;
  wire \REC[0]_i_5_0 ;
  wire \REC_reg[8] ;
  wire RTR_TX;
  wire RXOUT_reg;
  wire SRST;
  wire Sampled_din;
  wire \State[0]_i_11_n_0 ;
  wire \State[0]_i_7_n_0 ;
  wire [1:0]TEC;
  wire \TEC[8]_i_5 ;
  wire \TEC_reg[8] ;
  wire TRANSMIT;
  wire TRANSMIT_1;
  wire TRANSMIT_reg;
  wire TRANSMITr;
  wire [3:0]TXSTATES;
  wire \TXSTATES[1]_i_4_n_0 ;
  wire \TXSTATES[2]_i_3_n_0 ;
  wire \TXSTATES_reg[1]_0 ;
  wire \TXSTATES_reg[1]_1 ;
  wire \TXSTATES_reg[1]_2 ;
  wire \TXSTATES_reg[2]_0 ;
  wire \TXSTATES_reg[3]_0 ;
  wire \TXSTATES_reg[3]_1 ;
  wire \TXSTATES_reg[3]_2 ;
  wire TX_INST_0_i_4_n_0;
  wire TX_INST_0_i_5_n_0;
  wire Tq;
  wire TransBS_n_13;
  wire TransBS_n_14;
  wire TransBS_n_15;
  wire TransBS_n_16;
  wire TransBS_n_17;
  wire TransBS_n_18;
  wire TransBS_n_19;
  wire TransBS_n_20;
  wire TransBS_n_21;
  wire TransBS_n_22;
  wire TransBS_n_23;
  wire TransBS_n_24;
  wire TransBS_n_25;
  wire TransBS_n_26;
  wire TransBS_n_27;
  wire TransBS_n_28;
  wire TransBS_n_29;
  wire TransBS_n_30;
  wire TransBS_n_31;
  wire [63:0]data_TX;
  wire done_TXr;
  wire done_i_10_n_0;
  wire done_i_12;
  wire done_i_12_0;
  wire done_i_13_n_0;
  wire done_i_16_n_0;
  wire done_i_17_n_0;
  wire done_i_18_n_0;
  wire done_i_19_n_0;
  wire done_i_2__0_n_0;
  wire done_i_6_n_0;
  wire done_i_9_n_0;
  wire done_reg_0;
  wire donefromtxr;
  wire imTX;
  wire imTX0_out;
  wire imTX_i_2_n_0;
  wire imTX_reg_0;
  wire imTX_reg_1;
  wire req_Error_RX;
  wire req_Error_reg;
  wire req_Error_reg_0;
  wire req_Error_reg_1;
  wire req_Error_reg_2;
  wire req_Errorr;
  wire req_Errorr_reg_n_0;
  wire \serial[0]_i_13_n_0 ;
  wire \serial[0]_i_34_n_0 ;
  wire txcrc_n_0;
  wire txcrc_n_1;
  wire txcrc_n_2;
  wire txcrc_n_3;
  wire txcrc_n_4;
  wire txcrc_n_5;

  LUT6 #(
    .INIT(64'h44444444444FF444)) 
    \CRC_RG[14]_i_12 
       (.I0(TransBS_n_20),
        .I1(RTR_TX),
        .I2(\Cnt_reg_n_0_[0] ),
        .I3(\Cnt_reg_n_0_[1] ),
        .I4(\Cnt_reg_n_0_[2] ),
        .I5(\serial[0]_i_34_n_0 ),
        .O(\CRC_RG[14]_i_12_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF001500BF)) 
    \CRC_RG[14]_i_9 
       (.I0(TransBS_n_25),
        .I1(TransBS_n_20),
        .I2(TransBS_n_24),
        .I3(\CRC_RG[14]_i_12_n_0 ),
        .I4(TransBS_n_23),
        .I5(\serial[0]_i_13_n_0 ),
        .O(\CRC_RG[14]_i_9_n_0 ));
  LUT6 #(
    .INIT(64'h00000000FFFFFFFE)) 
    \Cnt[0]_i_3 
       (.I0(\Cnt_reg_n_0_[4] ),
        .I1(\Cnt_reg_n_0_[5] ),
        .I2(\Cnt_reg_n_0_[3] ),
        .I3(\Cnt_reg_n_0_[1] ),
        .I4(\Cnt_reg_n_0_[2] ),
        .I5(\Cnt_reg_n_0_[0] ),
        .O(\Cnt[0]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h00000000FFFE0000)) 
    \Cnt[0]_i_5 
       (.I0(D_Len_TX[2]),
        .I1(D_Len_TX[3]),
        .I2(D_Len_TX[1]),
        .I3(D_Len_TX[0]),
        .I4(\Cnt[5]_i_10_n_0 ),
        .I5(RTR_TX),
        .O(\Cnt[0]_i_5_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \Cnt[1]_i_4__0 
       (.I0(\Cnt_reg_n_0_[0] ),
        .I1(\Cnt_reg_n_0_[1] ),
        .O(\Cnt[1]_i_4__0_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair109" *) 
  LUT4 #(
    .INIT(16'hFF5D)) 
    \Cnt[1]_i_5 
       (.I0(TXSTATES[2]),
        .I1(TXSTATES[0]),
        .I2(TransBS_n_20),
        .I3(TXSTATES[1]),
        .O(\Cnt[1]_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair105" *) 
  LUT5 #(
    .INIT(32'h0001FFFF)) 
    \Cnt[1]_i_6__0 
       (.I0(TXSTATES[2]),
        .I1(TXSTATES[1]),
        .I2(TXSTATES[3]),
        .I3(TXSTATES[0]),
        .I4(SRST),
        .O(\Cnt[1]_i_6__0_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \Cnt[1]_i_8 
       (.I0(TXSTATES[0]),
        .I1(TXSTATES[1]),
        .O(\Cnt[1]_i_8_n_0 ));
  LUT6 #(
    .INIT(64'h1E001E001EFF0000)) 
    \Cnt[2]_i_2__0 
       (.I0(\Cnt_reg_n_0_[0] ),
        .I1(\Cnt_reg_n_0_[1] ),
        .I2(\Cnt_reg_n_0_[2] ),
        .I3(TransBS_n_20),
        .I4(TXSTATES[0]),
        .I5(TXSTATES[1]),
        .O(\Cnt[2]_i_2__0_n_0 ));
  LUT6 #(
    .INIT(64'hF0F0F0F0F0F0F00E)) 
    \Cnt[3]_i_2__1 
       (.I0(\Cnt_reg_n_0_[4] ),
        .I1(\Cnt_reg_n_0_[5] ),
        .I2(\Cnt_reg_n_0_[3] ),
        .I3(\Cnt_reg_n_0_[0] ),
        .I4(\Cnt_reg_n_0_[1] ),
        .I5(\Cnt_reg_n_0_[2] ),
        .O(\Cnt[3]_i_2__1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair110" *) 
  LUT4 #(
    .INIT(16'hBBFB)) 
    \Cnt[3]_i_4 
       (.I0(TransBS_n_20),
        .I1(TXSTATES[0]),
        .I2(D_Len_TX[0]),
        .I3(RTR_TX),
        .O(\Cnt[3]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h555555555555555B)) 
    \Cnt[4]_i_3__0 
       (.I0(\Cnt_reg_n_0_[4] ),
        .I1(\Cnt_reg_n_0_[5] ),
        .I2(\Cnt_reg_n_0_[3] ),
        .I3(\Cnt_reg_n_0_[0] ),
        .I4(\Cnt_reg_n_0_[1] ),
        .I5(\Cnt_reg_n_0_[2] ),
        .O(\Cnt[4]_i_3__0_n_0 ));
  LUT6 #(
    .INIT(64'hDFFDDFFDDFFDDFFF)) 
    \Cnt[4]_i_5 
       (.I0(\Cnt[5]_i_10_n_0 ),
        .I1(RTR_TX),
        .I2(D_Len_TX[1]),
        .I3(D_Len_TX[0]),
        .I4(D_Len_TX[3]),
        .I5(D_Len_TX[2]),
        .O(\Cnt[4]_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair104" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \Cnt[5]_i_10 
       (.I0(TXSTATES[0]),
        .I1(TransBS_n_20),
        .O(\Cnt[5]_i_10_n_0 ));
  LUT6 #(
    .INIT(64'h5555555555555557)) 
    \Cnt[5]_i_5 
       (.I0(\Cnt_reg_n_0_[5] ),
        .I1(\Cnt_reg_n_0_[3] ),
        .I2(\Cnt_reg_n_0_[0] ),
        .I3(\Cnt_reg_n_0_[1] ),
        .I4(\Cnt_reg_n_0_[2] ),
        .I5(\Cnt_reg_n_0_[4] ),
        .O(\Cnt[5]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h4444440000000040)) 
    \Cnt[5]_i_9 
       (.I0(RTR_TX),
        .I1(\Cnt[5]_i_10_n_0 ),
        .I2(D_Len_TX[3]),
        .I3(D_Len_TX[1]),
        .I4(D_Len_TX[0]),
        .I5(D_Len_TX[2]),
        .O(\Cnt[5]_i_9_n_0 ));
  FDCE \Cnt_reg[0] 
       (.C(Tq),
        .CE(TransBS_n_31),
        .CLR(\CRC_RG_reg[0] ),
        .D(TransBS_n_19),
        .Q(\Cnt_reg_n_0_[0] ));
  FDCE \Cnt_reg[1] 
       (.C(Tq),
        .CE(TransBS_n_31),
        .CLR(\CRC_RG_reg[0] ),
        .D(TransBS_n_18),
        .Q(\Cnt_reg_n_0_[1] ));
  FDCE \Cnt_reg[2] 
       (.C(Tq),
        .CE(TransBS_n_31),
        .CLR(\CRC_RG_reg[0] ),
        .D(TransBS_n_17),
        .Q(\Cnt_reg_n_0_[2] ));
  FDCE \Cnt_reg[3] 
       (.C(Tq),
        .CE(TransBS_n_31),
        .CLR(\CRC_RG_reg[0] ),
        .D(TransBS_n_16),
        .Q(\Cnt_reg_n_0_[3] ));
  FDCE \Cnt_reg[4] 
       (.C(Tq),
        .CE(TransBS_n_31),
        .CLR(\CRC_RG_reg[0] ),
        .D(TransBS_n_15),
        .Q(\Cnt_reg_n_0_[4] ));
  FDCE \Cnt_reg[5] 
       (.C(Tq),
        .CE(TransBS_n_31),
        .CLR(\CRC_RG_reg[0] ),
        .D(TransBS_n_14),
        .Q(\Cnt_reg_n_0_[5] ));
  (* SOFT_HLUTNM = "soft_lutpair112" *) 
  LUT2 #(
    .INIT(4'h1)) 
    \REC[8]_i_12 
       (.I0(imTX),
        .I1(\TEC[8]_i_5 ),
        .O(imTX_reg_1));
  LUT3 #(
    .INIT(8'h45)) 
    \REC[8]_i_5 
       (.I0(imTX_reg_1),
        .I1(\REC_reg[8] ),
        .I2(req_Error_RX),
        .O(req_Error_reg_2));
  (* SOFT_HLUTNM = "soft_lutpair107" *) 
  LUT4 #(
    .INIT(16'hF7FB)) 
    \State[0]_i_11 
       (.I0(TXSTATES[2]),
        .I1(TXSTATES[1]),
        .I2(TXSTATES[3]),
        .I3(TXSTATES[0]),
        .O(\State[0]_i_11_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair105" *) 
  LUT4 #(
    .INIT(16'hE0E1)) 
    \State[0]_i_7 
       (.I0(TXSTATES[2]),
        .I1(TXSTATES[1]),
        .I2(TXSTATES[3]),
        .I3(TXSTATES[0]),
        .O(\State[0]_i_7_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair112" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \TEC[8]_i_14 
       (.I0(imTX),
        .I1(\TEC[8]_i_5 ),
        .O(imTX_reg_0));
  LUT5 #(
    .INIT(32'hF8FF8888)) 
    TRANSMITr_i_1
       (.I0(TRANSMIT),
        .I1(TRANSMIT_reg),
        .I2(done_TXr),
        .I3(done_reg_0),
        .I4(TRANSMITr),
        .O(TRANSMIT_1));
  (* SOFT_HLUTNM = "soft_lutpair109" *) 
  LUT3 #(
    .INIT(8'h45)) 
    \TXSTATES[1]_i_4 
       (.I0(TXSTATES[1]),
        .I1(TransBS_n_20),
        .I2(TXSTATES[0]),
        .O(\TXSTATES[1]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h000C00001CCC1CCC)) 
    \TXSTATES[2]_i_3 
       (.I0(TransBS_n_20),
        .I1(TXSTATES[2]),
        .I2(TXSTATES[0]),
        .I3(TXSTATES[1]),
        .I4(\Cnt_reg[1]_0 ),
        .I5(TXSTATES[3]),
        .O(\TXSTATES[2]_i_3_n_0 ));
  FDCE \TXSTATES_reg[0] 
       (.C(Tq),
        .CE(E),
        .CLR(\CRC_RG_reg[0] ),
        .D(D[0]),
        .Q(TXSTATES[0]));
  FDCE \TXSTATES_reg[1] 
       (.C(Tq),
        .CE(E),
        .CLR(\CRC_RG_reg[0] ),
        .D(D[1]),
        .Q(TXSTATES[1]));
  FDCE \TXSTATES_reg[2] 
       (.C(Tq),
        .CE(E),
        .CLR(\CRC_RG_reg[0] ),
        .D(D[2]),
        .Q(TXSTATES[2]));
  FDCE \TXSTATES_reg[3] 
       (.C(Tq),
        .CE(E),
        .CLR(\CRC_RG_reg[0] ),
        .D(D[3]),
        .Q(TXSTATES[3]));
  (* SOFT_HLUTNM = "soft_lutpair106" *) 
  LUT4 #(
    .INIT(16'h003E)) 
    TX_INST_0_i_4
       (.I0(TXSTATES[0]),
        .I1(TXSTATES[2]),
        .I2(TXSTATES[1]),
        .I3(TXSTATES[3]),
        .O(TX_INST_0_i_4_n_0));
  LUT6 #(
    .INIT(64'hFFFFFBFFAFAFABAF)) 
    TX_INST_0_i_5
       (.I0(TXSTATES[2]),
        .I1(\CRC_RG[14]_i_9_n_0 ),
        .I2(TXSTATES[0]),
        .I3(TXSTATES[1]),
        .I4(TransBS_n_22),
        .I5(TransBS_n_21),
        .O(TX_INST_0_i_5_n_0));
  design_1_FPGAPROJECT_0_0_bitstuffer_8 TransBS
       (.\CRC_RG_reg[14] (txcrc_n_0),
        .\CRC_RG_reg[14]_0 (txcrc_n_1),
        .\CRC_RG_reg[14]_1 (txcrc_n_5),
        .\Cnt[0]_i_2_0 (\Cnt[0]_i_2 ),
        .\Cnt_reg[0] (\Cnt[0]_i_5_n_0 ),
        .\Cnt_reg[0]_0 (\Cnt[0]_i_3_n_0 ),
        .\Cnt_reg[1] (\Cnt_reg[1]_0 ),
        .\Cnt_reg[1]_0 (\Cnt[1]_i_4__0_n_0 ),
        .\Cnt_reg[1]_1 (\Cnt[1]_i_5_n_0 ),
        .\Cnt_reg[1]_2 (\Cnt[1]_i_6__0_n_0 ),
        .\Cnt_reg[1]_3 (\Cnt[1]_i_8_n_0 ),
        .\Cnt_reg[2] (TransBS_n_20),
        .\Cnt_reg[2]_0 (\Cnt[2]_i_2__0_n_0 ),
        .\Cnt_reg[2]_1 (\TXSTATES[1]_i_4_n_0 ),
        .\Cnt_reg[3] (TransBS_n_22),
        .\Cnt_reg[3]_0 (\Cnt[3]_i_2__1_n_0 ),
        .\Cnt_reg[3]_1 (\Cnt[3]_i_4_n_0 ),
        .\Cnt_reg[4] (TransBS_n_25),
        .\Cnt_reg[4]_0 (TransBS_n_29),
        .\Cnt_reg[4]_1 (\Cnt[4]_i_3__0_n_0 ),
        .\Cnt_reg[4]_2 (txcrc_n_4),
        .\Cnt_reg[4]_3 (\Cnt[4]_i_5_n_0 ),
        .\Cnt_reg[5] (\Cnt[5]_i_5_n_0 ),
        .\Cnt_reg[5]_0 (\Cnt[5]_i_9_n_0 ),
        .\Cnt_reg[5]_1 (\Cnt_reg[5]_0 ),
        .D({TransBS_n_14,TransBS_n_15,TransBS_n_16,TransBS_n_17,TransBS_n_18,TransBS_n_19}),
        .D_Len_TX(D_Len_TX),
        .\D_Len_TX_1[3] (TransBS_n_26),
        .E(TransBS_n_13),
        .IDE_TX(IDE_TX),
        .ID_TX(ID_TX),
        .\ID_TX_1[10] (TransBS_n_27),
        .\ID_TX_1[28] (TransBS_n_24),
        .\ID_TX_1[28]_0 (TransBS_n_28),
        .\ID_TX_1[8] (TransBS_n_23),
        .Q(TXSTATES),
        .\REC[0]_i_5 (\REC[0]_i_5 ),
        .\REC[0]_i_5_0 (\REC[0]_i_5_0 ),
        .\REC[0]_i_6_0 (\State[0]_i_11_n_0 ),
        .RTR_TX(RTR_TX),
        .RXOUT_reg(RXOUT_reg),
        .SRST(SRST),
        .SRST_1(TransBS_n_31),
        .Sampled_din(Sampled_din),
        .\State[0]_i_2 (\TXSTATES_reg[1]_0 ),
        .\State[0]_i_4_0 (txcrc_n_2),
        .\State[2]_i_3 (\State[0]_i_7_n_0 ),
        .TEC(TEC),
        .\TEC_reg[8] (\TEC_reg[8] ),
        .\TXSTATES_reg[1] (\TXSTATES_reg[1]_1 ),
        .\TXSTATES_reg[1]_0 (\TXSTATES_reg[1]_2 ),
        .\TXSTATES_reg[1]_1 (TransBS_n_21),
        .\TXSTATES_reg[2] (\TXSTATES_reg[2]_0 ),
        .\TXSTATES_reg[3] (\TXSTATES_reg[3]_0 ),
        .\TXSTATES_reg[3]_0 (\TXSTATES_reg[3]_1 ),
        .\TXSTATES_reg[3]_1 (\TXSTATES_reg[3]_2 ),
        .TX_INST_0_i_2(TX_INST_0_i_4_n_0),
        .TX_INST_0_i_2_0(TX_INST_0_i_5_n_0),
        .Tq(Tq),
        .done_i_4_0(done_i_16_n_0),
        .done_i_4_1(done_i_17_n_0),
        .done_i_4_2(done_i_18_n_0),
        .done_i_4_3(done_i_19_n_0),
        .done_reg(TransBS_n_30),
        .done_reg_0(done_i_2__0_n_0),
        .done_reg_1(done_i_10_n_0),
        .done_reg_2(done_i_9_n_0),
        .done_reg_3(done_i_13_n_0),
        .done_reg_4(done_i_6_n_0),
        .done_reg_5(done_reg_0),
        .imTX0_out(imTX0_out),
        .imTX_reg(imTX_i_2_n_0),
        .imTX_reg_0(\TXSTATES[2]_i_3_n_0 ),
        .req_Error_RX(req_Error_RX),
        .req_Error_reg(req_Error_reg),
        .req_Error_reg_0(req_Error_reg_0),
        .req_Error_reg_1(req_Error_reg_1),
        .req_Errorr(req_Errorr),
        .req_Errorr_reg(req_Errorr_reg_n_0),
        .\serial[0]_i_12_0 ({\Cnt_reg_n_0_[5] ,\Cnt_reg_n_0_[4] ,\Cnt_reg_n_0_[3] ,\Cnt_reg_n_0_[2] ,\Cnt_reg_n_0_[1] ,\Cnt_reg_n_0_[0] }),
        .\serial[0]_i_2_0 (\serial[0]_i_13_n_0 ),
        .\serial_reg[0]_0 (txcrc_n_3),
        .\serial_reg[0]_1 (\CRC_RG_reg[0] ));
  (* SOFT_HLUTNM = "soft_lutpair108" *) 
  LUT4 #(
    .INIT(16'h0080)) 
    ack_error_i_4
       (.I0(TXSTATES[1]),
        .I1(TXSTATES[2]),
        .I2(TXSTATES[0]),
        .I3(TXSTATES[3]),
        .O(\TXSTATES_reg[1]_0 ));
  LUT6 #(
    .INIT(64'h0000000000000002)) 
    done_i_10
       (.I0(TRANSMITr),
        .I1(TXSTATES[0]),
        .I2(TXSTATES[3]),
        .I3(TXSTATES[1]),
        .I4(TXSTATES[2]),
        .I5(done_i_12),
        .O(done_i_10_n_0));
  (* SOFT_HLUTNM = "soft_lutpair111" *) 
  LUT2 #(
    .INIT(4'hB)) 
    done_i_13
       (.I0(TXSTATES[2]),
        .I1(TXSTATES[3]),
        .O(done_i_13_n_0));
  (* SOFT_HLUTNM = "soft_lutpair111" *) 
  LUT2 #(
    .INIT(4'hB)) 
    done_i_16
       (.I0(TXSTATES[2]),
        .I1(TXSTATES[1]),
        .O(done_i_16_n_0));
  (* SOFT_HLUTNM = "soft_lutpair110" *) 
  LUT2 #(
    .INIT(4'h2)) 
    done_i_17
       (.I0(TransBS_n_20),
        .I1(TXSTATES[0]),
        .O(done_i_17_n_0));
  (* SOFT_HLUTNM = "soft_lutpair108" *) 
  LUT4 #(
    .INIT(16'hD7F5)) 
    done_i_18
       (.I0(TXSTATES[2]),
        .I1(TXSTATES[1]),
        .I2(TXSTATES[0]),
        .I3(TransBS_n_20),
        .O(done_i_18_n_0));
  (* SOFT_HLUTNM = "soft_lutpair104" *) 
  LUT5 #(
    .INIT(32'h0D0DFDF0)) 
    done_i_19
       (.I0(TRANSMITr),
        .I1(done_i_12),
        .I2(TransBS_n_20),
        .I3(done_i_12_0),
        .I4(TXSTATES[0]),
        .O(done_i_19_n_0));
  (* SOFT_HLUTNM = "soft_lutpair107" *) 
  LUT4 #(
    .INIT(16'h0010)) 
    done_i_2__0
       (.I0(TXSTATES[0]),
        .I1(TXSTATES[3]),
        .I2(TXSTATES[1]),
        .I3(TXSTATES[2]),
        .O(done_i_2__0_n_0));
  LUT6 #(
    .INIT(64'hCFFE0000FFFFFFFF)) 
    done_i_6
       (.I0(TXSTATES[0]),
        .I1(TXSTATES[2]),
        .I2(TXSTATES[3]),
        .I3(TXSTATES[1]),
        .I4(\Cnt_reg[5]_0 ),
        .I5(SRST),
        .O(done_i_6_n_0));
  (* SOFT_HLUTNM = "soft_lutpair106" *) 
  LUT5 #(
    .INIT(32'h0100FFFF)) 
    done_i_9
       (.I0(\Cnt_reg[1]_0 ),
        .I1(TXSTATES[1]),
        .I2(TXSTATES[0]),
        .I3(TXSTATES[2]),
        .I4(TXSTATES[3]),
        .O(done_i_9_n_0));
  FDPE done_reg
       (.C(Tq),
        .CE(1'b1),
        .D(TransBS_n_30),
        .PRE(\CRC_RG_reg[0] ),
        .Q(done_reg_0));
  LUT2 #(
    .INIT(4'h8)) 
    donefromtxr_i_1
       (.I0(SRST),
        .I1(done_reg_0),
        .O(donefromtxr));
  LUT6 #(
    .INIT(64'h8888888888888880)) 
    imTX_i_2
       (.I0(imTX),
        .I1(SRST),
        .I2(TXSTATES[0]),
        .I3(TXSTATES[3]),
        .I4(TXSTATES[1]),
        .I5(TXSTATES[2]),
        .O(imTX_i_2_n_0));
  FDCE imTX_reg
       (.C(Tq),
        .CE(E),
        .CLR(\CRC_RG_reg[0] ),
        .D(imTX0_out),
        .Q(imTX));
  FDCE req_Errorr_reg
       (.C(Tq),
        .CE(E),
        .CLR(\CRC_RG_reg[0] ),
        .D(req_Errorr),
        .Q(req_Errorr_reg_n_0));
  LUT6 #(
    .INIT(64'h55555555555555D5)) 
    \serial[0]_i_13 
       (.I0(TransBS_n_29),
        .I1(\Cnt_reg_n_0_[0] ),
        .I2(\Cnt_reg_n_0_[1] ),
        .I3(\serial[0]_i_34_n_0 ),
        .I4(IDE_TX),
        .I5(\Cnt_reg_n_0_[2] ),
        .O(\serial[0]_i_13_n_0 ));
  LUT3 #(
    .INIT(8'hFB)) 
    \serial[0]_i_34 
       (.I0(\Cnt_reg_n_0_[3] ),
        .I1(\Cnt_reg_n_0_[4] ),
        .I2(\Cnt_reg_n_0_[5] ),
        .O(\serial[0]_i_34_n_0 ));
  design_1_FPGAPROJECT_0_0_CRC_9 txcrc
       (.\CRC_RG[14]_i_8_0 (TransBS_n_29),
        .\CRC_RG[14]_i_8_1 (TransBS_n_28),
        .\CRC_RG[14]_i_8_2 (TransBS_n_27),
        .\CRC_RG[14]_i_8_3 (TransBS_n_26),
        .\CRC_RG_reg[0]_0 (\CRC_RG_reg[0] ),
        .\CRC_RG_reg[14]_0 (\Cnt_reg[5]_0 ),
        .\Cnt[5]_i_7 (\CRC_RG[14]_i_9_n_0 ),
        .\Cnt_reg[5] (txcrc_n_3),
        .E(TransBS_n_13),
        .Q(TXSTATES),
        .SRST(SRST),
        .SRST_1(txcrc_n_0),
        .\TXSTATES_reg[0] (txcrc_n_4),
        .\TXSTATES_reg[2] (txcrc_n_5),
        .\TXSTATES_reg[3] (txcrc_n_1),
        .\TXSTATES_reg[3]_0 (txcrc_n_2),
        .Tq(Tq),
        .data_TX(data_TX),
        .\serial[0]_i_2 ({\Cnt_reg_n_0_[5] ,\Cnt_reg_n_0_[4] ,\Cnt_reg_n_0_[3] ,\Cnt_reg_n_0_[2] ,\Cnt_reg_n_0_[1] ,\Cnt_reg_n_0_[0] }));
endmodule

(* ORIG_REF_NAME = "bitstuffer" *) 
module design_1_FPGAPROJECT_0_0_bitstuffer
   (E,
    done_reg,
    req_Error_reg,
    req_Error_reg_0,
    req_Error_reg_1,
    \TXSTATES_reg[0] ,
    req_Errorr,
    \TXSTATES_reg[1] ,
    D,
    RXOUT_reg,
    SRST_0_0,
    imTX0_out,
    \TXSTATES_reg[0]_0 ,
    \TXSTATES_reg[2] ,
    \TXSTATES_reg[3] ,
    SRST_0,
    Q,
    done_reg_0,
    done_reg_1,
    \Cnt_reg[4] ,
    \Cnt_reg[4]_0 ,
    IDE_TX_0,
    done_i_4_0,
    done_i_4_1,
    \Cnt[0]_i_2_0 ,
    done_i_4_2,
    \serial_reg[4]_0 ,
    \Cnt_reg[1] ,
    \Cnt_reg[1]_0 ,
    done_reg_2,
    done_reg_3,
    done_reg_4,
    \REC[8]_i_12 ,
    \State[0]_i_2 ,
    req_Error_RX,
    \TEC[8]_i_17 ,
    \TEC[8]_i_17_0 ,
    Sampled_din,
    req_Errorr_reg,
    \TXSTATES_reg[0]_1 ,
    \D_Len[0]_i_3 ,
    \serial_reg[0]_0 ,
    \State[0]_i_4_0 ,
    \Cnt_reg[4]_1 ,
    \Cnt_reg[5] ,
    imTX_reg,
    imTX,
    done_reg_5,
    done_i_4_3,
    done_i_4_4,
    \Cnt_reg[3] ,
    \Cnt_reg[3]_0 ,
    \Cnt_reg[3]_1 ,
    \Cnt_reg[2] ,
    \Cnt_reg[2]_0 ,
    \Cnt_reg[2]_1 ,
    \Cnt_reg[5]_0 ,
    \Cnt_reg[0] ,
    \Cnt[0]_i_2_1 ,
    \Cnt[0]_i_3_0 ,
    \Cnt[0]_i_3_1 ,
    \CRC_RG_reg[14] ,
    \CRC_RG_reg[14]_0 ,
    \TXSTATES_reg[2]_0 ,
    clk,
    \serial_reg[0]_1 );
  output [0:0]E;
  output done_reg;
  output req_Error_reg;
  output req_Error_reg_0;
  output req_Error_reg_1;
  output \TXSTATES_reg[0] ;
  output req_Errorr;
  output \TXSTATES_reg[1] ;
  output [1:0]D;
  output RXOUT_reg;
  output [5:0]SRST_0_0;
  output imTX0_out;
  output \TXSTATES_reg[0]_0 ;
  output \TXSTATES_reg[2] ;
  output [0:0]\TXSTATES_reg[3] ;
  input SRST_0;
  input [3:0]Q;
  input done_reg_0;
  input done_reg_1;
  input \Cnt_reg[4] ;
  input \Cnt_reg[4]_0 ;
  input IDE_TX_0;
  input done_i_4_0;
  input done_i_4_1;
  input \Cnt[0]_i_2_0 ;
  input done_i_4_2;
  input \serial_reg[4]_0 ;
  input \Cnt_reg[1] ;
  input \Cnt_reg[1]_0 ;
  input done_reg_2;
  input done_reg_3;
  input done_reg_4;
  input \REC[8]_i_12 ;
  input \State[0]_i_2 ;
  input req_Error_RX;
  input \TEC[8]_i_17 ;
  input \TEC[8]_i_17_0 ;
  input Sampled_din;
  input req_Errorr_reg;
  input \TXSTATES_reg[0]_1 ;
  input \D_Len[0]_i_3 ;
  input \serial_reg[0]_0 ;
  input \State[0]_i_4_0 ;
  input \Cnt_reg[4]_1 ;
  input \Cnt_reg[5] ;
  input imTX_reg;
  input imTX;
  input done_reg_5;
  input done_i_4_3;
  input done_i_4_4;
  input \Cnt_reg[3] ;
  input \Cnt_reg[3]_0 ;
  input \Cnt_reg[3]_1 ;
  input \Cnt_reg[2] ;
  input \Cnt_reg[2]_0 ;
  input \Cnt_reg[2]_1 ;
  input \Cnt_reg[5]_0 ;
  input [0:0]\Cnt_reg[0] ;
  input \Cnt[0]_i_2_1 ;
  input [1:0]\Cnt[0]_i_3_0 ;
  input \Cnt[0]_i_3_1 ;
  input \CRC_RG_reg[14] ;
  input \CRC_RG_reg[14]_0 ;
  input \TXSTATES_reg[2]_0 ;
  input clk;
  input \serial_reg[0]_1 ;

  wire \CRC_RG[14]_i_5_n_0 ;
  wire \CRC_RG_reg[14] ;
  wire \CRC_RG_reg[14]_0 ;
  wire \Cnt[0]_i_2_0 ;
  wire \Cnt[0]_i_2_1 ;
  wire \Cnt[0]_i_2_n_0 ;
  wire [1:0]\Cnt[0]_i_3_0 ;
  wire \Cnt[0]_i_3_1 ;
  wire \Cnt[0]_i_3_n_0 ;
  wire \Cnt[0]_i_4_n_0 ;
  wire \Cnt[1]_i_2_n_0 ;
  wire \Cnt[1]_i_3__0_n_0 ;
  wire \Cnt[2]_i_3_n_0 ;
  wire \Cnt[2]_i_4__0_n_0 ;
  wire \Cnt[3]_i_3__1_n_0 ;
  wire \Cnt[3]_i_7_n_0 ;
  wire \Cnt[3]_i_8_n_0 ;
  wire \Cnt[3]_i_9_n_0 ;
  wire \Cnt[4]_i_2__0_n_0 ;
  wire \Cnt[4]_i_5__0_n_0 ;
  wire \Cnt[5]_i_3__0_n_0 ;
  wire \Cnt[5]_i_5_n_0 ;
  wire \Cnt[5]_i_6_n_0 ;
  wire \Cnt[5]_i_7__0_n_0 ;
  wire [0:0]\Cnt_reg[0] ;
  wire \Cnt_reg[1] ;
  wire \Cnt_reg[1]_0 ;
  wire \Cnt_reg[2] ;
  wire \Cnt_reg[2]_0 ;
  wire \Cnt_reg[2]_1 ;
  wire \Cnt_reg[3] ;
  wire \Cnt_reg[3]_0 ;
  wire \Cnt_reg[3]_1 ;
  wire \Cnt_reg[4] ;
  wire \Cnt_reg[4]_0 ;
  wire \Cnt_reg[4]_1 ;
  wire \Cnt_reg[5] ;
  wire \Cnt_reg[5]_0 ;
  wire [1:0]D;
  wire \D_Len[0]_i_3 ;
  wire [0:0]E;
  wire IDE_TX_0;
  wire [3:0]Q;
  wire \REC[8]_i_12 ;
  wire RXOUT_reg;
  wire SRST_0;
  wire [5:0]SRST_0_0;
  wire Sampled_din;
  wire \State[0]_i_2 ;
  wire \State[0]_i_4_0 ;
  wire \State[0]_i_7_n_0 ;
  wire \TEC[8]_i_17 ;
  wire \TEC[8]_i_17_0 ;
  wire \TEC[8]_i_23_n_0 ;
  wire \TXSTATES[0]_i_2_n_0 ;
  wire \TXSTATES[0]_i_3_n_0 ;
  wire \TXSTATES[1]_i_2_n_0 ;
  wire \TXSTATES[3]_i_5_n_0 ;
  wire \TXSTATES_reg[0] ;
  wire \TXSTATES_reg[0]_0 ;
  wire \TXSTATES_reg[0]_1 ;
  wire \TXSTATES_reg[1] ;
  wire \TXSTATES_reg[2] ;
  wire \TXSTATES_reg[2]_0 ;
  wire [0:0]\TXSTATES_reg[3] ;
  wire clk;
  wire done_i_10_n_0;
  wire done_i_11_n_0;
  wire done_i_3_n_0;
  wire done_i_4_0;
  wire done_i_4_1;
  wire done_i_4_2;
  wire done_i_4_3;
  wire done_i_4_4;
  wire done_i_4_n_0;
  wire done_i_5_n_0;
  wire done_i_7_n_0;
  wire done_i_8_n_0;
  wire done_reg;
  wire done_reg_0;
  wire done_reg_1;
  wire done_reg_2;
  wire done_reg_3;
  wire done_reg_4;
  wire done_reg_5;
  wire imTX;
  wire imTX0_out;
  wire imTX_reg;
  wire req_Error_RX;
  wire req_Error_reg;
  wire req_Error_reg_0;
  wire req_Error_reg_1;
  wire req_Errorr;
  wire req_Errorr_i_2_n_0;
  wire req_Errorr_reg;
  wire [3:0]serial;
  wire \serial[0]_i_1_n_0 ;
  wire \serial[0]_i_2_n_0 ;
  wire \serial[1]_i_1_n_0 ;
  wire \serial[2]_i_1_n_0 ;
  wire \serial[3]_i_1_n_0 ;
  wire \serial[4]_i_1_n_0 ;
  wire \serial[4]_i_2_n_0 ;
  wire \serial_reg[0]_0 ;
  wire \serial_reg[0]_1 ;
  wire \serial_reg[4]_0 ;
  wire \serial_reg_n_0_[4] ;

  LUT6 #(
    .INIT(64'h5D555D5D5D5D5D5D)) 
    \CRC_RG[14]_i_1 
       (.I0(\CRC_RG_reg[14] ),
        .I1(\CRC_RG_reg[14]_0 ),
        .I2(\CRC_RG[14]_i_5_n_0 ),
        .I3(Q[3]),
        .I4(\Cnt_reg[4]_1 ),
        .I5(Q[0]),
        .O(\TXSTATES_reg[3] ));
  (* SOFT_HLUTNM = "soft_lutpair193" *) 
  LUT5 #(
    .INIT(32'h80000001)) 
    \CRC_RG[14]_i_5 
       (.I0(\serial_reg_n_0_[4] ),
        .I1(serial[3]),
        .I2(serial[0]),
        .I3(serial[1]),
        .I4(serial[2]),
        .O(\CRC_RG[14]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h020202020202028A)) 
    \Cnt[0]_i_1 
       (.I0(SRST_0),
        .I1(Q[3]),
        .I2(\Cnt[0]_i_2_n_0 ),
        .I3(\Cnt[0]_i_3_n_0 ),
        .I4(Q[2]),
        .I5(\Cnt_reg[0] ),
        .O(SRST_0_0[0]));
  LUT6 #(
    .INIT(64'h00E000E0FFE0FFEF)) 
    \Cnt[0]_i_2 
       (.I0(\Cnt_reg[0] ),
        .I1(done_reg_1),
        .I2(Q[2]),
        .I3(Q[1]),
        .I4(Q[0]),
        .I5(\Cnt[0]_i_4_n_0 ),
        .O(\Cnt[0]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair198" *) 
  LUT4 #(
    .INIT(16'h55CF)) 
    \Cnt[0]_i_3 
       (.I0(\TXSTATES[3]_i_5_n_0 ),
        .I1(done_reg_1),
        .I2(Q[0]),
        .I3(Q[1]),
        .O(\Cnt[0]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000F10000)) 
    \Cnt[0]_i_4 
       (.I0(\Cnt[0]_i_2_1 ),
        .I1(\Cnt_reg[0] ),
        .I2(\Cnt[0]_i_2_0 ),
        .I3(Q[2]),
        .I4(Q[1]),
        .I5(\Cnt[5]_i_7__0_n_0 ),
        .O(\Cnt[0]_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair197" *) 
  LUT4 #(
    .INIT(16'h02A2)) 
    \Cnt[1]_i_1__0 
       (.I0(SRST_0),
        .I1(\Cnt[1]_i_2_n_0 ),
        .I2(Q[3]),
        .I3(\Cnt[1]_i_3__0_n_0 ),
        .O(SRST_0_0[1]));
  LUT6 #(
    .INIT(64'hFFFFFFBBFFC0BABB)) 
    \Cnt[1]_i_2 
       (.I0(\Cnt[5]_i_7__0_n_0 ),
        .I1(Q[0]),
        .I2(done_reg_1),
        .I3(Q[1]),
        .I4(Q[2]),
        .I5(\Cnt_reg[1]_0 ),
        .O(\Cnt[1]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFBABAFAF0BAB0)) 
    \Cnt[1]_i_3__0 
       (.I0(Q[2]),
        .I1(\TXSTATES[3]_i_5_n_0 ),
        .I2(Q[1]),
        .I3(\Cnt_reg[1] ),
        .I4(\Cnt_reg[1]_0 ),
        .I5(Q[0]),
        .O(\Cnt[1]_i_3__0_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000AA02AA)) 
    \Cnt[2]_i_1__0 
       (.I0(SRST_0),
        .I1(\Cnt_reg[2] ),
        .I2(Q[2]),
        .I3(Q[3]),
        .I4(\Cnt[2]_i_3_n_0 ),
        .I5(\Cnt[2]_i_4__0_n_0 ),
        .O(SRST_0_0[2]));
  (* SOFT_HLUTNM = "soft_lutpair195" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \Cnt[2]_i_3 
       (.I0(Q[1]),
        .I1(\TXSTATES[3]_i_5_n_0 ),
        .O(\Cnt[2]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hFF700000FF77FF77)) 
    \Cnt[2]_i_4__0 
       (.I0(done_reg_0),
        .I1(IDE_TX_0),
        .I2(\Cnt[4]_i_5__0_n_0 ),
        .I3(Q[2]),
        .I4(\Cnt_reg[2]_0 ),
        .I5(\Cnt_reg[2]_1 ),
        .O(\Cnt[2]_i_4__0_n_0 ));
  LUT6 #(
    .INIT(64'h000000A8AAAAAAAA)) 
    \Cnt[3]_i_1__0 
       (.I0(SRST_0),
        .I1(\Cnt_reg[3] ),
        .I2(\Cnt[3]_i_3__1_n_0 ),
        .I3(\Cnt_reg[3]_0 ),
        .I4(Q[2]),
        .I5(\Cnt_reg[3]_1 ),
        .O(SRST_0_0[3]));
  LUT2 #(
    .INIT(4'h8)) 
    \Cnt[3]_i_3__1 
       (.I0(\Cnt[3]_i_7_n_0 ),
        .I1(Q[1]),
        .O(\Cnt[3]_i_3__1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair196" *) 
  LUT5 #(
    .INIT(32'h999AAAAA)) 
    \Cnt[3]_i_7 
       (.I0(Sampled_din),
        .I1(\Cnt[3]_i_8_n_0 ),
        .I2(\serial_reg[0]_0 ),
        .I3(\Cnt[3]_i_9_n_0 ),
        .I4(\D_Len[0]_i_3 ),
        .O(\Cnt[3]_i_7_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair193" *) 
  LUT5 #(
    .INIT(32'h00000001)) 
    \Cnt[3]_i_8 
       (.I0(serial[0]),
        .I1(serial[3]),
        .I2(\serial_reg_n_0_[4] ),
        .I3(serial[1]),
        .I4(serial[2]),
        .O(\Cnt[3]_i_8_n_0 ));
  LUT5 #(
    .INIT(32'h80000000)) 
    \Cnt[3]_i_9 
       (.I0(serial[2]),
        .I1(serial[1]),
        .I2(serial[0]),
        .I3(serial[3]),
        .I4(\serial_reg_n_0_[4] ),
        .O(\Cnt[3]_i_9_n_0 ));
  LUT6 #(
    .INIT(64'h20AA20AA20222020)) 
    \Cnt[4]_i_1__0 
       (.I0(SRST_0),
        .I1(Q[3]),
        .I2(\Cnt[4]_i_2__0_n_0 ),
        .I3(\Cnt_reg[4] ),
        .I4(\Cnt_reg[4]_1 ),
        .I5(\Cnt[5]_i_5_n_0 ),
        .O(SRST_0_0[4]));
  LUT6 #(
    .INIT(64'h5555005100510051)) 
    \Cnt[4]_i_2__0 
       (.I0(Q[2]),
        .I1(\Cnt_reg[4] ),
        .I2(\Cnt_reg[4]_0 ),
        .I3(\Cnt[4]_i_5__0_n_0 ),
        .I4(IDE_TX_0),
        .I5(done_reg_0),
        .O(\Cnt[4]_i_2__0_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair194" *) 
  LUT2 #(
    .INIT(4'hB)) 
    \Cnt[4]_i_5__0 
       (.I0(\Cnt[5]_i_7__0_n_0 ),
        .I1(Q[1]),
        .O(\Cnt[4]_i_5__0_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair199" *) 
  LUT3 #(
    .INIT(8'h4F)) 
    \Cnt[5]_i_1 
       (.I0(\Cnt[5]_i_3__0_n_0 ),
        .I1(\serial_reg[4]_0 ),
        .I2(SRST_0),
        .O(E));
  LUT6 #(
    .INIT(64'h80888080AAAAAAAA)) 
    \Cnt[5]_i_2__0 
       (.I0(SRST_0),
        .I1(\Cnt_reg[5] ),
        .I2(\Cnt[5]_i_5_n_0 ),
        .I3(Q[3]),
        .I4(\Cnt_reg[4]_1 ),
        .I5(\Cnt[5]_i_6_n_0 ),
        .O(SRST_0_0[5]));
  LUT6 #(
    .INIT(64'h8000000000000002)) 
    \Cnt[5]_i_3__0 
       (.I0(\CRC_RG_reg[14]_0 ),
        .I1(serial[2]),
        .I2(serial[1]),
        .I3(serial[0]),
        .I4(serial[3]),
        .I5(\serial_reg_n_0_[4] ),
        .O(\Cnt[5]_i_3__0_n_0 ));
  LUT5 #(
    .INIT(32'h20202220)) 
    \Cnt[5]_i_5 
       (.I0(Q[3]),
        .I1(Q[2]),
        .I2(\Cnt[3]_i_3__1_n_0 ),
        .I3(Q[0]),
        .I4(Q[1]),
        .O(\Cnt[5]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hFFEFFFEFFFEFFFFF)) 
    \Cnt[5]_i_6 
       (.I0(\Cnt[5]_i_7__0_n_0 ),
        .I1(Q[3]),
        .I2(Q[1]),
        .I3(Q[2]),
        .I4(\Cnt_reg[5] ),
        .I5(\Cnt_reg[5]_0 ),
        .O(\Cnt[5]_i_6_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair198" *) 
  LUT2 #(
    .INIT(4'h1)) 
    \Cnt[5]_i_7__0 
       (.I0(Q[0]),
        .I1(\Cnt[3]_i_7_n_0 ),
        .O(\Cnt[5]_i_7__0_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair196" *) 
  LUT4 #(
    .INIT(16'h00A8)) 
    \D_Len[0]_i_4 
       (.I0(\D_Len[0]_i_3 ),
        .I1(\Cnt[3]_i_9_n_0 ),
        .I2(\serial_reg[0]_0 ),
        .I3(\Cnt[3]_i_8_n_0 ),
        .O(\TXSTATES_reg[0] ));
  LUT6 #(
    .INIT(64'h5555555545554514)) 
    \REC[8]_i_16 
       (.I0(req_Error_RX),
        .I1(\TXSTATES_reg[0] ),
        .I2(Sampled_din),
        .I3(\State[0]_i_2 ),
        .I4(done_reg_2),
        .I5(\REC[8]_i_12 ),
        .O(req_Error_reg_1));
  LUT6 #(
    .INIT(64'hAAAAAAAAFEFFFEFE)) 
    \State[0]_i_4 
       (.I0(\Cnt_reg[1] ),
        .I1(\REC[8]_i_12 ),
        .I2(\State[0]_i_7_n_0 ),
        .I3(\State[0]_i_2 ),
        .I4(\Cnt[3]_i_7_n_0 ),
        .I5(req_Error_RX),
        .O(req_Error_reg));
  LUT6 #(
    .INIT(64'h000000005555DDD5)) 
    \State[0]_i_7 
       (.I0(Sampled_din),
        .I1(\D_Len[0]_i_3 ),
        .I2(\Cnt[3]_i_9_n_0 ),
        .I3(\serial_reg[0]_0 ),
        .I4(\Cnt[3]_i_8_n_0 ),
        .I5(\State[0]_i_4_0 ),
        .O(\State[0]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'h171C00000800171C)) 
    \TEC[0]_i_4 
       (.I0(Q[1]),
        .I1(Q[2]),
        .I2(Q[3]),
        .I3(Q[0]),
        .I4(Sampled_din),
        .I5(\TXSTATES_reg[0] ),
        .O(\TXSTATES_reg[1] ));
  LUT6 #(
    .INIT(64'h00005554FFFFFFFF)) 
    \TEC[8]_i_22 
       (.I0(req_Error_RX),
        .I1(\TEC[8]_i_23_n_0 ),
        .I2(\State[0]_i_7_n_0 ),
        .I3(\REC[8]_i_12 ),
        .I4(\TEC[8]_i_17 ),
        .I5(\TEC[8]_i_17_0 ),
        .O(req_Error_reg_0));
  LUT6 #(
    .INIT(64'h00000000FF5700A8)) 
    \TEC[8]_i_23 
       (.I0(\D_Len[0]_i_3 ),
        .I1(\Cnt[3]_i_9_n_0 ),
        .I2(\serial_reg[0]_0 ),
        .I3(\Cnt[3]_i_8_n_0 ),
        .I4(Sampled_din),
        .I5(\State[0]_i_2 ),
        .O(\TEC[8]_i_23_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair200" *) 
  LUT3 #(
    .INIT(8'h08)) 
    \TXSTATES[0]_i_1 
       (.I0(\TXSTATES[0]_i_2_n_0 ),
        .I1(SRST_0),
        .I2(\TXSTATES_reg[0]_1 ),
        .O(D[0]));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFAB00AB)) 
    \TXSTATES[0]_i_2 
       (.I0(done_i_11_n_0),
        .I1(Q[3]),
        .I2(\TXSTATES[0]_i_3_n_0 ),
        .I3(\Cnt[5]_i_3__0_n_0 ),
        .I4(Q[0]),
        .I5(done_reg_5),
        .O(\TXSTATES[0]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hF0F0EEEFF00FFFFF)) 
    \TXSTATES[0]_i_3 
       (.I0(\Cnt[5]_i_7__0_n_0 ),
        .I1(\Cnt[0]_i_2_0 ),
        .I2(Q[0]),
        .I3(done_reg_1),
        .I4(Q[2]),
        .I5(Q[1]),
        .O(\TXSTATES[0]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair200" *) 
  LUT3 #(
    .INIT(8'h04)) 
    \TXSTATES[1]_i_1 
       (.I0(\TXSTATES[1]_i_2_n_0 ),
        .I1(SRST_0),
        .I2(\TXSTATES_reg[0]_1 ),
        .O(D[1]));
  LUT5 #(
    .INIT(32'h74777444)) 
    \TXSTATES[1]_i_2 
       (.I0(Q[1]),
        .I1(\Cnt[5]_i_3__0_n_0 ),
        .I2(done_i_8_n_0),
        .I3(Q[3]),
        .I4(done_i_7_n_0),
        .O(\TXSTATES[1]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair199" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \TXSTATES[2]_i_2 
       (.I0(Q[2]),
        .I1(\Cnt[5]_i_3__0_n_0 ),
        .I2(\TXSTATES_reg[2]_0 ),
        .O(\TXSTATES_reg[2] ));
  (* SOFT_HLUTNM = "soft_lutpair195" *) 
  LUT5 #(
    .INIT(32'h0CA030F0)) 
    \TXSTATES[3]_i_4 
       (.I0(\TXSTATES[3]_i_5_n_0 ),
        .I1(Q[0]),
        .I2(Q[3]),
        .I3(Q[2]),
        .I4(Q[1]),
        .O(\TXSTATES_reg[0]_0 ));
  LUT6 #(
    .INIT(64'h22202222AAAAAAAA)) 
    \TXSTATES[3]_i_5 
       (.I0(\Cnt[3]_i_7_n_0 ),
        .I1(Q[0]),
        .I2(\Cnt[0]_i_3_0 [1]),
        .I3(\Cnt[0]_i_3_0 [0]),
        .I4(\Cnt[0]_i_3_1 ),
        .I5(done_reg_1),
        .O(\TXSTATES[3]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hFBF0F000F0F0FB0F)) 
    ack_error_i_6
       (.I0(\TXSTATES_reg[0] ),
        .I1(Sampled_din),
        .I2(Q[3]),
        .I3(Q[1]),
        .I4(Q[2]),
        .I5(Q[0]),
        .O(RXOUT_reg));
  LUT6 #(
    .INIT(64'hFF08FFFFFF080000)) 
    done_i_1
       (.I0(done_reg_2),
        .I1(done_i_3_n_0),
        .I2(done_i_4_n_0),
        .I3(done_i_5_n_0),
        .I4(done_reg_3),
        .I5(done_reg_4),
        .O(done_reg));
  LUT6 #(
    .INIT(64'h0000000155555555)) 
    done_i_10
       (.I0(Q[3]),
        .I1(done_i_4_0),
        .I2(done_i_4_1),
        .I3(\Cnt[0]_i_2_0 ),
        .I4(\Cnt[5]_i_7__0_n_0 ),
        .I5(done_i_4_2),
        .O(done_i_10_n_0));
  LUT6 #(
    .INIT(64'h00000000222F2F2F)) 
    done_i_11
       (.I0(\Cnt[3]_i_3__1_n_0 ),
        .I1(done_i_4_3),
        .I2(Q[1]),
        .I3(Q[0]),
        .I4(done_reg_1),
        .I5(done_i_4_4),
        .O(done_i_11_n_0));
  LUT6 #(
    .INIT(64'h0000000000E2FFE2)) 
    done_i_3
       (.I0(done_i_7_n_0),
        .I1(Q[3]),
        .I2(done_i_8_n_0),
        .I3(\Cnt[5]_i_3__0_n_0 ),
        .I4(Q[1]),
        .I5(\TXSTATES_reg[2] ),
        .O(done_i_3_n_0));
  LUT6 #(
    .INIT(64'hFFFFFFFFEFEFEFEA)) 
    done_i_4
       (.I0(done_reg_5),
        .I1(Q[0]),
        .I2(\Cnt[5]_i_3__0_n_0 ),
        .I3(done_i_10_n_0),
        .I4(done_i_11_n_0),
        .I5(\TXSTATES_reg[0]_0 ),
        .O(done_i_4_n_0));
  LUT6 #(
    .INIT(64'h20000000FFFFFFFF)) 
    done_i_5
       (.I0(Q[3]),
        .I1(Q[2]),
        .I2(done_reg_0),
        .I3(done_reg_1),
        .I4(req_Errorr_i_2_n_0),
        .I5(SRST_0),
        .O(done_i_5_n_0));
  (* SOFT_HLUTNM = "soft_lutpair194" *) 
  LUT5 #(
    .INIT(32'hC3F3EBAB)) 
    done_i_7
       (.I0(\Cnt[5]_i_7__0_n_0 ),
        .I1(Q[1]),
        .I2(Q[0]),
        .I3(done_reg_1),
        .I4(Q[2]),
        .O(done_i_7_n_0));
  LUT6 #(
    .INIT(64'hF3F5F3FFF3F5F30F)) 
    done_i_8
       (.I0(done_reg_1),
        .I1(\TXSTATES[3]_i_5_n_0 ),
        .I2(Q[2]),
        .I3(Q[1]),
        .I4(Q[0]),
        .I5(\Cnt_reg[1] ),
        .O(done_i_8_n_0));
  LUT6 #(
    .INIT(64'hFF44F4FF00000000)) 
    imTX_i_1
       (.I0(imTX_reg),
        .I1(imTX),
        .I2(\TXSTATES[0]_i_2_n_0 ),
        .I3(done_i_3_n_0),
        .I4(\TXSTATES_reg[0]_0 ),
        .I5(SRST_0),
        .O(imTX0_out));
  LUT6 #(
    .INIT(64'h00000000CFFE0000)) 
    req_Errorr_i_1
       (.I0(Q[0]),
        .I1(Q[2]),
        .I2(Q[3]),
        .I3(Q[1]),
        .I4(SRST_0),
        .I5(req_Errorr_i_2_n_0),
        .O(req_Errorr));
  LUT2 #(
    .INIT(4'h1)) 
    req_Errorr_i_2
       (.I0(req_Errorr_reg),
        .I1(\TXSTATES_reg[1] ),
        .O(req_Errorr_i_2_n_0));
  (* SOFT_HLUTNM = "soft_lutpair197" *) 
  LUT2 #(
    .INIT(4'hB)) 
    \serial[0]_i_1 
       (.I0(\serial[0]_i_2_n_0 ),
        .I1(SRST_0),
        .O(\serial[0]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h1555555555555557)) 
    \serial[0]_i_2 
       (.I0(\serial_reg[0]_0 ),
        .I1(serial[2]),
        .I2(serial[1]),
        .I3(serial[0]),
        .I4(serial[3]),
        .I5(\serial_reg_n_0_[4] ),
        .O(\serial[0]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair202" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \serial[1]_i_1 
       (.I0(SRST_0),
        .I1(serial[0]),
        .O(\serial[1]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair202" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \serial[2]_i_1 
       (.I0(SRST_0),
        .I1(serial[1]),
        .O(\serial[2]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair201" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \serial[3]_i_1 
       (.I0(SRST_0),
        .I1(serial[2]),
        .O(\serial[3]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h00000AA8FFFFFFFF)) 
    \serial[4]_i_1 
       (.I0(\serial_reg[4]_0 ),
        .I1(Q[0]),
        .I2(Q[2]),
        .I3(Q[1]),
        .I4(Q[3]),
        .I5(SRST_0),
        .O(\serial[4]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair201" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \serial[4]_i_2 
       (.I0(SRST_0),
        .I1(serial[3]),
        .O(\serial[4]_i_2_n_0 ));
  FDPE \serial_reg[0] 
       (.C(clk),
        .CE(\serial[4]_i_1_n_0 ),
        .D(\serial[0]_i_1_n_0 ),
        .PRE(\serial_reg[0]_1 ),
        .Q(serial[0]));
  FDCE \serial_reg[1] 
       (.C(clk),
        .CE(\serial[4]_i_1_n_0 ),
        .CLR(\serial_reg[0]_1 ),
        .D(\serial[1]_i_1_n_0 ),
        .Q(serial[1]));
  FDCE \serial_reg[2] 
       (.C(clk),
        .CE(\serial[4]_i_1_n_0 ),
        .CLR(\serial_reg[0]_1 ),
        .D(\serial[2]_i_1_n_0 ),
        .Q(serial[2]));
  FDCE \serial_reg[3] 
       (.C(clk),
        .CE(\serial[4]_i_1_n_0 ),
        .CLR(\serial_reg[0]_1 ),
        .D(\serial[3]_i_1_n_0 ),
        .Q(serial[3]));
  FDCE \serial_reg[4] 
       (.C(clk),
        .CE(\serial[4]_i_1_n_0 ),
        .CLR(\serial_reg[0]_1 ),
        .D(\serial[4]_i_2_n_0 ),
        .Q(\serial_reg_n_0_[4] ));
endmodule

(* ORIG_REF_NAME = "bitstuffer" *) 
module design_1_FPGAPROJECT_0_0_bitstuffer_8
   (\TEC_reg[8] ,
    req_Error_reg,
    req_Error_reg_0,
    req_Error_reg_1,
    \TXSTATES_reg[3] ,
    req_Errorr,
    \TXSTATES_reg[1] ,
    RXOUT_reg,
    imTX0_out,
    \TXSTATES_reg[3]_0 ,
    \TXSTATES_reg[3]_1 ,
    \TXSTATES_reg[2] ,
    \TXSTATES_reg[1]_0 ,
    E,
    D,
    \Cnt_reg[2] ,
    \TXSTATES_reg[1]_1 ,
    \Cnt_reg[3] ,
    \ID_TX_1[8] ,
    \ID_TX_1[28] ,
    \Cnt_reg[4] ,
    \D_Len_TX_1[3] ,
    \ID_TX_1[10] ,
    \ID_TX_1[28]_0 ,
    \Cnt_reg[4]_0 ,
    done_reg,
    SRST_1,
    TEC,
    req_Error_RX,
    \State[2]_i_3 ,
    \Cnt_reg[1] ,
    \State[0]_i_2 ,
    \REC[0]_i_5 ,
    \REC[0]_i_5_0 ,
    Sampled_din,
    done_reg_0,
    Q,
    SRST,
    req_Errorr_reg,
    imTX_reg,
    \CRC_RG_reg[14] ,
    \CRC_RG_reg[14]_0 ,
    \CRC_RG_reg[14]_1 ,
    \Cnt_reg[1]_0 ,
    \Cnt_reg[1]_1 ,
    \Cnt_reg[1]_2 ,
    TX_INST_0_i_2,
    \State[0]_i_4_0 ,
    \REC[0]_i_6_0 ,
    done_reg_1,
    \Cnt_reg[3]_0 ,
    \Cnt_reg[5] ,
    \Cnt_reg[4]_1 ,
    \Cnt_reg[2]_0 ,
    \Cnt_reg[4]_2 ,
    IDE_TX,
    \Cnt_reg[2]_1 ,
    \Cnt_reg[0] ,
    \Cnt_reg[0]_0 ,
    \serial[0]_i_12_0 ,
    \Cnt_reg[3]_1 ,
    done_reg_2,
    \Cnt_reg[5]_0 ,
    done_reg_3,
    \Cnt_reg[1]_3 ,
    \Cnt[0]_i_2_0 ,
    TX_INST_0_i_2_0,
    \serial_reg[0]_0 ,
    imTX_reg_0,
    \serial[0]_i_2_0 ,
    RTR_TX,
    ID_TX,
    D_Len_TX,
    done_reg_4,
    done_reg_5,
    \Cnt_reg[4]_3 ,
    done_i_4_0,
    done_i_4_1,
    done_i_4_2,
    \Cnt_reg[5]_1 ,
    done_i_4_3,
    Tq,
    \serial_reg[0]_1 );
  output \TEC_reg[8] ;
  output req_Error_reg;
  output req_Error_reg_0;
  output req_Error_reg_1;
  output \TXSTATES_reg[3] ;
  output req_Errorr;
  output \TXSTATES_reg[1] ;
  output RXOUT_reg;
  output imTX0_out;
  output \TXSTATES_reg[3]_0 ;
  output \TXSTATES_reg[3]_1 ;
  output \TXSTATES_reg[2] ;
  output \TXSTATES_reg[1]_0 ;
  output [0:0]E;
  output [5:0]D;
  output \Cnt_reg[2] ;
  output \TXSTATES_reg[1]_1 ;
  output \Cnt_reg[3] ;
  output \ID_TX_1[8] ;
  output \ID_TX_1[28] ;
  output \Cnt_reg[4] ;
  output \D_Len_TX_1[3] ;
  output \ID_TX_1[10] ;
  output \ID_TX_1[28]_0 ;
  output \Cnt_reg[4]_0 ;
  output done_reg;
  output [0:0]SRST_1;
  input [1:0]TEC;
  input req_Error_RX;
  input \State[2]_i_3 ;
  input \Cnt_reg[1] ;
  input \State[0]_i_2 ;
  input \REC[0]_i_5 ;
  input \REC[0]_i_5_0 ;
  input Sampled_din;
  input done_reg_0;
  input [3:0]Q;
  input SRST;
  input req_Errorr_reg;
  input imTX_reg;
  input \CRC_RG_reg[14] ;
  input \CRC_RG_reg[14]_0 ;
  input \CRC_RG_reg[14]_1 ;
  input \Cnt_reg[1]_0 ;
  input \Cnt_reg[1]_1 ;
  input \Cnt_reg[1]_2 ;
  input TX_INST_0_i_2;
  input \State[0]_i_4_0 ;
  input \REC[0]_i_6_0 ;
  input done_reg_1;
  input \Cnt_reg[3]_0 ;
  input \Cnt_reg[5] ;
  input \Cnt_reg[4]_1 ;
  input \Cnt_reg[2]_0 ;
  input \Cnt_reg[4]_2 ;
  input IDE_TX;
  input \Cnt_reg[2]_1 ;
  input \Cnt_reg[0] ;
  input \Cnt_reg[0]_0 ;
  input [5:0]\serial[0]_i_12_0 ;
  input \Cnt_reg[3]_1 ;
  input done_reg_2;
  input \Cnt_reg[5]_0 ;
  input done_reg_3;
  input \Cnt_reg[1]_3 ;
  input \Cnt[0]_i_2_0 ;
  input TX_INST_0_i_2_0;
  input \serial_reg[0]_0 ;
  input imTX_reg_0;
  input \serial[0]_i_2_0 ;
  input RTR_TX;
  input [28:0]ID_TX;
  input [3:0]D_Len_TX;
  input done_reg_4;
  input done_reg_5;
  input \Cnt_reg[4]_3 ;
  input done_i_4_0;
  input done_i_4_1;
  input done_i_4_2;
  input \Cnt_reg[5]_1 ;
  input done_i_4_3;
  input Tq;
  input \serial_reg[0]_1 ;

  wire \CRC_RG[14]_i_5_n_0 ;
  wire \CRC_RG_reg[14] ;
  wire \CRC_RG_reg[14]_0 ;
  wire \CRC_RG_reg[14]_1 ;
  wire \Cnt[0]_i_2_0 ;
  wire \Cnt[0]_i_2_n_0 ;
  wire \Cnt[0]_i_4_n_0 ;
  wire \Cnt[1]_i_2_n_0 ;
  wire \Cnt[1]_i_3_n_0 ;
  wire \Cnt[2]_i_3__0_n_0 ;
  wire \Cnt[2]_i_4_n_0 ;
  wire \Cnt[2]_i_5__0_n_0 ;
  wire \Cnt[3]_i_3_n_0 ;
  wire \Cnt[3]_i_5_n_0 ;
  wire \Cnt[3]_i_6__0_n_0 ;
  wire \Cnt[4]_i_2__0_n_0 ;
  wire \Cnt[4]_i_4__0_n_0 ;
  wire \Cnt[4]_i_6__0_n_0 ;
  wire \Cnt[5]_i_3_n_0 ;
  wire \Cnt[5]_i_4__0_n_0 ;
  wire \Cnt[5]_i_6_n_0 ;
  wire \Cnt[5]_i_7_n_0 ;
  wire \Cnt[5]_i_8_n_0 ;
  wire \Cnt_reg[0] ;
  wire \Cnt_reg[0]_0 ;
  wire \Cnt_reg[1] ;
  wire \Cnt_reg[1]_0 ;
  wire \Cnt_reg[1]_1 ;
  wire \Cnt_reg[1]_2 ;
  wire \Cnt_reg[1]_3 ;
  wire \Cnt_reg[2] ;
  wire \Cnt_reg[2]_0 ;
  wire \Cnt_reg[2]_1 ;
  wire \Cnt_reg[3] ;
  wire \Cnt_reg[3]_0 ;
  wire \Cnt_reg[3]_1 ;
  wire \Cnt_reg[4] ;
  wire \Cnt_reg[4]_0 ;
  wire \Cnt_reg[4]_1 ;
  wire \Cnt_reg[4]_2 ;
  wire \Cnt_reg[4]_3 ;
  wire \Cnt_reg[5] ;
  wire \Cnt_reg[5]_0 ;
  wire \Cnt_reg[5]_1 ;
  wire [5:0]D;
  wire [3:0]D_Len_TX;
  wire \D_Len_TX_1[3] ;
  wire [0:0]E;
  wire IDE_TX;
  wire [28:0]ID_TX;
  wire \ID_TX_1[10] ;
  wire \ID_TX_1[28] ;
  wire \ID_TX_1[28]_0 ;
  wire \ID_TX_1[8] ;
  wire [3:0]Q;
  wire \REC[0]_i_5 ;
  wire \REC[0]_i_5_0 ;
  wire \REC[0]_i_6_0 ;
  wire \REC[0]_i_9_n_0 ;
  wire RTR_TX;
  wire RXOUT_reg;
  wire SRST;
  wire [0:0]SRST_1;
  wire Sampled_din;
  wire \State[0]_i_2 ;
  wire \State[0]_i_4_0 ;
  wire \State[0]_i_8_n_0 ;
  wire \State[2]_i_3 ;
  wire [1:0]TEC;
  wire \TEC_reg[8] ;
  wire \TXSTATES[0]_i_3_n_0 ;
  wire \TXSTATES[1]_i_3_n_0 ;
  wire \TXSTATES[3]_i_6_n_0 ;
  wire \TXSTATES_reg[1] ;
  wire \TXSTATES_reg[1]_0 ;
  wire \TXSTATES_reg[1]_1 ;
  wire \TXSTATES_reg[2] ;
  wire \TXSTATES_reg[3] ;
  wire \TXSTATES_reg[3]_0 ;
  wire \TXSTATES_reg[3]_1 ;
  wire TX_INST_0_i_2;
  wire TX_INST_0_i_2_0;
  wire Tq;
  wire done_i_11_n_0;
  wire done_i_12_n_0;
  wire done_i_3__0_n_0;
  wire done_i_4_0;
  wire done_i_4_1;
  wire done_i_4_2;
  wire done_i_4_3;
  wire done_i_4_n_0;
  wire done_i_5_n_0;
  wire done_i_7_n_0;
  wire done_i_8_n_0;
  wire done_reg;
  wire done_reg_0;
  wire done_reg_1;
  wire done_reg_2;
  wire done_reg_3;
  wire done_reg_4;
  wire done_reg_5;
  wire imTX0_out;
  wire imTX_reg;
  wire imTX_reg_0;
  wire req_Error_RX;
  wire req_Error_reg;
  wire req_Error_reg_0;
  wire req_Error_reg_1;
  wire req_Errorr;
  wire req_Errorr_i_2_n_0;
  wire req_Errorr_reg;
  wire [3:0]serial;
  wire [5:0]\serial[0]_i_12_0 ;
  wire \serial[0]_i_12_n_0 ;
  wire \serial[0]_i_1_n_0 ;
  wire \serial[0]_i_25_n_0 ;
  wire \serial[0]_i_27_n_0 ;
  wire \serial[0]_i_2_0 ;
  wire \serial[0]_i_2_n_0 ;
  wire \serial[0]_i_31_n_0 ;
  wire \serial[0]_i_3_n_0 ;
  wire \serial[0]_i_4_n_0 ;
  wire \serial[0]_i_55_n_0 ;
  wire \serial[0]_i_56_n_0 ;
  wire \serial[0]_i_57_n_0 ;
  wire \serial[0]_i_58_n_0 ;
  wire \serial[0]_i_59_n_0 ;
  wire \serial[0]_i_60_n_0 ;
  wire \serial[0]_i_61_n_0 ;
  wire \serial[0]_i_62_n_0 ;
  wire \serial[0]_i_63_n_0 ;
  wire \serial[0]_i_64_n_0 ;
  wire \serial[0]_i_65_n_0 ;
  wire \serial[0]_i_66_n_0 ;
  wire \serial[0]_i_67_n_0 ;
  wire \serial[0]_i_68_n_0 ;
  wire \serial[0]_i_69_n_0 ;
  wire \serial[0]_i_6_n_0 ;
  wire \serial[0]_i_70_n_0 ;
  wire \serial[1]_i_1_n_0 ;
  wire \serial[2]_i_1_n_0 ;
  wire \serial[3]_i_1_n_0 ;
  wire \serial[4]_i_1_n_0 ;
  wire \serial[4]_i_2_n_0 ;
  wire \serial_reg[0]_0 ;
  wire \serial_reg[0]_1 ;
  wire \serial_reg_n_0_[4] ;

  LUT6 #(
    .INIT(64'h5D555D5D5D5D5D5D)) 
    \CRC_RG[14]_i_1 
       (.I0(\CRC_RG_reg[14] ),
        .I1(\CRC_RG_reg[14]_0 ),
        .I2(\CRC_RG[14]_i_5_n_0 ),
        .I3(Q[3]),
        .I4(Q[0]),
        .I5(\CRC_RG_reg[14]_1 ),
        .O(E));
  (* SOFT_HLUTNM = "soft_lutpair91" *) 
  LUT5 #(
    .INIT(32'h80000001)) 
    \CRC_RG[14]_i_5 
       (.I0(serial[0]),
        .I1(\serial_reg_n_0_[4] ),
        .I2(serial[3]),
        .I3(serial[1]),
        .I4(serial[2]),
        .O(\CRC_RG[14]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h8A8888888A8A8A8A)) 
    \Cnt[0]_i_1 
       (.I0(SRST),
        .I1(\Cnt[0]_i_2_n_0 ),
        .I2(Q[3]),
        .I3(\Cnt_reg[0]_0 ),
        .I4(\CRC_RG_reg[14]_1 ),
        .I5(\Cnt[0]_i_4_n_0 ),
        .O(D[0]));
  LUT6 #(
    .INIT(64'h000000000000EC20)) 
    \Cnt[0]_i_2 
       (.I0(\Cnt_reg[2] ),
        .I1(Q[1]),
        .I2(Q[0]),
        .I3(\TXSTATES[3]_i_6_n_0 ),
        .I4(done_reg_3),
        .I5(\serial[0]_i_12_0 [0]),
        .O(\Cnt[0]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hBBAABAAAAAAABAAA)) 
    \Cnt[0]_i_4 
       (.I0(\Cnt[3]_i_5_n_0 ),
        .I1(\Cnt_reg[0] ),
        .I2(Q[0]),
        .I3(Q[1]),
        .I4(\Cnt_reg[2] ),
        .I5(\serial[0]_i_12_0 [0]),
        .O(\Cnt[0]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h00000000AAAA222A)) 
    \Cnt[1]_i_1 
       (.I0(\Cnt[1]_i_2_n_0 ),
        .I1(\Cnt[1]_i_3_n_0 ),
        .I2(\Cnt_reg[1]_0 ),
        .I3(\Cnt_reg[1]_1 ),
        .I4(Q[3]),
        .I5(\Cnt_reg[1]_2 ),
        .O(D[1]));
  LUT6 #(
    .INIT(64'hFFFF55FF5D5D5555)) 
    \Cnt[1]_i_2 
       (.I0(Q[3]),
        .I1(Q[2]),
        .I2(\Cnt_reg[1] ),
        .I3(\Cnt_reg[1]_0 ),
        .I4(\Cnt_reg[1]_3 ),
        .I5(\TXSTATES[1]_i_3_n_0 ),
        .O(\Cnt[1]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFEFEFFFFFAFAFBFF)) 
    \Cnt[1]_i_3 
       (.I0(\Cnt[5]_i_8_n_0 ),
        .I1(Q[1]),
        .I2(Q[2]),
        .I3(\Cnt_reg[2] ),
        .I4(Q[0]),
        .I5(\Cnt_reg[1]_0 ),
        .O(\Cnt[1]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h0000020000AA02AA)) 
    \Cnt[2]_i_1__0 
       (.I0(SRST),
        .I1(\Cnt_reg[2]_0 ),
        .I2(Q[2]),
        .I3(Q[3]),
        .I4(\Cnt[2]_i_3__0_n_0 ),
        .I5(\Cnt[2]_i_4_n_0 ),
        .O(D[2]));
  (* SOFT_HLUTNM = "soft_lutpair90" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \Cnt[2]_i_3__0 
       (.I0(Q[1]),
        .I1(\TXSTATES[3]_i_6_n_0 ),
        .O(\Cnt[2]_i_3__0_n_0 ));
  LUT6 #(
    .INIT(64'hFF77FF770070FF70)) 
    \Cnt[2]_i_4 
       (.I0(\Cnt_reg[4]_2 ),
        .I1(IDE_TX),
        .I2(\Cnt[4]_i_6__0_n_0 ),
        .I3(Q[2]),
        .I4(\Cnt_reg[2]_1 ),
        .I5(\Cnt[2]_i_5__0_n_0 ),
        .O(\Cnt[2]_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair96" *) 
  LUT3 #(
    .INIT(8'h56)) 
    \Cnt[2]_i_5__0 
       (.I0(\serial[0]_i_12_0 [2]),
        .I1(\serial[0]_i_12_0 [1]),
        .I2(\serial[0]_i_12_0 [0]),
        .O(\Cnt[2]_i_5__0_n_0 ));
  LUT6 #(
    .INIT(64'h008000000080AAAA)) 
    \Cnt[3]_i_1__0 
       (.I0(SRST),
        .I1(\Cnt[5]_i_4__0_n_0 ),
        .I2(\Cnt_reg[3]_0 ),
        .I3(Q[2]),
        .I4(Q[3]),
        .I5(\Cnt[3]_i_3_n_0 ),
        .O(D[3]));
  LUT6 #(
    .INIT(64'hFF080000FF88FF88)) 
    \Cnt[3]_i_3 
       (.I0(\Cnt_reg[3]_1 ),
        .I1(Q[1]),
        .I2(\Cnt_reg[2] ),
        .I3(\Cnt[3]_i_5_n_0 ),
        .I4(\Cnt_reg[1]_1 ),
        .I5(\Cnt[3]_i_6__0_n_0 ),
        .O(\Cnt[3]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair93" *) 
  LUT4 #(
    .INIT(16'hFFAB)) 
    \Cnt[3]_i_5 
       (.I0(\Cnt[5]_i_8_n_0 ),
        .I1(Q[0]),
        .I2(Q[1]),
        .I3(Q[2]),
        .O(\Cnt[3]_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair92" *) 
  LUT4 #(
    .INIT(16'hAAA9)) 
    \Cnt[3]_i_6__0 
       (.I0(\serial[0]_i_12_0 [3]),
        .I1(\serial[0]_i_12_0 [0]),
        .I2(\serial[0]_i_12_0 [1]),
        .I3(\serial[0]_i_12_0 [2]),
        .O(\Cnt[3]_i_6__0_n_0 ));
  LUT6 #(
    .INIT(64'h00008A88AAAA8A88)) 
    \Cnt[4]_i_1__0 
       (.I0(SRST),
        .I1(\Cnt[4]_i_2__0_n_0 ),
        .I2(\Cnt_reg[4]_1 ),
        .I3(\CRC_RG_reg[14]_1 ),
        .I4(Q[3]),
        .I5(\Cnt[4]_i_4__0_n_0 ),
        .O(D[4]));
  LUT6 #(
    .INIT(64'h5555001500150015)) 
    \Cnt[4]_i_2__0 
       (.I0(Q[2]),
        .I1(\Cnt_reg[4]_3 ),
        .I2(\Cnt_reg[4]_1 ),
        .I3(\Cnt[4]_i_6__0_n_0 ),
        .I4(IDE_TX),
        .I5(\Cnt_reg[4]_2 ),
        .O(\Cnt[4]_i_2__0_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair88" *) 
  LUT5 #(
    .INIT(32'hFFFFF4F7)) 
    \Cnt[4]_i_4__0 
       (.I0(\Cnt[5]_i_7_n_0 ),
        .I1(Q[1]),
        .I2(\Cnt_reg[4]_1 ),
        .I3(Q[0]),
        .I4(Q[2]),
        .O(\Cnt[4]_i_4__0_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair93" *) 
  LUT2 #(
    .INIT(4'hB)) 
    \Cnt[4]_i_6__0 
       (.I0(\Cnt[5]_i_8_n_0 ),
        .I1(Q[1]),
        .O(\Cnt[4]_i_6__0_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair95" *) 
  LUT3 #(
    .INIT(8'h4F)) 
    \Cnt[5]_i_1 
       (.I0(\Cnt[5]_i_3_n_0 ),
        .I1(\Cnt_reg[5]_1 ),
        .I2(SRST),
        .O(SRST_1));
  LUT6 #(
    .INIT(64'h00080000AAAAAAAA)) 
    \Cnt[5]_i_2__0 
       (.I0(SRST),
        .I1(\Cnt[5]_i_4__0_n_0 ),
        .I2(\Cnt_reg[5] ),
        .I3(Q[2]),
        .I4(Q[3]),
        .I5(\Cnt[5]_i_6_n_0 ),
        .O(D[5]));
  LUT6 #(
    .INIT(64'h8000000100000000)) 
    \Cnt[5]_i_3 
       (.I0(serial[2]),
        .I1(serial[1]),
        .I2(serial[3]),
        .I3(\serial_reg_n_0_[4] ),
        .I4(serial[0]),
        .I5(\CRC_RG_reg[14]_0 ),
        .O(\Cnt[5]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair88" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \Cnt[5]_i_4__0 
       (.I0(\Cnt[5]_i_7_n_0 ),
        .I1(Q[1]),
        .I2(Q[0]),
        .O(\Cnt[5]_i_4__0_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFEEFEFAFAFFFF)) 
    \Cnt[5]_i_6 
       (.I0(Q[3]),
        .I1(\Cnt[5]_i_8_n_0 ),
        .I2(\Cnt_reg[5] ),
        .I3(\Cnt_reg[5]_0 ),
        .I4(Q[2]),
        .I5(Q[1]),
        .O(\Cnt[5]_i_6_n_0 ));
  LUT5 #(
    .INIT(32'h9A99AAAA)) 
    \Cnt[5]_i_7 
       (.I0(Sampled_din),
        .I1(\serial[0]_i_3_n_0 ),
        .I2(\serial[0]_i_4_n_0 ),
        .I3(\State[0]_i_4_0 ),
        .I4(TX_INST_0_i_2),
        .O(\Cnt[5]_i_7_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \Cnt[5]_i_8 
       (.I0(Q[0]),
        .I1(\Cnt[5]_i_7_n_0 ),
        .O(\Cnt[5]_i_8_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFBBBBBBBA)) 
    \REC[0]_i_6 
       (.I0(TEC[1]),
        .I1(req_Error_RX),
        .I2(\REC[0]_i_9_n_0 ),
        .I3(\State[0]_i_8_n_0 ),
        .I4(\State[2]_i_3 ),
        .I5(\Cnt_reg[1] ),
        .O(\TEC_reg[8] ));
  LUT6 #(
    .INIT(64'h00005554FFFFFFFF)) 
    \REC[0]_i_7 
       (.I0(req_Error_RX),
        .I1(\REC[0]_i_9_n_0 ),
        .I2(\State[0]_i_8_n_0 ),
        .I3(\State[2]_i_3 ),
        .I4(\REC[0]_i_5 ),
        .I5(\REC[0]_i_5_0 ),
        .O(req_Error_reg_0));
  LUT6 #(
    .INIT(64'h00000000FF5D00A2)) 
    \REC[0]_i_9 
       (.I0(TX_INST_0_i_2),
        .I1(\State[0]_i_4_0 ),
        .I2(\serial[0]_i_4_n_0 ),
        .I3(\serial[0]_i_3_n_0 ),
        .I4(Sampled_din),
        .I5(\State[0]_i_2 ),
        .O(\REC[0]_i_9_n_0 ));
  LUT6 #(
    .INIT(64'hAAAAAAAAFEFFFEFE)) 
    \State[0]_i_4 
       (.I0(\Cnt_reg[1] ),
        .I1(\State[2]_i_3 ),
        .I2(\State[0]_i_8_n_0 ),
        .I3(\State[0]_i_2 ),
        .I4(\Cnt[5]_i_7_n_0 ),
        .I5(req_Error_RX),
        .O(req_Error_reg));
  LUT6 #(
    .INIT(64'h000000005555DD5D)) 
    \State[0]_i_8 
       (.I0(Sampled_din),
        .I1(TX_INST_0_i_2),
        .I2(\State[0]_i_4_0 ),
        .I3(\serial[0]_i_4_n_0 ),
        .I4(\serial[0]_i_3_n_0 ),
        .I5(\REC[0]_i_6_0 ),
        .O(\State[0]_i_8_n_0 ));
  LUT6 #(
    .INIT(64'h5555555545554514)) 
    \State[2]_i_5 
       (.I0(req_Error_RX),
        .I1(\TXSTATES_reg[3] ),
        .I2(Sampled_din),
        .I3(\State[0]_i_2 ),
        .I4(done_reg_0),
        .I5(\State[2]_i_3 ),
        .O(req_Error_reg_1));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFAB00AB)) 
    \TXSTATES[0]_i_2 
       (.I0(done_i_12_n_0),
        .I1(Q[3]),
        .I2(\TXSTATES[0]_i_3_n_0 ),
        .I3(\Cnt[5]_i_3_n_0 ),
        .I4(Q[0]),
        .I5(done_reg_1),
        .O(\TXSTATES_reg[3]_1 ));
  LUT6 #(
    .INIT(64'hFF00EEFE0FF0FFFF)) 
    \TXSTATES[0]_i_3 
       (.I0(\Cnt[5]_i_8_n_0 ),
        .I1(\Cnt_reg[0] ),
        .I2(\Cnt_reg[2] ),
        .I3(Q[0]),
        .I4(Q[2]),
        .I5(Q[1]),
        .O(\TXSTATES[0]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h88888888B8B8BBB8)) 
    \TXSTATES[1]_i_2 
       (.I0(Q[1]),
        .I1(\Cnt[5]_i_3_n_0 ),
        .I2(done_reg_2),
        .I3(\TXSTATES[1]_i_3_n_0 ),
        .I4(\Cnt_reg[2]_1 ),
        .I5(done_i_7_n_0),
        .O(\TXSTATES_reg[1]_0 ));
  (* SOFT_HLUTNM = "soft_lutpair89" *) 
  LUT3 #(
    .INIT(8'h45)) 
    \TXSTATES[1]_i_3 
       (.I0(Q[2]),
        .I1(\TXSTATES[3]_i_6_n_0 ),
        .I2(Q[1]),
        .O(\TXSTATES[1]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair95" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \TXSTATES[2]_i_2 
       (.I0(Q[2]),
        .I1(\Cnt[5]_i_3_n_0 ),
        .I2(imTX_reg_0),
        .O(\TXSTATES_reg[2] ));
  (* SOFT_HLUTNM = "soft_lutpair89" *) 
  LUT5 #(
    .INIT(32'h30880CCC)) 
    \TXSTATES[3]_i_4 
       (.I0(\TXSTATES[3]_i_6_n_0 ),
        .I1(Q[3]),
        .I2(Q[0]),
        .I3(Q[2]),
        .I4(Q[1]),
        .O(\TXSTATES_reg[3]_0 ));
  LUT6 #(
    .INIT(64'h117C00000080117C)) 
    \TXSTATES[3]_i_5 
       (.I0(Q[1]),
        .I1(Q[2]),
        .I2(Q[0]),
        .I3(Q[3]),
        .I4(Sampled_din),
        .I5(\TXSTATES_reg[3] ),
        .O(\TXSTATES_reg[1] ));
  LUT6 #(
    .INIT(64'hAAAAAAAA22222022)) 
    \TXSTATES[3]_i_6 
       (.I0(\Cnt[5]_i_7_n_0 ),
        .I1(Q[0]),
        .I2(TEC[0]),
        .I3(\Cnt[0]_i_2_0 ),
        .I4(TEC[1]),
        .I5(\Cnt_reg[2] ),
        .O(\TXSTATES[3]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'h00000000AAAA00A2)) 
    TX_INST_0_i_3
       (.I0(TX_INST_0_i_2),
        .I1(TX_INST_0_i_2_0),
        .I2(\serial_reg[0]_0 ),
        .I3(Q[3]),
        .I4(\serial[0]_i_4_n_0 ),
        .I5(\serial[0]_i_3_n_0 ),
        .O(\TXSTATES_reg[3] ));
  LUT6 #(
    .INIT(64'hFFB0FF00FF0B000F)) 
    ack_error_i_5
       (.I0(\TXSTATES_reg[3] ),
        .I1(Sampled_din),
        .I2(Q[0]),
        .I3(Q[3]),
        .I4(Q[1]),
        .I5(Q[2]),
        .O(RXOUT_reg));
  LUT6 #(
    .INIT(64'hFF08FFFFFF080000)) 
    done_i_1
       (.I0(done_reg_0),
        .I1(done_i_3__0_n_0),
        .I2(done_i_4_n_0),
        .I3(done_i_5_n_0),
        .I4(done_reg_4),
        .I5(done_reg_5),
        .O(done_reg));
  LUT6 #(
    .INIT(64'h0000000155555555)) 
    done_i_11
       (.I0(Q[3]),
        .I1(done_i_4_0),
        .I2(done_i_4_1),
        .I3(\Cnt_reg[0] ),
        .I4(\Cnt[5]_i_8_n_0 ),
        .I5(done_i_4_2),
        .O(done_i_11_n_0));
  LUT6 #(
    .INIT(64'h000000003B083B3B)) 
    done_i_12
       (.I0(\Cnt[5]_i_7_n_0 ),
        .I1(Q[1]),
        .I2(done_i_4_3),
        .I3(\Cnt_reg[2] ),
        .I4(Q[0]),
        .I5(done_reg_3),
        .O(done_i_12_n_0));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFFFE)) 
    done_i_14
       (.I0(\serial[0]_i_12_0 [2]),
        .I1(\serial[0]_i_12_0 [1]),
        .I2(\serial[0]_i_12_0 [0]),
        .I3(\serial[0]_i_12_0 [3]),
        .I4(\serial[0]_i_12_0 [5]),
        .I5(\serial[0]_i_12_0 [4]),
        .O(\Cnt_reg[2] ));
  LUT6 #(
    .INIT(64'h0000444555554445)) 
    done_i_3__0
       (.I0(\TXSTATES_reg[2] ),
        .I1(done_i_7_n_0),
        .I2(done_i_8_n_0),
        .I3(done_reg_2),
        .I4(\Cnt[5]_i_3_n_0 ),
        .I5(Q[1]),
        .O(done_i_3__0_n_0));
  LUT6 #(
    .INIT(64'hFEFFFEFFFEFFFEEE)) 
    done_i_4
       (.I0(\TXSTATES_reg[3]_0 ),
        .I1(done_reg_1),
        .I2(Q[0]),
        .I3(\Cnt[5]_i_3_n_0 ),
        .I4(done_i_11_n_0),
        .I5(done_i_12_n_0),
        .O(done_i_4_n_0));
  LUT6 #(
    .INIT(64'h00100000FFFFFFFF)) 
    done_i_5
       (.I0(done_reg_3),
        .I1(\Cnt_reg[2] ),
        .I2(Q[0]),
        .I3(Q[1]),
        .I4(req_Errorr_i_2_n_0),
        .I5(SRST),
        .O(done_i_5_n_0));
  LUT6 #(
    .INIT(64'h0000CCF30000AEBB)) 
    done_i_7
       (.I0(\Cnt[5]_i_8_n_0 ),
        .I1(Q[0]),
        .I2(\Cnt_reg[2] ),
        .I3(Q[1]),
        .I4(Q[3]),
        .I5(Q[2]),
        .O(done_i_7_n_0));
  (* SOFT_HLUTNM = "soft_lutpair90" *) 
  LUT5 #(
    .INIT(32'h22220030)) 
    done_i_8
       (.I0(\TXSTATES[3]_i_6_n_0 ),
        .I1(Q[2]),
        .I2(Q[0]),
        .I3(\Cnt_reg[2] ),
        .I4(Q[1]),
        .O(done_i_8_n_0));
  LUT6 #(
    .INIT(64'hBBBBBBFEAAAAAAAA)) 
    imTX_i_1
       (.I0(imTX_reg),
        .I1(\TXSTATES_reg[3]_0 ),
        .I2(\TXSTATES_reg[3]_1 ),
        .I3(\TXSTATES_reg[2] ),
        .I4(\TXSTATES_reg[1]_0 ),
        .I5(SRST),
        .O(imTX0_out));
  LUT6 #(
    .INIT(64'h00000000CFFE0000)) 
    req_Errorr_i_1
       (.I0(Q[0]),
        .I1(Q[2]),
        .I2(Q[3]),
        .I3(Q[1]),
        .I4(SRST),
        .I5(req_Errorr_i_2_n_0),
        .O(req_Errorr));
  LUT2 #(
    .INIT(4'h1)) 
    req_Errorr_i_2
       (.I0(req_Errorr_reg),
        .I1(\TXSTATES_reg[1] ),
        .O(req_Errorr_i_2_n_0));
  LUT2 #(
    .INIT(4'hB)) 
    \serial[0]_i_1 
       (.I0(\serial[0]_i_2_n_0 ),
        .I1(SRST),
        .O(\serial[0]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h8888888888088888)) 
    \serial[0]_i_10 
       (.I0(\D_Len_TX_1[3] ),
        .I1(Q[1]),
        .I2(\serial[0]_i_25_n_0 ),
        .I3(\serial[0]_i_12_0 [3]),
        .I4(\serial[0]_i_12_0 [2]),
        .I5(\serial[0]_i_12_0 [1]),
        .O(\TXSTATES_reg[1]_1 ));
  LUT6 #(
    .INIT(64'h00000000FEAB02A8)) 
    \serial[0]_i_11 
       (.I0(\ID_TX_1[10] ),
        .I1(\serial[0]_i_12_0 [3]),
        .I2(\serial[0]_i_27_n_0 ),
        .I3(\serial[0]_i_12_0 [4]),
        .I4(\ID_TX_1[28]_0 ),
        .I5(\Cnt_reg[4]_0 ),
        .O(\Cnt_reg[3] ));
  LUT6 #(
    .INIT(64'h00450045000300CF)) 
    \serial[0]_i_12 
       (.I0(\ID_TX_1[8] ),
        .I1(\Cnt_reg[2] ),
        .I2(RTR_TX),
        .I3(\serial[0]_i_31_n_0 ),
        .I4(\ID_TX_1[28] ),
        .I5(\Cnt_reg[4] ),
        .O(\serial[0]_i_12_n_0 ));
  LUT6 #(
    .INIT(64'hBABBBABBBABBBABA)) 
    \serial[0]_i_2 
       (.I0(\serial[0]_i_3_n_0 ),
        .I1(\serial[0]_i_4_n_0 ),
        .I2(Q[3]),
        .I3(\serial_reg[0]_0 ),
        .I4(Q[2]),
        .I5(\serial[0]_i_6_n_0 ),
        .O(\serial[0]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \serial[0]_i_24 
       (.I0(D_Len_TX[3]),
        .I1(D_Len_TX[2]),
        .I2(\serial[0]_i_12_0 [1]),
        .I3(D_Len_TX[1]),
        .I4(\serial[0]_i_12_0 [0]),
        .I5(D_Len_TX[0]),
        .O(\D_Len_TX_1[3] ));
  LUT2 #(
    .INIT(4'h1)) 
    \serial[0]_i_25 
       (.I0(\serial[0]_i_12_0 [4]),
        .I1(\serial[0]_i_12_0 [5]),
        .O(\serial[0]_i_25_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \serial[0]_i_26 
       (.I0(\serial[0]_i_55_n_0 ),
        .I1(\serial[0]_i_56_n_0 ),
        .I2(\serial[0]_i_57_n_0 ),
        .I3(\serial[0]_i_58_n_0 ),
        .I4(\serial[0]_i_59_n_0 ),
        .I5(\serial[0]_i_60_n_0 ),
        .O(\ID_TX_1[10] ));
  (* SOFT_HLUTNM = "soft_lutpair96" *) 
  LUT3 #(
    .INIT(8'hEA)) 
    \serial[0]_i_27 
       (.I0(\serial[0]_i_12_0 [2]),
        .I1(\serial[0]_i_12_0 [1]),
        .I2(\serial[0]_i_12_0 [0]),
        .O(\serial[0]_i_27_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \serial[0]_i_28 
       (.I0(\serial[0]_i_61_n_0 ),
        .I1(ID_TX[28]),
        .I2(\serial[0]_i_57_n_0 ),
        .I3(\serial[0]_i_62_n_0 ),
        .I4(\serial[0]_i_59_n_0 ),
        .I5(\serial[0]_i_63_n_0 ),
        .O(\ID_TX_1[28]_0 ));
  LUT6 #(
    .INIT(64'h000000005555777F)) 
    \serial[0]_i_29 
       (.I0(\serial[0]_i_12_0 [4]),
        .I1(\serial[0]_i_12_0 [2]),
        .I2(\serial[0]_i_12_0 [1]),
        .I3(\serial[0]_i_12_0 [0]),
        .I4(\serial[0]_i_12_0 [3]),
        .I5(\serial[0]_i_12_0 [5]),
        .O(\Cnt_reg[4]_0 ));
  LUT5 #(
    .INIT(32'h00000001)) 
    \serial[0]_i_3 
       (.I0(serial[3]),
        .I1(serial[0]),
        .I2(serial[2]),
        .I3(\serial_reg_n_0_[4] ),
        .I4(serial[1]),
        .O(\serial[0]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \serial[0]_i_30 
       (.I0(\serial[0]_i_64_n_0 ),
        .I1(\serial[0]_i_65_n_0 ),
        .I2(\Cnt[3]_i_6__0_n_0 ),
        .I3(\serial[0]_i_66_n_0 ),
        .I4(\Cnt[2]_i_5__0_n_0 ),
        .I5(\serial[0]_i_67_n_0 ),
        .O(\ID_TX_1[8] ));
  LUT6 #(
    .INIT(64'h0004000000000400)) 
    \serial[0]_i_31 
       (.I0(\serial[0]_i_12_0 [3]),
        .I1(\serial[0]_i_12_0 [4]),
        .I2(\serial[0]_i_12_0 [5]),
        .I3(\serial[0]_i_12_0 [2]),
        .I4(\serial[0]_i_12_0 [1]),
        .I5(\serial[0]_i_12_0 [0]),
        .O(\serial[0]_i_31_n_0 ));
  LUT6 #(
    .INIT(64'hCFC0AFAFCFC0A0A0)) 
    \serial[0]_i_32 
       (.I0(ID_TX[28]),
        .I1(\serial[0]_i_68_n_0 ),
        .I2(\Cnt[3]_i_6__0_n_0 ),
        .I3(\serial[0]_i_69_n_0 ),
        .I4(\Cnt[2]_i_5__0_n_0 ),
        .I5(\serial[0]_i_70_n_0 ),
        .O(\ID_TX_1[28] ));
  (* SOFT_HLUTNM = "soft_lutpair92" *) 
  LUT5 #(
    .INIT(32'h55555556)) 
    \serial[0]_i_33 
       (.I0(\serial[0]_i_12_0 [4]),
        .I1(\serial[0]_i_12_0 [2]),
        .I2(\serial[0]_i_12_0 [1]),
        .I3(\serial[0]_i_12_0 [0]),
        .I4(\serial[0]_i_12_0 [3]),
        .O(\Cnt_reg[4] ));
  (* SOFT_HLUTNM = "soft_lutpair91" *) 
  LUT5 #(
    .INIT(32'h80000000)) 
    \serial[0]_i_4 
       (.I0(serial[2]),
        .I1(serial[1]),
        .I2(serial[3]),
        .I3(\serial_reg_n_0_[4] ),
        .I4(serial[0]),
        .O(\serial[0]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hFCAF0CAFFCA00CA0)) 
    \serial[0]_i_55 
       (.I0(ID_TX[10]),
        .I1(ID_TX[11]),
        .I2(\serial[0]_i_12_0 [0]),
        .I3(\serial[0]_i_12_0 [1]),
        .I4(ID_TX[8]),
        .I5(ID_TX[9]),
        .O(\serial[0]_i_55_n_0 ));
  LUT6 #(
    .INIT(64'hFCAF0CAFFCA00CA0)) 
    \serial[0]_i_56 
       (.I0(ID_TX[14]),
        .I1(ID_TX[15]),
        .I2(\serial[0]_i_12_0 [0]),
        .I3(\serial[0]_i_12_0 [1]),
        .I4(ID_TX[12]),
        .I5(ID_TX[13]),
        .O(\serial[0]_i_56_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair94" *) 
  LUT4 #(
    .INIT(16'hAA95)) 
    \serial[0]_i_57 
       (.I0(\serial[0]_i_12_0 [3]),
        .I1(\serial[0]_i_12_0 [0]),
        .I2(\serial[0]_i_12_0 [1]),
        .I3(\serial[0]_i_12_0 [2]),
        .O(\serial[0]_i_57_n_0 ));
  LUT6 #(
    .INIT(64'hFCAF0CAFFCA00CA0)) 
    \serial[0]_i_58 
       (.I0(ID_TX[2]),
        .I1(ID_TX[3]),
        .I2(\serial[0]_i_12_0 [0]),
        .I3(\serial[0]_i_12_0 [1]),
        .I4(ID_TX[0]),
        .I5(ID_TX[1]),
        .O(\serial[0]_i_58_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair94" *) 
  LUT3 #(
    .INIT(8'h6A)) 
    \serial[0]_i_59 
       (.I0(\serial[0]_i_12_0 [2]),
        .I1(\serial[0]_i_12_0 [1]),
        .I2(\serial[0]_i_12_0 [0]),
        .O(\serial[0]_i_59_n_0 ));
  LUT6 #(
    .INIT(64'hAACFAACFAACFAAFF)) 
    \serial[0]_i_6 
       (.I0(\TXSTATES_reg[1]_1 ),
        .I1(\Cnt_reg[3] ),
        .I2(Q[1]),
        .I3(Q[0]),
        .I4(\serial[0]_i_12_n_0 ),
        .I5(\serial[0]_i_2_0 ),
        .O(\serial[0]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'hFCAF0CAFFCA00CA0)) 
    \serial[0]_i_60 
       (.I0(ID_TX[6]),
        .I1(ID_TX[7]),
        .I2(\serial[0]_i_12_0 [0]),
        .I3(\serial[0]_i_12_0 [1]),
        .I4(ID_TX[4]),
        .I5(ID_TX[5]),
        .O(\serial[0]_i_60_n_0 ));
  LUT6 #(
    .INIT(64'hFCAF0CAFFCA00CA0)) 
    \serial[0]_i_61 
       (.I0(ID_TX[26]),
        .I1(ID_TX[27]),
        .I2(\serial[0]_i_12_0 [0]),
        .I3(\serial[0]_i_12_0 [1]),
        .I4(ID_TX[24]),
        .I5(ID_TX[25]),
        .O(\serial[0]_i_61_n_0 ));
  LUT6 #(
    .INIT(64'hFCAF0CAFFCA00CA0)) 
    \serial[0]_i_62 
       (.I0(ID_TX[18]),
        .I1(ID_TX[19]),
        .I2(\serial[0]_i_12_0 [0]),
        .I3(\serial[0]_i_12_0 [1]),
        .I4(ID_TX[16]),
        .I5(ID_TX[17]),
        .O(\serial[0]_i_62_n_0 ));
  LUT6 #(
    .INIT(64'hFCAF0CAFFCA00CA0)) 
    \serial[0]_i_63 
       (.I0(ID_TX[22]),
        .I1(ID_TX[23]),
        .I2(\serial[0]_i_12_0 [0]),
        .I3(\serial[0]_i_12_0 [1]),
        .I4(ID_TX[20]),
        .I5(ID_TX[21]),
        .O(\serial[0]_i_63_n_0 ));
  LUT6 #(
    .INIT(64'hFCAF0CAFFCA00CA0)) 
    \serial[0]_i_64 
       (.I0(ID_TX[8]),
        .I1(ID_TX[9]),
        .I2(\serial[0]_i_12_0 [0]),
        .I3(\serial[0]_i_12_0 [1]),
        .I4(ID_TX[10]),
        .I5(ID_TX[11]),
        .O(\serial[0]_i_64_n_0 ));
  LUT6 #(
    .INIT(64'hFCAF0CAFFCA00CA0)) 
    \serial[0]_i_65 
       (.I0(ID_TX[12]),
        .I1(ID_TX[13]),
        .I2(\serial[0]_i_12_0 [0]),
        .I3(\serial[0]_i_12_0 [1]),
        .I4(ID_TX[14]),
        .I5(ID_TX[15]),
        .O(\serial[0]_i_65_n_0 ));
  LUT6 #(
    .INIT(64'hFCAF0CAFFCA00CA0)) 
    \serial[0]_i_66 
       (.I0(ID_TX[0]),
        .I1(ID_TX[1]),
        .I2(\serial[0]_i_12_0 [0]),
        .I3(\serial[0]_i_12_0 [1]),
        .I4(ID_TX[2]),
        .I5(ID_TX[3]),
        .O(\serial[0]_i_66_n_0 ));
  LUT6 #(
    .INIT(64'hFCAF0CAFFCA00CA0)) 
    \serial[0]_i_67 
       (.I0(ID_TX[4]),
        .I1(ID_TX[5]),
        .I2(\serial[0]_i_12_0 [0]),
        .I3(\serial[0]_i_12_0 [1]),
        .I4(ID_TX[6]),
        .I5(ID_TX[7]),
        .O(\serial[0]_i_67_n_0 ));
  LUT6 #(
    .INIT(64'hFCAF0CAFFCA00CA0)) 
    \serial[0]_i_68 
       (.I0(ID_TX[24]),
        .I1(ID_TX[25]),
        .I2(\serial[0]_i_12_0 [0]),
        .I3(\serial[0]_i_12_0 [1]),
        .I4(ID_TX[26]),
        .I5(ID_TX[27]),
        .O(\serial[0]_i_68_n_0 ));
  LUT6 #(
    .INIT(64'hFCAF0CAFFCA00CA0)) 
    \serial[0]_i_69 
       (.I0(ID_TX[16]),
        .I1(ID_TX[17]),
        .I2(\serial[0]_i_12_0 [0]),
        .I3(\serial[0]_i_12_0 [1]),
        .I4(ID_TX[18]),
        .I5(ID_TX[19]),
        .O(\serial[0]_i_69_n_0 ));
  LUT6 #(
    .INIT(64'hFCAF0CAFFCA00CA0)) 
    \serial[0]_i_70 
       (.I0(ID_TX[20]),
        .I1(ID_TX[21]),
        .I2(\serial[0]_i_12_0 [0]),
        .I3(\serial[0]_i_12_0 [1]),
        .I4(ID_TX[22]),
        .I5(ID_TX[23]),
        .O(\serial[0]_i_70_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair98" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \serial[1]_i_1 
       (.I0(SRST),
        .I1(serial[0]),
        .O(\serial[1]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair98" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \serial[2]_i_1 
       (.I0(SRST),
        .I1(serial[1]),
        .O(\serial[2]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair97" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \serial[3]_i_1 
       (.I0(SRST),
        .I1(serial[2]),
        .O(\serial[3]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h00000AA8FFFFFFFF)) 
    \serial[4]_i_1 
       (.I0(\Cnt_reg[5]_1 ),
        .I1(Q[0]),
        .I2(Q[2]),
        .I3(Q[1]),
        .I4(Q[3]),
        .I5(SRST),
        .O(\serial[4]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair97" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \serial[4]_i_2 
       (.I0(SRST),
        .I1(serial[3]),
        .O(\serial[4]_i_2_n_0 ));
  FDPE \serial_reg[0] 
       (.C(Tq),
        .CE(\serial[4]_i_1_n_0 ),
        .D(\serial[0]_i_1_n_0 ),
        .PRE(\serial_reg[0]_1 ),
        .Q(serial[0]));
  FDCE \serial_reg[1] 
       (.C(Tq),
        .CE(\serial[4]_i_1_n_0 ),
        .CLR(\serial_reg[0]_1 ),
        .D(\serial[1]_i_1_n_0 ),
        .Q(serial[1]));
  FDCE \serial_reg[2] 
       (.C(Tq),
        .CE(\serial[4]_i_1_n_0 ),
        .CLR(\serial_reg[0]_1 ),
        .D(\serial[2]_i_1_n_0 ),
        .Q(serial[2]));
  FDCE \serial_reg[3] 
       (.C(Tq),
        .CE(\serial[4]_i_1_n_0 ),
        .CLR(\serial_reg[0]_1 ),
        .D(\serial[3]_i_1_n_0 ),
        .Q(serial[3]));
  FDCE \serial_reg[4] 
       (.C(Tq),
        .CE(\serial[4]_i_1_n_0 ),
        .CLR(\serial_reg[0]_1 ),
        .D(\serial[4]_i_2_n_0 ),
        .Q(\serial_reg_n_0_[4] ));
endmodule

(* ORIG_REF_NAME = "dff" *) 
module design_1_FPGAPROJECT_0_0_dff
   (q_reg_0,
    RX,
    clk,
    q_reg_1);
  output q_reg_0;
  input RX;
  input clk;
  input q_reg_1;

  wire RX;
  wire clk;
  wire q_reg_0;
  wire q_reg_1;

  FDCE q_reg
       (.C(clk),
        .CE(1'b1),
        .CLR(q_reg_1),
        .D(RX),
        .Q(q_reg_0));
endmodule

(* ORIG_REF_NAME = "dff" *) 
module design_1_FPGAPROJECT_0_0_dff_1
   (q,
    q_reg_0,
    clk,
    q_reg_1);
  output q;
  input q_reg_0;
  input clk;
  input q_reg_1;

  wire clk;
  wire q;
  wire q_reg_0;
  wire q_reg_1;

  FDCE q_reg
       (.C(clk),
        .CE(1'b1),
        .CLR(q_reg_1),
        .D(q_reg_0),
        .Q(q));
endmodule

(* ORIG_REF_NAME = "dff" *) 
module design_1_FPGAPROJECT_0_0_dff_11
   (q_reg_0,
    RX,
    Tq,
    q_reg_1);
  output q_reg_0;
  input RX;
  input Tq;
  input q_reg_1;

  wire RX;
  wire Tq;
  wire q_reg_0;
  wire q_reg_1;

  FDCE q_reg
       (.C(Tq),
        .CE(1'b1),
        .CLR(q_reg_1),
        .D(RX),
        .Q(q_reg_0));
endmodule

(* ORIG_REF_NAME = "dff" *) 
module design_1_FPGAPROJECT_0_0_dff_12
   (RXBUSs,
    q_reg_0,
    Tq,
    q_reg_1);
  output RXBUSs;
  input q_reg_0;
  input Tq;
  input q_reg_1;

  wire RXBUSs;
  wire Tq;
  wire q_reg_0;
  wire q_reg_1;

  FDCE q_reg
       (.C(Tq),
        .CE(1'b1),
        .CLR(q_reg_1),
        .D(q_reg_0),
        .Q(RXBUSs));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
