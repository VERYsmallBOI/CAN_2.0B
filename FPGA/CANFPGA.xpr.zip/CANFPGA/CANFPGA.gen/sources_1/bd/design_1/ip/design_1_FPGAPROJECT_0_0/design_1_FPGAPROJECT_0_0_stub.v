// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2025.2 (win64) Build 6299465 Fri Nov 14 19:35:11 GMT 2025
// Date        : Tue Sep 15 17:17:25 2026
// Host        : CLANKER running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode synth_stub
//               c:/Users/Tamil/Documents/Mirafra/CAN_FPGA/CANFPGA/CANFPGA.gen/sources_1/bd/design_1/ip/design_1_FPGAPROJECT_0_0/design_1_FPGAPROJECT_0_0_stub.v
// Design      : design_1_FPGAPROJECT_0_0
// Purpose     : Stub declaration of top-level module interface
// Device      : xc7z007sclg400-1
// --------------------------------------------------------------------------------

// This empty module with port declaration file causes synthesis tools to infer a black box for IP.
// The synthesis directives are for Synopsys Synplify support to prevent IO buffer insertion.
// Please paste the declaration into a Verilog source file or add the file as an additional source.
(* CHECK_LICENSE_TYPE = "design_1_FPGAPROJECT_0_0,FPGAPROJECT,{}" *) (* CORE_GENERATION_INFO = "design_1_FPGAPROJECT_0_0,FPGAPROJECT,{x_ipProduct=Vivado 2025.2,x_ipVendor=xilinx.com,x_ipLibrary=module_ref,x_ipName=FPGAPROJECT,x_ipVersion=1.0,x_ipCoreRevision=1,x_ipLanguage=VERILOG,x_ipSimLanguage=MIXED}" *) (* DowngradeIPIdentifiedWarnings = "yes" *) 
(* IP_DEFINITION_SOURCE = "module_ref" *) (* X_CORE_INFO = "FPGAPROJECT,Vivado 2025.2" *) 
module design_1_FPGAPROJECT_0_0(CAN_CLK, CAN_RST, SRST_0, BRP_0, Mode_0, 
  TRANSMIT_0, IDE_TX_0, RTR_TX_0, D_Len_TX_0, ID_TX_0, data_TX_0, done_RX_0, done_TX_0, IDE_rec_0, 
  RTR_rec_0, D_Len_rec_0, TOFILTERd_0, TOFILTERI_0, TEC_0, REC_0, SRST_1, BRP_1, Mode_1, TRANSMIT_1, 
  IDE_TX_1, RTR_TX_1, D_Len_TX_1, ID_TX_1, data_TX_1, done_RX_1, done_TX_1, IDE_rec_1, RTR_rec_1, 
  D_Len_rec_1, TOFILTERd_1, TOFILTERI_1, TEC_1, REC_1)
/* synthesis syn_black_box black_box_pad_pin="CAN_RST,SRST_0,BRP_0[4:0],Mode_0[2:0],TRANSMIT_0,IDE_TX_0,RTR_TX_0,D_Len_TX_0[3:0],ID_TX_0[28:0],data_TX_0[63:0],done_RX_0,done_TX_0,IDE_rec_0,RTR_rec_0,D_Len_rec_0[3:0],TOFILTERd_0[63:0],TOFILTERI_0[28:0],TEC_0[8:0],REC_0[8:0],SRST_1,BRP_1[4:0],Mode_1[2:0],TRANSMIT_1,IDE_TX_1,RTR_TX_1,D_Len_TX_1[3:0],ID_TX_1[28:0],data_TX_1[63:0],done_RX_1,done_TX_1,IDE_rec_1,RTR_rec_1,D_Len_rec_1[3:0],TOFILTERd_1[63:0],TOFILTERI_1[28:0],TEC_1[8:0],REC_1[8:0]" */
/* synthesis syn_force_seq_prim="CAN_CLK" */;
  (* X_INTERFACE_INFO = "xilinx.com:signal:clock:1.0 CAN_CLK CLK" *) (* X_INTERFACE_MODE = "slave" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME CAN_CLK, ASSOCIATED_RESET CAN_RST, FREQ_HZ 10000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN /clk_wiz_0_clk_out1, INSERT_VIP 0" *) input CAN_CLK /* synthesis syn_isclock = 1 */;
  (* X_INTERFACE_INFO = "xilinx.com:signal:reset:1.0 CAN_RST RST" *) (* X_INTERFACE_MODE = "slave" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME CAN_RST, POLARITY ACTIVE_LOW, INSERT_VIP 0" *) input CAN_RST;
  input SRST_0;
  input [4:0]BRP_0;
  input [2:0]Mode_0;
  input TRANSMIT_0;
  input IDE_TX_0;
  input RTR_TX_0;
  input [3:0]D_Len_TX_0;
  input [28:0]ID_TX_0;
  input [63:0]data_TX_0;
  output done_RX_0;
  output done_TX_0;
  output IDE_rec_0;
  output RTR_rec_0;
  output [3:0]D_Len_rec_0;
  output [63:0]TOFILTERd_0;
  output [28:0]TOFILTERI_0;
  output [8:0]TEC_0;
  output [8:0]REC_0;
  input SRST_1;
  input [4:0]BRP_1;
  input [2:0]Mode_1;
  input TRANSMIT_1;
  input IDE_TX_1;
  input RTR_TX_1;
  input [3:0]D_Len_TX_1;
  input [28:0]ID_TX_1;
  input [63:0]data_TX_1;
  output done_RX_1;
  output done_TX_1;
  output IDE_rec_1;
  output RTR_rec_1;
  output [3:0]D_Len_rec_1;
  output [63:0]TOFILTERd_1;
  output [28:0]TOFILTERI_1;
  output [8:0]TEC_1;
  output [8:0]REC_1;
endmodule
