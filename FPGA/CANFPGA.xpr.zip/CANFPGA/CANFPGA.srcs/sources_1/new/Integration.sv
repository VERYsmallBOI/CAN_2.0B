module Integration (
    input wire clk_in1,   // input clock to clock wizard
    input wire rst        // reset input (connect to resetn and CAN_RST)
);

    // Clock wizard output
    wire clk_out1;

    // VIO probe_out wires
    wire [63:0] probe_out0;
    wire [28:0] probe_out1;
    wire [4:0]  probe_out2;
    wire [3:0]  probe_out3;
    wire [2:0]  probe_out4;
    wire        probe_out5;
    wire        probe_out6;
    wire        probe_out7;
    wire [63:0] probe_out8;
    wire [28:0] probe_out9;
    wire [4:0]  probe_out10;
    wire [3:0]  probe_out11;
    wire [2:0]  probe_out12;
    wire        probe_out13;
    wire        probe_out14;
    wire        probe_out15;
    wire        probe_out16;
    wire        probe_out17;

    // FPGAPROJECT output wires
    wire [63:0] TOFILTERd_0;
    wire [28:0] TOFILTERI_0;
    wire [8:0]  TEC_0;
    wire [8:0]  REC_0;
    wire [3:0]  D_Len_rec_0;
    wire        RTR_rec_0;
    wire        IDE_rec_0;
    wire        done_RX_0;
    wire        done_TX_0;

    wire [63:0] TOFILTERd_1;
    wire [28:0] TOFILTERI_1;
    wire [8:0]  TEC_1;
    wire [8:0]  REC_1;
    wire [3:0]  D_Len_rec_1;
    wire        RTR_rec_1;
    wire        IDE_rec_1;
    wire        done_RX_1;
    wire        done_TX_1;

    // Clock wizard instance
    clk_wiz_0 clk_wiz_inst (
        .clk_out1(clk_out1),
        .resetn(rst),      // assuming active-low reset; if active-high, use ~rst
        .clk_in1(clk_in1)
    );

    // VIO instance
    vio_0 vio1 (
        .clk(clk_out1),
        .probe_in0(TOFILTERd_0),
        .probe_in1(TOFILTERI_0),
        .probe_in2(REC_0),
        .probe_in3(TEC_0),
        .probe_in4(D_Len_rec_0),
        .probe_in5(RTR_rec_0),
        .probe_in6(IDE_rec_0),
        .probe_in7(done_RX_0),
        .probe_in8(done_TX_0),
        .probe_in9(TOFILTERd_1),
        .probe_in10(TOFILTERI_1),
        .probe_in11(REC_1),
        .probe_in12(TEC_1),
        .probe_in13(D_Len_rec_1),
        .probe_in14(RTR_rec_1),
        .probe_in15(IDE_rec_1),
        .probe_in16(done_RX_1),
        .probe_in17(done_TX_1),
        .probe_out0(probe_out0),
        .probe_out1(probe_out1),
        .probe_out2(probe_out2),
        .probe_out3(probe_out3),
        .probe_out4(probe_out4),
        .probe_out5(probe_out5),
        .probe_out6(probe_out6),
        .probe_out7(probe_out7),
        .probe_out8(probe_out8),
        .probe_out9(probe_out9),
        .probe_out10(probe_out10),
        .probe_out11(probe_out11),
        .probe_out12(probe_out12),
        .probe_out13(probe_out13),
        .probe_out14(probe_out14),
        .probe_out15(probe_out15),
        .probe_out16(probe_out16),
        .probe_out17(probe_out17)
    );

    // FPGAPROJECT instance
    FPGAPROJECT u_FPGAPROJECT (
        .CAN_CLK(clk_out1),
        .CAN_RST(rst),        // same reset
        .SRST_0(probe_out16),
        .BRP_0(probe_out2),
        .Mode_0(probe_out4),
        .TRANSMIT_0(probe_out7),
        .IDE_TX_0(probe_out6),
        .RTR_TX_0(probe_out5),
        .D_Len_TX_0(probe_out3),
        .ID_TX_0(probe_out1),
        .data_TX_0(probe_out0),
        .done_RX_0(done_RX_0),
        .done_TX_0(done_TX_0),
        .IDE_rec_0(IDE_rec_0),
        .RTR_rec_0(RTR_rec_0),
        .D_Len_rec_0(D_Len_rec_0),
        .TOFILTERd_0(TOFILTERd_0),
        .TOFILTERI_0(TOFILTERI_0),
        .TEC_0(TEC_0),
        .REC_0(REC_0),
        .SRST_1(probe_out17),
        .BRP_1(probe_out10),
        .Mode_1(probe_out12),
        .TRANSMIT_1(probe_out15),
        .IDE_TX_1(probe_out14),
        .RTR_TX_1(probe_out13),
        .D_Len_TX_1(probe_out11),
        .ID_TX_1(probe_out9),
        .data_TX_1(probe_out8),
        .done_RX_1(done_RX_1),
        .done_TX_1(done_TX_1),
        .IDE_rec_1(IDE_rec_1),
        .RTR_rec_1(RTR_rec_1),
        .D_Len_rec_1(D_Len_rec_1),
        .TOFILTERd_1(TOFILTERd_1),
        .TOFILTERI_1(TOFILTERI_1),
        .TEC_1(TEC_1),
        .REC_1(REC_1)
    );

endmodule