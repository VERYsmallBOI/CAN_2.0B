module FPGAPROJECT (
    input  wire CAN_CLK,
    input  wire CAN_RST,

    // =========================
    // CANCORE_0 external signals
    // =========================

    input  wire        SRST_0,

    input  wire [4:0]  BRP_0,
    input  wire [2:0]  Mode_0,

    input  wire        TRANSMIT_0,
    input  wire        IDE_TX_0,
    input  wire        RTR_TX_0,
    input  wire [3:0]  D_Len_TX_0,
    input  wire [28:0] ID_TX_0,
    input  wire [63:0] data_TX_0,

    output wire        done_RX_0,
    output wire        done_TX_0,

    output wire        IDE_rec_0,
    output wire        RTR_rec_0,
    output wire [3:0]  D_Len_rec_0,
    output wire [63:0] TOFILTERd_0,
    output wire [28:0] TOFILTERI_0,

    output wire [8:0]  TEC_0,
    output wire [8:0]  REC_0,


    // =========================
    // CANCORE_1 external signals
    // =========================

    input wire         SRST_1,

    input wire [4:0]   BRP_1,
    input wire [2:0]   Mode_1,

    input wire         TRANSMIT_1,
    input wire         IDE_TX_1,
    input wire         RTR_TX_1,
    input wire [3:0]   D_Len_TX_1,
    input wire [28:0]  ID_TX_1,
    input wire [63:0]  data_TX_1,

    output wire        done_RX_1,
    output wire        done_TX_1,

    output wire        IDE_rec_1,
    output wire        RTR_rec_1,
    output wire [3:0]  D_Len_rec_1,
    output wire [63:0] TOFILTERd_1,
    output wire [28:0] TOFILTERI_1,

    output wire [8:0]  TEC_1,
    output wire [8:0]  REC_1
);

    wire TX_0, TX_1;
    wire BUS;

    // ============================================================
    // CAN BUS
    // ============================================================

    assign BUS = TX_0 && TX_1;


    // ============================================================
    // CANCORE INSTANCE 0
    // ============================================================

    CANCORE CANCORE_0 (
        .CAN_CLK    (CAN_CLK),
        .CAN_RST    (CAN_RST),

        .RX         (BUS),
        .TX         (TX_0),

        .done_RX    (done_RX_0),
        .done_TX    (done_TX_0),

        .SRST       (SRST_0),

        // Fixed timing parameters
        .SJW        (3'd2),
        .TPROP      (4'd4),
        .TSEG1      (4'd4),
        .TSEG2      (4'd4),

        .BRP        (BRP_0),
        .Mode       (Mode_0),

        .TRANSMIT   (TRANSMIT_0),
        .IDE_TX     (IDE_TX_0),
        .RTR_TX     (RTR_TX_0),
        .D_Len_TX   (D_Len_TX_0),
        .ID_TX      (ID_TX_0),
        .data_TX    (data_TX_0),

        .IDE_rec    (IDE_rec_0),
        .RTR_rec    (RTR_rec_0),
        .D_Len_rec  (D_Len_rec_0),
        .TOFILTERd  (TOFILTERd_0),
        .TOFILTERI  (TOFILTERI_0),

        .TEC        (TEC_0),
        .REC        (REC_0)
    );


    // ============================================================
    // CANCORE INSTANCE 1
    // ============================================================

   (* keep_hierarchy = "yes" *) CANCORE CANCORE_1 (
        .CAN_CLK    (CAN_CLK),
        .CAN_RST    (CAN_RST),

        .RX         (BUS),
        .TX         (TX_1),

        .done_RX    (done_RX_1),
        .done_TX    (done_TX_1),

        .SRST       (SRST_1),

        // Fixed timing parameters
        .SJW        (3'd2),
        .TPROP      (4'd4),
        .TSEG1      (4'd4),
        .TSEG2      (4'd4),

        .BRP        (BRP_1),
        .Mode       (Mode_1),

        .TRANSMIT   (TRANSMIT_1),
        .IDE_TX     (IDE_TX_1),
        .RTR_TX     (RTR_TX_1),
        .D_Len_TX   (D_Len_TX_1),
        .ID_TX      (ID_TX_1),
        .data_TX    (data_TX_1),

        .IDE_rec    (IDE_rec_1),
        .RTR_rec    (RTR_rec_1),
        .D_Len_rec  (D_Len_rec_1),
        .TOFILTERd  (TOFILTERd_1),
        .TOFILTERI  (TOFILTERI_1),

        .TEC        (TEC_1),
        .REC        (REC_1)
    );

endmodule