transcript off
onbreak {quit -force}
onerror {quit -force}
transcript on

vlib work
vlib riviera/xpm
vlib riviera/xil_defaultlib

vmap xpm riviera/xpm
vmap xil_defaultlib riviera/xil_defaultlib

vlog -work xpm  -incr "+incdir+../../../../CANFPGA.gen/sources_1/bd/design_1/ipshared/a415" "+incdir+../../../../../../../../../../AMDDesignTools/2025.2/Vivado/data/rsb/busdef" "+incdir+../../../../CANFPGA.gen/sources_1/bd/design_1/ipshared/5431/hdl/verilog" "+incdir+../../../../CANFPGA.gen/sources_1/bd/design_1/ipshared/4e08/hdl/verilog" "+incdir+../../../../CANFPGA.gen/sources_1/bd/design_1/ipshared/0de9/hdl" -l xpm -l xil_defaultlib \
"C:/AMDDesignTools/2025.2/Vivado/data/ip/xpm/xpm_cdc/hdl/xpm_cdc.sv" \

vcom -work xpm -93  -incr \
"C:/AMDDesignTools/2025.2/Vivado/data/ip/xpm/xpm_VCOMP.vhd" \

vlog -work xil_defaultlib  -incr -v2k5 "+incdir+../../../../CANFPGA.gen/sources_1/bd/design_1/ipshared/a415" "+incdir+../../../../../../../../../../AMDDesignTools/2025.2/Vivado/data/rsb/busdef" "+incdir+../../../../CANFPGA.gen/sources_1/bd/design_1/ipshared/5431/hdl/verilog" "+incdir+../../../../CANFPGA.gen/sources_1/bd/design_1/ipshared/4e08/hdl/verilog" "+incdir+../../../../CANFPGA.gen/sources_1/bd/design_1/ipshared/0de9/hdl" -l xpm -l xil_defaultlib \
"../../../bd/design_1/ip/design_1_vio_0_0/sim/design_1_vio_0_0.v" \
"../../../bd/design_1/ip/design_1_clk_wiz_0_0/design_1_clk_wiz_0_0_clk_wiz.v" \
"../../../bd/design_1/ip/design_1_clk_wiz_0_0/design_1_clk_wiz_0_0.v" \
"../../../bd/design_1/ip/design_1_FPGAPROJECT_0_0/sim/design_1_FPGAPROJECT_0_0.v" \
"../../../bd/design_1/sim/design_1.v" \

vlog -work xil_defaultlib \
"glbl.v"

